---
name: "🚀 Feature Request"
about: Request a new feature to help us improve
title: ''
labels: 'enhancement'
assignees: ''

---

### What Problem Does This Solve? 

Please provide a concise description of the problem this request solves.



------



### Suggest a Solution (optional)

Please provide a concise description of your suggested solution. If there are multiple solutions, describe them independently and optionally follow them with a comparison.



------

