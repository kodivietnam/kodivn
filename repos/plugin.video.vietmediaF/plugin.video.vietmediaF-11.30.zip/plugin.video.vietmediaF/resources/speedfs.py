import requests #line:1
import xbmcgui ,xbmc ,xbmcvfs #line:2
import os ,sys ,time ,json ,random ,base64 #line:3
from resources import fshare #line:4
from addon import alert ,notify ,TextBoxes ,ADDON ,ADDON_ID ,ADDON_PROFILE ,LOG ,PROFILE #line:5
USERDATA =os .path .join (xbmcvfs .translatePath ('special://home/'),'userdata')#line:6
path =xbmcvfs .translatePath (USERDATA +"/test.zip")#line:7

def sppedfs ():#line:12
    fshare .check_session ()#line:8
    session_id =ADDON .getSetting ('sessionfshare')#line:9
    token =ADDON .getSetting ('tokenfshare')#line:10
    O0OOOO0000OOO00O0 =base64 .b64decode ('aHR0cHM6Ly93d3cuZnNoYXJlLnZuL2ZvbGRlci8yOVZDVFZMMjdLWFQ=').decode ('utf-8')#line:15
    OOO0000O00O0O00O0 ='kodivietmediaf-K58W6U'#line:14
    O0O0OOO00O00OO000 ={'User-Agent':OOO0000O00O0O00O0 ,'Cookie':'session_id=%s'%session_id }#line:19
    O0OO0O0OOO0OOO00O =0 #line:20
    OOOO000O00OOO00O0 ={'token':token ,'url':O0OOOO0000OOO00O0 ,'dirOnly':0 ,'pageIndex':O0OO0O0OOO0OOO00O ,'limit':60 ,}#line:21
    OOO0O0OO0O0OO0OO0 ="https://api.fshare.vn/api/fileops/getFolderList"#line:22
    O00000O0OO0OOO00O =requests .post (OOO0O0OO0O0OO0OO0 ,headers =O0O0OOO00O00OO000 ,json =OOOO000O00OOO00O0 )#line:24
    if O00000O0OO0OOO00O :#line:26
        O000OOO0OOO0000O0 =(O00000O0OO0OOO00O .content ).decode ("utf-8")#line:27
        OOO00O0O0O00OOO0O =[]#line:28
        O000OOO0OOO0000O0 =json .loads (O000OOO0OOO0000O0 )#line:29
        for OOO000OO000OO0OO0 in O000OOO0OOO0000O0 :#line:30
            OOOO0OOO0000OOOO0 =OOO000OO000OO0OO0 ['furl']#line:31
            OOO00O0O0O00OOO0O +=[OOOO0OOO0000OOOO0 ]#line:32
        OOOOOO00OO0OO000O = (random .choice (OOO00O0O0O00OOO0O ))#line:33
    OOOOOO00OO0OO000O =fshare .get_download_link (token ,session_id ,OOOOOO00OO0OO000O )#line:38
    OO0OO000O00O0O0OO =requests .head (OOOOOO00OO0OO000O )#line:39
    OOOO000O0O00OO000 =int (OO0OO000O00O0O0OO .headers .get ("Content-Length",0 ))#line:40
    if xbmcvfs .exists (path ):#line:41
        os .remove (path )#line:42
    O00O000O0O0OOO0O0 =xbmcgui .DialogProgress ()#line:43
    O00O000O0O0OOO0O0 .create ("Đo tốc độ Fshare...","")#line:44
    def OO000O0OOO0OO0O0O ():#line:45
        O0OOO0OOO00OO0OO0 =time .time ()#line:46
        OO0O00O0O0O000OOO =0 #line:47
        OOOO0OOO0000O000O =8192 #line:48
        O0000OO0OO000OO0O =[]#line:49
        with requests .get (OOOOOO00OO0OO000O ,stream =True )as O0O00O00000O0000O :#line:50
            O0O00O00000O0000O .raise_for_status ()#line:51
            with open (path ,"wb")as O00OOOOO000O0O00O :#line:52
                for OOOOO0O0OOOO0OOO0 in O0O00O00000O0000O .iter_content (chunk_size =OOOO0OOO0000O000O ):#line:53
                    if OOOOO0O0OOOO0OOO0 :#line:54
                        O00OOOOO000O0O00O .write (OOOOO0O0OOOO0OOO0 )#line:55
                        OO0O00O0O0O000OOO +=len (OOOOO0O0OOOO0OOO0 )#line:56
                        OO0000O0O00OOO0O0 =int (OO0O00O0O0O000OOO /OOOO000O0O00OO000 *100 )#line:57
                        O0O00O0OOO00OOOO0 =OO0O00O0O0O000OOO /(time .time ()-O0OOO0OOO00OO0OO0 )#line:58
                        O00O0O00OOO0OO00O =(OOOO000O0O00OO000 -OO0O00O0O0O000OOO )/O0O00O0OOO00OOOO0 if O0O00O0OOO00OOOO0 >0 else 0 #line:59
                        O00O000O0O0OOO0O0 .update (OO0000O0O00OOO0O0 ,"Tốc độ hiện tại đến Fshare: [COLOR yellow]{:.2f} MB/s[/COLOR]\n{}%  quá trình kiểm tra\nThời gian còn lại: {}".format (O0O00O0OOO00OOOO0 /1024 /1024 ,OO0000O0O00OOO0O0 ,time .strftime ('%H:%M:%S',time .gmtime (O00O0O00OOO0OO00O ))))#line:60
                        if O00O000O0O0OOO0O0 .iscanceled ():#line:62
                            xbmcgui .Dialog ().ok ("Thông báo","Huỷ đo tốc độ thành công")#line:63
                            os .remove (path )#line:64
                            return #line:65
        O00O000O0O0OOO0O0 .close ()#line:67
        O0O00OOO00O000O0O =time .time ()#line:68
        OO0000OOOOOO0O00O =O0O00OOO00O000O0O -O0OOO0OOO00OO0OO0 #line:69
        O0O0OO00000O0O0OO =OO0O00O0O0O000OOO /OO0000OOOOOO0O00O #line:70
        O0000000O00OO0OOO =round ((O0O0OO00000O0O0OO /1024 /1024 )*8 ,2 )#line:71
        O00O00OOOOOO0O0OO (O0000000O00OO0OOO )#line:72
    def O00O00OOOOOO0O0OO (OO0OOO0O0O00OO00O ):#line:73
        OO00000O0OO00O00O =xbmcgui .Dialog ()#line:74
        OO0OOOOOO00O0O000 ="SD (360p)"#line:75
        if OO0OOO0O0O00OO00O >=100 :#line:76
            OO0OOOOOO00O0O000 ="ISO 8K UHD"#line:77
        elif OO0OOO0O0O00OO00O >=50 :#line:78
            OO0OOOOOO00O0O000 ="Video 4K UHD"#line:79
        elif OO0OOO0O0O00OO00O >=35 :#line:80
            OO0OOOOOO00O0O000 ="Bluray 4K"#line:81
        elif OO0OOO0O0O00OO00O >=25 :#line:82
            OO0OOOOOO00O0O000 ="Bluray 1080p"#line:83
        elif OO0OOO0O0O00OO00O >=20 :#line:84
            OO0OOOOOO00O0O000 ="Video 1440p QHD"#line:85
        elif OO0OOO0O0O00OO00O >=10 :#line:86
            OO0OOOOOO00O0O000 ="Video 1080p FHD"#line:87
        elif OO0OOO0O0O00OO00O >=5 :#line:88
            OO0OOOOOO00O0O000 ="Video 720p HD"#line:89
        elif OO0OOO0O0O00OO00O >=3 :#line:90
            OO0OOOOOO00O0O000 ="480p SD"#line:91
        elif OO0OOO0O0O00OO00O >=1.5 :#line:92
            OO0OOOOOO00O0O000 ="360p SD"#line:93
        OO00000O0OO00O00O .ok ("Đề xuất chất lượng video",f"Chất lượng video phù hợp với tốc độ [COLOR yellow]{OO0OOO0O0O00OO00O} Mbps[/COLOR] của bạn là: [COLOR yellow]{OO0OOOOOO00O0O000}[/COLOR]\n[I]Đây chỉ là kết quả tham khảo, ngoài ra còn phụ thuộc vào bitrate của video.[/I]")#line:94
    OO000O0OOO0OO0O0O ()#line:95
