import xbmc, xbmcaddon
if xbmcaddon.Addon().getSetting('on_off') == 'true':
    xbmc.executebuiltin('RunAddon(plugin.video.vietmediaF)')
    xbmc.executebuiltin('RunPlugin(plugin://plugin.video.vietmediaF/?action=account_fshare)')