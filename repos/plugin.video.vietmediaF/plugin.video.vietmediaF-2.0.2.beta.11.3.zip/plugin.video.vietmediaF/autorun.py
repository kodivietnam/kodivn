import xbmc,time

def autorun():
    xbmc.executebuiltin("RunAddon(plugin.video.vietmediaF)")
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.vietmediaF/?action=account_fshare)")

autorun()







