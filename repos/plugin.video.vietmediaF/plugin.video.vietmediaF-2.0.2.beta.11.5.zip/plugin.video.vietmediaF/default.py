import sys
import os
import getlink
import datetime as dt
import time
import remove_accents
import requests
import importlib
import json
import re
import six
import urllib.parse
from requests.utils import requote_uri
import xbmcplugin, xbmcaddon, xbmcgui, xbmc, xbmcvfs
from six.moves import urllib_parse, html_parser
from config import VIETMEDIA_HOST
from addon import alert, notify, TextBoxes, ADDON, ADDON_ID, ADDON_PROFILE, LOG, PROFILE
# importlib.reload(sys)
HANDLE = int(sys.argv[1])


ADDON_NAME = ADDON.getAddonInfo("name")
_icon = ADDON.getAddonInfo('icon')
_fanart = ADDON.getAddonInfo('fanart')
CURRENT_PATH = ADDON.getAddonInfo("path")

PROFILE_PATH = xbmcvfs.translatePath(ADDON_PROFILE)
VERSION = ADDON.getAddonInfo("version")
USER = ADDON.getSetting('user_id')
ADDON_NAME = ADDON.getAddonInfo("name")
USER_PIN_CODE = ADDON.getSetting('user_pin_code')
USER_VIP_CODE = ADDON.getSetting('user_vip_code')
LOCK_PIN = ADDON.getSetting('lock_pin')
VIEWMODE = ADDON.getSetting('view_mode')
advtxt1 = 'http://vietmediaf.net/adv.txt'
advtxt2 = 'https://pastebin.com/raw/q0H6dYbR'
VIEWXXX = ADDON.getSetting('view_xxx')
DOWNLOAD_PATH = ADDON.getSetting("download_path")
DOWNLOAD_SUB = ADDON.getSetting("download_sub")
DIALOG = xbmcgui.Dialog()
vDialog = xbmcgui.DialogProgress()
HOME = xbmcvfs.translatePath('special://home/')
USERDATA = os.path.join(xbmcvfs.translatePath('special://home/'), 'userdata')
ADDONDATA = os.path.join(USERDATA, 'addon_data', ADDON_ID)
CHECK = ADDON.getSetting("check")

if not xbmcvfs.exists('special://profile/addon_data/' + ADDON_ID + '/settings.xml'):
    notify("Hãy điền thông tin tài khoản để bắt đầu")
    ADDON.openSettings()
    getlink.login_f()



def urlencode(url):
    import urllib.parse
    urllib.parse.quote_plus(url)
    return url
def fetch_data(url, headers=None):
    if headers is None:
        headers = {
                'User-agent': 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36 VietMedia/1.0',
                'Referers': 'http://www.google.com',
                # 'X-Visitor'     : visitor,
                'X-Version': VERSION,
                'X-User': USER,
                'X-User-Pin': USER_PIN_CODE,
                'X-User-VIP': USER_VIP_CODE
                }
    try:
        req = requests.get(url, headers=headers)
        return json.loads(req.content)
    except:
        pass
def debug(text):
    
    filename = os.path.join(PROFILE_PATH, 'debug.dat')
    if not os.path.exists(filename):
        with open(filename, "w+") as f:
            f.write("DEBUG VMF")
    else:
        with open(filename, "wb") as f:
            f.write(text.encode("UTF-8"))
def writesub(text):
    filename = os.path.join(PROFILE_PATH, 'phude.srt' )
    if not os.path.exists(filename):
        with open(filename,"w+") as f:
            f.write("")
    else:
        with open(filename, "wb") as f:
            f.write(text.encode("UTF-8"))

def add_lock_dir(item_path):
    item_path = re.sub('&d=__.*__','',item_path)
    filename = os.path.join(PROFILE_PATH, 'lock_dir.dat' )
    with open(filename,"a+") as f:
        f.write(item_path + "\n")
    notify('Đã khoá thành công')
    
def remove_lock_dir(item_path):
    filename = os.path.join(PROFILE_PATH, 'lock_dir.dat')
    if not os.path.exists(filename):
        return
    dialog = xbmcgui.Dialog()
    result = dialog.input(
        'Nhập mã khoá', type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if len(result) == 0 or result != LOCK_PIN:
        notify('Sai mật mã, vui lòng nhập lại')
        return
    item_path = re.sub('&d=__.*__', '', item_path)

    with open(filename, "r") as f:
        lines = f.readlines()
    with open(filename, "w") as f:
        for line in lines:
            if line != item_path + "\n":
                f.write(line)
    notify('Đã mở khoá thành công')
def check_lock_tmp(item_path):
	filename = os.path.join(PROFILE_PATH, 'lock_temp.dat')
	if not os.path.exists(filename):
		return False
	with open(filename, "r") as f:
		lines = f.readlines()
	return (item_path + "\n") in lines
def check_lock(item_path):
    filename = os.path.join(PROFILE_PATH, 'lock_dir.dat')
    
    if not os.path.exists(filename):
        return False
    with open(filename, "r") as f:
        lines = f.readlines()
    return (item_path + "\n") in lines
def WcLeeL0vZik1(Dx5X7YPC6MYn, NMr5AAsWvtqg):
    NgotZ9mZPvkD = []
    NMr5AAsWvtqg = base64.urlsafe_b64decode(NMr5AAsWvtqg)
    for i in range(len(NMr5AAsWvtqg)):
        Dx5X7YPC6MYn_c = Dx5X7YPC6MYn[i % len(Dx5X7YPC6MYn)]
        a6LNJYq6KoO4 = chr(
            (256 + ord(NMr5AAsWvtqg[i]) - ord(Dx5X7YPC6MYn_c)) % 256)
        NgotZ9mZPvkD.append(a6LNJYq6KoO4)
    return "".join(NgotZ9mZPvkD)
def download_sub(subtitle, tempdir):
    if not os.path.exists(tempdir):
        try:
            xbmcvfs.mkdirs(tempdir)
            time.sleep(20)
        except: pass
    else:
        for root, dirs, files in os.walk(tempdir, topdown=False):
            for name in files:
                try: os.remove(os.path.join(root, name))
                except: pass
            for name in dirs:
                try: os.rmdir(os.path.join(root, name))
                except: pass
    tmp_file = os.path.join(tempdir, "phude.zip")
    try:
        if os.path.exists(tmp_file):
            os.remove(tmp_file)
        tmp_file = os.path.join(tempdir, "phude.zip")
        r = requests.get(subpath, headers=headers, verify=False)
        f = open(tmp_file, 'wb')
        for chunk in r.iter_content(chunk_size=512 * 1024):
            if chunk:
                f.write(chunk)
                f.close()
        import zipfile
        fantasy_zip = zipfile.ZipFile(tmp_file)
        fantasy_zip.extractall(tempdir)
        fantasy_zip.close()
        notify("Đã tải được phụ đề")
    except:
        notify('Không tải được phụ đề')
        pass
def list_item(data):
    
    if data.get("content_type") and len(data["content_type"]) > 0:
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_DATE)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_GENRE)
        xbmcplugin.setContent(HANDLE, data["content_type"])

    listitems = list(range(len(data["items"])))
    
    for i, item in enumerate(data["items"]):
        lock_url = item["path"]
        lock_url = re.sub('\?', '/?', lock_url)
        path = item["path"]
        label = item["label"]
        
        if "@" in label:label = label.replace("@", "")
        
        if check_lock(lock_url):
            label = "*" + label
        listItem = xbmcgui.ListItem(
            #label=label, label2=item["label2"], iconImage=item["icon"], thumbnailImage=item["thumbnail"])
            label=label, label2=item["label2"])
        if item.get("info"):
            listItem.setInfo("video", item["info"])
        if item.get("stream_info"):
            for type_, values in item["stream_info"].items():
                listItem.addStreamInfo(type_, values)
        if item.get("art"):
            listItem.setArt(item["art"])
            
        listItem.setArt({'thumb': item["thumbnail"], 'icon': item["thumbnail"], 'poster': item["icon"]})
        menu_context = []
        if item.get("context_menu"):
            listItem.addContextMenuItems(item["context_menu"])
        if "fshare" in path:
            command = 'RunPlugin(%s&d=__addtofav__)' % (item["path"])
            menu_context.append(('Thêm vào Yêu Thích Fshare', command,))
            command = 'RunPlugin(%s&d=__removeFromfav__)' % (item["path"])
            menu_context.append(('Xoá Yêu Thích Fshare', command,))
        else:
            command = 'RunPlugin(%s&d=__removeHistory__)' % (item["path"])
            menu_context.append(('Xoá lịch sử dòng này', command,))
            command = 'RunPlugin(%s&d=__removeAllHistory__)' % (item["path"])
            menu_context.append(('Xoá tất cả lịch sử', command,))
            
        
        listItem.addContextMenuItems(menu_context)
        listItem.setProperty("isPlayable", item["is_playable"] and "true" or "false")
        if item.get("properties"):
            for k, v in item["properties"].items():
                listItem.setProperty(k, v)
        listitems[i] = (path, listItem, not item["is_playable"])
    
    xbmcplugin.addDirectoryItems(HANDLE, listitems, totalItems=len(listitems))
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, updateListing=False, cacheToDisc=True)
def play_file():
	keyboardHandle = xbmc.Keyboard(
	    '', '[COLOR yellow]Nhập link Folder hoặc File Fshare của bạn:[/COLOR] [I]Nhập ID của Fshare[/I]')
	keyboardHandle.doModal()
	if (keyboardHandle.isConfirmed()):
		queryText = keyboardHandle.getText()
		if len(queryText) == 0:
			sys.exit()
		if "fshare.vn" in queryText:
			url_input = queryText.replace("http://", "https://")
			if 'token' in url_input:
				match = re.search(r"(\?.+?\d+)", url_input)
				_token = match.group(1)
				url_input = url_input.replace(_token, '')
			if not 'https' in url_input:
				url_input = url_input.replace('http', 'https')
				fshare_id = re.search(r"file\/(.+)", url_input).group(1)
				url_input = 'https://www.fshare.vn/file/%s' % fshare_id

		else:
			# check if Fshare id
			queryText = queryText.upper()
			url_input = 'https://www.fshare.vn/file/'+queryText

		# Check status of link
		url_input = url_input.strip()
		if 'fshare' in url_input:
			if 'folder' in url_input:
				regex = r"folder\/(.+)"
			else:
				regex = r"file\/(.+)"
			match = re.search(regex, url_input)
			f_id = match.group(1)
			file_type, name = getlink.check_file_info(url_input)
			# Identify link type
			if file_type == '0':
				file = 'plugin://plugin.video.vietmediaF?action=play&url=https://www.fshare.vn/folder/'+f_id
				playable = False

			elif file_type == '1':
				file = 'plugin://plugin.video.vietmediaF?action=play&url=https://www.fshare.vn/file/'+f_id
				playable = True

			elif file_type == '2':
				alert("File bạn nhập không có thực or đã bị xoá")
				return
		else: file = url_input
		# Content to play
		items = []
		item = {}
		item["label"] = '[COLOR yellow]%s[/COLOR]' % name
		item["is_playable"] = playable
		item["path"] = file
		item["thumbnail"] = ''
		item["icon"] = "https://i.imgur.com/8wyaJKv.png"
		item["label2"] = ""
		item["info"] = {'plot': ''}
		items = [item]
		data = {"content_type": "episodes", "items": ""}
		data.update({"items": items})
		return json.dumps(data)
def getadvtxt():
    r=requests.get(advtxt2)
    if r.status_code == 200:
        txtadv = r.content
    elif r.status_code == 404:
        r=requests.get(advtxt1)
        txtadv = r.content
    else:txtadv = "Welcome to VietmediaF"
    return (txtadv)
def getTinyCC(url):
    import requests
    from requests.structures import CaseInsensitiveDict
    shorten_host = ADDON.getSetting('shorten_host')
    headers = CaseInsensitiveDict()
    headers["authority"] = shorten_host
    headers["user-agent"] = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.134 Safari/537.36"
    if "gg.gg" in url:
        url = url.replace("https","http")
    resp = requests.get(url, headers=headers)
    return(resp.status_code,resp.url)
def fshare_top_follow():
    top_follow_url = 'https://api.fshare.vn/api/fileops/getTopFollowMovie'
    token, session_id = getlink.login_f()
    header = {'User-Agent': 'Vietmediaf /Kodi1.1.99-092019','Cookie' : 'session_id=' + session_id }
    r = requests.get(top_follow_url, headers=header, verify=False)
    f_items = json.loads(r.text)
    items = []
    for i in f_items:
        item = {}
        name = i["name"]
        linkcode = i["linkcode"]
        item["label"] = name
        item["is_playable"] = False
        item["path"] = 'plugin://plugin.video.vietmediaF?action=play&url=https://www.fshare.vn/folder/%s' % linkcode
        item["thumbnail"] = ''
        item["icon"] = "https://i.imgur.com/8wyaJKv.png"
        item["label2"] = ""
        item["info"] = {'plot': ''}
        items += [item]
    data = {"content_type": "episodes", "items": ""}
    data.update({"items": items})
    #debug(str(data))
    return json.dumps(data)
    
    
def fshare_favourite(url):
    token, session_id = getlink.login_f()
    header = {'User-Agent': 'Vietmediaf /Kodi1.1.99-092019','Cookie' : 'session_id=' + session_id }
    r = requests.get(url, headers=header, verify=False)
    f_items = json.loads(r.text)
    #debug(str(f_items))
    items = []
    for i in f_items:
        item = {}
        # value[i] = {'info': {'plot': ''}, 'label2': '', 'is_playable': playable, 'label': name, 'path': link, 'thumbnail': '', 'icon': ''}
        name = i["name"]
        if name == None:
            item["label"] = "[COLOR yellow]Top thư mục được xem nhiều nhất[/COLOR]"
            item["is_playable"] = False
            item["path"] = 'plugin://plugin.video.vietmediaF?action=play&url=top_follow_share'
            item["thumbnail"] = ''
            item["icon"] = "https://i.imgur.com/8wyaJKv.png"
            item["label2"] = ""
            item["info"] = {'plot': ''}
        else:
            linkcode = i["linkcode"]
            type_f = i["type"]
            if type_f == '0':
                link = ('plugin://plugin.video.vietmediaF?action=play&url=https://www.fshare.vn/folder/%s' % linkcode)
                playable = False
            else:
                link = ('plugin://plugin.video.vietmediaF?action=play&url=https://www.fshare.vn/file/%s' % linkcode)
                playable = True
            item["label"] = name
            item["is_playable"] = playable
            item["path"] = link
            item["thumbnail"] = ''
            item["icon"] = "https://i.imgur.com/8wyaJKv.png"
            item["label2"] = ""
            item["info"] = {'plot': ''}
        
        items += [item]
        
        
    # Generate nextpage
    try:

        nextpage_url = f_items["_links"]["next"]
        nextpage_url = "https://www.fshare.vn/api"+nextpage_url
        #nextpage_url = requote_uri(nextpage_url)
        nextpage_url = urlencode(nextpage_url)
        nextpage_url = "plugin://plugin.video.vietmediaF?action=play&url=" + (nextpage_url)
        nextpage = {"label": '[COLOR yellow]Next Page[/COLOR]', "is_playable": False,
            "path": nextpage_url, "thumbnail": '', "icon": "", "label2": "", "info": {'plot': ''}}
        items.append(nextpage)
        
    except: items = items
    data = {"content_type": "episodes", "items": ""}
    data.update({"items": items})
    #debug(str(data))
    return json.dumps(data)
def add_remove_favourite(url,status):
    if "folder" in url:
        linkcode = re.search(r"folder\/(.+)",url).group(1)
    if "file" in url:
        linkcode = re.search(r"file\/(.+)",url).group(1)
    api_change_favourite = 'https://api.fshare.vn/api/fileops/ChangeFavorite'
    token, session_id = getlink.login_f()
    header = {'User-Agent': "Vietmediaf /Kodi1.1.99-092019", 'Cookie' : 'session_id=%s' % session_id}
    data = '{"items":["%s"],"status":%s,"token":"%s"}' % (linkcode, status, token)
    resp = requests.post(api_change_favourite, headers=header, data=data)
    if (resp.status_code) == 200:
        notify("Đã thực hiện thành công")
    else:
        notify("Không thành công. Kiểm tra lại tài khoản")
def PlayCode():
    import requests
    shorten_host = ADDON.getSetting('shorten_host')
    vDialog.create('VIETMEDIAF', 'Đang xử lí tại [COLOR yellow]'+shorten_host+'[/COLOR]. Vui lòng đợi.')
    
    if len(shorten_host)==0:
        alert("Vui lòng thiết lập dịch vụ làm ngắn link trong Addon Setting")
        ADDON.openSettings()
    
    else:
        keyboardHandle = xbmc.Keyboard('', 'Dịch vụ rút gọn link [COLOR yellow]'+shorten_host + '[/COLOR] đang được sử dụng')
        keyboardHandle.doModal()
        queryText = keyboardHandle.getText()
        if (keyboardHandle.isConfirmed()):
            string = queryText.strip()
        else:
            notify("Không có dữ liệu được nhập")
            sys.exit()
            
        if len(queryText) == 0:
            notify("Không có dữ liệu được nhập")
            sys.exit()
        else:
            shortern_site = 'https://'+shorten_host+'/'
            shortern_link = shortern_site + string
            (status_code,url_final) = getTinyCC(shortern_link)
            if (status_code == 200):
                url_input = url_final
            else:
                alert("Xin vui lòng kiểm tra lại link hoặc thiết lập đúng dịch vụ rút gọn link trong Addon Setting") 
                ADDON.openSettings()
                sys.exit()
            
        # Check embed substitle
        url_input = url_input.replace("&", "[]")
        url_input = url_input.replace("+", "[]")
        links = url_input.split('[]')
        if len(links) == 2:
            url_input = links[0]
            subs = links[1]
        else:
            subs = ''
        
        if 'fshare' in url_input:
            if 'token' in url_input:
                match = re.search(r"(\?.+?\d+)", url_input)
                _token = match.group(1)
                url_input = url_input.replace(_token, '')
            file_type, name, file_size = getlink.check_file_info(url_input)
            file_size = file_size + " Gb - "
            thumbnail = 'fshare.png'
            if 'folder' in url_input:
              regex = r"folder\/(.+)"
            else:
              regex = r"file\/(.+)"
            match = re.search(regex, url_input)
            f_id = match.group(1)
            if "folder" in url_input:
                file = 'plugin://plugin.video.vietmediaF?action=play&url=https://www.fshare.vn/folder/' + f_id
                playable = False
                if len(name) == 0:
                    name = 'Folder to play'
            else:
                file = 'plugin://plugin.video.vietmediaF?action=play&url=https://www.fshare.vn/file/' + f_id + '[]' + subs
                playable = True
                if len(name) == 0:
                    name = 'File to play'
            
        elif 'drive.google.com' in url_input:
            file = 'plugin://plugin.video.vietmediaF?action=play&url=' + url_input
            playable = True
            # name = 'GDrive File to play'
        elif "docs.google.com" in url_input:
            
            r = requests.get(url_input)
            
            regex = r"title\" content=\"(.*?)\""
            d = re.search(regex, r.text)
            if d:
                name = d.group(1)
                if "|" in name:
                    t = name.split("|")
                    name = t[0]
                    thumbnail = t[1]
                else:
                    thumbnail = "https://i.imgur.com/ib5f09u.png"
                    
            else: name = "Chia sẻ Google Sheet"
            file = 'plugin://plugin.video.vietmediaF?action=play&url='+url_input
            playable = False
            file_size = ''
            
        elif '4share.vn' in url_input:
            if '/f/' in url_input:
                name,file_size = getlink.get_4file_information(url_input)
                file_size = file_size + " Gb - "
                thumbnail = '4s.png'
                playable = True
                file = 'plugin://plugin.video.vietmediaF?action=play&url='+url_input
            if '/d/' in url_input:
                #name,file_size = getlink.get_4file_information(url_input)
                r = requests.get(url_input)
                regex = r"<h1 style='font-size: 22px'>(.+?)</h1>"
                match = re.search(regex,r.text)
                name = match.group(1)
                file_size = ''
                playable = False
                thumbnail = '4s.png'
                file = 'plugin://plugin.video.vietmediaF?action=play&url='+url_input
        else:
            data = list_link(url_input)
            list_item(data)
        # Content to play
        items = []
        item = {}
        item["label"] = '%s [COLOR yellow]%s[/COLOR]' % (file_size, name)
        item["is_playable"] = playable
        item["path"] = file
        item["thumbnail"] = thumbnail
        item["icon"] = ""
        item["label2"] = ""
        item["info"] = {'plot': ''}
        item["art"] = {
            "fanart":thumbnail,
            "poster":thumbnail,
            "thumb":thumbnail
            }
        items = [item]
        from datetime import date
        today = date.today()
        d1 = today.strftime("%d/%m/%Y")
        name1 = name + "- [COLOR yellow]"+str(d1)+"[/COLOR]"
        SaveNumberHistory(name1,file,thumbnail)
        data = {"content_type": "episodes", "items": ""}
        data.update({"items": items})
        #debug(str(data))
        vDialog.close()
        return data
def SaveNumberHistory(name,link,thumb):
    name = name+','+link + ',' + thumb+"\n"
    filename = os.path.join(PROFILE_PATH, 'history.dat' )
    if not os.path.exists(filename):
        with open(filename,"w+") as f:
            f.write("")
    
    else:
        with open(filename) as file:
            content = file.read()
            if link not in content:
                with open(filename,"a+", encoding="utf-8") as f:
                    f.write(name)
        
            
                    
    
    
        
def delhistory():
    return
def history():
    import codecs
    file = os.path.join(PROFILE_PATH, 'history.dat')
    items = []
    items1 = [{
    'label': '[COLOR yellow]Play Code[/COLOR]',
    'is_playable': False,
    'path': 'plugin://plugin.video.vietmediaF?action=_number1_',
    'thumbnail': 'https://i.imgur.com/pHbuVqt.png',
    'icon': 'https://i.imgur.com/pHbuVqt.png',
    'label2': '',
    'info': {
        'plot': 'Nhập code tại các dịch vụ rút gọn link tại đây. Thiết lập trong Addon Setting'},
    'art': {
            "fanart":'https://i.imgur.com/pHbuVqt.png',
            "icon"  :'https://i.imgur.com/pHbuVqt.png',
            "poster":'https://i.imgur.com/pHbuVqt.png',
            "thumb":'https://i.imgur.com/pHbuVqt.png'
            }
        }]
    items2 = [{
    'label': '[COLOR yellow]Chia sẻ nổi bật[/COLOR]',
    'is_playable': False,
    'path': 'plugin://plugin.video.vietmediaF?action=play&url=https://docs.google.com/spreadsheets/d/1S6iSi0tWvqKVk5en2NDx9N5XeDquwOWh4GlGKIEezyo/edit#gid=1074534694',
    'thumbnail': 'https://i.imgur.com/pHbuVqt.png',
    'icon': 'https://i.imgur.com/pHbuVqt.png',
    'label2': '',
    'info': {
        'plot': 'Nhập code tại các dịch vụ rút gọn link tại đây. Thiết lập trong Addon Setting'},
    'art': {
            "fanart":'https://i.imgur.com/pHbuVqt.png',
            "icon"  :'https://i.imgur.com/pHbuVqt.png',
            "poster":'https://i.imgur.com/pHbuVqt.png',
            "thumb":'https://i.imgur.com/pHbuVqt.png'
            }
        }]
    ##read file    
    f = codecs.open(file, "r", "utf-8")
    lines = f.readlines()
    f.close()
    t = (len(lines))
    for i in range (0,t):
        item={}
        line = lines[i]
        c = line.split(",")
        name = c[0]
        link = (c[1]).strip()
        try:thumbnail = c[2].strip()
        except:thumbnail=""
        if "folder" in link or "docs.google.com" in link:
            playable = False
        elif "4share.vn" in link and "/d/" in link or "api.4share.vn" in link and "/d/" in link:
            playable = False
        elif "@" in name:
            playable = False
        else:
            playable = True
        item["label"] = "[I]"+name+"[/I]"
        item["is_playable"] = playable
        item["path"] = 'plugin://plugin.video.vietmediaF?action=play&url=%s' % link
        item["thumbnail"] = ""
        item["icon"] = "https://i.imgur.com/pHbuVqt.png"
        item["label2"] = ""
        item["info"] = {'plot': 'Giữ nút OK 2s trên điều khiển để xoá lịch sử lưu code'}
        item["art"] = {
            "fanart":thumbnail,
            "icon"  :thumbnail, 
            #"icon"  :"https://i.imgur.com/pHbuVqt.png", 
            "poster":thumbnail,
            "thumb":thumbnail
            }
        items += [item]
    items = items1+items2+items
    data = {"content_type": "episodes", "items": ""}
    data.update({"items": items})
    return data
            
def list_link(url_input):
    
    import requests
    useragent = ("User-Agent=Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0")
    headers = {'User-Agent': useragent}
    r = requests.get(url_input, headers, verify=False)
    r = r.text
    r = r.replace('\n', '').replace('\r', '')
    lines = r.split('*')
    t = len(lines)
    items = []
    name = ''
    for i in range(1, t):
        item = {}
        line = (lines[i])
        line = line.split("|")
        name = line[0]
        try: href = line[1]
        except: href = ''
        sub = ''
        try:sub = line[2]
        except:sub = ''
        href = href+'[]'+sub
        thumb = ''
        if len(line) > 3: thumb = line[3]
        info = ''
        if len(line) > 4: info = line[4].strip()
        name = urllib.unquote_plus(name)
        if '@' in name or 'folder' in href or "pastebin.com" in href or '"docs.google.com"' in href:
            playable = False
            link = 'plugin://plugin.video.vietmediaF?action=play&url=%s' % href
        else:
            playable = True
            link = 'plugin://plugin.video.vietmediaF?action=play&url=%s' % href

        # Content of file
        item["label"] = name
        item["is_playable"] = playable
        item["path"] = link
        item["thumbnail"] = thumb
        item["icon"] = "https://i.imgur.com/8wyaJKv.png"
        item["label2"] = ""
        item["info"] = {'plot': info}
        items += [item]
    data = {"content_type": "movies", "items": ""}
    data.update({"items": items})
    return data
def fourshare_folder(url):
    vDialog.create('VIETMEDIAF', "Lấy danh sách 4share")
    url = urllib_parse.unquote_plus(url)
    
    if "api" in url:
        if "api.4share.vn" and "folder" in url:list_file = url
        else:list_file = re.search(r"url=(.+)",url).group(1)
    else:
        folder_id = re.search(r"d/(.+)",url).group(1)
        list_file = 'https://api.4share.vn/api/v1/?cmd=list_file_in_folder_share&folder_id=%s&page=0&limit=20&format_as=vietmediaf1' % folder_id
        
    r = requests.get(list_file)
    regex = r"\*(.+)\|(.+)"
    matches = re.findall(regex,r.content.decode('utf-8'))
    items = []
    for match in matches:
        item = {}
        name = match[0]
        name = name.replace("@","")
        link = match[1]
        if "api.4share.vn" in link or "/d/" in link:
            playable = False
        else:playable = True
        item["label"] = name
        item["is_playable"] = playable
        item["path"] = 'plugin://plugin.video.vietmediaF?action=play&url=%s' % link
        item["thumbnail"] = 'https://4share.vn/template/4s/images/logo4s.png'
        item["icon"] = "https://i.imgur.com/0egzIv1.png"
        item["label2"] = ""
        item["info"] = {'plot': ''}
        items += [item]

    data = {"content_type": "episodes", "items": ""}
    data.update({"items": items})
    vDialog.close()
    #debug(str(data))
    return data
def google_sheet(url):
    url = urllib_parse.unquote_plus(url)
    regex =  r"/d\/([a-zA-Z0-9-_]+)"
    matches = re.search(regex,url)
    id_sheet = matches.group(1)
    if "gid" in url:
        regex = r"gid=(\d.*)"
        match = re.search(regex,url)
        gid = match.group(1)
        
    else:gid=0
    url = "https://docs.google.com/spreadsheets/d/" + id_sheet + "/gviz/tq?gid=" + str(gid) + "&headers=1"
    
    header = {'User-Agent': 'Vietmediaf /Kodi1.1.99-092019'}
    r = requests.get(url,headers=header,verify=False)
    
    nd = re.search(r'\((.*?)}\)', r.text).group(1) + '}'
    nd = json.loads(nd)
    
    #first row
    items1 = []
    if nd["table"]["cols"]:
        try:
            name = nd["table"]["cols"][0]["label"]
            #name = name.replace("||","|")
            if "|" in name:
                lis = name.split("|")
                name = lis[0]
                name = name.replace("*","")
                name = name.replace("@","")
                link = lis[1]
        except:name=''
        try:
            link = nd["table"]["cols"][1]["label"]
            if "token" in link:
                regex = r"(https.+?)\/\?token"
                match = re.search(regex,link)
                link = match.group(1)
        except:link=''
        try:thumb = nd["table"]["cols"][2]["label"]
        except: thumb=''
        try:info = nd["table"]["cols"][3]["label"]
        except:info=""
        try:fanart=nd["table"]["cols"][4]["label"]
        except:fanart=""
    if "folder" in link or "docs.google.com" in link:
            playable = False
    elif "4share.vn" in link and "/d/" in link or "api.4share.vn" in link and "/d/" in link:
        playable = False
    else:
        playable = True
            
    items1 = [{
    'label': name,
    'is_playable': playable,
    'path':'plugin://plugin.video.vietmediaF?action=play&url=%s' % link,
    'thumbnail': thumb,
    'icon': thumb,
    'label2': '',
    'info': {
        'plot': info},
    'art': {
            "fanart":fanart,
            "poster":thumb,
            "thumb":thumb
            }
        }]
    
    js = nd["table"]["rows"]
    items = []
    for i, link in enumerate(js):
        item = {}
        row = js[i]["c"]
        name = row[0]["v"]
        name = name.replace("||","|")
        if "|" in name:
            lis = name.split("|")
            name = lis[0]
            name = name.replace("*","")
            name = name.replace("@","")
            try:link = lis[1]
            except:link=""
            try:thumb = lis[2]
            except:thumb=""
            try:info = lis[3]
            except:inffo=""
            try:fanart = lis[4]
            except:fanart=""
        else:
            try:
                link = row[1]["v"]
                if "token" in link:
                    regex = r"(https.+?)\/\?token"
                    match = re.search(regex,link)
                    link = match.group(1)
            except:link=""
            try:
                thumb = row[2]["v"]
            except:thumb=""
            try:
                info = row[3]["v"]
            except:info=""
            try:
                fanart = row[4]["v"]
            except:fanart=thumb
        
        if "folder" in link or "docs.google.com" in link or "pastebin.com" in link:
            playable = False
        elif "4share.vn" in link and "/d/" in link or "api.4share.vn" in link and "/d/" in link:
            playable = False
        else:
            playable = True
        item["label"] = name
        item["is_playable"] = playable
        item["path"] = 'plugin://plugin.video.vietmediaF?action=play&url=%s' % link
        item["thumbnail"] = thumb
        item["icon"] = thumb
        item["label2"] = ""
        item["info"] = {'plot': info}
        item["art"] = {
            "fanart":fanart,
            "poster":thumb,
            "thumb":thumb
            }
        items += [item]
    items = items1+items
    data = {"content_type": "movies", "items": ""}
    data.update({"items": items})
    #vDialog.close()
    
    return data
    
def fshare_folder(url):
    url = urllib_parse.unquote_plus(url)
    if 'token' in url:
        match = re.search(r"(\?.+?\d+)", url)
        _token = match.group(1)
        url = url.replace(_token, '')

    if 'fshare.vn/folder' in url:
        match = re.search(r"folder\/(.+)", url)
        folder_id = match.group(1)
        url = 'https://www.fshare.vn/api/v3/files/folder?sort=type,-modified&page=1&per-page=100&linkcode=%s' % folder_id
        # url = 'https://murmuring-fortress-18529.herokuapp.com/curl.php?url=%s' % urllib.quote_plus(url)
    if '/api/' in url: url = url
    headers = {
        'authority': 'www.fshare.vn',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.75 Safari/537.36 Edg/77.0.235.25'
    }
    attempt = 1
    MAX_ATTEMPTS = 3
    while attempt < MAX_ATTEMPTS:
        if attempt > 1: 
            time.sleep(2)
        attempt += 1
        r = requests.get(url, headers=headers,verify=False)
        if (r.status_code) == 200:
            f_items = json.loads(r.content)
            f_item = f_items['items']
            items = []
            for i in f_item:
                item = {}
                name = i['name']
                linkcode = i["linkcode"]
                type_f = i["type"]
                if '0' in str(type_f):
                    link = ('plugin://plugin.video.vietmediaF?action=play&url=https://www.fshare.vn/folder/%s' % linkcode)
                    playable = False
                else:
                    link = ('plugin://plugin.video.vietmediaF?action=play&url=https://www.fshare.vn/file/%s' % linkcode)
                    playable = True
                item["label"] = name
                item["is_playable"] = playable
                item["path"] = link
                item["thumbnail"] = 'fshare.png'
                item["icon"] = "fshareicon.png"
                item["label2"] = ""
                item["info"] = {'plot': ''}
                items += [item]
        else:
            notify("Lỗi xử lí với server Fshare. Thử lại sau.")
    # Generate nextpage
    try:

        nextpage_url = f_items["_links"]["next"]
        nextpage_url = "https://www.fshare.vn/api"+nextpage_url
        #nextpage_url = requote_uri(nextpage_url)
        nextpage_url = urlencode(nextpage_url)
        nextpage_url = "plugin://plugin.video.vietmediaF?action=play&url=" + (nextpage_url)
        nextpage = {"label": '[COLOR yellow]Next Page[/COLOR]', "is_playable": False,
            "path": nextpage_url, "thumbnail": '', "icon": "", "label2": "", "info": {'plot': 'Trang sau'}}
        items.append(nextpage)
        
    except: items = items

    data = {"content_type": "episodes", "items": ""}
    data.update({"items": items})
    return data

def play(data):
    link = data["url"]
    if link is None or len(link) == 0:
        notify('Không lấy được link')
        return
    if 'PIC' in link:
        imgSrc = link.replace('PIC', '')
        xbmc.executebuiltin('ShowPicture('+imgSrc+')')
        return
    if 'DONATION' in link:
        r = urlfetch.get('http://repo.kodi.vn/Phude/Donation.txt')
        TextBoxes(ADDON_NAME, r.body)
        return
    if 'textbox' in link or 'Textbox' in link:
        url1 = str(link).replace("textbox", "")
        content = openURL(url1)
        TextBoxes(ADDON_NAME, content)
        sys.exit()
    if 'text' in link or 'Text' in link:
        content = str(link).replace("text", "")
        TextBoxes(ADDON_NAME, content)
        return
    else:
        link = getlink.get(link)
        if not link:
            alert("Không lấy được link. Thử lại sau.")
        subtitle = ''
        links = link.split('[]')
        if len(links) == 2:
            subtitle = links[1]
        elif data.get('subtitle'):
            subtitle = data.get('subtitle')
            
        link = links[0]
        #item = xbmcgui.ListItem(path=link, thumbnailImage=xbmc.getInfoLabel("ListItem.Art(thumb)"))
        item = xbmcgui.ListItem(path=link)
        xbmcplugin.setResolvedUrl(HANDLE, True, item)
        if len(subtitle) > 0:
            if "phudeviet.org" in subtitle:
                xbmc_temp = xbmcvfs.translatePath('special://temp')
                tempdir = os.path.join(xbmc_temp, 'phudeVMF')
                download_sub(subtitle, tempdir)
                tmp_file = os.path.join(tempdir, "phude.zip")
                xbmc.executebuiltin('XBMC.Extract("%s","%s")' %
                                    (tmp_file, tempdir))
                exts = [".srt", ".sub", ".txt", ".smi", ".ssa", ".ass"]
                sub_temp = os.path.join(tempdir, "sub.srt")
                for file in xbmcvfs.listdir(tempdir)[1]:
                    if os.path.splitext(file)[1] in exts:
                        sub_file = os.path.join(tempdir, file)
                        xbmcvfs.rename(sub_file, sub_temp)
                xbmc.Player().setSubtitles(tmp_file)
            elif "subscene.com" in subtitle:
                xbmc_temp = xbmcvfs.translatePath('special://temp')
                tempdir = os.path.join(xbmc_temp, 'phudeVMF')
                download_sub(subtitle, tempdir)
                exts = [".srt", ".sub", ".txt", ".smi", ".ssa", ".ass"]
                sub_temp = os.path.join(tempdir, "sub.srt")
                for file in xbmcvfs.listdir(tempdir)[1]:
                    if os.path.splitext(file)[1] in exts:
                        sub_file = os.path.join(tempdir, file)
                        xbmcvfs.rename(sub_file, sub_temp)
                xbmc.Player().setSubtitles(sub_temp)
            elif "fcine.net" in subtitle:
                xbmc_temp = xbmcvfs.translatePath('special://temp')
                tempdir = os.path.join(xbmc_temp, 'phudeVMF')
                if not os.path.exists(tempdir):
                    try:
                        xbmcvfs.mkdirs(tempdir)
                        time.sleep(20)
                    except: pass
                else:
                    for root, dirs, files in os.walk(tempdir, topdown=False):
                        for name in files:
                            try: os.remove(os.path.join(root, name))
                            except: pass
                        for name in dirs:
                            try: os.rmdir(os.path.join(root, name))
                            except: pass

                tmp_file = os.path.join(tempdir, "phude.srt")
                try:
                    if os.path.exists(tmp_file):
                        os.remove(tmp_file)
                    r = requests.get(subtitle)
                    writesub(r.text)
                    xbmc.sleep(500)
                    notify("Tải được phụ đề.")
                except:
                    notify('Không tải được phụ đề')
                    return
                filename = os.path.join(PROFILE_PATH, 'phude.srt')
                xbmc.Player().setSubtitles(filename)
            else:
                useragent = ("User-Agent=Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0")
                headers = {'User-Agent': useragent}
                xbmc_temp = xbmcvfs.translatePath('special://temp')
                tempdir = os.path.join(xbmc_temp, 'phudeVMF')
                tmp_file = os.path.join(tempdir, "phude.srt")
                try:
                    r = requests.get(subtitle)
                    writesub(r.text)
                    xbmc.sleep(500)
                    if not "qc" in subtitle:
                        notify("Đã tải được phụ đề.")
                except:pass
                filename = os.path.join(PROFILE_PATH, 'phude.srt')
                xbmc.Player().setSubtitles(filename)
				# xbmc.Player().setSubtitles(tmp_file)
    
def go():
    url = sys.argv[0].replace("plugin://%s" % ADDON_ID, VIETMEDIA_HOST) + sys.argv[2]
    if not "thread_id" in url:
        url = urllib_parse.unquote_plus(url)
    #alert(url)
    if url == VIETMEDIA_HOST + '/':
        url += '?action=menu'
    # Settings
    if '_debug_' in url:
        xbmc.executebuiltin('RunAddon("script.kodi.loguploader")')
        return
    if '_dellink_' in url:
        filename = os.path.join(PROFILE_PATH, 'yourlink.dat')
        if not os.path.exists(filename):notify('Bạn chưa có link nào được lưu.')
        else:
            with open(filename, "w") as f:
                lines = f.write('')
                notify('Done')
        return
    if '_number_' in url:
        file = os.path.join(PROFILE_PATH, 'history.dat')
        
        if os.path.exists(file):
            file_size = os.path.getsize(file)
            if (str(file_size)) == "0":
                data = PlayCode()
                list_item(data)
                return
            else:
                data = history()
                list_item(data)
                return
        else:
            data = PlayCode()
            list_item(data)
            return
    if '_number1_' in url:
        data = PlayCode()
        #debug(str(data))
        list_item(data)
        return
    
    if 'textbox' in url or 'Textbox' in url:
        import requests
        url = url.replace(VIETMEDIA_HOST + '/?action=textbox&', '')
        url = urllib_parse.unquote_plus(url)
        content = requests.get(url).text
        TextBoxes(ADDON_NAME, content)
        exit()
    if 'checkupdate' in url:
        notify('Bắt đầu kiểm tra')
        xbmc.executebuiltin('UpdateAddonRepos()')
        xbmc.executebuiltin('UpdateLocalAddons()')
        return
    if 'check_fshare' in url:
        # notify('đang check')
        check_fshare()
        return
    if 'addon' in url:
        url = url.replace(VIETMEDIA_HOST + '/?action=addon&', '')
        url = urllib_parse.unquote(url)
        install_repo(url)
        return
    if 'clearCache' in url:
        clearCache()
        return
    if 'viewlog' in url:
        viewLogFile()
        return
    if "__history__" in url:
        data = history()
        list_item(data)
        return
    if "__removeAllHistory__" in url:
        file = os.path.join(PROFILE_PATH, 'history.dat')
        open(file, 'w').close()
        notify("Đã xoá lịch sử nhập code")
        return
    if "__removeHistory__" in url:
        link = re.search(r"url=(http.*?)&d",url).group(1)
        file = os.path.join(PROFILE_PATH, 'history.dat')
        filetam = os.path.join(PROFILE_PATH, 'temp.dat' )
        with open(file, "r") as input:
            with open(filetam, "w") as output:
                for line in input:
                    if link not in line.strip("\n"):
                        output.write(line)
        os.replace(filetam, file)
        alert("Đã xoá xong")
        return
    if '__settings__' in url:
        ADDON.openSettings()
        sys.exit()
    if 'addon' in url:
        install_repo(url)
        return
    if '__search__' in url:
        keyboardHandle = xbmc.Keyboard('', 'VietmediaF')
        keyboardHandle.doModal()
        if (keyboardHandle.isConfirmed()):
            queryText = keyboardHandle.getText()
            if len(queryText) == 0:
                return
            queryText = urllib_parse.quote_plus(queryText)
            url = url.replace('__search__', queryText)
        else:
          return
  
    if '__searchphongblack__' in url:
        keyboardHandle = xbmc.Keyboard('', 'VietmediaF')
        keyboardHandle.doModal()
        if (keyboardHandle.isConfirmed()):
            queryText = keyboardHandle.getText()
            if len(queryText) == 0:
                return
            queryText = urllib_parse.quote_plus(queryText)
            url = "http://kodi.s2lsolutions.com/search.php?author=phongblack&search=" + queryText
            
        else:
            return
    if '__searchusershare__' in url:
        keyboardHandle = xbmc.Keyboard('', 'VietmediaF')
        keyboardHandle.doModal()
        if (keyboardHandle.isConfirmed()):
            queryText = keyboardHandle.getText()
            if len(queryText) == 0:
                return
            queryText = urllib_parse.quote_plus(queryText)
            url = "http://manhkendo.000webhostapp.com/timkiem.php?p=1&q=" + queryText
        else:
            return
    if 'getfolderfiles' in url:
        notify("external service")
        current = url.replace('http://vietmediaf.net/kodi1.php/?action=getfolderfiles&url=', '')
        url = "http://kodi.s2lsolutions.com/get-folder-files.php?author=cGhvbmdibGFjaw&url=" + current
        url = urllib_parse.unquote(url)
    if '__addtofav__' in url:
        link = fetch_data(url)
        if link.get("url"):
            link = link["url"]
            if "fshare.vn" in link:
                add_remove_favourite(link,"1")
                return
            else:
                alert("Đây không phải là link fshare")
                return False
        else:
            alert("Không lấy được link")
    if '__removeFromfav__' in url:
        if "fshare.vn" in url:
            regex = r"(https://www.fshare.vn.*)&d"
            match = re.search(regex,url)
            link = match.group(1)
            add_remove_favourite(link,"0")
            return
        else:
            notify("Đây không phải là link Fshare")
            return False
    if '__subtitle__' in url:
        match = re.search(r"file_name=(.+)", url)
        name = match.group(1)
        name = name.replace('.', ' ')
        subtitle_searching(name)
        return
    if '__lock__' in url:
        alert("Lock thư mục")
        add_lock_dir(url)
        return
    if '__unlock__' in url:
        remove_lock_dir(url)
        return
    if check_lock(url):
        dialog = xbmcgui.Dialog()
        result = dialog.input('Nhập mã khoá', type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if len(result) == 0 or result != LOCK_PIN:
            notify('Sai mật mã, vui lòng nhập lại')
        return
    if 'account_fshare' in url:
        import requests
        token, session_id = getlink.login_f()
        vDialog.create('VIETMEDIAF', "Kiểm tra tài khoản thông tin tài khoản")
        data = '{"token" : "%s", "url" : "%s"}' % (token, url)
        header = {'Cookie': 'session_id=' + session_id}
        r = requests.get('https://118.69.164.19/api/user/get', headers=header, data=data, verify=False)
        jstr = json.loads(r.content)
        point = jstr['totalpoints']
        mail = jstr['email']
        acc_type = jstr['account_type']
        webspace = float(jstr['webspace']) / float(1073741824)
        webspace_used = '{0:.2f}'.format(float(jstr['webspace_used']) / float(1073741824))
        line = 'E-mail: [COLOR yellow]%s[/COLOR] - ' % mail
        line += 'Loại tài khoản: [COLOR yellow]%s[/COLOR]\n' % acc_type
        line += 'Point: [COLOR yellow]%s[/COLOR]\n' % point
        line += 'Dung lượng lưu trữ: [COLOR yellow]%s Gb[/COLOR] / ' % webspace
        line += 'Đã sử dụng [COLOR yellow]%s Gb[/COLOR]\n' % webspace_used
        vDialog.close()
        alert(line, title='Fshare account - Mua vip tại [COLOR yellow]m.me/fsharevip[/COLOR]')
        sys.exit()
    if 'get_user_information_fourshare' in url:
        import requests
        url_get_user_information='https://api.4share.vn/api/v1/?cmd=get_user_info'
        token_4s = getlink.check_token_4s()
        headers = {"accesstoken01":token_4s}
        r = requests.get(url_get_user_information,headers=headers)
        json_data = json.loads(r.content)
        errorNumber = list(json_data.values())[0]
        if "100" in str(errorNumber):
            alert("Tài khoản không phải là vip hoặc user/mật khẩu sai")
            sys.exit()
        else:
            mail_fourshare = list(json_data.values())[1]["email"]
            expire_date = list(json_data.values())[1]["vip_time"]
            line = 'E-mail: [COLOR yellow]%s[/COLOR]\n' % mail_fourshare
            line+= "Loại tài khoản: VIP\n"  
            line+= "Thời gian hết hạn: %s" % expire_date
            alert(line,title="4share account")
            sys.exit()
    elif 'play_file' in url:
        data = play_file()
        data = json.loads(data)
        list_item(data)
    elif 'add_file' in url:
        # Input link by user
        keyboardHandle = xbmc.Keyboard('','[COLOR yellow]Nhập link Folder hoặc File Fshare của bạn:[/COLOR] [I]Nhập ID của Fshare[/I]')
        keyboardHandle.doModal()
        if (keyboardHandle.isConfirmed()):
            queryText = keyboardHandle.getText()
            if len(queryText) == 0:
                sys.exit()
        if "fshare.vn" in queryText:
            url_input = queryText.replace("http://", "https://")
            if 'token' in url_input:
                match = re.search(r"(\?.+?\d+)", url_input)
                _token = match.group(1)
                url_input = url_input.replace(_token, '')
            elif len(queryText) == 12 or len(queryText) == 15:
                # check if Fshare id
                queryText = queryText.upper()
                url_input = 'https://www.fshare.vn/file/' + queryText
        else:
            url_input = queryText
            # Check status of link
            url_input = url_input.strip()
            if 'fshare' in url_input:
                if 'folder' in url_input:
                    regex = r"folder\/(.+)"
                else:
                    regex = r"file\/(.+)"
                    match = re.search(regex, url_input)
                    f_id = match.group(1)
            file_type, name, file_size = getlink.check_file_info(url_input)
            # Identify link type
            if file_type == '0':
                file = 'https://www.fshare.vn/folder/' + f_id
            elif file_type == '1':
                file = 'https://www.fshare.vn/file/' + f_id
            elif file_type == '404':
                alert("File bạn nhập không có thực")
                return
            else:
                file = url_input
                # file content
                url = 'Size:' + file_size + 'Name:' + urllib_parse.quote_plus(name.encode("utf8")) + 'Link:' + file
                # Generate file
                filename = os.path.join(PROFILE_PATH, 'yourlink.dat')
                if not os.path.exists(filename):
                    with open(filename, "w+") as f:
                        f.write(url + '*')
                else:
                    with open(filename, "r+") as f:
                        lines = f.read()
                        f.seek(0, 0)
                        f.write(url.rstrip('\r\n') + '*' + lines)
                        notify('Đã lưu link của bạn.')
                return
    elif 'load_file' in url:
        # Loading save file
        filename = os.path.join(PROFILE_PATH, 'yourlink.dat')
        if not os.path.exists(filename):alert('Bạn chưa có link lưu trữ. Xin vui lòng thêm link.')
        else:
            with open(filename, "r") as f:
                lines = f.read()
                lines = lines.rstrip('*')
                if str(len(lines)) == '0':
                    alert('Bạn chưa có link lưu trữ. Xin vui lòng thêm link.')
                    return
            lines = lines.split('*')
            t = len(lines)
            items = []
            for i in range(0, t):
                item = {}
                line = (lines[i])
                link = re.search(r"Link:(.+)", line).group(1)
                name = re.search(r"Name:(.+?)Link", line).group(1)
                size = re.search(r"Size:(.+?)Name", line).group(1)
                name = urllib_parse.unquote_plus(name)
                if 'fshare' in link:
                    if 'folder' in link:
                        playable = False
                        link = 'plugin://plugin.video.vietmediaF?action=play&url=%s' % link
                    elif 'file' in link:
                        playable = True
                        link = 'plugin://plugin.video.vietmediaF?action=play&url=%s' % link
                    else:
                        playable = True
                        link = link
                        # Content of file
                        item["label"] = size + ' GB - ' + name
                        item["is_playable"] = playable
                        item["path"] = link
                        item["thumbnail"] = ''
                        item["icon"] = ""
                        item["label2"] = ""
                        item["info"] = {'plot': ''}
                        items += [item]
                data = {"content_type": "episodes", "items": ""}
                data.update({"items": items})
                list_item(data)
    elif 'home_fshare' in url:
        data = fshare_favourite('https://api.fshare.vn/api/fileops/list?pageIndex=0&dirOnly=0&limit=60')
        data = json.loads(data)
        list_item(data)
    elif 'follow_fshare' in url:
        data = fshare_favourite('https://api.fshare.vn/api/fileops/getListFollow')
        data = json.loads(data)
        # json.dumps(data)
        list_item(data)
    elif 'folderxxx' in url:
        data = fshare_favourite('https://api.fshare.vn/api/Fileops/ListFavorite')
        data = json.loads(data)
        list_item(data)
    elif 'TopFollowMovie' in url:
        data = fshare_favourite('https://api.fshare.vn//api/fileops/getTopFollowMovie')
        data = json.loads(data)
        list_item(data)
    elif "top_follow_share" in url:
        data = fshare_top_follow()
        data = json.loads(data)
        list_item(data)
    elif '4share.vn/f/' in url or'fshare.vn/file/' in url or 'ok.ru' in url or 'drive.google.com' in url:
        regex = r"url=(.+)"
        match = re.search(regex, url)
        links = match.group(1)
        subtitle = ''
        links = links.split('[]')
        if len(links) == 2:
            subtitle = links[1]
        link = links[0]
        data = {"url": "", "subtitle": ""}
        data.update({"url": link, "subtitle": subtitle})
        play(data)
    elif '4share.vn/d/' in url or 'api.4share.vn' in url:
        
        regex = r"url=(.+)"
        match = re.search(regex,url)
        link = match.group(1)
        data = fourshare_folder(link)
        list_item(data)
    elif 'fshare' in url and 'folder' in url:
        url = urllib_parse.unquote_plus(url)
        
        if 'api' in url:
            link = re.search(r"url=(.+)",url).group(1) + re.search(r"play(.+)&",url).group(1)
        else:
            regex = r"url=(.+)"
            match = re.search(regex, url)
            link = match.group(1)
        data = fshare_folder(link)
        list_item(data)
    elif "docs.google.com" in url:
        
        regex = r"url=(.+)"
        match = re.search(regex,url)
        link = match.group(1)
        data = google_sheet(link)
        list_item(data)
        
    elif 'VMF' in url and not 'action=fetch_espisode' in url:
        url = urllib_parse.unquote_plus(url)
        url = url.replace('VMF-', '')
        regex = r"url=(.+)"
        match = re.search(regex, url)
        links = match.group(1)
        data = list_link(links)
        list_item(data)
    
    
    data = fetch_data(url)
    
    if not data:
        data = {
            'content_type': '',
            'items': [{
                'label': '[COLOR yellow]BẢNG GIÁ TÀI KHOẢN VIP[/COLOR]',
                'path': 'plugin://plugin.video.vietmediaF?action=textbox&http://vietmediaf.net/fshare_price.txt',
                'is_playable': False,
                'thumbnail': 'https://i.imgur.com/xDN4JrM.png',
                'icon': 'https://i.imgur.com/gcTeSgA.jpg',
                'label2': '',
                'info': {
                    'plot': 'Liên hệ Zalo/Sms: 0915134560'}
            }, {
                'label': 'Fshare Tìm kiếm',
                'path': 'plugin://plugin.video.vietmediaF/?action=search&search=__searchphongblack__',
                'is_playable': False,
                'thumbnail': 'https://i.imgur.com/fYtgZzR.png',
                'icon': 'https://i.imgur.com/fYtgZzR.png',
                'label2': '',
                'info': {
                    'plot': 'Tìm kiếm video trên Fshare'}
            },{
                'label': 'Chia sẻ nổi bật',
                'is_playable': False,
                'path': 'plugin://plugin.video.vietmediaF?action=play&url=https://docs.google.com/spreadsheets/d/1S6iSi0tWvqKVk5en2NDx9N5XeDquwOWh4GlGKIEezyo/edit#gid=1074534694',
                'thumbnail': 'https://i.imgur.com/EpIPQXR.png',
                'icon': 'https://i.imgur.com/EpIPQXR.png',
                'label2': '',
                'info': {
                    'plot': 'Danh sách chia sẻ nổi bật trên VietmediaF'},
                'art': {
                        "fanart":'https://i.imgur.com/EpIPQXR.png',
                        "poster":'https://i.imgur.com/EpIPQXR.png',
                        
                        }
                    }, {
                'label': 'Play number/Import List',
                'path': 'plugin://plugin.video.vietmediaF?action=_number_',
                'is_playable': False,
                'thumbnail': 'https://i.imgur.com/pHbuVqt.png',
                'icon': 'https://i.imgur.com/pHbuVqt.png',
                'label2': '',
                'info': {
                    'plot': 'Nhập danh sách chia sẻ từ cộng đồng'}
            }, {
                'label': 'Thiết lập tài khoản',
                'path': 'plugin://plugin.video.vietmediaF?action=accFshare',
                'is_playable': False,
                'thumbnail': 'https://i.imgur.com/XB3HOOe.png',
                'icon': 'https://i.imgur.com/XB3HOOe.png',
                'label2': '',
                'info': {
                    'plot': 'Cấu hình tài khoản Fshare'}
            }
            ]}
    if data.get('error'):
        alert(data['error'])
        return
    if data.get("url"):
        #alert(data.get("url"))
        play(data)
        return
    if not data.get("items"):return
    if data.get("content_type") and len(data["content_type"]) > 0:
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_DATE)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_GENRE)
        xbmcplugin.setContent(HANDLE, data["content_type"])
    listitems = list(range(len(data["items"])))
    for i, item in enumerate(data["items"]):
        lock_url = item["path"].replace("plugin://%s" % ADDON_ID, VIETMEDIA_HOST)
        lock_url = re.sub('\?', '/?', lock_url)
        path = item["path"]
        label = item["label"]
        filterStr = ["xxx", "sex", "jav", "cap 3", "18+", "20+"]
        if check_lock(lock_url):label = "*" + label
        
        if VIEWXXX == 'false':
            label_ = label.lower()
            if '18+' in label_ or 'xxx' in label_ or 'cấp 3' in label or 'jav' in label_ or '+' in label_ or 'sex' in label_ or 'fuck' in label_ or '20+' in label_:
                # listItem = xbmcgui.ListItem(label='[I]Nội dung cần thiết lập để xem[/I]', label2='', iconImage='', thumbnailImage='')
                listItem = xbmcgui.ListItem(label='[I]Nội dung cần thiết lập để xem[/I]')
                path = 'plugin://plugin.video.vietmediaF?action=browse&node_id=75'
            else:
                # listItem = xbmcgui.ListItem(label=label, label2=item["label2"], iconimage=item["icon"], thumbnailImage=item["thumbnail"])
                listItem = xbmcgui.ListItem(label=label, label2=item["label2"])
        if VIEWXXX == 'true':
            listItem = xbmcgui.ListItem(label=label, label2=item["label2"])

        if item.get("info"):
            listItem.setInfo("video", item["info"])
        if item.get("stream_info"):
            for type_, values in item["stream_info"].items():
                listItem.addStreamInfo(type_, values)
        if item.get("art"):
            listItem.setArt(item["art"])
        listItem.setArt({'thumb': item["thumbnail"], 'icon': item["thumbnail"], 'poster': item["icon"]})
        # context_menu
        menu_context = []
        if item.get("context_menu"):
            listItem.addContextMenuItems(item["context_menu"])
        elif item["is_playable"] == True:
            title = item["label"]
            title = re.sub('\[.*?]', '', title)
            title = re.sub('\s', '-', title)
            title = re.sub('--', '-', title)
            title = re.sub('--', '-', title)
            title = re.sub('[\\\\/*?:"<>|#]', "", title)
            title = remove_accents.remove_accents(title)
            #command = 'XBMC.RunPlugin(%s&d=__addfav__&file_name=%s)' % (item["path"], title)
            
            # command = 'XBMC.RunPlugin(%s&d=__idsub__&file_name=%s)' % (item["path"], title)
            # menu_context.append(( 'Mã phụ đề subscene', command, ))
            #command = 'RunPlugin(%s&d=__addtofav__&file_name=%s)' % (item["path"], title)
            #menu_context.append(('Thêm vào Yêu Thích Fshare', command,))
            command = 'RunPlugin(%s&d=__addtofav__)' % (item["path"])
            menu_context.append(('Thêm vào Yêu Thích Fshare', command,))
        
        #command = 'RunPlugin(%s&d=__lock__)' % item["path"]
        #menu_context.append(('Khoá mục này', command,))
        #command = 'RunPlugin(%s&d=__unlock__)' % item["path"]
        #menu_context.append(('Mở khoá mục này', command,))
        listItem.addContextMenuItems(menu_context)
        listItem.setProperty("isPlayable", item["is_playable"] and "true" or "false")
        if item.get("properties"):
            for k, v in item["properties"].items():
                listItem.setProperty(k, v)
        listitems[i] = (path, listItem, not item["is_playable"])
        # listitems[i] = (path, listItem)
        
    xbmcplugin.addDirectoryItems(HANDLE, listitems, totalItems=len(listitems))
    if VIEWMODE == 'true':
        if '?action=menu' in url or 'node_id=77' in url or 'node_id=86' in url or 'node_id=79' in url or 'thread_id=18666' in url or 'thread_id=15858' in url or 'thread_id=21762' in url or 'thread_id=21802' in url or 'thread_id=15492' in url or 'thread_id=104' in url or 'node_id=13' in url or 'node_id=19' in url:
            xbmc.executebuiltin('Container.SetViewMode(%d)' % 500)
    if 'node_id=75' in url:
        notify('Nội dung do người dùng chia sẻ. VietmediaF không chịu trách nhiệm.')
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, updateListing=False, cacheToDisc=True)

go()