import xbmc, os, sys
monitor = xbmc.Monitor()
while not monitor.abortRequested():
    if (os.path.isfile("/storage/emulated/0/voice")):
        lisearch = open("/storage/emulated/0/voice", "r")
        search = lisearch.read()
        lisearch.close()
        xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.video.vnmedia/resources/lib/mkd/onfshare/timfshare/searchfs/?search_query=%s,return)" %(search))
        os.remove("/storage/emulated/0/voice")