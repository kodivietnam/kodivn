import xbmcaddon
import os
ADDON_ID = xbmcaddon.Addon().getAddonInfo('id')
PATH = xbmcaddon.Addon().getAddonInfo('path')
ART = os.path.join(PATH, 'resources', 'media')
ADDONTITLE = '[COLOR red][B]KENDO[/B][/COLOR] [COLOR blue]SETUP[/COLOR]'
BUILDERNAME = ''
EXCLUDES = [ADDON_ID, '']
BUILDFILE = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kendobandung.vnm'
UPDATECHECK = 0
APKFILE = 'http://'
YOUTUBETITLE = ''
YOUTUBEFILE = 'http://'
ADDONFILE = 'http://'
ADVANCEDFILE = 'http://'
ICONBUILDS = os.path.join(ART, 'builds.png')
ICONMAINT = os.path.join(ART, 'maintenance.png')
ICONSPEED = os.path.join(ART, 'speed.png')
ICONAPK = os.path.join(ART, 'apkinstaller.png')
ICONADDONS = os.path.join(ART, 'addoninstaller.png')
ICONYOUTUBE = os.path.join(ART, 'youtube.png')
ICONSAVE = os.path.join(ART, 'savedata.png')
ICONTRAKT = os.path.join(ART, 'keeptrakt.png')
ICONREAL = os.path.join(ART, 'keepdebrid.png')
ICONLOGIN = os.path.join(ART, 'keeplogin.png')
ICONCONTACT = os.path.join(ART, 'information.png')
ICONSETTINGS = os.path.join(ART, 'settings.png')
HIDESPACERS = 'No'
SPACER = '='
COLOR1 = 'blue'
COLOR2 = 'white'
THEME1 = u'[COLOR {color2}]{{}}[/COLOR]'.format(color1=COLOR1, color2=COLOR2)
THEME2 = u'[COLOR {color1}]{{}}[/COLOR]'.format(color1=COLOR1)
THEME3 = u'[COLOR {color1}]{{}}[/COLOR]'.format(color1=COLOR1)
THEME4 = u'[COLOR {color1}]BUILD:[/COLOR] [COLOR {color2}]{{}}[/COLOR]'.format(color1=COLOR1, color2=COLOR2)
THEME5 = u'[COLOR {color1}]BUILD:[/COLOR] [COLOR {color2}]{{}}[/COLOR]'.format(color1=COLOR1, color2=COLOR2)
HIDECONTACT = 'Yes'
CONTACT = ''
CONTACTICON = os.path.join(ART, 'qricon.png')
CONTACTFANART = 'http://'
AUTOUPDATE = 'No'
AUTOINSTALL = 'No'
REPOID = 'repository.vmfmatrix'
REPOADDONXML = 'https://raw.githubusercontent.com/nguyenducmanh609/kodivn/master/addons.xml'
REPOZIPURL = 'https://'
ENABLE = 'No'
NOTIFICATION = ''
HEADERTYPE = 'Text'
FONTHEADER = 'Font14'
HEADERMESSAGE = '[COLOR red][B]KENDO[/B][/COLOR] [COLOR yellow][B]SETUP[/B][/COLOR]'
HEADERIMAGE = 'http://'
FONTSETTINGS = 'Font13'
BACKGROUND = 'http://'