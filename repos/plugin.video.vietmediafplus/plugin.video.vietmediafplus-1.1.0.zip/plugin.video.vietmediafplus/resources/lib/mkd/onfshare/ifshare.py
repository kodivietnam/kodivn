from codequick import Route, Listitem, run, Script
from resources.lib.kedon import __addon__, getlink, __icon__, __addonnoti__, convert_bytes, play_fs, userpassfs
import urlquick
import xbmc
import xbmcgui
import re
import requests
SERVICE_URL = 'http://fshare.fun/api/v1/get'


@Route.register
def index_fs(plugin, idfd, next_page):
    # url = 'https://www.fshare.vn/api/v3/files/folder?linkcode=%s&sort=type,name&page=%s' % (idfd, str(next_page))
    url = '%s?command=get_fshare&linkcode=%s&sort=type,name&page=%s' % (
        SERVICE_URL, idfd, str(next_page))
    # kq = getlink(url, url, 60*60)
    kq = requests.post(url)
    if 'items' in kq.text and len(kq.json()['items']) > 0:
        for k in kq.json()['items']:
            item = Listitem()
            if k['type'] == 0:
                item.label = k['name']
                item.info['plot'] = 'https://fshare.vn/folder/%s' % k['linkcode']
                item.art['thumb'] = 'http://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=0&size=400x400&ecc=L' % item.info['plot']
                item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
                item.set_callback(index_fs, k['linkcode'], 1)
                yield item
            elif k['type'] == 1:
                item.label = k['name'] + ' (' + convert_bytes(k['size']) + ')'
                item.info['plot'] = 'https://fshare.vn/file/%s' % k['linkcode']
                linkplay = 'https://www.fshare.vn/file/' + k['linkcode']
                item.art['thumb'] = 'http://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=0&size=400x400&ecc=L' % item.info['plot']
                item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
                item.set_callback(play_fs, linkplay, item.label)
                yield item
    else:
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)' % (
            __addonnoti__, u'Fshare link folder die', 10000, __icon__))
        xbmc.executebuiltin('Container.Refresh')
    # if kq.json().get('_links').get('last'):
    # 	last_page = re.search(r'&page=(\d+)', kq.json().get('_links').get('last')).group(1)
    # 	if int(last_page) > next_page:
    # 		yield Listitem.next_page(idfd, next_page + 1,  callback=index_fs)


@Route.register
def fs_favorite(plugin, content_type='segment'):
    try:
        session_id = userpassfs()[1]
        headerfsvn = {'User-Agent': 'Vietmediaf /Kodi1.1.99-092019',
                      'Cookie': 'session_id=' + session_id}
        resp = urlquick.get('https://api.fshare.vn/api/fileops/listFavorite',
                            timeout=30, max_age=15*60, headers=headerfsvn)
    except:
        xbmcgui.Dialog().ok(__addonnoti__,
                            'Đăng nhập không thành công\nKiểm tra lại tài khoản, mật khẩu, đường truyền Internet')
        __addon__.openSettings()
        exit()
    for k in resp.json():
        item = Listitem()
        if k['type'] == '0':
            item.label = k['name']
            item.info['plot'] = 'https://fshare.vn/folder/%s' % k['linkcode']
            item.art['thumb'] = 'http://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=0&size=400x400&ecc=L' % item.info['plot']
            item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
            item.set_callback(index_fs, k['linkcode'], 1)
            yield item
        elif k['type'] == '1':
            item.label = k['name']
            item.info['plot'] = 'https://fshare.vn/file/%s' % k['linkcode']
            linkplay = 'https://www.fshare.vn/file/' + k['linkcode']
            item.art['thumb'] = 'http://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=0&size=400x400&ecc=L' % item.info['plot']
            item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
            item.set_callback(play_fs, linkplay, item.label)
            yield item
    yield []


@Route.register
def fs_topfollow(plugin, content_type='segment'):
    session_id = userpassfs()[1]
    headerfsvn = {'User-Agent': 'Vietmediaf /Kodi1.1.99-092019',
                  'Cookie': 'session_id=' + session_id}
    try:
        resp = urlquick.get('https://api.fshare.vn/api/fileops/getTopFollowMovie',
                            timeout=30, max_age=7*24*60*60, headers=headerfsvn)
    except:
        xbmcgui.Dialog().ok(__addonnoti__,
                            'Đăng nhập không thành công\nKiểm tra lại tài khoản, mật khẩu, đường truyền Internet')
        __addon__.openSettings()
        exit()
    for k in resp.json():
        item = Listitem()
        item.label = k['name']
        item.info['plot'] = 'https://fshare.vn/file/%s' % k['linkcode']
        item.art['thumb'] = 'http://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=0&size=400x400&ecc=L' % item.info['plot']
        item.art['fanart'] = 'https://www.fshare.vn/images/top-follow/title.png'
        item.set_callback(index_fs, k['linkcode'], 1)
        yield item
    yield []
