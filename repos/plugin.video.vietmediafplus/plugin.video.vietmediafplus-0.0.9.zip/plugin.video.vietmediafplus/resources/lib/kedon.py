from codequick import Resolver, Listitem, run, Script
import urlquick
import xbmc
import xbmcgui
import xbmcaddon
import requests
from urllib.request import urlopen

__addon__ = xbmcaddon.Addon()
__addonname__ = __addon__.getAddonInfo('name')
__version__ = __addon__.getAddonInfo('version')
__icon__ = __addon__.getAddonInfo('icon')
__settings__ = xbmcaddon.Addon(id='plugin.video.vietmediafplus')
__addonnoti__ = __addonname__ + ' v' + __version__
shorturl = __addon__.getSetting('shorten_host')
useragent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.5112.102 Safari/537.36 OPR/90.0.4480.54'
code = 'User-Agent=' + useragent
news = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/qc.ass'
tb = 'Nội dung được tìm kiếm từ Internet, VietmediaF Plus không kiểm soát cũng như không chịu trách nhiệm về nội dung này. Đề nghị khán giả cân nhắc trước khi xem.'


def convert_bytes(size):
    for x in ['bytes', 'KB', 'MB', 'GB', 'TB']:
        if size < 1024.0:
            return "%3.1f %s" % (size, x)
        size /= 1024.0
    return size


def getlink(url, ref, luu):
    try:
        resp = urlquick.get(f'https://mi3s.top/web?trang={url}', timeout=15, max_age=luu)
        resp.encoding = 'utf-8'
        return resp
    except Exception as E:
        xbmc.log(msg=str(E), level=xbmc.LOGERROR)
        Script.notify(__addonnoti__, 'Lỗi kết nối')
        exit()


def postlink(url, ref, luu):
    try:
        resp = urlquick.post(url, timeout=10, max_age=luu, headers={
                             'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.88 Safari/537.36', 'referer': ref})
        resp.encoding = 'utf-8'
        return resp
    except:
        Script.notify(__addonnoti__, 'Lỗi kết nối')
        exit()


def postlinktimfs(url, ref, luu):
    try:
        resp = urlquick.post(url, timeout=10, max_age=luu, headers={'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.88 Safari/537.36',
                                                                    'referer': ref,
                                                                    'authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJuYW1lIjoiZnNoYXJlIiwidXVpZCI6IjcxZjU1NjFkMTUiLCJ0eXBlIjoicGFydG5lciIsImV4cGlyZXMiOjAsImV4cGlyZSI6MH0.WBWRKbFf7nJ7gDn1rOgENh1_doPc07MNsKwiKCJg40U'})
        resp.encoding = 'utf-8'
        return resp
    except:
        Script.notify(__addonnoti__, 'Lỗi kết nối')
        exit()


def replace_all(dict, str):
    for key in dict:
        str = str.replace(key, dict[key])
    return str


def get_user_input():
    kb = xbmc.Keyboard('', 'NumberCode được chia sẻ bởi facebook Hội mê Phim')
    kb.doModal()
    if not kb.isConfirmed():
        return
    query = kb.getText()
    return query


def get_info_fs(url):

    try:
        contents = urlopen(url).read().decode() 
        titleOpenPos = contents.find('<title>') + 7
        titleClosePos = contents.find('</title>') - 9
        return (contents[titleOpenPos:titleClosePos])
    except Exception as E:
        xbmc.log(msg=str(E), level=xbmc.LOGERROR)
        return 'Không lấy được tên tập tin'


def userpassfs():
    username = __settings__.getSetting('username')
    password = __settings__.getSetting('password')
    if len(username) == 0 or len(password) == 0:
        __addon__.openSettings()
    else:
        payload = '{"app_key":"L2S7R6ZMagggC5wWkQhX2+aDi467PPuftWUMRFSn","user_email":"' + \
            username+'","password":"'+password+'"}'
        head = {'cache-control': 'no-cache',
                'User-Agent': 'Vietmediaf /Kodi1.1.99-092019'}
        try:
            resp = urlquick.post('https://api.fshare.vn/api/user/login',
                                 data=payload, headers=head, timeout=20, max_age=6*60*60)
            resp.raise_for_status()
        except:
            xbmcgui.Dialog().ok(__addonnoti__,
                                'Sau 3 lần đăng nhập không thành công, tài khoản sẽ bị khoá 10 phút\nKiểm tra lại tài khoản, mật khẩu, đường truyền Internet...')
            __addon__.openSettings()
            exit()
        token = resp.json()['token']
        session_id = resp.json()['session_id']
        return (token, session_id, username, password)


def getrow(row):
    if row is not None and row['v'] is not None:
        return row['v']
    else:
        return ''


@Resolver.register
def play_fs(plugin, url, title):
    try:
        session_id = userpassfs()[1]
        token = userpassfs()[0]
        payload = {'token': token, 'url': url}
        headerfsvn = {'User-Agent': 'Vietmediaf /Kodi1.1.99-092019',
                      'Cookie': 'session_id=' + session_id}
        resp = urlquick.post('https://api.fshare.vn/api/session/download',
                             timeout=10, max_age=0, json=payload, headers=headerfsvn)
        return Listitem().from_dict(**{'label': title, 'subtitles': {news}, 'callback': resp.json()['location']})
    except:
        xbmcgui.Dialog().ok(__addonnoti__, 'Tập tin này bị hỏng')