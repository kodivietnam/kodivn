from codequick import Route, Listitem, run
from resources.lib.kedon import tb, postlinktimfs, play_fs, get_info_fs, __addonnoti__, convert_bytes
from resources.lib.mkd.onfshare.ifshare import index_fs, SERVICE_URL
import xbmcgui, urllib, requests, urlquick, re
@Route.register
def searchfs(plugin, search_query):
    dp = xbmcgui.DialogProgress()
    dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
    params = {
        'command': 'get_recommend',
        'keyword': search_query
    }
    try:
        res = requests.post(SERVICE_URL, data=params).json()
        if res['status'] == '1':
            fshareUrls = res['recommend'].split(',')
            for fshareUrl in fshareUrls:
                if fshareUrl != '':
                    item = Listitem()
                    x = fshareUrl
                    item.label = get_info_fs(x)
                    item.info['plot'] = x
                    item.art['thumb'] = 'http://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=0&size=400x400&ecc=L' % item.info['plot']
                    item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
                    item.set_callback(play_fs, x, item.label)
                    yield item
    except:
        pass
    search_query = urllib.parse.quote_plus(search_query)
    urlvmf = 'http://phongblack.me/search.php?author=phongblack&search=%s' % search_query
    url = 'https://api.timfshare.com/v1/string-query-search?query=%s' % search_query
    respvmf = urlquick.get(urlvmf, timeout=10, max_age=0, headers={'user-agent': 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36 VietMedia/1.0','referer': 'http://www.google.com'})
    x = respvmf.json()['items']
    for m in x:
        item1 = Listitem()
        ten = re.sub('[\[\]\{\}]','|', m['label'])
        if 'info' in m:
            mota = m['info']['plot']
        path = m['path']
        if '/file/' in path:
            item1.label = ten
            link = path.split('&url=')
            linkplay = link[1]
            item1.art['thumb'] = item1.art['landscape'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=1&size=400x400&ecc=L' % linkplay
            item1.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
            item1.info['plot'] = mota
            item1.set_callback(play_fs, linkplay, item1.label)
            yield item1
        elif '/folder/' in path:
            item1.label = ten
            link = path.split('&url=')
            linkplay = link[1]
            thumuc = linkplay.split('folder/')
            item1.art['thumb'] = item1.art['landscape'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=1&size=400x400&ecc=L' % linkplay
            item1.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
            item1.info['plot'] = mota
            item1.set_callback(index_fs, thumuc[1], 1)
            yield item1
    url = 'https://api.timfshare.com/v1/string-query-search?query=' + search_query
    resp = postlinktimfs(url, 'https://timfshare.com/', 172800)
    kq = resp.json()
    if kq['data']:
        for k in kq['data']:
            item = Listitem()
            if 'folder' in k['url']:
                item.label = k['name']
                thumuc = k['url'].split('folder/')
                item.info['plot'] = 'https://fshare.vn/folder/%s' % thumuc[1]
                item.art['thumb'] = 'http://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=0&size=400x400&ecc=L' % item.info['plot']
                item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
                item.set_callback(index_fs, thumuc[1], 1)
                yield item
            elif 'file' in k['url']:
                item.label = k['name'] + ' (' + convert_bytes(k['size']) + ')'
                linkplay = k['url']
                item.info['plot'] = linkplay
                item.art['thumb'] = 'http://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=0&size=400x400&ecc=L' % item.info['plot']
                item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
                item.set_callback(play_fs, linkplay, item.label)
                yield item
    else:
        xbmcgui.Dialog().ok(__addonnoti__, 'Không tìm thấy kết quả')
        yield []