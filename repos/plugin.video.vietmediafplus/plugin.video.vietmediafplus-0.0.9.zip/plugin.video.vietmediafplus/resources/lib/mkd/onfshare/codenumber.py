from codequick import Route, Listitem, run, Script
from resources.lib.kedon import getlink, get_user_input, get_info_fs, play_fs, __addonnoti__, shorturl
from resources.lib.mkd.onfshare.ifshare import index_fs
import re, xbmcgui, urllib
@Route.register
def searchnumber(plugin, search_query):
    search_query = get_user_input()
    if not search_query:
        return []
    dp = xbmcgui.DialogProgress()
    dp.create(__addonnoti__, 'Đang lấy dữ liệu từ máy chủ %s...' % shorturl.upper())
    search_query = urllib.parse.quote_plus(search_query)
    z = 'https://%s/%s' % (shorturl, search_query)
    resp = getlink(z, z, 127800)
    x = resp.url
    item = Listitem()
    if 'folder' in x:
        if '?' in x:
            match = re.search(r'folder/(.*?)\?', x)
            idfd = match.group(1)
        else:
            tach = x.split('folder/')
            idfd = tach[1]
        item.label = z
        item.info['plot'] = 'https://fshare.vn/folder/%s' % idfd
        next_page = 1
        item.art['thumb'] = 'http://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=0&size=400x400&ecc=L' % item.info['plot']
        item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
        item.set_callback(index_fs, idfd, next_page)
        yield item
    elif 'file' in x:
        item.label = get_info_fs(x)
        item.info['plot'] = x
        item.art['thumb'] = 'http://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=0&size=400x400&ecc=L' % item.info['plot']
        item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
        item.set_callback(play_fs, x, item.label)
        yield item
    else:
        yield []
