from codequick import Route, Listitem, run
from resources.lib.kedon import tb, postlinktimfs, play_fs, get_info_fs, __addonnoti__, convert_bytes
from resources.lib.mkd.onfshare.ifshare import index_fs, SERVICE_URL
import xbmcgui
import urllib
import requests


@Route.register
def searchfs(plugin, search_query):
    dp = xbmcgui.DialogProgress()
    dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
    params = {
        'command': 'get_recommend',
        'keyword': search_query
    }
    try:
        res = requests.post(SERVICE_URL, data=params).json()
        if res['status'] == '1':
            fshareUrls = res['recommend'].split(',')
            for fshareUrl in fshareUrls:
                if fshareUrl != '':
                    item = Listitem()
                    x = fshareUrl
                    item.label = get_info_fs(x)
                    item.info['plot'] = x
                    item.art['thumb'] = 'http://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=0&size=400x400&ecc=L' % item.info['plot']
                    item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
                    item.set_callback(play_fs, x, item.label)
                    yield item
    except:
        pass
    search_query = urllib.parse.quote_plus(search_query)
    url = 'https://api.timfshare.com/v1/string-query-search?query=' + search_query
    resp = postlinktimfs(url, 'https://timfshare.com/', 48*60*60)
    kq = resp.json()
    for k in kq['data']:
        item = Listitem()
        if 'folder' in k['url']:
            item.label = k['name']
            thumuc = k['url'].split('folder/')
            item.info['plot'] = 'https://fshare.vn/folder/%s' % thumuc[1]
            item.art['thumb'] = 'http://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=0&size=400x400&ecc=L' % item.info['plot']
            item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
            item.set_callback(index_fs, thumuc[1], 1)
            yield item
        elif 'file' in k['url']:
            item.label = k['name'] + ' (' + convert_bytes(k['size']) + ')'
            linkplay = k['url']
            item.info['plot'] = linkplay
            item.art['thumb'] = 'http://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=0&size=400x400&ecc=L' % item.info['plot']
            item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
            item.set_callback(play_fs, linkplay, item.label)
            yield item
        else:
            yield []
