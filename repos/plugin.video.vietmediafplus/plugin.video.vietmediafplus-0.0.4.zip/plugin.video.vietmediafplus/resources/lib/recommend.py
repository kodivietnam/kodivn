from codequick import Route, Listitem, run, Script
from resources.lib.mkd.onfshare.ifshare import index_fs, SERVICE_URL
import requests


@Route.register
def fs_recommend(plugin, content_type='segment'):
    params = {
        'command': 'get_recommend_folder',
    }
    try:
        res = requests.post(SERVICE_URL, data=params).json()
        if res['status'] == '1':
            for linkcode in res['recommend']:
                item = Listitem()
                item.info['plot'] = 'https://fshare.vn/folder/%s' % linkcode
                item.label = res['recommend'][linkcode]
                item.art['thumb'] = 'http://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=0&size=400x400&ecc=L' % item.info['plot']
                item.art['fanart'] = 'https://banner2.cleanpng.com/20180411/pfq/kisspng-handshake-clip-art-shake-5acecaff127372.4661743715235018230756.jpg'
                item.set_callback(index_fs, linkcode, 1)
                yield item
    except:
        pass
    yield []
