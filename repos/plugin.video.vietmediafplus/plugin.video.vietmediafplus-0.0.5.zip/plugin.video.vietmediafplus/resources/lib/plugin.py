from codequick import Route, Listitem, run
from resources.lib.qrplay import qrplay
from resources.lib.recommend import fs_recommend
from resources.lib.mkd.gcs import index_gcs
from resources.lib.mkd.onfshare.codenumber import searchnumber
from resources.lib.mkd.onfshare.ifshare import fs_favorite, fs_topfollow
from resources.lib.mkd.onfshare.timfshare import searchfs


@Route.register
def root(plugin, content_type='segment'):
    Fsharefavorite = {'label': 'Fshare Favorite',
                      'info': {'plot': 'Yêu thích'},
                      'art': {'thumb': 'https://banner2.cleanpng.com/20180319/ikq/kisspng-heart-love-brand-logo-favourites-5ab0468bbe3665.1130427115215018357791.jpg',
                              'fanart': 'https://fsharetv.com/img/fsharetv.png'},
                      'callback': fs_favorite}
    Fsharefollow = {'label': 'TOP FSHARE',
                    'info': {'plot': 'Top 15 thư mục theo dõi nhiều nhất'},
                    'art': {'thumb': 'https://www.fshare.vn/images/top-follow/title.png',
                            'fanart': 'https://fsharetv.com/img/fsharetv.png'},
                    'callback': fs_topfollow}
    FshareRecommend = {'label': 'Phim Đề Xuất',
                       'info': {'plot': 'Xem phim ở thư mục này giúp tác giả có thể duy trì kho phim trong vùng lưu trữ đảm bảo. Kho sẽ bổ sung dần khi số lần tải đạt yêu cầu của Fshare'},
                       'art': {'thumb': 'https://banner2.cleanpng.com/20180411/pfq/kisspng-handshake-clip-art-shake-5acecaff127372.4661743715235018230756.jpg',
                               'fanart': 'https://banner2.cleanpng.com/20180411/pfq/kisspng-handshake-clip-art-shake-5acecaff127372.4661743715235018230756.jpg'},
                       'callback': fs_recommend}
    yield makeNewestItem()
    yield Listitem.search(searchfs)
    yield makeQrPlayItem()
    yield makePlayNumberCodeItem()    
    yield Listitem.from_dict(**Fsharefavorite)
    yield Listitem.from_dict(**Fsharefollow)
    gcs = {'label': 'Góc chia sẻ',
           'info': {'plot': 'Nội dung được chia sẻ từ hội mê phim'},
           'art': {'thumb': 'https://itseovn.com/data/avatars/l/51/51797.jpg',
                   'fanart': 'https://fsharetv.com/img/fsharetv.png'},
           'callback': index_gcs}
    yield Listitem.from_dict(**gcs)
    yield Listitem.from_dict(**FshareRecommend)


def makePlayNumberCodeItem():
    item = Listitem()
    item.label = 'Play NumberCode'
    item.info['plot'] = 'Mã CODE được tạo từ trang rút gọn http://gg.gg'
    item.path = searchnumber
    item.art['thumb'] = 'https://reference.vn/wp-content/uploads/2019/04/lic-su-so-tu-nhien.jpg'
    item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
    item.set_callback(searchnumber, item.path)
    return item


def makeQrPlayItem():
    item = Listitem()
    item.label = 'Mobile Play'
    item.info['plot'] = 'Dùng điện thoại để nhập link Fshare hoặc nhập từ khóa tìm kiếm thuận tiện'
    item.path = qrplay
    item.art['thumb'] = 'https://banner2.cleanpng.com/20180616/jao/kisspng-computer-icons-qr-code-download-mobile-phones-qrcode-5b255cd1736764.9771995515291752494727.jpg'
    item.art['fanart'] = 'https://banner2.cleanpng.com/20180303/leq/kisspng-template-download-mobile-phone-qr-code-vector-creative-hand-phone-5a9aa86bd143f0.9505955915200850998572.jpg'
    item.set_callback(qrplay)
    return item

def makeNewestItem():
    item = Listitem()
    item.label = 'Phim mới nhất'
    item.info['plot'] = 'Nội dung mới nhất được chia sẻ từ hội mê phim'
    item.art['thumb'] = 'https://itseovn.com/data/avatars/l/51/51797.jpg'
    item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
    item.set_callback(index_gcs, 'NewestURL')
    return item