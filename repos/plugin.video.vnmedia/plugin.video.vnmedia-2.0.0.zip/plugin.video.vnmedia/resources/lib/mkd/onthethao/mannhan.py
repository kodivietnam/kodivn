from codequick import Route, Listitem, run
@Route.register
def index_mannhan(plugin, **kwargs):
    from resources.lib.kedon import quangcao, replace_all, getlink, stream, referer, play_vnm, tb, mannhan
    url = mannhan()[0]
    resp = getlink(url, url, 400)
    if resp is not None:
        if '.m3u8' in resp.text:
            import re, json, datetime
            ll = re.search(r',lives=(.*?)</script>', resp.text).group(1)
            nd = re.sub('([{,:])(\w+)([},:])','\\1\"\\2\"\\3',ll)
            thaythe = {
                "'[":"[",
                "]'":"]"
                }
            nd = replace_all(thaythe, nd)
            m = json.loads(nd)
            for b1 in m:
                if 'hlsUrlsManNhan' in b1:
                    for b2 in b1['hlsUrlsManNhan']:
                        item1 = Listitem()
                        if b2['url']:
                            tg2 = datetime.datetime.fromtimestamp(int(b1['time'])/1000).strftime('%H:%M %d-%m')
                            item1.info['plot'] = tb
                            item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://1966649973.slave.anycastapnic.com/template/public/img/logo.png'
                            ten2 = b1['titleManNhan'].split(':')[1].strip()
                            chatluong2 = b2['name']
                            tentrandau2 = f'{tg2} {chatluong2}: {ten2}'
                            if b1['blvManNhan']:
                                item1.label = f'{tentrandau2} - BLV: {b1["blvManNhan"]}'
                            else:
                                item1.label = tentrandau2
                            linktrandau2 = f'{stream(b2["url"])}{referer(url)}'
                            item1.set_callback(play_vnm, linktrandau2, item1.label, '')
                            yield item1
            for k1 in m:
                for k2 in k1['hlsUrls']:
                    item2 = Listitem()
                    if k2['url']:
                        tg1 = datetime.datetime.fromtimestamp(int(k1['time'])/1000).strftime('%H:%M %d-%m')
                        item2.info['plot'] = tb
                        item2.art['thumb'] = item2.art['landscape'] = item2.art['fanart'] = 'https://9767a59e2b.vws.vegacdn.vn/template/logo1.png'
                        chatluong1 = k2['name']
                        ten1 = k1['title'].split(':')[1].strip()
                        tentrandau1 = f'{tg1} {chatluong1}: {ten1}'
                        if k1['blv']:
                            item2.label = f'{tentrandau1} - BLV: {k1["blv"]}'
                        else:
                            item2.label = tentrandau1
                        linktrandau1 = f'{stream(k2["url"])}{referer(url)}'
                        item2.set_callback(play_vnm, linktrandau1, item2.label, '')
                        yield item2
        else:
            yield quangcao()
    else:
        yield quangcao()