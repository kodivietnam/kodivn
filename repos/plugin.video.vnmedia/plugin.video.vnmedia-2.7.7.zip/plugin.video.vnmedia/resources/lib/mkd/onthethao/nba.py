from codequick import Route, Listitem, Resolver
from resources.lib.kedon import fu, getlink, quangcao
from urllib.parse import urlparse
from bs4 import BeautifulSoup
@Route.register
def index_nba(plugin, **kwargs):
	url = 'https://stream.tructiepnba.com/'
	resp = getlink(url, url, 1000)
	if (resp is not None):
		soup = BeautifulSoup(resp.content, 'html.parser')
		for block in soup.select('div.wp-block-group__inner-container'):
			try:
				title = block.select_one('h2').get_text(strip=True)
				time = block.select_one('p').get_text(strip=True)
				buttons = block.select('a.wp-block-button__link')
				for button in buttons:
					language = button.text.strip()
					link = button['href']
					item = Listitem()
					item.label = f'{language} - {time}: {title}'
					item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/nba.png'
					item.set_callback(list_nba, button['href'], item.label)
					yield item
			except:
				pass
	else:
		yield quangcao()
@Route.register
def list_nba(plugin, url, title, **kwargs):
	resp = getlink(url, url, 400)
	if (resp is not None):
		item1 = Listitem()
		item1.label = f'SV1 - {title}'
		item1.art['thumb'] = item1.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/nba.png'
		item1.set_callback(Resolver.ref('/resources/lib/kedon:ifr_khomuc'), url, item1.label)
		yield item1
		soup = BeautifulSoup(resp.content, 'html.parser')
		for episode in soup.select('pagelinkselement#post-pagination a'):
			item = Listitem()
			item.label = f'{episode.get_text(strip=True)} - {title}'
			item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/nba.png'
			item.set_callback(Resolver.ref('/resources/lib/kedon:ifr_khomuc'), episode.get('href'), item.label)
			yield item
	else:
		yield quangcao()