from codequick import Route, Listitem, Script, Resolver
from resources.lib.kedon import search_history_get, search_history_clear, fu, get_info_fs, yttk, __addonnoti__, quangcao, search_history_save
from xbmcaddon import Addon
from xbmcgui import Dialog, DialogProgress
from urllib.parse import quote_plus
from functools import lru_cache
import re
def get_user_input():
	shorturl = Addon().getSetting('shorten_host')
	search_term = Dialog().input(f'{shorturl.upper()} - Mã CODE được chia sẻ bởi facebook Hội mê Phim')
	return search_term
@Route.register
def index_number(plugin, **kwargs):
	yield PlayNumberCode()
	yield Listitem.from_dict(**{'label': 'MÃ CODE gần đây',
	'info': {'plot': 'MÃ CODE đã nhập'},
	'art': {'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/watched.png',
	'fanart': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'},
	'callback': index_codeganday})
@Route.register
def index_codeganday(plugin, **kwargs):
	if b:= search_history_get():
		for m in b:
			item = Listitem()
			item.label = m.split('/')[-1]
			item.art['thumb'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/numbercode.png'
			item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
			item.set_callback(dulieucode, m)
			yield item
		yield Listitem.from_dict(**{'label': 'Xoá lịch sử CODE',
		'info': {'plot': 'Xoá lịch sử mã code đã nhập'},
		'art': {'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/watched.png',
		'fanart': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'},
		'callback': search_history_clear})
	else:
		yield []
@Route.register
def dulieucode(plugin, m, **kwargs):
	x = fu(m)
	if 'folder' in x:
		item = Listitem()
		item.label = get_info_fs(x)[0]
		item.info['mediatype'] = 'episode'
		item.info['rating'] = 10.0
		item.info['trailer'] = yttk(item.label)
		item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={x}&qzone=1&margin=1&size=400x400&ecc=L'
		item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
		item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', x)
		item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), x, 0)
		yield item
	elif 'file' in x:
		item = Listitem()
		item.label = get_info_fs(x)[0]
		item.info['size'] = get_info_fs(x)[1]
		item.info['mediatype'] = 'episode'
		item.info['rating'] = 10.0
		item.info['trailer'] = yttk(item.label)
		item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={x}&qzone=1&margin=1&size=400x400&ecc=L'
		item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
		if Addon().getSetting('taifshare') == 'true':
			item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', x)
		item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', x)
		item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), x, item.label)
		yield item
	else:
		Script.notify(__addonnoti__, 'CODE không đúng')
		yield quangcao()
@Route.register
def searchnumber(plugin,search_query, **kwargs):
	shorturl = Addon().getSetting('shorten_host')
	search_query = get_user_input()
	if search_query == '':
		Script.notify(f'{__addonnoti__} - {shorturl.upper()}', 'Bạn chưa nhập CODE')
		yield quangcao()
	else:
		dp = DialogProgress()
		dp.create(__addonnoti__, f'Đang lấy dữ liệu từ máy chủ {shorturl.upper()}...')
		dp.update(5)
		search_query = quote_plus(search_query)
		z = f'http://{shorturl}/{search_query}'
		search_history_save(z)
		x = fu(z)
		if 'folder' in x:
			item = Listitem()
			item.label = get_info_fs(x)[0]
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = yttk(item.label)
			item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={x}&qzone=1&margin=1&size=400x400&ecc=L'
			item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
			item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', x)
			item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), x, 0)
			yield item
		elif 'file' in x:
			item = Listitem()
			item.label = get_info_fs(x)[0]
			item.info['size'] = get_info_fs(x)[1]
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = yttk(item.label)
			item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={x}&qzone=1&margin=1&size=400x400&ecc=L'
			item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
			if Addon().getSetting('taifshare') == 'true':
				item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', x)
			item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', x)
			item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), x, item.label)
			yield item
		else:
			Script.notify(__addonnoti__, 'CODE không đúng')
			yield quangcao()
		dp.update(100)
		dp.close()
@lru_cache(maxsize=None)
def PlayNumberCode():
	shorturl = Addon().getSetting('shorten_host')
	item = Listitem()
	item.label = 'MÃ CODE'
	item.info['plot'] = f'Mã CODE được chia sẻ bởi nhóm fb Hội mê phim - máy chủ {shorturl.upper()}'
	item.path = searchnumber
	item.art['thumb'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/numbercode.png'
	item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
	item.set_callback(searchnumber, item.path)
	return item