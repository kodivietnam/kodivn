from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from resources.lib.kedon import getlink, ifr_xembong, quangcao
@Route.register
def index_vaoroi(plugin, **kwargs):
	url = 'https://vaoroi5.live'
	resp = getlink(url, url, 15*60)
	if resp is not None:
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('div.panel.panel-default div.matches-lst-tr.clearfix')
		for episode in episodes:
			item = Listitem()
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = f'{url}/themes/frontend/default/img/vaoroi-logo.png'
			linktrandau = f'{url}{episode.select_one("a").get("href")}'
			time = episode.select_one('p.mltt-up.live_nows').get_text()
			title = episode.select_one('a.mlt-info').get_text()
			title = '\n'.join([ll.rstrip() for ll in title.splitlines() if ll.strip()])
			title = title.replace('\n', ' ')
			item.label = f'{time}: {title}'
			item.set_callback(ifr_xembong, linktrandau, item.label)
			yield item
	else:
		yield quangcao()