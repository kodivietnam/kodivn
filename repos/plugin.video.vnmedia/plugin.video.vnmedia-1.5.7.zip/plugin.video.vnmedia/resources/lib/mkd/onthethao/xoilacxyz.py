from codequick import Route, Listitem, run
from resources.lib.kedon import quangcao, getlink, stream, referer, play_vnm, tiengruoi
from urllib.parse import urlparse
import datetime
a = urlparse(tiengruoi()[2])
xoilac = f'{a.scheme}://{a.netloc}'
@Route.register
def index_xoilacxyz(plugin, **kwargs):
	url = 'https://api.vebo.xyz/api/match/live'
	resp = getlink(url, xoilac, 15*60)
	if resp is not None:
		kq = resp.json()
		for k in kq['data']:
			item = Listitem()
			time = datetime.datetime.fromtimestamp(int(k['timestamp'])/1000).strftime('%H:%M %d-%m')
			idk = k['id']
			if k['commentators']:
				item.label = f'{time}: {k["name"]} ({k["commentators"][0]["name"]})'
			else:
				item.label = f'{time}: {k["name"]}'
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = f'{xoilac}/xl/static/img/logo.png'
			item.set_callback(list_xoilacxyz, idk, item.label)
			yield item
	else:
		yield quangcao()
@Route.register
def list_xoilacxyz(plugin, idk, title, **kwargs):
	url = f'https://api.vebo.xyz/api/match/{idk}/meta'
	resp = getlink(url, xoilac, 5*60)
	if resp is not None:
		if '.m3u8' in resp.text:
			kq = resp.json()
			for k in kq['data']['play_urls']:
				item = Listitem()
				item.label = f'{k["name"]} - {title}'
				linktrandau = f'{stream(k["url"])}{referer(xoilac)}'
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = f'{xoilac}/xl/static/img/logo.png'
				item.set_callback(play_vnm, linktrandau, item.label, '')
				yield item
		else:
			yield quangcao()
	else:
		yield quangcao()