from codequick import Script, Route, Listitem, Resolver
from resources.lib.kedon import getlinkphongblack, postlinktimfs, getlinkvnm, __addonnoti__, tb, yttk, get_info_fs
from concurrent.futures import ThreadPoolExecutor, as_completed
from xbmcgui import DialogProgress
from urllib.parse import quote_plus
from xbmcaddon import Addon
from json import loads
from functools import lru_cache
import re
@lru_cache(maxsize=None)
def get_tkfs1(search_query):
	try:
		return getlinkphongblack(f'http://phongblack.me/search.php?author=phongblack&search={search_query}', 'http://www.google.com', -1)
	except:
		return getlinkphongblack(f'http://kodi.s2lsolutions.com/search.php?author=phongblack&search={search_query}', 'http://www.google.com', -1)
@lru_cache(maxsize=None)
def get_tkfs2(search_query):
	return postlinktimfs(f'http://api.timfshare.com/v1/string-query-search?query={search_query}', 'https://timfshare.com/', -1)
@lru_cache(maxsize=None)
def get_tkfs3(search_query):
	return getlinkvnm(f'http://thuvienhd.com/?feed=fsharejson&search={search_query}', 'https://thuvienhd.com/')
@lru_cache(maxsize=None)
def get_tkfs4():
	return getlinkvnm(f'http://thuvienhd.com/?feed=fsharejson&search=', 'https://thuvienhd.com/')
@Route.register
def searchfs(plugin, search_query, **kwargs):
	dp = DialogProgress()
	dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
	search_query = quote_plus(search_query)
	with ThreadPoolExecutor(4) as ex:
		f1 = ex.submit(get_tkfs1, search_query)
		f2 = ex.submit(get_tkfs2, search_query)
		f3 = ex.submit(get_tkfs3, search_query)
		f4 = ex.submit(get_tkfs4)
		result_f1 = f1.result()
		result_f2 = f2.result()
		result_f3 = f3.result()
		result_f4 = f4.result()
	dp.update(50)
	try:
		if result_f3 is not None and result_f4 is not None:
			if f3.result().content != f4.result().content:
				kqtvhd = f3.result().json()
				for dem, t in enumerate(kqtvhd):
					item = Listitem()
					item.label = t['title']
					item.info['plot'] = f'{t["title"]}\n{tb}'
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(item.label)
					item.art['thumb'] = item.art['fanart'] = t['image']
					item.set_callback(timnhanhfs, dem, search_query)
					yield item
	except:
		if result_f3 is not None and result_f4 is not None:
			if f3.result().content != f4.result().content:
				text = f3.result().text
				data = re.sub(r'<(.*?)\n','',text)
				jsm = loads(data)
				for dem, t in enumerate(jsm):
					item = Listitem()
					item.label = t['title']
					item.info['plot'] = f'{t["title"]}\n{tb}'
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(item.label)
					item.art['thumb'] = item.art['fanart'] = t['image']
					item.set_callback(timnhanhfs, dem, search_query)
					yield item
	try:
		x = result_f1.json()['items']
		for m in x:
			if 'info' in m:
				mota = f"{m['info']['plot']}\n{tb}"
			else:
				mote = tb
			path = m['path']
			if '/file/' in path:
				item = Listitem()
				item.label = m['label']
				link = path.split('&url=')[1]
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = yttk(item.label)
				item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={path.split("&url=")[1]}&qzone=1&margin=1&size=400x400&ecc=L'
				item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
				item.info['plot'] = mota
				if Addon().getSetting('taifshare') == 'true':
					item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', link)
				item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
				item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), link, item.label)
				yield item
			elif '/folder/' in path:
				item = Listitem()
				item.label = m['label']
				link = path.split("&url=")[1]
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = yttk(item.label)
				item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={path.split("&url=")[1]}&qzone=1&margin=1&size=400x400&ecc=L'
				item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
				item.info['plot'] = mota
				item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
				item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), link, 0)
				yield item
	except:
		try:
			kq = result_f2.json()
			if 'data' in kq:
				for k in kq['data']:
					item = Listitem()
					item.label = k['name']
					item.info['plot'] = tb
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(item.label)
					item.art['thumb'] = f"https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={k['url']}&qzone=1&margin=1&size=400x400&ecc=L"
					item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
					item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', k['url'])
					if 'folder' in k['url']:
						item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), k['url'], 0)
					else:
						item.info['size'] = k['size']
						if Addon().getSetting('taifshare') == 'true':
							item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', k['url'])
						item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), k['url'], item.label)
					yield item
		except:
			pass
	dp.update(100)
	dp.close()
@Route.register
def index_pdx(plugin, **kwargs):
	resptvhd = get_tkfs3('')
	try:
		kqtvhd = resptvhd.json()
		for dem, t in enumerate(kqtvhd):
			item = Listitem()
			item.label = t['title']
			item.info['plot'] = f'{t["title"]}\n{tb}'
			item.info['mediatype'] = 'movie'
			item.info['rating'] = 10.0
			item.info['trailer'] = yttk(item.label)
			item.art['thumb'] = item.art['fanart'] = t['image']
			item.set_callback(timnhanhfs, dem, '')
			yield item
	except:
		text = resptvhd.text
		data = re.sub(r'<(.*?)\n','',text)
		jsm = loads(data)
		for dem, t in enumerate(jsm):
			item = Listitem()
			item.label = t['title']
			item.info['plot'] = f'{t["title"]}\n{tb}'
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = yttk(item.label)
			item.art['thumb'] = item.art['fanart'] = t['image']
			item.set_callback(timnhanhfs, dem, '')
			yield item
@Route.register
def timnhanhfs(plugin, dem, tukhoa):
	try:
		kqtvhd = get_tkfs3(tukhoa).json()
	except:
		kqtvhd = loads(re.sub(r'<(.*?)\n', '', get_tkfs3(tukhoa).text))
	if kqtvhd[dem]['links']:
		urls = [k['link'] for k in kqtvhd[dem]['links']]
		length = len(urls)
		dialog = DialogProgress()
		dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
		dialog.update(5, f'Đang giải mã {length} dữ liệu...')
		with ThreadPoolExecutor(length) as ex:
			future_to_url = {ex.submit(get_info_fs, url): url for url in urls}
			for future in as_completed(future_to_url):
				link = future_to_url[future]
				data = future.result()
				item = Listitem()
				item.label = data[0]
				item.info['plot'] = tb
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = yttk(item.label)
				item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={link}&qzone=1&margin=1&size=400x400&ecc=L'
				item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
				item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
				if 'folder' in link:
					item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), link, 0)
				else:
					item.info['size'] = data[1]
					if Addon().getSetting('taifshare') == 'true':
						item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', link)
					item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), link, item.label)
				yield item
				dialog.update(50)
		dialog.update(100)
		dialog.close()
	else:
		yield []