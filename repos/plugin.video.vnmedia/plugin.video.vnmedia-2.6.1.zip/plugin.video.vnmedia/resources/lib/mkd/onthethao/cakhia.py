from codequick import Route, Listitem, Resolver
from urllib.parse import urlparse
from resources.lib.kedon import getlinkvnm, fu, getlink, tb, stream, referer, quangcao
from datetime import datetime, timedelta
from itertools import chain
from functools import lru_cache
from bs4 import BeautifulSoup
from functools import lru_cache
import sys
def cakhia():
	url = 'http://caheo10.link'
	r = getlinkvnm(url, url)
	try:
		return BeautifulSoup(r.content, 'html.parser').select_one('a[target="_blank"]').get('href')
	except:
		sys.exit()
@Route.register
def index_cakhia(plugin, **kwargs):
	v = urlparse(fu(cakhia()))
	url = f'{v.scheme}://{v.netloc}/'
	ux = f'{url}node-cache/get-lives-home'
	resp = getlink(ux, ux, 400)
	if (resp is not None) and ('.m3u8' in resp.text):
		kq = resp.json()
		m = chain.from_iterable(kq['data'].values())
		for k in m:
			tg = (datetime.fromisoformat(k['time'][:-1]) + timedelta(hours=7)).strftime('%H:%M %d-%m')
			doi1 = k['teamA']['name']
			doi2 = k['teamB']['name']
			for d in k['hlsUrls']:
				if 'm3u8' in d['url']:
					item1 = Listitem()
					if blv1:= k['commentator']:
						item1.label = f'{d["name"]}-{tg}: {doi1}-{doi2} - BLV: {blv1}'
					else:
						item1.label = f'{d["name"]}-{tg}: {doi1}-{doi2}'
					item1.info['plot'] = tb
					item1.art['thumb'] = item1.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/cakhia.png'
					item1.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), f'{stream(d["url"])}{referer(url)}', item1.label, '')
					yield item1
			if 'hlsUrlsCaHeo' in k:
				for e in k['hlsUrlsCaHeo']:
					if 'm3u8' in e['url']:
						item2 = Listitem()
						if blv2:= k['commentatorCaHeo']:
							item2.label = f'{e["name"]}-{tg}: {doi1}-{doi2} - BLV: {blv2}'
						else:
							item2.label = f'{e["name"]}-{tg}: {doi1}-{doi2}'
						item2.info['plot'] = tb
						item2.art['thumb'] = item2.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/caheo.png'
						item2.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), f'{stream(e["url"])}{referer(url)}', item2.label, '')
						yield item2
	else:
		yield quangcao()