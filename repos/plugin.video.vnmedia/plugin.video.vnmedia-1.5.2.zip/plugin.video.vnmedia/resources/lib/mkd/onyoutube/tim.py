from codequick import Route, Listitem, run, Script, Resolver
from resources.lib.kedon import getlink, getlinkweb, get_kara_input, __addonnoti__, quangcao, replace_all, stream, news, qc
from resources.lib.mkd.onyoutube.video import youtube_tatcavideo, youtube_kenh
from xbmc import getInfoLabel
import re, xbmcgui, urllib
thaythe = {'\\"':'','\\u0026':'&'}
@Route.register
def search_youtube(plugin,search_query, **kwargs):
	dp = xbmcgui.DialogProgress()
	dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
	search_query = urllib.parse.quote_plus(search_query)
	url = 'https://www.youtube.com/results?gl=VN&hl=vi&search_query=%s' % search_query.replace(' ','+')
	resp = getlinkweb(url, url, 24*60*60)
	if resp is not None:
		kq = replace_all(thaythe, resp.text)
		if 'videoRenderer' in kq:
			listplay = re.findall(r'videoRenderer(.*?)accessibility', kq)
			for k in listplay:
				item = Listitem()
				tenvd = re.search(r'text":"(.*?)"}', k).group(1)
				idvd = re.search(r'videoId":"(.*?)"', k).group(1)
				anhvd = 'https://i.ytimg.com/vi/%s/sddefault.jpg' % idvd
				item.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=%s' % idvd
				item.label = tenvd
				item.art['thumb'] = item.art['landscape'] = item.art["fanart"] = anhvd
				item.set_callback(item.path)
				yield item
		elif 'playlistRenderer' in kq:
			listplay1 = re.findall(r'playlistRenderer(.*?)webPageType', kq)
			for k1 in listplay1:
				item1 = Listitem()
				tenvd1 = re.search(r'"simpleText":"(.*?)"}', k1).group(1)
				idvd1 = re.search(r'webCommandMetadata":{"url":"(.*?)"', k1).group(1)
				anhvd1 = 'https://i.ytimg.com/vi/%s/sddefault.jpg' % idvd1
				item1.label = tenvd
				item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = anhvd1
				item1.set_callback(youtube_tatcavideo, '%s%s' % (url, idvd1))
				yield item1
		elif 'channelRenderer' in kq:
			listplay2 = re.findall(r'channelRenderer(.*?)webPageType', kq)
			for k2 in listplay2:
				item2 = Listitem()
				tenvd2 = re.search(r'"simpleText":"(.*?)"}', k2).group(1)
				idvd2 = re.search(r'"url":"(.*?)"', k2).group(1)
				anhvd2 = 'https://i.ytimg.com/vi/%s/sddefault.jpg' % idvd2
				item2.label = tenvd2
				item2.art['thumb'] = item2.art['landscape'] = item2.art['fanart'] = 'https:%s' % anhvd2
				item2.set_callback(youtube_kenh, '%s%s' % (url, idvd2))
				yield item2
		else:
			yield []
	else:
		yield quangcao()
@Route.register
def search_karaoke(plugin,search_query, **kwargs):
	search_query = get_kara_input()
	if not search_query:
		Script.notify(__addonnoti__, 'Bạn chưa nhập từ khoá tìm kiếm')
		yield quangcao()
	else:
		dp = xbmcgui.DialogProgress()
		dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
		search_query = urllib.parse.quote_plus(search_query)
		url = 'https://www.youtube.com/results?gl=VN&hl=vi&search_query=Karaoke+%s' % search_query.replace(' ','+')
		resp = getlinkweb(url, url, 48*60*60)
		if resp is not None:
			kq = replace_all(thaythe, resp.text)
			listplay = re.findall(r'videoRenderer(.*?)accessibility', kq)
			for k in listplay:
				item = Listitem()
				tenvd = re.search(r'text":"(.*?)"}', k).group(1)
				idvd = re.search(r'videoId":"(.*?)"', k).group(1)
				anhvd = 'https://i.ytimg.com/vi/%s/sddefault.jpg' % idvd
				item.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=%s' % idvd
				item.label = tenvd
				item.art['thumb'] = item.art['landscape'] = item.art['fanart']= anhvd
				item.set_callback(item.path)
				yield item
		else:
			yield quangcao
@Resolver.register
def trailer_youtube(plugin, search_query, **kwargs):
	b = urllib.parse.quote_plus(search_query)
	url = 'https://m.youtube.com/results?gl=VN&hl=vi&search_query=Trailer+%s' % b.replace(' ','+')
	resp = getlink(url, url, 24*60*60)
	if resp is not None:
		idx = re.search(r'videoId\\x22:\\x22(.*?)\\', resp.text)
		if idx:
			linkplay = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=%s' % idx.group(1)
		else:
			linkplay = stream(qc)
		if '.m3u8' in linkplay:
			return Listitem().from_dict(**{'label':getInfoLabel('ListItem.Label'),'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
		else:
			return Listitem().from_dict(**{'label':getInfoLabel('ListItem.Label'),'callback':linkplay})