from codequick import Route, Listitem, run
from resources.lib.kedon import tb, postlinktimfs, play_fs, __addonnoti__, getlink, __addon__, getlinkphongblack
from resources.lib.mkd.onfshare.ifshare import index_fs, tfavo
from resources.lib.download import downloadfs
import xbmcgui, urllib, urlquick, re
@Route.register
def searchfs(plugin, search_query, **kwargs):
	dp = xbmcgui.DialogProgress()
	dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
	dp.update(0)
	search_query = urllib.parse.quote_plus(search_query)
	urlvmf = 'http://phongblack.me/search.php?author=phongblack&search=%s' % search_query
	respvmf = getlinkphongblack(urlvmf, 'http://www.google.com', 15*60)
	if respvmf is not None:
		x = respvmf.json()['items']
		for m in x:
			item1 = Listitem()
			ten = re.sub('[\[\]\{\}]','|', m['label'])
			if 'info' in m:
				mota = m['info']['plot']
			path = m['path']
			if '/file/' in path:
				item1.label = ten
				link = path.split('&url=')
				linkplay = link[1]
				item1.info['mediatype'] = 'episode'
				item1.info['rating'] = 10.0
				item1.info['trailer'] = 'plugin://plugin.video.vnmedia/resources/lib/mkd/onyoutube/tim/trailer_youtube/?search_query=%s' % re.sub(r'\W+',' ', item1.label)
				item1.art['thumb'] = item1.art['landscape'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=1&size=400x400&ecc=L' % linkplay
				item1.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item1.info['plot'] = mota
				if __addon__.getSetting("taifshare") == "true":
					item1.context.script(downloadfs, 'Tải về', linkplay)
				item1.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
				item1.set_callback(play_fs, linkplay, item1.label)
				yield item1
			elif '/folder/' in path:
				item1.label = ten
				link = path.split('&url=')
				linkplay = link[1]
				thumuc = linkplay.split('folder/')
				item1.info['mediatype'] = 'episode'
				item1.info['rating'] = 10.0
				item1.info['trailer'] = 'plugin://plugin.video.vnmedia/resources/lib/mkd/onyoutube/tim/trailer_youtube/?search_query=%s' % re.sub(r'\W+',' ', item1.label)
				item1.art['thumb'] = item1.art['landscape'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=1&size=400x400&ecc=L' % linkplay
				item1.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item1.info['plot'] = mota
				item1.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
				item1.set_callback(index_fs, thumuc[1], 1)
				yield item1
	else:
		yield []
	url = 'https://api.timfshare.com/v1/string-query-search?query=%s' % search_query
	resp = postlinktimfs(url, 'https://timfshare.com/', 15*60)
	if resp is not None:
		kq = resp.json()
		if kq['data']:
			for k in kq['data']:
				item = Listitem()
				linkplay = k['url']
				if 'folder' in linkplay:
					item.label = k['name']
					thumuc = linkplay.split('folder/')
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = 'plugin://plugin.video.vnmedia/resources/lib/mkd/onyoutube/tim/trailer_youtube/?search_query=%s' % re.sub(r'\W+',' ', item.label)
					item.art['thumb'] = item.art['landscape'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=1&size=400x400&ecc=L' % linkplay
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
					item.set_callback(index_fs, thumuc[1], 1)
					yield item
				elif 'file' in linkplay:
					item.label = k['name']
					item.info['size'] = k['size']
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = 'plugin://plugin.video.vnmedia/resources/lib/mkd/onyoutube/tim/trailer_youtube/?search_query=%s' % re.sub(r'\W+',' ', item.label)
					item.art['thumb'] = item.art['landscape'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=1&size=400x400&ecc=L' % linkplay
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					if __addon__.getSetting("taifshare") == "true":
						item.context.script(downloadfs, 'Tải về', linkplay)
					item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
					item.set_callback(play_fs, linkplay, item.label)
					yield item
	else:
		yield []
	urltvhd = 'https://thuvienhd.com/?feed=fsharejson&search=%s' % search_query
	resptvhd = getlink(urltvhd, 'https://thuvienhd.com/', 15*60)
	if resptvhd is not None:
		kqtvhd = resptvhd.json()
		for t in kqtvhd:
			for d in t['links']:
				item = Listitem()
				linkplay = d['link']
				if 'folder' in linkplay:
					item.label = d['title']
					thumuc = linkplay.split('folder/')
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = 'plugin://plugin.video.vnmedia/resources/lib/mkd/onyoutube/tim/trailer_youtube/?search_query=%s' % re.sub(r'\W+',' ', item.label)
					item.art['thumb'] = item.art['landscape'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=1&size=400x400&ecc=L' % linkplay
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
					item.set_callback(index_fs, thumuc[1], 1)
					yield item
				elif 'file' in linkplay:
					item.label = d['title']
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = 'plugin://plugin.video.vnmedia/resources/lib/mkd/onyoutube/tim/trailer_youtube/?search_query=%s' % re.sub(r'\W+',' ', item.label)
					item.art['thumb'] = item.art['landscape'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=1&size=400x400&ecc=L' % linkplay
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					if __addon__.getSetting("taifshare") == "true":
						item.context.script(downloadfs, 'Tải về', linkplay)
					item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
					item.set_callback(play_fs, linkplay, item.label)
					yield item
	else:
		yield []
	dp.update(100)
	dp.close()