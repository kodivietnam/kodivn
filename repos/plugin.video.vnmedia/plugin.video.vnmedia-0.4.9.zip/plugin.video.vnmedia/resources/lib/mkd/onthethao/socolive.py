from codequick import Route, Listitem, run
from resources.lib.kedon import tb, getlink, stream, referer, play_vnm
import re
import json
@Route.register
def index_socolive(plugin, content_type='segment'):
	url = 'https://json.cvndnss.com/all_live_rooms.json'
	resp = getlink(url, url, 5*60)
	nd = re.search(r'\((.*?)}\)', resp.text).group(1) + '}'
	m = json.loads(nd)
	for k in m['data']['1']:
		item = Listitem()
		item.label = k['title']
		linktrandau = 'https://json.cvndnss.com/room/' + k['roomNum'] + '/detail.json'
		item.info['plot'] = tb
		item.art['thumb'] = 'https://sta.cvndnss.com/web/assets/soco/img/logo2.png'
		item.art['fanart'] = 'https://sta.cvndnss.com/web/assets/soco/img/logo2.png'
		item.set_callback(list_socolive, linktrandau, item.label)
		yield item

@Route.register
def list_socolive(plugin, url, title):
	resp = getlink(url, url, 5*60)
	nd = re.search(r'\((.*?)\)', resp.text).group(1)
	m = json.loads(nd)
	l = m['data']['stream']
	for key, value in l.items():
		item = Listitem()
		item.label = key + '-' + title
		if 'm3u8' in value:
			linktrandau = stream(value) + referer('https://socolive.org')
		else:
			linktrandau = value
		item.info['plot'] = tb
		item.art['thumb'] = 'https://sta.cvndnss.com/web/assets/soco/img/logo2.png'
		item.art['fanart'] = 'https://sta.cvndnss.com/web/assets/soco/img/logo2.png'
		item.set_callback(play_vnm, linktrandau, item.label, '')
		yield item