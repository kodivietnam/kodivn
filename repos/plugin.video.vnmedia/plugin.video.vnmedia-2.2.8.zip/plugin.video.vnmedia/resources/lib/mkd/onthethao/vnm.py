from codequick import Route, Listitem, Resolver
from importlib import import_module
from urllib.parse import unquote
@Route.register
def index_vnm(plugin, **kwargs):
	w = import_module('resources.lib.kedon')
	url = 'https://mi3s.top/vnmedia'
	resp = w.getlinkvnm(url, url).data.decode('utf-8')
	if resp:
		tach = [r.rstrip().split('|') for r in resp.splitlines() if r.strip()]
		for k in tach:
			item = Listitem()
			item.label = k[0]
			item.info['plot'] = w.tb
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = k[3]
			item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), unquote(k[1]).strip(), item.label, '')
			yield item
	else:
		yield w.quangcao()