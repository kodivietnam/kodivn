from codequick import Route, Listitem
from resources.lib.kedon import tb
@Route.register
def listiptv_root(plugin, **kwargs):
	T = {'Truyền hình FPT1': 'http://raw.githubusercontent.com/ntd249/ntdiptv/main/fptudp',
	'Truyền hình FPT2': 'http://raw.githubusercontent.com/thanh51/repository.thanh51/master/ONETV.m3u',
	'Truyền hình VNPT': 'http://raw.githubusercontent.com/ntd249/ntdiptv/main/mytvrtp',
	'Truyền hình Viettel': 'http://raw.githubusercontent.com/ntd249/ntdiptv/main/viettelrtp',
	'VietSimpleTV': 'http://vietcago.tk/tv.m3u',
	'KIPTV SPORT': 'http://hqth.me/kiptvs',
	'VthanhTV': 'http://vthanhtivi.pw',
	'PhapSonyTx5': 'http://raw.githubusercontent.com/rupanh123-phap/rupanh123-phap/main/Phaptx5.mp4',
	'Coocaa': 'http://hqth.me/coca',
	'Nguyễn Kiệt': 'http://raw.githubusercontent.com/ytpit20218/kiptv/main/kiptv.m3u',
	'VietNgaTV': 'http://raw.githubusercontent.com/phuhdtv/vietngatv/master/vietngatv.m3u',
	'Beartv': 'http://bit.ly/beartvplay',
	'PCRTV': 'http://hqth.me/pcriptv',
	'BepTV': 'http://live2.bep40.shop/b4tv.m3u',
	'360 Sport': 'http://hqth.me/90p',
	'Phim miễn phí': 'http://iptvvn.xyz/phimiptv',
	'Phim lẻ': 'http://hqth.me/phimle',
	'Phim lẻ tvhay': 'http://hqth.me/tvhayphimle',
	'Phim lẻ fptplay': 'http://hqth.me/fptphimle',
	'Phim bộ': 'http://hqth.me/phimbo',
	'ChinaTV': 'http://hqth.me/china-tv',
	'Quốc tế': 'http://raw.githubusercontent.com/thanh51/repository.thanh51/master/IPTV.m3u'}
	yield Listitem.from_dict(**{'label': 'Xem lại truyền hình',
	'info':{'plot':tb},
	'art':{'thumb':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/xemlaitv.png',
	'fanart':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/xemlaitv.png'},
	'callback':Route.ref('/resources/lib/mkd/ontruyenhinh/replayvtv:index_vtv')})
	yield Listitem.from_dict(**{'label': 'VTVGO',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/vtvgo.png',
	'fanart':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/vtvgo.png'},
	'callback':Route.ref('/resources/lib/mkd/ontruyenhinh/vtvgo:index_vtvgo')})
	for k in T:
		item = Listitem()
		item.label = k
		item.info['plot'] = tb
		item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/iptv.png'
		item.set_callback(Route.ref('/resources/lib/mkd/ontruyenhinh/listiptv:list_iptv'), T[k])
		yield item