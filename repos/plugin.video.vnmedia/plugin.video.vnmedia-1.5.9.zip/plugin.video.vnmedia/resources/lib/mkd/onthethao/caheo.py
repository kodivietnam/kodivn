from codequick import Route, Listitem, run
from datetime import datetime, timedelta
from urllib.parse import urlparse
from resources.lib.kedon import quangcao, getlink, stream, referer, play_vnm, caheo
l = caheo()[0]
m = urlparse(l)
url = f'{m.scheme}://{m.netloc}/'
@Route.register
def index_caheo(plugin, **kwargs):
	ux = f'{url}node-cache/get-lives-home'
	resp = getlink(ux, ux, 400)
	if resp is not None:
		if  '.m3u8' in resp.text:
			kq = resp.json()
			for m in kq['data'].values():
				for k in m:
					time = (datetime.fromisoformat(k['time'][:-1]) + timedelta(hours=7)).strftime('%H:%M %d-%m')
					doi1 = k['teamA']['name']
					doi2 = k['teamB']['name']
					blv1 = k['commentator']
					blv2 = k['commentatorCaHeo']
					if 'hlsUrlsCaHeo' in k:
						for e in k['hlsUrlsCaHeo']:
							if 'm3u8' in e['url']:
								item2 = Listitem()
								tentrandau2 = f'{e["name"]}-{time}: {doi1}-{doi2}'
								linktrandau2 = f'{stream(e["url"])}{referer(url)}'
								if blv2:
									item2.label = f'{tentrandau2} - BLV: {blv2}'
								else:
									item2.label = tentrandau2
								item2.art['thumb'] = item2.art['landscape'] = item2.art['fanart'] = 'https://i.imgur.com/KdSuVMn.png'
								item2.set_callback(play_vnm, linktrandau2, item2.label, '')
								yield item2
					for d in k['hlsUrls']:
						if 'm3u8' in d['url']:
							item1 = Listitem()
							tentrandau1 = f'{d["name"]}-{time}: {doi1}-{doi2}'
							linktrandau1 = f'{stream(d["url"])}{referer(url)}'
							if blv1:
								item1.label = f'{tentrandau1} - BLV: {blv1}'
							else:
								item1.label = tentrandau1
							item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://i.imgur.com/TTprlUP.png'
							item1.set_callback(play_vnm, linktrandau1, item1.label, '')
							yield item1
		else:
			yield quangcao()
	else:
		yield quangcao()