from codequick import Route, Listitem, Resolver, run
from resources.lib.kedon import tb, quangcao, useragentweb, news, stream, referer, qc, __addonnoti__, getlinkweb
from resources.lib.mkd.onfshare.ifshare import loginvgo
from bs4 import BeautifulSoup
import re, urllib, xbmcgui
@Route.register
def search_vgo(plugin,search_query, **kwargs):
	dp = xbmcgui.DialogProgress()
	dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
	dp.update(0)
	search_query = urllib.parse.quote_plus(search_query)
	url = f'https://vtvgo.vn/search.html?search-keyword={search_query.replace(" ","+")}'
	r = loginvgo().get(url)
	if r is not None:
		if 'news-slide-content-item' in r.text:
			soup = BeautifulSoup(r.content, 'html.parser')
			episodes = soup.select('div.news-slide-content-item')
			for episode in episodes:
				item = Listitem()
				item.label = episode.select_one('h2 a').get_text()
				linkphim = episode.select_one('h2 a').get('href')
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = episode.select_one('img').get('src')
				item.set_callback(ifr_vgo, linkphim, item.label)
				yield item
		else:
			Script.notify(__addonnoti__, 'Không tìm thấy kết quả')
			yield quangcao()
	else:
		yield quangcao()
	dp.update(100)
	dp.close()
@Route.register
def index_vtvgo(plugin, **kwargs):
	yield Listitem.search(search_vgo)
	khovideo = {'label': 'KHO VIDEO',
	'info': {'plot': 'Kho Video'},
	'art': {'thumb': 'https://wap.vtvgo.vn/vtvgo_all_device.png',
	'fanart': 'https://wap.vtvgo.vn/vtvgo_all_device.png'},
	'callback': index_khovd}
	tructuyenvtvgo = {'label': 'XEM TRỰC TUYẾN',
	'info': {'plot': 'Xem trực tuyến'},
	'art': {'thumb': 'https://wap.vtvgo.vn/vtvgo_all_device.png',
	'fanart': 'https://wap.vtvgo.vn/vtvgo_all_device.png'},
	'callback': list_truyenhinhvtvgo}
	yield Listitem.from_dict(**tructuyenvtvgo)
	yield Listitem.from_dict(**khovideo)
@Route.register
def list_truyenhinhvtvgo(plugin, **kwargs):
	url = 'https://vtvgo.vn/trang-chu.html'
	r = loginvgo().get(url)
	if r is not None:
		soup = BeautifulSoup(r.content, 'html.parser')
		episodes = soup.select('div.list_channel a')
		for episode in episodes:
			item = Listitem()
			linkkenh = episode.get('href')
			anh = episode.select_one('img').get('src')
			item.label = episode.get('alt')
			item.info['plot'] = tb
			item.art['thumb'] = item.art['landscape'] = anh
			item.art['fanart'] = 'https://is3-ssl.mzstatic.com/image/thumb/Purple126/v4/b2/97/48/b2974814-bc6e-3d59-8ea3-86ace210b426/AppIcon-0-0-1x_U007emarketing-0-0-0-7-0-0-sRGB-0-0-0-GLES2_U002c0-512MB-85-220-0-0.png/1200x600wa.png'
			item.set_callback(play_vtvgo, linkkenh, item.label)
			yield item
	else:
		yield quangcao()
@Route.register
def index_khovd(plugin, **kwargs):
	url = 'https://vtvgo.vn/kho-video.html'
	resp = loginvgo().get(url)
	if resp is not None:
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('a.color-white')
		for episode in episodes:
			item = Listitem()
			linkthumuc = episode.get('href')
			idthumuc = re.search(r'(\d+)\.', linkthumuc).group(1).replace('.', '')
			next_page = 1
			item.label = episode.get_text()
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://wap.vtvgo.vn/vtvgo_all_device.png'
			item.set_callback(list_thumucvd, idthumuc, next_page)
			yield item
	else:
		yield quangcao()
@Route.register
def list_thumucvd(plugin, idthumuc, next_page, **kwargs):
	url = f'https://vtvgo.vn/ajax-get-more-item-playlist?next_page={next_page}&channel_id={idthumuc}'
	resp = getlinkweb(url, url, 3600)
	if resp is not None:
		if 'http' in resp.text:
			soup = BeautifulSoup(resp.content, 'html.parser')
			episodes = soup.select('div.swiper-slide')
			for episode in episodes:
				item = Listitem()
				linkclip = episode.select_one('h2 a').get('href')
				tenclip = episode.select_one('h2 a').get_text()
				anhclip = episode.select_one('img').get('src')
				item.label = tenclip
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = anhclip
				item.set_callback(ifr_vgo, linkclip, item.label)
				yield item
			item = Listitem()
			item1 = Listitem()
			item1.label = f'Trang {next_page + 1}'
			item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
			item1.set_callback(list_thumucvd, idthumuc, next_page + 1)
			yield item1
		else:
			yield []
	else:
		yield quangcao()
@Resolver.register
def play_vtvgo(plugin, url, title, **kwargs):
	r = loginvgo().get(url)
	if r is not None:
		x = r.cookies.get_dict()
		time = re.search(r"var time = '(.*?)'", r.text)[1]
		token = re.search(r"var token = '(.*?)'", r.text)[1]
		id = re.search(r'var id = (.*?);', r.text)[1]
		urlx = 'https://vtvgo.vn/ajax-get-stream'
		payload = {'type_id': '1','id': id,'time': time,'token': token}
		headx = {'user-agent': useragentweb,
		'x-requested-with': 'XMLHttpRequest',
		'referer': f'https://vtvgo.vn/xem-truc-tuyen-kenh-vtv-{id}.html',
		'content-type': 'application/x-www-form-urlencoded; charset=UTF-8'}
		p = loginvgo().post(urlx, data=urllib.parse.urlencode(payload, quote_via=urllib.parse.quote), cookies=x, headers=headx)
		if '.m3u8' in p.text:
			linkplay = f'{stream(p.json()["chromecast_url"])}{referer(url)}'
		else:
			linkplay = stream(qc)
		if '.m3u8' in linkplay:
			return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
		else:
			return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay})
	else:
		linkplay = stream(qc)
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
@Resolver.register
def ifr_vgo(plugin,url,title, **kwargs):
	r = loginvgo().get(url)
	if r is not None:
		if '.m3u8' in r.text:
			match = re.search(r'((http|https)?:\/\/[^/\s]+/\S+?\.m3u8([^(\"|\')]*))', r.text)
			linkplay = f'{stream(match.group(1))}{referer(url)}'
		else:
			linkplay = stream(qc)
		if '.m3u8' in linkplay:
			return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
		else:
			return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay})
	else:
		linkplay = stream(qc)
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})