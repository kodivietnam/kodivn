from codequick import Route, Resolver, Listitem
from kodi_six import xbmc, xbmcgui
from resources.lib.addon_utils import get_item_label, get_item_media_path
from resources.lib.menu_utils import get_sorted_menu
@Route.register
def root(plugin):
    xbmc.executebuiltin('UpdateAddonRepos()')
    return generic_menu(plugin, 'root')
@Route.register
def generic_menu(plugin, item_id=None, **kwargs):
    if item_id is None:
        xbmc.executebuiltin(f'Action(Back,{xbmcgui.getCurrentWindowId()})')
        yield False
    else:
        menu_id = item_id
        plugin.redirect_single_item = True
        menu = get_sorted_menu(plugin, menu_id)
        if not menu:
            yield False
        for index, (item_order, item_id, item_infos) in enumerate(menu):
            item = Listitem()
            item.label = get_item_label(item_id, item_infos)
            if 'thumb' in item_infos:
                item.art['thumb'] = get_item_media_path(item_infos['thumb'])
            if 'fanart' in item_infos:
                item.art['fanart'] = get_item_media_path(
                    item_infos['fanart'])
            item.params['item_id'] = item_id
            if 'route' in item_infos:
                item.set_callback((Route.ref(item_infos['route'])))
            elif 'resolver' in item_infos:
                item.set_callback((Resolver.ref(item_infos['resolver'])))
            else:
                continue
            yield item