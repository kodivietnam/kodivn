from codequick import Route, Listitem, Resolver
from resources.lib.kedon import getlinkvnm, tb, quangcao, getlink, referer, stream
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
from bs4 import BeautifulSoup
from functools import lru_cache
import re, sys
@lru_cache(maxsize=None)
def respphut90():
	url = 'http://bit.ly/tiengruoi'
	r = getlinkvnm(url, url)
	try:
		tr = BeautifulSoup(r.content, 'html.parser').select_one('a[target="_blank"]').get('href')
		resp90 = getlinkvnm(tr, tr)
		if (resp90 is not None):
			html_content = re.sub(r"(\n\s*//.*)", "", resp90.text)
			ref = re.search(r'base_embed_url\s*=\s*("|\')([^"\s]+)("|\')', html_content)[2]
		else:
			ref = tr
		return ref
	except:
		sys.exit()
def get_tv1():
	return getlinkvnm('https://api.vebo.xyz/api/match/featured', 'https://90m.tv/')
def get_tv2():
	return getlinkvnm('https://api.vebo.xyz/api/match/featured/mt', 'https://90m.tv/')
@Route.register
def index_90p(plugin, **kwargs):
	ref = respphut90()
	with ThreadPoolExecutor(2) as ex:
		f1 = ex.submit(get_tv1)
		f2 = ex.submit(get_tv2)
		resp1 = f1.result()
		resp2 = f2.result()
	if (resp1 is not None) or (resp2 is not None):
		for k1 in resp1.json()['data']:
			item1 = Listitem()
			time = datetime.fromtimestamp(int(k1['timestamp'])/1000).strftime('%H:%M %d-%m')
			if k1['commentators']:
				item1.label = f'[COLOR yellow]{time}: {k1["name"]} ({k1["commentators"][0]["name"]})[/COLOR]'
			else:
				item1.label = f'[COLOR yellow]{time}: {k1["name"]}[/COLOR]'
			item1.info['plot'] = tb
			item1.art['thumb'] = item1.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/90p.png'
			item1.set_callback(list_90p, k1['id'], item1.label)
			yield item1
		for k2 in resp2.json()['data']:
			item2 = Listitem()
			time = datetime.fromtimestamp(int(k2['timestamp'])/1000).strftime('%H:%M %d-%m')
			if k2['commentators']:
				item2.label = f'{time}: {k2["name"]} ({k2["commentators"][0]["name"]})'
			else:
				item2.label = f'{time}: {k2["name"]}'
			item2.info['plot'] = tb
			item2.art['thumb'] = item2.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/vebo.png'
			item2.set_callback(list_90p, k2['id'], item2.label)
			yield item2
	else:
		yield quangcao()
@Route.register
def list_90p(plugin, idk, title, **kwargs):
	ref = respphut90()
	url = f'http://api.vebo.xyz/api/match/{idk}/meta'
	resp = getlink(url, ref, 400)
	if (resp is not None) and ('.m3u8' in resp.text):
		kq = resp.json()
		for k in kq['data']['play_urls']:
			item = Listitem()
			item.label = f'{k["name"]} - {title}'
			item.info['plot'] = tb
			item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/90p.png'
			item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), f'{stream(k["url"])}{referer(ref)}', item.label, '')
			yield item
	else:
		yield quangcao()