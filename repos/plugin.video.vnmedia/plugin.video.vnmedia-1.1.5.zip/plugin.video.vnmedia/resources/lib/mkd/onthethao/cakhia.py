from codequick import Route, Listitem, run
from datetime import datetime, timedelta
from bs4 import BeautifulSoup
from urllib.parse import urlparse
from resources.lib.kedon import quangcao, getlink, stream, referer, play_vnm, tb, cakhia
l = cakhia()[0]
m = urlparse(l)
url = '%s://%s/' % (m.scheme, m.netloc)
@Route.register
def index_cakhia(plugin, **kwargs):
	ux = '%snode-cache/get-lives-home' % url
	resp = getlink(ux, ux, 6*60)
	if 'm3u8' in resp.text:
		kq = resp.json()
		for k1 in kq['data']['liveMatchings']:
			for k2 in k1['hlsUrls']:
				item1 = Listitem()
				if 'm3u8' in k2['url'] and k2['name']:
					time1 = (datetime.fromisoformat(k1['time'][:-1]) + timedelta(hours=7)).strftime('%H:%M %d-%m')
					linktrandau1 = '%s%s' % (stream(k2['url']), referer(url))
					tentrandau1 = '%s-%s: %s-%s' % (k2['name'], time1, k1['teamA']['name'], k1['teamB']['name'])
					if k1['commentator']:
						item1.label = '%s - BLV: %s' % (tentrandau1, k1['commentator'])
					else:
						item1.label = tentrandau1
					item1.info['plot'] = tb
					item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://i.imgur.com/TTprlUP.png'
					item1.set_callback(play_vnm, linktrandau1, item1.label, '')
					yield item1
			for k2 in k1['hlsUrlsCaHeo']:
				item1 = Listitem()
				if 'm3u8' in k2['url'] and k2['name']:
					time1 = (datetime.fromisoformat(k1['time'][:-1]) + timedelta(hours=7)).strftime('%H:%M %d-%m')
					linktrandau1 = '%s%s' % (stream(k2['url']), referer(url))
					tentrandau1 = '%s-%s: %s-%s' % (k2['name'], time1, k1['teamA']['name'], k1['teamB']['name'])
					if k1['commentatorCaHeo']:
						item1.label = '%s - BLV: %s' % (tentrandau1, k1['commentatorCaHeo'])
					else:
						item1.label = tentrandau1
					item1.info['plot'] = tb
					item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://i.imgur.com/KdSuVMn.png'
					item1.set_callback(play_vnm, linktrandau1, item1.label, '')
					yield item1
		for b1 in kq['data']['livesSapDienRa']:
			for b2 in b1['hlsUrls']:
				item2 = Listitem()
				if 'm3u8' in b2['url'] and b2['name']:
					time2 = (datetime.fromisoformat(b1['time'][:-1]) + timedelta(hours=7)).strftime('%H:%M %d-%m')
					linktrandau2 = '%s%s' % (stream(b2['url']), referer(url))
					tentrandau2 = '%s-%s: %s-%s' % (b2['name'], time2, b1['teamA']['name'], b1['teamB']['name'])
					if b1['commentator']:
						item2.label = '%s - BLV: %s' % (tentrandau2, b1['commentator'])
					else:
						item2.label = tentrandau2
					item2.info['plot'] = tb
					item2.art['thumb'] = item2.art['landscape'] = item2.art['fanart'] = 'https://i.imgur.com/TTprlUP.png'
					item2.set_callback(play_vnm, linktrandau2, item2.label, '')
					yield item2
			if 'hlsUrlsCaHeo' in b1:
				for b2 in b1['hlsUrlsCaHeo']:
					item2 = Listitem()
					if 'm3u8' in b2['url'] and b2['name']:
						time2 = (datetime.fromisoformat(b1['time'][:-1]) + timedelta(hours=7)).strftime('%H:%M %d-%m')
						linktrandau2 = '%s%s' % (stream(b2['url']), referer(url))
						tentrandau2 = '%s-%s: %s-%s' % (b2['name'], time2, b1['teamA']['name'], b1['teamB']['name'])
						if b1['commentatorCaHeo']:
							item2.label = '%s - BLV: %s' % (tentrandau2, b1['commentatorCaHeo'])
						else:
							item2.label = tentrandau2
						item2.info['plot'] = tb
						item2.art['thumb'] = item2.art['landscape'] = item2.art['fanart'] = 'https://i.imgur.com/KdSuVMn.png'
						item2.set_callback(play_vnm, linktrandau2, item2.label, '')
						yield item2
	else:
		yield quangcao()