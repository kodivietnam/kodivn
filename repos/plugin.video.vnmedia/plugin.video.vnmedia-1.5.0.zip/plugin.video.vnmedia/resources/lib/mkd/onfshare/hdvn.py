from codequick import Route, Listitem, run, Script
from bs4 import BeautifulSoup
from resources.lib.kedon import quangcao, getlink, play_fs, __addonnoti__, get_info_fs, __addon__
from resources.lib.mkd.onfshare.ifshare import index_fs, loginfhdvn, likehdvn, tfavo, hdvn
from resources.lib.download import downloadfs
import xbmcgui, urllib, re, threading
threads = []
dulieu = {}
def get_html(link):
    dulieu[link] = get_info_fs(link)
nhomhdvn = {
'4K': '%s/forums/4k.337/' % hdvn,
'WEB-DL, HDTV 4K': '%s/forums/web-dl-hdtv-4k.344/' % hdvn,
'Bluray Remux 4K': '%s/forums/bluray-remux-4k.345/' % hdvn,
'Bluray Nguyên Gốc 4K': '%s/forums/bluray-nguyen-goc-4k.346/' % hdvn,
'Fshare.vn': '%s/forums/fshare-vn.33/'  % hdvn,
'Fshare-WEB-DL, HDTV': '%s/forums/web-dl-hdtv.271/' % hdvn,
'Fshare-Bluray Remux': '%s/forums/bluray-remux.324/' % hdvn,
'Fshare-mHD, SD': '%s/forums/mhd-sd.77/' % hdvn,
'Fshare-Bluray nguyên gốc': '%s/forums/bluray-nguyen-goc.78/' % hdvn,
'Thư viện link Phim': '%s/forums/thu-vien-link-phim.150/' % hdvn,
'Phim có audio Việt': '%s/forums/phim-co-audio-viet.265/' % hdvn,
'Phim bộ - Series': '%s/forums/phim-bo-series.57/' % hdvn,
'Phim bộ - mHD, SD': '%s/forums/mhd-sd.104/' % hdvn,
'Phim hoạt hình': '%s/forums/phim-hoat-hinh.123/' % hdvn,
'Phim hoạt hình - mHD, SD': '%s/forums/mhd-sd.124/' % hdvn,
'Phim tài liệu - Documentaries': '%s/forums/phim-tai-lieu-documentaries.116/' % hdvn,
'Phim 3D': '%s/forums/3d.110/' % hdvn,
'Phim cho iOS/Android': '%s/forums/phim-cho-ios-android.157/' % hdvn,
'Music request': '%s/forums/music-request.28/' % hdvn,
'HD Video Clip': '%s/forums/hd-video-clip.50/' % hdvn,
'Video nhạc US-EU': '%s/forums/us-eu.189/' % hdvn,
'Video nhạc Việt Nam': '%s/forums/viet-nam.191/' % hdvn,
'Video nhạc Asia': '%s/forums/asia.190/' % hdvn,
'Soundtrack': '%s/forums/soundtrack.73/' % hdvn,
'Lossless Albums': '%s/forums/lossless-albums.26/' % hdvn,
'Lossless Việt Nam': '%s/forums/nhac-viet-nam.183/' % hdvn,
'Lossless Quốc tế': '%s/forums/nhac-quoc-te.184/' % hdvn,
'Lossless không lời': '%s/forums/nhac-khong-loi.185/' % hdvn,
'Lossy albums': '%s/forums/lossy-albums.27/' % hdvn,
'mHD, SD Video Clips': '%s/forums/mhd-sd-video-clips.25/' % hdvn
}
@Route.register
def search_hdvn(plugin,search_query, **kwargs):
    dp = xbmcgui.DialogProgress()
    dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
    dp.update(0)
    search_query = urllib.parse.quote_plus(search_query)
    url = '%s/search/2022/?page=1&q=%s&t=post&o=date&c[node]=337+344+345+346+33+271+324+77+78' % (hdvn, search_query.replace(' ','+'))
    r = getlink(url, url, 2*24*60*60)
    if r is not None:
        idsearch = re.search(r'search/([0-9]+)', r.url).group(1)
        if 'titleText' in r.text:
            soup = BeautifulSoup(r.content, 'html.parser')
            episodes = soup.select('div.titleText a')
            for episode in episodes:
                item = Listitem()
                item.label = episode.get_text()
                item.info['mediatype'] = 'episode'
                item.info['rating'] = 10.0
                item.info['trailer'] = 'plugin://plugin.video.vnmedia/resources/lib/mkd/onyoutube/tim/trailer_youtube/?search_query=%s' % re.sub(r'[^a-zA-Z0-9]',' ', item.label)
                linkphim = episode.get('href')
                item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = '%s/images/hd-vietnam-logo.png' % hdvn
                item.set_callback(hdvn_link, linkphim)
                yield item
            yield Listitem.next_page(search_query, 2, idsearch, callback=search_hdvnnext)
        else:
            Script.notify(__addonnoti__, 'Không tìm thấy kết quả')
            yield quangcao()
    else:
        yield quangcao()
    dp.update(100)
    dp.close()

@Route.register
def search_hdvnnext(plugin,search_query, next_page, idsearch, **kwargs):
    search_query = urllib.parse.quote_plus(search_query)
    url = '%s/search/%s/?page=%s&q=%s&t=post&o=date&c[node]=337+344+345+346+33+271+324+77+78' % (hdvn, idsearch, next_page, search_query.replace(' ','+'))
    r = getlink(url, url, 2*24*60*60)
    if r is not None:
        if 'titleText' in r.text:
            soup = BeautifulSoup(r.content, 'html.parser')
            episodes = soup.select('div.titleText a')
            for episode in episodes:
                item = Listitem()
                item.label = episode.get_text()
                item.info['mediatype'] = 'episode'
                item.info['rating'] = 10.0
                item.info['trailer'] = 'plugin://plugin.video.vnmedia/resources/lib/mkd/onyoutube/tim/trailer_youtube/?search_query=%s' % re.sub(r'[^a-zA-Z0-9]',' ', item.label)
                linkphim = episode.get('href')
                item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = '%s/images/hd-vietnam-logo.png' % hdvn
                item.set_callback(hdvn_link, linkphim)
                yield item
            item1 = Listitem()
            item1.label = 'Trang %s' % (next_page + 1)
            item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
            item1.set_callback(search_hdvnnext, search_query, next_page + 1, idsearch)
            yield item1
        else:
            Script.notify(__addonnoti__, 'Không tìm thấy kết quả')
            yield quangcao()
    else:
        yield quangcao()
@Route.register
def index_hdvn(plugin, **kwargs):
    yield Listitem.search(search_hdvn)
    for tenlist, urllist in list(nhomhdvn.items()):
        item = Listitem()
        item.label = tenlist
        item.art['thumb'] = item.art['landscape'] = '%s/images/hd-vietnam-logo.png'  % hdvn
        item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
        item.set_callback(hdvn_page, url=urllist, next_page=1)
        yield item

@Route.register
def hdvn_page(plugin, url, next_page, **kwargs):
    trangtiep = '%spage-%s' % (url, next_page)
    r = getlink(trangtiep, trangtiep, 15*60)
    if r is not None:
        soup = BeautifulSoup(r.content, 'html.parser')
        episodes = soup.select('a.PreviewTooltip')
        for episode in episodes:
            item = Listitem()
            linkphim = episode.get('href')
            p = episode.get_text()
            item.label = re.sub('[\[\]\{\}]','|', p)
            item.info['mediatype'] = 'episode'
            item.info['rating'] = 10.0
            item.info['trailer'] = 'plugin://plugin.video.vnmedia/resources/lib/mkd/onyoutube/tim/trailer_youtube/?search_query=%s' % re.sub(r'[^a-zA-Z0-9]',' ', item.label)
            item.art['thumb'] = item.art['landscape'] = '%s/images/hd-vietnam-logo.png' % hdvn
            item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
            item.set_callback(hdvn_link, linkphim)
            yield item
        item1 = Listitem()
        item1.label = 'Trang %s' % (next_page + 1)
        item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
        item1.set_callback(hdvn_page, url, next_page + 1)
        yield item1
    else:
        yield quangcao()

@Route.register
def hdvn_link(plugin, url, **kwargs):
    likehdvn(url)
    r = loginfhdvn().get('%s/%s' % (hdvn, url))
    if 'fshare.vn' in r.text:
        soup = BeautifulSoup(r.content, 'html.parser')
        episodes = soup.select('a.externalLink')
        urls = []
        for episode in episodes:
            if 'fshare.vn' in episode.get('href'):
                linkphim = episode.get('href')
                urls.append(linkphim)
        length = len(episodes)
        done = len(urls)
        progress = int(done * 100 / length)
        dialog = xbmcgui.DialogProgress()
        dialog.create('%s đang giải mã...' % __addonnoti__, 'Đang giải mã %d dữ liệu...' % length)
        dialog.update(progress, 'Đang giải mã %d/%d dữ liệu...' % (done, length))
        for link in urls:
            thread = threading.Thread(target=get_html, args=(link, ))
            thread.start()
            threads.append(thread)
        for t in threads:
            t.join()
        for k in urls:
            x = dulieu[k]
            ten = x[0]
            dungluong = x[1]
            diachi = x[2]
            item = Listitem()
            if 'folder' in diachi:
                item.label = ten
                thumuc = diachi.split('folder/')
                item.info['mediatype'] = 'episode'
                item.info['rating'] = 10.0
                item.info['trailer'] = 'plugin://plugin.video.vnmedia/resources/lib/mkd/onyoutube/tim/trailer_youtube/?search_query=%s' % re.sub(r'[^a-zA-Z0-9]',' ', item.label)
                item.art['thumb'] = item.art['landscape'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=1&size=400x400&ecc=L' % link
                item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
                item.context.script(tfavo, 'Thêm vào Fshare Favorite', diachi)
                item.set_callback(index_fs, thumuc[1], 1)
                yield item
            elif 'file' in diachi:
                item.label = ten
                item.info['size'] = dungluong
                item.info['mediatype'] = 'episode'
                item.info['rating'] = 10.0
                item.info['trailer'] = 'plugin://plugin.video.vnmedia/resources/lib/mkd/onyoutube/tim/trailer_youtube/?search_query=%s' % re.sub(r'[^a-zA-Z0-9]',' ', item.label)
                item.art['thumb'] = item.art['landscape'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=1&size=400x400&ecc=L' % link
                item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
                if __addon__.getSetting("taifshare") == "true":
                    item.context.script(downloadfs, 'Tải về', diachi)
                item.context.script(tfavo, 'Thêm vào Fshare Favorite', diachi)
                item.set_callback(play_fs, diachi, item.label)
                yield item
            dialog.update(100)
            dialog.close()
    else:
        yield quangcao()