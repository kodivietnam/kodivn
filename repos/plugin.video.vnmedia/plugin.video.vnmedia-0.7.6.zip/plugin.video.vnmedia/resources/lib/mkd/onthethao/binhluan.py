from codequick import Route, Listitem, run
from resources.lib.kedon import quangcao, getlink, stream, referer, play_vnm, tb

binhluantv = 'https://xoilac.90phuttttttttt.xyz'
@Route.register
def index_binhluan(plugin, **kwargs):
	url = binhluantv + '/api/matches-in-home?id=0'
	resp = getlink(url, url, 10*60)
	kq = resp.json()
	for k in kq[0]['data']:
		item1 = Listitem()
		ten = '[LIVE]' + k['title']
		linktran = binhluantv + '/api/match/' + k['_id']
		item1.info['plot'] = tb
		item1.label = ten
		item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://xoilac.90phuttttttttt.xyz/imgs/logo.png'
		item1.set_callback(list_binhluantv, linktran, item1.label)
		yield item1
	for m in kq[1]['data']:
		item2 = Listitem()
		time = m['timeStartPlayMod']
		ngay = m['dayinweek']
		ten = m['title']
		linktran = binhluantv + '/api/match/' + m['_id']
		item2.info['plot'] = tb
		item2.label = time + ' ' + ngay + ' ' + ten
		item2.art['thumb'] = item2.art['landscape'] = item2.art['fanart'] = 'https://xoilac.90phuttttttttt.xyz/imgs/logo.png'
		item2.set_callback(list_binhluantv, linktran, item2.label)
		yield item2

@Route.register
def list_binhluantv(plugin, url, title, **kwargs):
	resp = getlink(url, url, 0)
	kq = resp.json()
	if 'm3u8' in resp.text:
		for k in kq['streamsLink']:
			item = Listitem()
			ten = k['label'] + ' ' + title
			linktran = stream(k['link'].replace('\t','')) + referer(url)
			item.info['plot'] = tb
			item.label = ten
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://xoilac.90phuttttttttt.xyz/imgs/logo.png'
			item.set_callback(play_vnm, linktran, item.label, '')
			yield item
	else:
		yield quangcao()