from codequick import Route, Listitem, run
from resources.lib.kedon import getlink, play_vnm, stream
import datetime
@Route.register
def get_thvl(plugin, ten, hom, **kwargs):
	if ten == 'thvl1':
		idk = 'aab94d1f-44e1-4992-8633-6d46da08db42'
	elif ten == 'thvl2':
		idk = 'bc60bddb-99ac-416e-be26-eb4d0852f5cc'
	elif ten == 'thvl3':
		idk = 'f2ad2726-d315-4612-b78d-746721788fc8'
	elif ten == 'thvl4':
		idk = '442692d6-c296-4835-b060-72c4cd235bd2'
	else:
		yield []
	url = 'https://api.thvli.vn/backend/cm/epg/?channel_id=' + idk + '&platform=web&schedule_date=' + str(hom)
	resp = getlink(url, url, 0)
	for k in resp.json()['items']:
		item = Listitem()
		tg = datetime.datetime.fromtimestamp(k['start_at']).strftime('%H:%M')
		item.label = tg + ' ' + str(hom) + ': ' + k['title']
		linkplay = stream(str(k['link_play']))
		item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
		item.set_callback(play_vnm, linkplay, item.label, '')
		yield item