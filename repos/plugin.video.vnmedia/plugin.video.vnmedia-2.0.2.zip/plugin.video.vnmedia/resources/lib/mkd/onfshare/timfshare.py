from codequick import Route, Listitem, run
dulieu = {}
def get_tkfs1(search_query):
	from resources.lib.kedon import getlinkphongblack
	urlvmf = f'http://phongblack.me/search.php?author=phongblack&search={search_query}'
	dulieu[get_tkfs1] = getlinkphongblack(urlvmf, 'http://www.google.com', 3600)
def get_tkfs2(search_query):
	from resources.lib.kedon import postlinktimfs
	url = f'https://api.timfshare.com/v1/string-query-search?query={search_query}'
	dulieu[get_tkfs2] = postlinktimfs(url, 'https://timfshare.com/', 3600)
def get_tkfs3(search_query):
	from resources.lib.kedon import getlink
	urltvhd = f'https://thuvienhd.com/?feed=fsharejson&search={search_query}'
	dulieu[get_tkfs3] = getlink(urltvhd, 'https://thuvienhd.com/', 3600)
@Route.register
def searchfs(plugin, search_query, **kwargs):
	from resources.lib.kedon import tb, play_fs, __addonnoti__, yttk
	import xbmcgui, threading, urllib, re, xbmcaddon
	dp = xbmcgui.DialogProgress()
	dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
	dp.update(5)
	search_query = urllib.parse.quote_plus(search_query)
	t1 = threading.Thread(target=get_tkfs1, args=(search_query, ))
	t2 = threading.Thread(target=get_tkfs2, args=(search_query, ))
	t3 = threading.Thread(target=get_tkfs3, args=(search_query, ))
	t1.start()
	t2.start()
	t3.start()
	t1.join()
	t2.join()
	t3.join()
	if dulieu[get_tkfs1] is not None:
		from resources.lib.mkd.onfshare.ifshare import index_fs, tfavo
		x = dulieu[get_tkfs1].json()['items']
		for m in x:
			item1 = Listitem()
			ten = re.sub('[\[\]\{\}]','|', m['label'])
			if 'info' in m:
				mota = m['info']['plot']
			path = m['path']
			if '/file/' in path:
				item1.label = ten
				link = path.split('&url=')
				linkplay = link[1]
				item1.info['mediatype'] = 'episode'
				item1.info['rating'] = 10.0
				item1.info['trailer'] = yttk(item1.label)
				item1.art['thumb'] = item1.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
				item1.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item1.info['plot'] = f'{mota}\n{tb}'
				if xbmcaddon.Addon().getSetting("taifshare") == "true":
					from resources.lib.download import downloadfs
					item1.context.script(downloadfs, 'Tải về', linkplay)
				item1.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
				item1.set_callback(play_fs, linkplay, item1.label)
				yield item1
			elif '/folder/' in path:
				item1.label = ten
				link = path.split('&url=')
				linkplay = link[1]
				thumuc = linkplay.split('folder/')
				item1.info['mediatype'] = 'episode'
				item1.info['rating'] = 10.0
				item1.info['trailer'] = yttk(item1.label)
				item1.art['thumb'] = item1.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
				item1.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item1.info['plot'] = f'{mota}\n{tb}'
				item1.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
				item1.set_callback(index_fs, thumuc[1], 1)
				yield item1
	else:
		yield []
	if dulieu[get_tkfs2] is not None:
		from resources.lib.mkd.onfshare.ifshare import index_fs, tfavo
		kq = dulieu[get_tkfs2].json()
		if 'data' in kq:
			for k in kq['data']:
				item = Listitem()
				linkplay = k['url']
				if 'folder' in linkplay:
					item.label = k['name']
					thumuc = linkplay.split('folder/')
					item.info['plot'] = tb
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(item.label)
					item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
					item.set_callback(index_fs, thumuc[1], 1)
					yield item
				elif 'file' in linkplay:
					item.label = k['name']
					item.info['plot'] = tb
					item.info['size'] = k['size']
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(item.label)
					item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					if xbmcaddon.Addon().getSetting("taifshare") == "true":
						from resources.lib.download import downloadfs
						item.context.script(downloadfs, 'Tải về', linkplay)
					item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
					item.set_callback(play_fs, linkplay, item.label)
					yield item
	else:
		yield []
	if dulieu[get_tkfs3] is not None:
		from resources.lib.mkd.onfshare.ifshare import index_fs, tfavo
		kqtvhd = dulieu[get_tkfs3].json()
		for t in kqtvhd:
			for d in t['links']:
				item = Listitem()
				linkplay = d['link']
				if 'folder' in linkplay:
					item.label = d['title']
					thumuc = linkplay.split('folder/')
					item.info['plot'] = f'{t["title"]}\n{tb}'
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(item.label)
					item.art['thumb'] = item.art['landscape'] = t['image']
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
					item.set_callback(index_fs, thumuc[1], 1)
					yield item
				elif 'file' in linkplay:
					item.label = d['title']
					item.info['plot'] = f'{t["title"]}\n{tb}'
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(item.label)
					item.art['thumb'] = item.art['landscape'] = t['image']
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					if xbmcaddon.Addon().getSetting("taifshare") == "true":
						from resources.lib.download import downloadfs
						item.context.script(downloadfs, 'Tải về', linkplay)
					item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
					item.set_callback(play_fs, linkplay, item.label)
					yield item
	else:
		yield []
	dp.update(100)
	dp.close()
@Route.register
def index_pdx(plugin, **kwargs):
	from resources.lib.kedon import tb, play_fs, getlink, yttk
	urltvhd = 'https://thuvienhd.com/?feed=fsharejson&search='
	resptvhd = getlink(urltvhd, 'https://thuvienhd.com/', 3600)
	if resptvhd is not None:
		from resources.lib.mkd.onfshare.ifshare import index_fs, tfavo
		import xbmcaddon
		kqtvhd = resptvhd.json()
		for t in kqtvhd:
			for d in t['links']:
				item = Listitem()
				linkplay = d['link']
				if 'folder' in linkplay:
					item.label = d['title']
					thumuc = linkplay.split('folder/')
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(item.label)
					item.info['plot'] = f'{t["title"]}\n{tb}'
					item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = t['image']
					item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
					item.set_callback(index_fs, thumuc[1], 1)
					yield item
				elif 'file' in linkplay:
					item.label = d['title']
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(item.label)
					item.info['plot'] = f'{t["title"]}\n{tb}'
					item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = t['image']
					if xbmcaddon.Addon().getSetting("taifshare") == "true":
						from resources.lib.download import downloadfs
						item.context.script(downloadfs, 'Tải về', linkplay)
					item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
					item.set_callback(play_fs, linkplay, item.label)
					yield item
	else:
		yield []