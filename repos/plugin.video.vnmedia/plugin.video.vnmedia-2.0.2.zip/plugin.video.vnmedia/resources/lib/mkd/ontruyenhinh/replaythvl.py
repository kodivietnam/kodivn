from codequick import Route, Listitem, run
@Route.register
def get_thvl(plugin, ten, hom, **kwargs):
	import datetime
	from resources.lib.kedon import getlink, play_vnm, stream, quangcao
	if ten == 'thvl1':
		idk = 'aab94d1f-44e1-4992-8633-6d46da08db42'
	elif ten == 'thvl2':
		idk = 'bc60bddb-99ac-416e-be26-eb4d0852f5cc'
	elif ten == 'thvl3':
		idk = 'f2ad2726-d315-4612-b78d-746721788fc8'
	elif ten == 'thvl4':
		idk = '442692d6-c296-4835-b060-72c4cd235bd2'
	url = f'http://api.thvli.vn/backend/cm/epg/?channel_id={idk}&platform=web&schedule_date={hom}'
	resp = getlink(url, url, -1)
	if resp is not None:
		for k in resp.json()['items']:
			if '.m3u8' in str(k['link_play']):
				item = Listitem()
				tg = datetime.datetime.fromtimestamp(k['start_at']).strftime('%H:%M')
				item.label = f'{tg} {hom}: {k["title"]}'
				linkplay = stream(str(k['link_play']))
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
				item.set_callback(play_vnm, linkplay, item.label, '')
				yield item
	else:
		yield quangcao()
@Route.register
def get_vtv(plugin, ten, hom, **kwargs):
	import datetime
	from resources.lib.kedon import getlink, play_vnm, stream, referer, quangcao
	if ten == '3':
		idk = 'dac12e23-ebcc-4c69-aaf5-5b2b8d47c41f'
	elif ten == '4':
		idk = 'f86bb850-f6ef-4c9d-b0ad-b8fe16ef27e9'
	elif ten == '110':
		idk = '070e2561-5d82-459d-b769-8210fd48fbf4'
	elif ten == '98':
		idk = 'd055b75f-05c9-4799-8581-c46b60b878dd'
	url = f'http://api.tv360.vn/public/v1/live/get-live-schedule?id={ten}&datetime={hom}'
	resp = getlink(url, url, -1)
	if resp is not None and 'duration' in resp.text:
		for k in resp.json()['data']['schedules']:
			item = Listitem()
			ngaytime = k['datetime']
			gio = k['startTime']
			ngay = k['date']
			ten = k['name']
			timebd = int(datetime.datetime.strptime(ngaytime + ' ' + gio, '%Y-%m-%d %H:%M').timestamp())
			timekt = timebd + k['duration']
			linkget = f'http://live.tv360.vn/manifest/{idk}/catchup/720p/720p.m3u8?media=true&start={timebd}&stop={timekt}'
			item.label = f'{gio} {ngay}: {ten}'
			linkplay = f'{stream(linkget)}{referer("http://tv360.vn/")}'
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
			item.set_callback(play_vnm, linkplay, item.label, '')
			yield item
	else:
		yield quangcao()