from codequick import Route, Listitem, run
@Route.register
def list_iptv(plugin, url, **kwargs):
	from resources.lib.kedon import logotv, tb, getlinkip, quangcao
	import re
	item = Listitem()
	item.label = 'TẤT CẢ CÁC KÊNH'
	item.info['plot'] = tb
	item.art['thumb'] = item.art['landscape'] = 'https://i.imgur.com/Mnuw95h.png'
	item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
	item.set_callback(little_iptv, url)
	yield item
	resp = getlinkip(url, url, 1000)
	if resp is not None:
		rp = resp.data.decode('utf-8')
		group = re.findall('group-title="(.*?)"', rp)
		um = []
		for tk in list(dict.fromkeys(group)):
			if ';' in tk:
				[um.append(k) for k in tk.split(';') if k not in um]
			else:
				um.append(tk)
		if '' in um:
			um.remove('')
		for p in um:
			item = Listitem()
			item.label = p
			item.info['plot'] = tb
			item.art['thumb'] = item.art['landscape'] = 'https://i.imgur.com/Mnuw95h.png'
			item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
			item.set_callback(info_iptv, url, p)
			yield item
	else:
		yield quangcao()
@Route.register
def info_iptv(plugin, url, tk, **kwargs):
	from resources.lib.kedon import logotv, tb, getlinkip, streamiptv, ace, play_vnm, quangcao, useragentott, referer
	import re
	resp = getlinkip(url, url, 1000)
	if resp is not None:
		if 'EXTINF' in resp.data.decode('utf-8'):
			rp = resp.data.decode('utf-8')
			tp = re.sub('M3U(.*?)\n|#[^EXT](.*?)\n', '', rp)
			ketqua = tp.split('#EXTINF')
			for tach in ketqua:
				kq = "\n".join([ll.rstrip() for ll in tach.splitlines() if ll.strip()])
				timuser = re.search(r'http-user-agent=(.*?)\n', kq)
				if timuser:
					user = timuser.group(1)
				else:
					user = useragentott
				k = kq.split('\n')
				item = Listitem()
				if len(k)>1:
					if f'group-title="{tk}"' in k[0] and ';' not in k[0]:
						if '://' in k[-1]:
							tenkenh = re.search('[,](?!.*[,])(.*?)$', k[0]).group(1)
							item.label = tenkenh
							kenh = k[-1]
							if 'acestream' in kenh:
								linkplay = ace(kenh, item.label)
								item.path = linkplay
								item.set_callback(item.path)
							elif ':6878' in kenh:
								linkplay = ace(kenh, item.label)
								item.path = linkplay
								item.set_callback(item.path)
							else:
								if 'http-referrer' in kq:
									refe = re.search(r'http-referrer=(.*?)\n', kq).group(1)
									linkplay = f'{streamiptv(kenh.strip(), user)}{referer(refe)}'
								else:
									linkplay = streamiptv(kenh.strip(), user)
								item.set_callback(play_vnm, linkplay, item.label, '')
							logo = re.search('tvg-logo="(.*?)"', k[0])
							if logo:
								item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = logo.group(1)
							else:
								item.art['thumb'] = item.art['landscape'] = logotv
								item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
							item.info['plot'] = tb
							yield item
					elif tk in k[0] and ';' in k[0]:
						if '://' in k[-1]:
							tenkenh = re.search('[,](?!.*[,])(.*?)$', k[0]).group(1)
							item.label = tenkenh
							kenh = k[-1]
							if 'acestream' in kenh:
								linkplay = ace(kenh, item.label)
								item.path = linkplay
								item.set_callback(item.path)
							elif ':6878' in kenh:
								linkplay = ace(kenh, item.label)
								item.path = linkplay
								item.set_callback(item.path)
							else:
								if 'http-referrer' in kq:
									refe = re.search(r'http-referrer=(.*?)\n', kq).group(1)
									linkplay = f'{streamiptv(kenh.strip(), user)}{referer(refe)}'
								else:
									linkplay = streamiptv(kenh.strip(), user)
								item.set_callback(play_vnm, linkplay, item.label, '')
							logo = re.search('tvg-logo="(.*?)"', k[0])
							if logo:
								item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = logo.group(1)
							else:
								item.art['thumb'] = item.art['landscape'] = logotv
								item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
							item.info['plot'] = tb
							yield item
		else:
			yield quangcao()
	else:
		yield quangcao()
@Route.register
def little_iptv(plugin, url, **kwargs):
	from resources.lib.kedon import logotv, tb, getlinkip, streamiptv, ace, play_vnm, quangcao, useragentott, referer
	import re
	resp = getlinkip(url, url, 1000)
	if resp is not None:
		if 'EXTINF' in resp.data.decode('utf-8'):
			rp = resp.data.decode('utf-8')
			tp = re.sub('M3U(.*?)\n|#[^EXT](.*?)\n', '', rp)
			ketqua = tp.split('#EXTINF')
			for tach in ketqua:
				kq = "\n".join([ll.rstrip() for ll in tach.splitlines() if ll.strip()])
				timuser = re.search(r'http-user-agent=(.*?)\n', kq)
				if timuser:
					user = timuser.group(1)
				else:
					user = useragentott
				k = kq.split('\n')
				item = Listitem()
				if len(k)>1:
					if '://' in k[-1]:
						tenkenh = re.search('[,](?!.*[,])(.*?)$', k[0]).group(1)
						group = re.search('group-title="(.*?)"', k[0])
						if group:
							nhomkenh = group.group(1)
						else:
							nhomkenh = 'TỔNG HỢP'
						item.info['plot'] = f'{nhomkenh} - {tenkenh}'
						item.label = f'{tenkenh} - {nhomkenh}'
						kenh = k[-1]
						if 'acestream' in kenh:
							linkplay = ace(kenh, item.label)
							item.path = linkplay
							item.set_callback(item.path)
						elif ':6878' in kenh:
							linkplay = ace(kenh, item.label)
							item.path = linkplay
							item.set_callback(item.path)
						else:
							if 'http-referrer' in kq:
								refe = re.search(r'http-referrer=(.*?)\n', kq).group(1)
								linkplay = f'{streamiptv(kenh.strip(), user)}{referer(refe)}'
							else:
								linkplay = streamiptv(kenh.strip(), user)
							item.set_callback(play_vnm, linkplay, item.label, '')
						logo = re.search('tvg-logo="(.*?)"', k[0])
						if logo:
							item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = logo.group(1)
						else:
							item.art['thumb'] = item.art['landscape'] = logotv
							item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
						yield item
		else:
			yield quangcao()
	else:
		yield quangcao()