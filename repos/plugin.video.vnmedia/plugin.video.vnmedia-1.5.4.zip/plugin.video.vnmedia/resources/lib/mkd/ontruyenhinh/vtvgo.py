from codequick import Route, Listitem, run
from resources.lib.kedon import tb, getlinkweb, play_vtvgo, ifr_khomuc, quangcao
from bs4 import BeautifulSoup
import re
@Route.register
def index_vtvgo(plugin, **kwargs):
	khovideo = {'label': 'KHO VIDEO',
	'info': {'plot': 'Kho Video'},
	'art': {'thumb': 'https://wap.vtvgo.vn/vtvgo_all_device.png',
	'fanart': 'https://wap.vtvgo.vn/vtvgo_all_device.png'},
	'callback': index_khovd}
	tructuyenvtvgo = {'label': 'XEM TRỰC TUYẾN',
	'info': {'plot': 'Xem trực tuyến'},
	'art': {'thumb': 'https://wap.vtvgo.vn/vtvgo_all_device.png',
	'fanart': 'https://wap.vtvgo.vn/vtvgo_all_device.png'},
	'callback': list_truyenhinhvtvgo}
	yield Listitem.from_dict(**tructuyenvtvgo)
	yield Listitem.from_dict(**khovideo)
@Route.register
def list_truyenhinhvtvgo(plugin, **kwargs):
	url = 'https://vtvgo.vn/trang-chu.html'
	r = getlinkweb(url, url, 24*60*60)
	if r is not None:
		soup = BeautifulSoup(r.content, 'html.parser')
		episodes = soup.select('div.list_channel a')
		for episode in episodes:
			item = Listitem()
			linkkenh = episode.get('href')
			anh = episode.select_one('img').get('src')
			item.label = episode.get('alt')
			item.info['plot'] = tb
			item.art['thumb'] = item.art['landscape'] = anh
			item.art['fanart'] = 'https://is3-ssl.mzstatic.com/image/thumb/Purple126/v4/b2/97/48/b2974814-bc6e-3d59-8ea3-86ace210b426/AppIcon-0-0-1x_U007emarketing-0-0-0-7-0-0-sRGB-0-0-0-GLES2_U002c0-512MB-85-220-0-0.png/1200x600wa.png'
			item.set_callback(play_vtvgo, linkkenh, item.label)
			yield item
	else:
		yield quangcao()
@Route.register
def index_khovd(plugin, **kwargs):
	url = 'https://vtvgo.vn/kho-video.html'
	resp = getlinkweb(url, url, 15*60)
	if resp is not None:
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('a.color-white')
		for episode in episodes:
			item = Listitem()
			linkthumuc = episode.get('href')
			idthumuc = re.search(r'(\d+)\.', linkthumuc).group(1).replace('.', '')
			next_page = 1
			item.label = episode.get_text()
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://wap.vtvgo.vn/vtvgo_all_device.png'
			item.set_callback(list_thumucvd, idthumuc, next_page)
			yield item
	else:
		yield quangcao()
@Route.register
def list_thumucvd(plugin, idthumuc, next_page, **kwargs):
	url = f'https://vtvgo.vn/ajax-get-more-item-playlist?next_page={next_page}&channel_id={idthumuc}'
	resp = getlinkweb(url, url, 15*60)
	if resp is not None:
		if 'http' in resp.text:
			soup = BeautifulSoup(resp.content, 'html.parser')
			episodes = soup.select('div.swiper-slide')
			for episode in episodes:
				item = Listitem()
				linkclip = episode.select_one('h2 a').get('href')
				tenclip = episode.select_one('h2 a').get_text()
				anhclip = episode.select_one('img').get('src')
				item.label = tenclip
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = anhclip
				item.set_callback(ifr_khomuc, linkclip, item.label)
				yield item
			item = Listitem()
			item1 = Listitem()
			item1.label = f'Trang {next_page + 1}'
			item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
			item1.set_callback(list_thumucvd, idthumuc, next_page + 1)
			yield item1
		else:
			yield []
	else:
		yield quangcao()