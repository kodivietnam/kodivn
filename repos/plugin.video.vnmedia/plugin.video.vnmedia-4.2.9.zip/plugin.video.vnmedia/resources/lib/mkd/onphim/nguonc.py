from codequick import Route, Listitem, Resolver
from resources.lib.kedon import getlink, getlinkvnm, quangcao, stream, gioithieu
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote_plus
from codequick.utils import color
from functools import lru_cache
import re
uop = 'https://phim.nguonc.com'
def get_info_nguonc(x):
	r = getlinkvnm(f'{uop}/api/film/{x}','https://phim.nguonc.com/')
	try:
		if r is not None and '18+' not in r.text:
			kq = r.json()
			try:
				img = kq['movie']['thumb_url']
			except:
				img = 'https://mi3s.top/thumb/phim/nguonc.png'
			try:
				ten = kq['movie']['name']
			except:
				pass
			try:
				mota = re.sub('<.*?>', '', kq['movie']['description'])
			except:
				mota = ten
			return (ten, img, mota)
		else:
			return None
	except:
		return None
def process_url(url):
	try:
		data = get_info_nguonc(url)
		return url, data
	except:
		return url, None
@Route.register
def search_nguonc(plugin, search_query=None):
	yield []
	if search_query is None:
		pass
	else:
		try:
			next_page = 1
			sr = quote_plus(search_query)
			url = f'{uop}/tim-kiem?keyword={sr}'
			trangtiep = f'{url}&page={next_page}&load=1'
			resp = getlink(trangtiep, url, 1800)
			if (resp is not None):
				rtext = resp.json()['view_up'][0][1]
				urls = re.findall(rf'"{uop}/phim/(.*?)"', rtext)
				length = len(urls)
				if length>0:
					with ThreadPoolExecutor(length) as ex:
						results = ex.map(process_url, urls)
					for (l, data) in results:
						if data is not None:
							item = Listitem()
							item.label = data[0]
							item.info['plot'] = data[2]
							item.info['mediatype'] = 'tvshow'
							item.art['thumb'] = item.art['poster'] = data[1]
							item.set_callback(id_nguonc, l)
							yield item
					if f'page={str(int(next_page) + 1)}' in rtext:
						item1 = Listitem()
						item1.label = f'Trang {next_page + 1}'
						item1.info['mediatype'] = 'tvshow'
						item1.art['thumb'] = item1.art['poster'] = 'https://mi3s.top/thumb/next.png'
						item1.set_callback(ds_nguonc, url, next_page + 1)
						yield item1
			else:
				yield quangcao()
		except:
			yield quangcao()
@lru_cache
@Route.register
def index_nguonc(plugin):
	yield Listitem.search(search_nguonc)
	T = {'Thể loại': nguonc_tl,
	'Quốc gia': nguonc_qg}
	dulieu = {
	'Phim mới': f'{uop}/danh-sach-phim',
	'Phim lẻ': f'{uop}/danh-sach/phim-le',
	'Phim bộ': f'{uop}/danh-sach/phim-bo',
	'Hoạt hình': f'{uop}/the-loai/hoat-hinh',
	'TV Shows': f'{uop}/danh-sach/tv-shows',
	}
	for b in T:
		i = Listitem()
		i.label = b
		i.info['mediatype'] = 'tvshow'
		i.art['thumb'] = i.art['poster'] = 'https://mi3s.top/thumb/phim/nguonc.png'
		i.set_callback(T[b])
		yield i
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.info['mediatype'] = 'tvshow'
		item.art['thumb'] = item.art['poster'] = 'https://mi3s.top/thumb/phim/nguonc.png'
		item.set_callback(ds_nguonc, dulieu[k], 1)
		yield item
@lru_cache
@Route.register
def nguonc_tl(plugin):
	dulieu = {
	'Hành Động': f'{uop}/the-loai/hanh-dong',
	'Phiêu Lưu': f'{uop}/the-loai/phieu-luu',
	'Hoạt Hình': f'{uop}/the-loai/hoat-hinh',
	'Hài': f'{uop}/the-loai/phim-hai',
	'Hình Sự': f'{uop}/the-loai/hinh-su',
	'Tài Liệu': f'{uop}/the-loai/tai-lieu',
	'Chính Kịch': f'{uop}/the-loai/chinh-kich',
	'Gia Đình': f'{uop}/the-loai/gia-dinh',
	'Giả Tượng': f'{uop}/the-loai/gia-tuong',
	'Lịch Sử': f'{uop}/the-loai/lich-su',
	'Kinh Dị': f'{uop}/the-loai/kinh-di',
	'Nhạc': f'{uop}/the-loai/phim-nhac',
	'Bí Ẩn': f'{uop}/the-loai/bi-an',
	'Lãng Mạn': f'{uop}/the-loai/lang-man',
	'Khoa Học Viễn Tưởng': f'{uop}/the-loai/khoa-hoc-vien-tuong',
	'Gây Cấn': f'{uop}/the-loai/gay-can',
	'Chiến Tranh': f'{uop}/the-loai/chien-tranh',
	'Tâm Lý': f'{uop}/the-loai/tam-ly',
	'Tình Cảm': f'{uop}/the-loai/tinh-cam',
	'Cổ Trang': f'{uop}/the-loai/co-trang',
	'Miền Tây': f'{uop}/the-loai/mien-tay',
	}
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.info['mediatype'] = 'tvshow'
		item.art['thumb'] = item.art['poster'] = 'https://mi3s.top/thumb/phim/nguonc.png'
		item.set_callback(ds_nguonc, dulieu[k], 1)
		yield item
@lru_cache
@Route.register
def nguonc_qg(plugin):
	dulieu = {
	'Âu Mỹ': f'{uop}/quoc-gia/au-my',
	'Anh': f'{uop}/quoc-gia/anh',
	'Trung Quốc': f'{uop}/quoc-gia/trung-quoc',
	'Indonesia': f'{uop}/quoc-gia/indonesia',
	'Việt Nam': f'{uop}/quoc-gia/viet-nam',
	'Pháp': f'{uop}/quoc-gia/phap',
	'Hồng Kông': f'{uop}/quoc-gia/hong-kong',
	'Hàn Quốc': f'{uop}/quoc-gia/han-quoc',
	'Nhật Bản': f'{uop}/quoc-gia/nhat-ban',
	'Thái Lan': f'{uop}/quoc-gia/thai-lan',
	'Đài Loan': f'{uop}/quoc-gia/dai-loan',
	'Nga': f'{uop}/quoc-gia/nga',
	'Hà Lan': f'{uop}/quoc-gia/ha-lan',
	'Philippines': f'{uop}/quoc-gia/philippines',
	'Ấn Độ': f'{uop}/quoc-gia/an-do',
	'Quốc gia khác': f'{uop}/quoc-gia/quoc-gia-khac',
	}
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.info['mediatype'] = 'tvshow'
		item.art['thumb'] = item.art['poster'] = 'https://mi3s.top/thumb/phim/nguonc.png'
		item.set_callback(ds_nguonc, dulieu[k], 1)
		yield item
@Route.register
def ds_nguonc(plugin, match=None, next_page=None):
	yield []
	if any((match is None,next_page is None)):
		pass
	else:
		try:
			n = f'{match}&page={next_page}&load=1' if '?' in match else f'{match}?page={next_page}&load=1'
			resp = getlink(n, n, 1800)
			if (resp is not None):
				rtext = resp.json()['view_up'][0][1]
				urls = re.findall(rf'"{uop}/phim/(.*?)"', rtext)
				length = len(urls)
				if length>0:
					with ThreadPoolExecutor(length) as ex:
						results = ex.map(process_url, urls)
					for (l, data) in results:
						if data is not None:
							item = Listitem()
							item.label = data[0]
							item.info['plot'] = data[2]
							item.info['mediatype'] = 'tvshow'
							item.art['thumb'] = item.art['poster'] = data[1]
							item.set_callback(id_nguonc, l)
							yield item
					if f'page={str(int(next_page) + 1)}' in rtext:
						item1 = Listitem()
						item1.label = f'Trang {next_page + 1}'
						item1.info['mediatype'] = 'tvshow'
						item1.art['thumb'] = item1.art['poster'] = 'https://mi3s.top/thumb/next.png'
						item1.set_callback(ds_nguonc, match, next_page + 1)
						yield item1
			else:
				yield quangcao()
		except:
			yield quangcao()
@Route.register
def id_nguonc(plugin, idk=None):
	yield []
	if idk is None:
		pass
	else:
		try:
			t = f'{uop}/api/film/{idk}'
			resp = getlink(t, t, 1800)
			if (resp is not None):
				try:
					kq = resp.json()
					ke = kq['movie']['episodes']
					title = kq['movie']['name']
					title2= kq['movie']['original_name']
					namefilm = f'{title}-{title2}'
					mota = re.sub('<.*?>', '', kq['movie']['description'])
					anh = kq['movie']['thumb_url']
					yield gioithieu(namefilm, mota, anh)
					b = ((k1['server_name'], k2['name'], k2['m3u8']) for k1 in ke for k2 in k1['items'] if 'm3u8' in k2)
					for k in b:
						item = Listitem()
						tenm = f"{color(k[0], 'yellow')} Tập {k[1]} - {namefilm}"
						item.label = tenm
						item.info['mediatype'] = 'episode'
						item.info['plot'] = mota
						item.art['thumb'] = item.art['poster'] = anh
						item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), stream(k[2]), tenm)
						yield item
				except:
					pass
			else:
				yield quangcao()
		except:
			yield quangcao()