from codequick import Route, Listitem
from resources.lib.kedon import replace_all, getlinkweb, quangcao
import re
@Route.register
def index_youtube(plugin):
	try:
		thaythe = {'\\"':'','\\u0026':'&'}
		streams = [
			('TOP VIDEO THỊNH HÀNH', 'https://mi3s.top/thumb/fshare/hot.png', '/resources/lib/mkd/onyoutube/video:youtube_thinhhanh'),
			('TOP ÂM NHẠC THỊNH HÀNH', 'https://mi3s.top/thumb/nhacyt.png', '/resources/lib/mkd/onyoutube/video:youtube_amnhacthinhhanh')
		]
		yield Listitem.search(Route.ref('/resources/lib/mkd/onyoutube/tim:search_youtube'))
		for name_key, banner_key, route_key in streams:
			i = Listitem()
			i.label = name_key
			i.info['mediatype'] = 'tvshow'
			i.art['thumb'] = i.art['poster'] = banner_key
			i.set_callback(Route.ref(route_key))
			yield i
		sre1 = re.compile(r'text":"(.*?)"}')
		sre2 = re.compile(r'videoId":"(.*?)"')
		url = 'https://www.youtube.com/?gl=VN&hl=vi'
		listplay = re.findall(r'videoRenderer(.*?)accessibility', replace_all(thaythe, getlinkweb(url, url, 1000).text))
		for k in listplay:
			item = Listitem()
			idvd = sre2.search(k)[1]
			item.label = sre1.search(k)[1]
			item.info['mediatype'] = 'episode'
			item.art['thumb'] = item.art['poster'] = f'https://i.ytimg.com/vi/{idvd}/sddefault.jpg'
			item.set_path(f'plugin://plugin.video.youtube/play/?video_id={idvd}')
			yield item
	except:
		yield quangcao()