from codequick import Route, Listitem, run, Script
from resources.lib.kedon import getlink, get_info_fs, play_fs, postlinktimfs, quangcao, __addon__, __addonnoti__
from resources.lib.mkd.onfshare.ifshare import index_fs, tfavo
from resources.lib.download import downloadfs
import urlquick, xbmcgui, xbmcaddon, xbmcvfs, xbmc, time, os, pyqrcode, re
CWD = __addon__.getAddonInfo('path')
PROFILE = __addon__.getAddonInfo('profile')
REMOTE_URL = 'http://fshare.fun/remote/'
SERVICE_URL = 'http://fshare.fun/api/v1/get'
PIN = ''
COMMAND = {}
@Route.register
def qrplay(plugin, **kwargs):
    global PIN, COMMAND
    PIN = create_pin()
    if (PIN == ''):
        yield quangcao()
    else:
        url = f'{REMOTE_URL}{PIN}'
        imagefile = os.path.join(xbmcvfs.translatePath(PROFILE), f'{PIN}.png')
        qrIMG = pyqrcode.create(url)
        qrIMG.png(imagefile, scale=10)
        message = f'Hãy scan QR bằng điện thoại [CR]Hoặc [CR]Vào url: [B]{url}[/B][CR]để nhập Fshare link hoặc từ khóa tìm kiếm'
        qr = QRCode("pin-dialog.xml", CWD, "default",
                    image=imagefile, text=message)
        qr.doModal()
        del qr
        xbmcvfs.delete(imagefile)
        if 'message' in COMMAND.keys() and COMMAND['message'] != '':
            fshareUrlStr = COMMAND['recommend']
            if (COMMAND['message'].find('http') != -1):
                fshareUrlStr = f'{fshareUrlStr},{COMMAND["message"].replace(" ", ",")}'
            fshareUrls = fshareUrlStr.split(',')
            for fshareUrl in fshareUrls:
                if fshareUrl != '':
                    item = Listitem()
                    x = fshareUrl
                    item.label = get_info_fs(x)
                    item.info['plot'] = x
                    item.art['thumb'] = f'http://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={item.info["plot"]}&qzone=1&margin=0&size=400x400&ecc=L'
                    item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
                    item.set_callback(play_fs, x, item.label)
                    yield item

            if (COMMAND['message'].find('http') == -1):
                urlvmf = f'http://phongblack.me/search.php?author=phongblack&search={COMMAND["message"]}'
                respvmf = urlquick.get(urlvmf, timeout=10, max_age=15*60, headers={'user-agent': 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36 VietMedia/1.0','referer': 'http://www.google.com'})
                if respvmf is not None:
                    x = respvmf.json()['items']
                    for m in x:
                        item1 = Listitem()
                        ten = re.sub('[\[\]\{\}]','|', m['label'])
                        if 'info' in m:
                            mota = m['info']['plot']
                        path = m['path']
                        if '/file/' in path:
                            item1.label = ten
                            link = path.split('&url=')
                            linkplay = link[1]
                            item1.art['thumb'] = item1.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
                            item1.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
                            item1.info['plot'] = mota
                            if __addon__.getSetting("taifshare") == "true":
                                item1.context.script(downloadfs, 'Tải về', linkplay)
                            item1.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
                            item1.set_callback(play_fs, linkplay, item1.label)
                            yield item1
                        elif '/folder/' in path:
                            item1.label = ten
                            link = path.split('&url=')
                            linkplay = link[1]
                            thumuc = linkplay.split('folder/')
                            item1.art['thumb'] = item1.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
                            item1.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
                            item1.info['plot'] = mota
                            item1.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
                            item1.set_callback(index_fs, thumuc[1], 1)
                            yield item1
                else:
                    yield []
                url = f'https://api.timfshare.com/v1/string-query-search?query={COMMAND["message"]}'
                resp = postlinktimfs(url, 'https://timfshare.com/', 15*60)
                if resp is not None:
                    kq = resp.json()
                    if kq['data']:
                        for k in kq['data']:
                            item = Listitem()
                            linkplay = k['url']
                            if 'folder' in linkplay:
                                item.label = k['name']
                                thumuc = linkplay.split('folder/')
                                item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
                                item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
                                item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
                                item.set_callback(index_fs, thumuc[1], 1)
                                yield item
                            elif 'file' in linkplay:
                                item.label = k['name']
                                item.info['size'] = k['size']
                                item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
                                item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
                                if __addon__.getSetting("taifshare") == "true":
                                    item.context.script(downloadfs, 'Tải về', linkplay)
                                item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
                                item.set_callback(play_fs, linkplay, item.label)
                                yield item
                else:
                    yield []
                urltvhd = f'https://thuvienhd.com/?feed=fsharejson&search={COMMAND["message"]}'
                resptvhd = getlink(urltvhd, 'https://thuvienhd.com/', 15*60)
                if resptvhd is not None:
                    kqtvhd = resptvhd.json()
                    for t in kqtvhd:
                        for d in t['links']:
                            item = Listitem()
                            linkplay = d['link']
                            if 'folder' in linkplay:
                                item.label = d['title']
                                thumuc = linkplay.split('folder/')
                                item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
                                item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
                                item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
                                item.set_callback(index_fs, thumuc[1], 1)
                                yield item
                            elif 'file' in linkplay:
                                item.label = d['title']
                                item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
                                item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
                                if __addon__.getSetting("taifshare") == "true":
                                    item.context.script(downloadfs, 'Tải về', linkplay)
                                item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
                                item.set_callback(play_fs, linkplay, item.label)
                                yield item
                else:
                    yield []
        else:
            yield quangcao()
        COMMAND = {}
def create_pin():
    try:
        params = {'command': 'get_pin', 'customer': '-get_pin'}
        res = urlquick.post(SERVICE_URL, data=params, timeout=20, max_age=0).json()
        return res
    except:
        return ''
class QRCode(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.image = kwargs["image"]
        self.text = kwargs["text"]

    def onInit(self):
        self.imagecontrol = 1001
        self.textbox = 1002
        self.okbutton = 1003
        self.showdialog()
        self.getCommand()

    def showdialog(self):
        self.getControl(self.imagecontrol).setImage(self.image)
        self.getControl(self.textbox).setText(self.text)
        self.setFocus(self.getControl(self.okbutton))
        self.windowId = xbmcgui.getCurrentWindowDialogId()

    def onClick(self, controlId):
        if (controlId == self.okbutton):
            xbmcgui.Window(10000).setProperty('waiting_command', 'false')
            self.close()

    def getCommand(self):
        global COMMAND
        max_waiting_time = time.time() + 120
        while self.windowId == xbmcgui.getCurrentWindowDialogId() and max_waiting_time > time.time():
            remaining = round(max_waiting_time-time.time())
            xbmc.sleep(1000)
            self.getControl(self.textbox).setText(
                self.text + f'[CR][CR]Thời gian chờ còn lại: {remaining} giây')
            params = {
                'command': 'get_command',
                'pin': PIN
            }
            try:
                res = urlquick.post(SERVICE_URL, data=params, timeout=20, max_age=0).json()
                if res['status'] == '1':
                    COMMAND = res
                    self.close()
                    break
            except:
                pass
        self.close()