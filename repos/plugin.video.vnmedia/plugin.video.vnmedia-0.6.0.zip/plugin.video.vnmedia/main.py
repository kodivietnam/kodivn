from resources.lib import plugin
if __name__ == "__main__":
  plugin.run()