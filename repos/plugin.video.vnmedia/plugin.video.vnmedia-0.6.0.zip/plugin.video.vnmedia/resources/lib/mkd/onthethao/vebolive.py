from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from resources.lib.kedon import getlink, ifr_vebolive
@Route.register
def index_vebolive(plugin, content_type='segment'):
	url = 'https://vebo.live/vb-ajax.php?action=load_more_live&page=0&key=home&posts_per_page=30'
	resp = getlink(url, url, 15*60)
	soup = BeautifulSoup(resp.json()['data']['html'], 'html.parser')
	episodes = soup.select('div.position-relative.match')
	for episode in episodes:
		item = Listitem()
		linktrandau = episode.select_one('a.btn-view.btn.btn-primary').get('href')
		thoigian = episode.select_one('p.match-date').text.strip()
		doinha = episode.select_one('div.text-center.match-team.team-home').text.strip()
		doikhach = episode.select_one('div.text-center.match-team.team-away').text.strip()
		giaidau = episode.select_one('div.match-league').text.strip()
		item.label = thoigian + ': ' + doinha + ' vs ' + doikhach + ' (' + giaidau + ')'
		item.art['thumb'] = 'https://vebo.live/wp-content/themes/bongda/public/images/logo.png'
		item.art['fanart'] = 'https://vebo.live/wp-content/themes/bongda/public/images/logo.png'
		item.set_callback(list_vebolive, linktrandau, item.label)
		yield item
@Route.register
def list_vebolive(plugin, url, title):
	resp = getlink(url, url, 5*60)
	soup = BeautifulSoup(resp.text, 'html.parser')
	episodes = soup.select('div.link-video a')
	for episode in episodes:
		item = Listitem()
		linktrandau = episode.get('href')
		item.label = episode.text.strip() + ' - ' + title
		item.art['thumb'] = 'https://vebo.live/wp-content/themes/bongda/public/images/logo.png'
		item.art['fanart'] = 'https://vebo.live/wp-content/themes/bongda/public/images/logo.png'
		item.set_callback(ifr_vebolive, linktrandau, item.label)
		yield item