def main():
    from codequick import run
    exception = run()
    if isinstance(exception, Exception):
        import importlib
        main = importlib.import_module('resources.lib.main')
        main.error_handler(exception)
if __name__ == '__main__':
    main()