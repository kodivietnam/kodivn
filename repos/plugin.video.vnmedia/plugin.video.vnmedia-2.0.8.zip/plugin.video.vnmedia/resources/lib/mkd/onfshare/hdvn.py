from codequick import Route, Listitem, run, Script
@Route.register
def search_hdvn(plugin,search_query, **kwargs):
    import xbmcgui, urllib
    from resources.lib.kedon import getlink, quangcao, __addonnoti__, yttk, tb
    from resources.lib.mkd.onfshare.ifshare import hdvn
    dp = xbmcgui.DialogProgress()
    dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
    dp.update(5)
    search_query = urllib.parse.quote_plus(search_query)
    url = f'{hdvn}/search/2022/?page=1&q={search_query.replace(" ","+")}&t=post&o=date&c[node]=337+344+345+346+33+271+324+77+78'
    r = getlink(url, url, 7200)
    if r is not None:
        import re
        idsearch = re.search(r'search/([0-9]+)', r.url).group(1)
        if 'titleText' in r.text:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(r.content, 'html.parser')
            episodes = soup.select('div.titleText a')
            for episode in episodes:
                item = Listitem()
                item.label = episode.get_text()
                item.info['plot'] = tb
                item.info['mediatype'] = 'episode'
                item.info['rating'] = 10.0
                item.info['trailer'] = yttk(item.label)
                linkphim = episode.get('href')
                item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = f'{hdvn}/images/hd-vietnam-logo.png'
                item.set_callback(hdvn_link, linkphim)
                yield item
            yield Listitem.next_page(search_query, 2, idsearch, callback=search_hdvnnext)
        else:
            Script.notify(__addonnoti__, 'Không tìm thấy kết quả')
            yield quangcao()
    else:
        yield quangcao()
    dp.update(100)
    dp.close()
@Route.register
def search_hdvnnext(plugin,search_query, next_page, idsearch, **kwargs):
    from resources.lib.kedon import getlink, quangcao, __addonnoti__, yttk, tb
    from resources.lib.mkd.onfshare.ifshare import hdvn
    import urllib
    search_query = urllib.parse.quote_plus(search_query)
    url = f'{hdvn}/search/{idsearch}/?page={next_page}&q={search_query.replace(" ","+")}&t=post&o=date&c[node]=337+344+345+346+33+271+324+77+78'
    r = getlink(url, url, 7200)
    if r is not None:
        if 'titleText' in r.text:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(r.content, 'html.parser')
            episodes = soup.select('div.titleText a')
            for episode in episodes:
                item = Listitem()
                item.label = episode.get_text()
                item.info['plot'] = tb
                item.info['mediatype'] = 'episode'
                item.info['rating'] = 10.0
                item.info['trailer'] = yttk(item.label)
                linkphim = episode.get('href')
                item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = f'{hdvn}/images/hd-vietnam-logo.png'
                item.set_callback(hdvn_link, linkphim)
                yield item
            item1 = Listitem()
            item1.label = f'Trang {next_page + 1}'
            item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
            item1.set_callback(search_hdvnnext, search_query, next_page + 1, idsearch)
            yield item1
        else:
            Script.notify(__addonnoti__, 'Không tìm thấy kết quả')
            yield quangcao()
    else:
        yield quangcao()
@Route.register
def index_hdvn(plugin, **kwargs):
    from resources.lib.mkd.onfshare.ifshare import hdvn
    nhomhdvn = {
    '4K': f'{hdvn}/forums/4k.337/',
    'WEB-DL, HDTV 4K': f'{hdvn}/forums/web-dl-hdtv-4k.344/',
    'Bluray Remux 4K': f'{hdvn}/forums/bluray-remux-4k.345/',
    'Bluray Nguyên Gốc 4K': f'{hdvn}/forums/bluray-nguyen-goc-4k.346/',
    'Fshare.vn': f'{hdvn}/forums/fshare-vn.33/',
    'Fshare-WEB-DL, HDTV': f'{hdvn}/forums/web-dl-hdtv.271/',
    'Fshare-Bluray Remux': f'{hdvn}/forums/bluray-remux.324/',
    'Fshare-mHD, SD': f'{hdvn}/forums/mhd-sd.77/',
    'Fshare-Bluray nguyên gốc': f'{hdvn}/forums/bluray-nguyen-goc.78/',
    'Thư viện link Phim': f'{hdvn}/forums/thu-vien-link-phim.150/',
    'Phim có audio Việt': f'{hdvn}/forums/phim-co-audio-viet.265/',
    'Phim bộ - Series': f'{hdvn}/forums/phim-bo-series.57/',
    'Phim bộ - mHD, SD': f'{hdvn}/forums/mhd-sd.104/',
    'Phim hoạt hình': f'{hdvn}/forums/phim-hoat-hinh.123/',
    'Phim hoạt hình - mHD, SD': f'{hdvn}/forums/mhd-sd.124/',
    'Phim tài liệu - Documentaries': f'{hdvn}/forums/phim-tai-lieu-documentaries.116/',
    'Phim 3D': f'{hdvn}/forums/3d.110/',
    'Phim cho iOS/Android': f'{hdvn}/forums/phim-cho-ios-android.157/',
    'Music request': f'{hdvn}/forums/music-request.28/',
    'HD Video Clip': f'{hdvn}/forums/hd-video-clip.50/',
    'Video nhạc US-EU': f'{hdvn}/forums/us-eu.189/',
    'Video nhạc Việt Nam': f'{hdvn}/forums/viet-nam.191/',
    'Video nhạc Asia': f'{hdvn}/forums/asia.190/',
    'Soundtrack': f'{hdvn}/forums/soundtrack.73/',
    'Lossless Albums': f'{hdvn}/forums/lossless-albums.26/',
    'Lossless Việt Nam': f'{hdvn}/forums/nhac-viet-nam.183/',
    'Lossless Quốc tế': f'{hdvn}/forums/nhac-quoc-te.184/',
    'Lossless không lời': f'{hdvn}/forums/nhac-khong-loi.185/',
    'Lossy albums': f'{hdvn}/forums/lossy-albums.27/',
    'mHD, SD Video Clips': f'{hdvn}/forums/mhd-sd-video-clips.25/'
    }
    from resources.lib.kedon import tb
    yield Listitem.search(search_hdvn)
    for tenlist, urllist in list(nhomhdvn.items()):
        item = Listitem()
        item.label = tenlist
        item.art['thumb'] = item.art['landscape'] = f'{hdvn}/images/hd-vietnam-logo.png'
        item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
        item.info['plot'] = tb
        item.set_callback(hdvn_page, url=urllist, next_page=1)
        yield item
@Route.register
def hdvn_page(plugin, url, next_page, **kwargs):
    from resources.lib.kedon import getlink, quangcao, yttk, tb
    from resources.lib.mkd.onfshare.ifshare import hdvn
    trangtiep = f'{url}page-{next_page}'
    r = getlink(trangtiep, trangtiep, 14400)
    if r is not None:
        from bs4 import BeautifulSoup
        import re
        soup = BeautifulSoup(r.content, 'html.parser')
        episodes = soup.select('a.PreviewTooltip')
        for episode in episodes:
            item = Listitem()
            linkphim = episode.get('href')
            p = episode.get_text()
            item.label = re.sub('[\[\]\{\}]','|', p)
            item.info['plot'] = tb
            item.info['mediatype'] = 'episode'
            item.info['rating'] = 10.0
            item.info['trailer'] = yttk(item.label)
            item.art['thumb'] = item.art['landscape'] = f'{hdvn}/images/hd-vietnam-logo.png'
            item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
            item.set_callback(hdvn_link, linkphim)
            yield item
        item1 = Listitem()
        item1.label = f'Trang {next_page + 1}'
        item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
        item1.set_callback(hdvn_page, url, next_page + 1)
        yield item1
    else:
        yield quangcao()
@Route.register
def hdvn_link(plugin, url, **kwargs):
    from resources.lib.kedon import quangcao, play_fs, __addonnoti__, yttk, tb, get_info_fs
    from resources.lib.mkd.onfshare.ifshare import loginfhdvn, likehdvn, tfavo, index_fs, hdvn
    likehdvn(url)
    r = loginfhdvn().get(f'{hdvn}/{url}')
    if 'fshare.vn' in r.text:
        from bs4 import BeautifulSoup
        import xbmcgui, xbmcaddon, concurrent.futures
        soup = BeautifulSoup(r.content, 'html.parser')
        episodes = soup.select('a.externalLink')
        urls = [episode.get('href') for episode in episodes if 'fshare.vn' in episode.get('href')]
        length = len(urls)
        dialog = xbmcgui.DialogProgress()
        dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
        dialog.update(5, f'Đang giải mã {length} dữ liệu...')
        with concurrent.futures.ThreadPoolExecutor(length) as ex:
            future_to_url = {ex.submit(get_info_fs, url): url for url in urls}
            for future in concurrent.futures.as_completed(future_to_url):
                link = future_to_url[future]
                data = future.result()
                ten = data[0]
                dungluong = data[1]
                item = Listitem()
                if 'folder' in link:
                    item.label = ten
                    thumuc = link.split('folder/')
                    item.info['plot'] = tb
                    item.info['mediatype'] = 'episode'
                    item.info['rating'] = 10.0
                    item.info['trailer'] = yttk(item.label)
                    item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={link}&qzone=1&margin=1&size=400x400&ecc=L'
                    item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
                    item.context.script(tfavo, 'Thêm vào Fshare Favorite', link)
                    item.set_callback(index_fs, thumuc[1], 1)
                    yield item
                elif 'file' in link:
                    item.label = ten
                    item.info['plot'] = tb
                    item.info['size'] = dungluong
                    item.info['mediatype'] = 'episode'
                    item.info['rating'] = 10.0
                    item.info['trailer'] = yttk(item.label)
                    item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={link}&qzone=1&margin=1&size=400x400&ecc=L'
                    item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
                    if xbmcaddon.Addon().getSetting("taifshare") == "true":
                        from resources.lib.download import downloadfs
                        item.context.script(downloadfs, 'Tải về', link)
                    item.context.script(tfavo, 'Thêm vào Fshare Favorite', link)
                    item.set_callback(play_fs, link, item.label)
                    yield item
                dialog.update(100)
        dialog.close()
    else:
        yield quangcao()