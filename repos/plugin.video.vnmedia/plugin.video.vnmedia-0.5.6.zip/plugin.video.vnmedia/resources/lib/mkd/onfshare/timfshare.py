from codequick import Route, Listitem, run
from resources.lib.kedon import tb, postlinktimfs, play_fs, __addonnoti__, convert_bytes
from resources.lib.mkd.onfshare.ifshare import index_fs
import xbmcgui, urllib
@Route.register
def searchfs(plugin, search_query):
	dp = xbmcgui.DialogProgress()
	dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
	search_query = urllib.parse.quote_plus(search_query)
	url = 'https://api.timfshare.com/v1/string-query-search?query=' + search_query
	resp = postlinktimfs(url, 'https://timfshare.com/', 48*60*60)
	kq = resp.json()
	for k in kq['data']:
		item = Listitem()
		if 'folder' in k['url']:
			item.label = k['name']
			thumuc = k['url'].split('folder/')
			item.art['thumb'] = 'https://static.mservice.io/placebrand/s/momo-upload-api-200424091506-637233165063699729.png'
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			item.set_callback(index_fs, thumuc[1], 1)
			yield item
		elif 'file' in k['url']:
			item.label = k['name'] + ' (' + convert_bytes(k['size']) + ')'
			linkplay = k['url']
			item.art['thumb'] = 'https://static.mservice.io/placebrand/s/momo-upload-api-200424091506-637233165063699729.png'
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			item.set_callback(play_fs, linkplay, item.label)
			yield item