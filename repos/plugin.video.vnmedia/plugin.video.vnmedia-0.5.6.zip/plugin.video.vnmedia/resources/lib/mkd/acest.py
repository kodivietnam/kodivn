from codequick import Route, Listitem, run
from resources.lib.kedon import tb
from resources.lib.mkd.ontruyenhinh.listiptv import list_iptv_sport
from resources.lib.mkd.onthethao.streamthunder import index_streamthunder
from resources.lib.mkd.onthethao.livetvxs import index_livetvxs
from resources.lib.mkd.onthethao.hl365 import index_highlights365
CATEace = {
'Acestream Khampha1': 'https://textuploader.com/dl6ui/raw',
'Acestream Khampha2': 'https://pastebin.com/raw/MDyHF0F6',
'Acestream CVACE': 'http://gg.gg/cvace'}
@Route.register
def index_acestream(plugin, content_type='segment'):
	for tenlist, urllist in list(CATEace.items()):
		item = Listitem()
		item.label = tenlist
		item.art['thumb'] = 'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg'
		item.art['fanart'] = 'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg'
		item.set_callback(list_iptv_sport, url=urllist)
		yield item
	wlivetvxs = {'label': 'Livetv.sx',
	'info':{'plot':tb}, 
	'art':{'thumb':'http://cdn.livetv495.me/img/logo_ru.jpg',
	'fanart':'http://cdn.livetv495.me/img/logo_ru.jpg'},
	'callback':index_livetvxs}
	wthunder = {'label': 'Streamthunder.org',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://raw.githubusercontent.com/dw4ss/streamthunder-demo-website/master/images/stream-hd.png',
	'fanart':'https://raw.githubusercontent.com/dw4ss/streamthunder-demo-website/master/images/stream-hd.png'},
	'callback':index_streamthunder}
	w365 = {'label': 'Highlights365.com',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://highlights365.com/static/images/highlights365/logo_header.png',
	'fanart':'https://highlights365.com/static/images/highlights365/logo_header.png'},
	'callback':index_highlights365}
	yield Listitem.from_dict(**wlivetvxs)
	yield Listitem.from_dict(**wthunder)
	yield Listitem.from_dict(**w365)