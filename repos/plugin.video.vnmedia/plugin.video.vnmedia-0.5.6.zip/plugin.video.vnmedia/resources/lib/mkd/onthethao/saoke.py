from codequick import Route, Listitem, run
from resources.lib.kedon import qc, tb, getlink, stream, referer, play_vnm
from datetime import datetime
import re, json
@Route.register
def index_saoke(plugin, content_type='segment'):
	url = 'https://saokelives.site/'
	resp = getlink(url, url, 5*60)
	if 'm3u8' in resp.text:
		match = re.search(r'lives=(.*?)</script>', resp.text).group(1)
		listplay = re.findall(r'{_id(.*?)primaryId', match)
		for k in listplay:
			ten = re.search(r'Xem trực tiếp bình luận bóng đá hôm nay: (.*?)"', k).group(1)
			tg = re.search(r'time:(.*?),', k).group(1)
			tgjs = json.loads(tg)
			time = datetime.fromtimestamp(tgjs/1000).strftime('%H:%M %d-%m')
			listname = re.findall(r'{name:(.*?)}', k)
			for m in listname:
				item = Listitem()
				if re.search(r'url:"(.*?)"', m).group(1):
					chatluong = re.search(r'"(.*?)"', m).group(1)
					linkplay = stream(re.search(r'url:"(.*?)"', m).group(1)) + referer(url)
					item.label = chatluong + ' ' + time + ' ' + ten
					item.info['plot'] = tb
					item.art['thumb'] = 'https://9767a59e2b.vws.vegacdn.vn/template/logo1.png'
					item.art['fanart'] = 'https://9767a59e2b.vws.vegacdn.vn/template/logo1.png'
					item.set_callback(play_vnm, linkplay, item.label, '')
					yield item
	else:
		item2 = Listitem()
		linkmacdinh = stream(qc)
		item2.label = 'Đang cập nhật'
		item2.info['plot'] = tb
		item2.art['thumb'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item2.art['fanart'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item2.set_callback(play_vnm, linkmacdinh, item2.label, '')
		yield item2