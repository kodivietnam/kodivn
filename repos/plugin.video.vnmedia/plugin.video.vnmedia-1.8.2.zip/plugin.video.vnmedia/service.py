def autorun_addon():
    import xbmc, xbmcaddon, xbmcgui, urllib3, json
    xbmc.executebuiltin('UpdateAddonRepos()')
    if xbmcaddon.Addon().getSetting('auto_run') == 'true':
        xbmc.executebuiltin('RunAddon(plugin.video.vnmedia)')
    http = urllib3.PoolManager()
    url = 'https://speedtest.vn/get-ip-info'
    r = http.request('GET', url, headers={'user-agent': 'Mozilla/5.0'})
    d = json.loads(r.data.decode('utf-8'))
    a = ''
    for k,v in d.items():
        a += f'{k.upper()}: {v}\n'
    p = xbmc.getInfoLabel('System.BuildVersion')
    xbmcgui.Dialog().ok('CỘNG ĐỒNG KODI VIỆT NAM', a)
    return
autorun_addon()