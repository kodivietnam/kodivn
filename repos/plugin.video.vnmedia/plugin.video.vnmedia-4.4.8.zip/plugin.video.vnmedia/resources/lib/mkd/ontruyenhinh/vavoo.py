from codequick import Route, Listitem, Resolver
from resources.lib.kedon import getlink, quangcao
from random import choice
from requests import Session
from json import loads
from io import BytesIO
from gzip import GzipFile
from binascii import unhexlify
from functools import lru_cache
lista_kpt = 'https://gitlab.com/flechanegra/top/-/raw/main/top..json'
ukey = 'https://raw.githubusercontent.com/michaz1988/michaz1988.github.io/master/data.json'
def getAuthSignature():
	veclist=getlink(ukey,ukey,300).json()
	vec = {"vec": choice(veclist)}
	with Session() as s:
		try:
			req = s.post('https://www.vavoo.tv/api/box/ping2', data=vec,timeout=20).json()
		except:
			req = s.post('https://www.vavoo.tv/api/box/ping2', data=vec,timeout=20, verify=False).json()
	if req.get('signed'):
		sig = req['signed']
	elif req.get('data', {}).get('signed'):
		sig = req['data']['signed']
	elif req.get('response', {}).get('signed'):
		sig = req['response']['signed']
	return sig
def content_decode(content):
	try:
		k = '1f8b0808d34445'
		if k in content:
			buf = BytesIO(unhexlify(content.split(k)[0]))
			f = GzipFile(fileobj=buf)
			content = f.read()
			try:
				content = content.decode('utf-8')
			except:
				pass
	except:
		pass
	return content
@lru_cache
@Route.register
def index_vavoo(plugin):
	dulieu = {
	'Server 1':index_vavoo1,
	'Server 2':index_vavoo2}
	for h in dulieu:
		i1 = Listitem()
		i1.label = h
		i1.info['mediatype'] = 'tvshow'
		i1.art['thumb'] = i1.art['poster'] = 'https://mi3s.top/thumb/vavoo.png'
		i1.set_callback(dulieu[h])
		yield i1
@Route.register
def index_vavoo1(plugin):
	yield []
	try:
		resp = getlink(lista_kpt, lista_kpt, 1000)
		if (resp is not None):
			result = loads(content_decode(resp.text))
			unique_groups = set()
			for k in result:
				group = k['group']
				if group not in unique_groups:
					unique_groups.add(group)
					item = Listitem()
					item.label = group
					item.info['mediatype'] = 'tvshow'
					item.art['thumb'] = item.art['poster'] = 'https://mi3s.top/thumb/vavoo.png'
					item.set_callback(list_vavoo1, group)
					yield item
		else:
			yield quangcao()
	except:
		yield quangcao()
@Route.register
def index_vavoo2(plugin):
	yield []
	try:
		url = f'https://www2.vavoo.to/live2/index'
		resp = getlink(url, url, 1000)
		unique_groups = set()
		if (resp is not None):
			for k in resp.json():
				group = k['group']
				if group not in unique_groups:
					unique_groups.add(group)
					item = Listitem()
					item.label = group
					item.info['mediatype'] = 'tvshow'
					item.art['thumb'] = item.art['poster'] = 'https://mi3s.top/thumb/vavoo.png'
					item.set_callback(list_vavoo2, group)
					yield item
		else:
			yield quangcao()
	except:
		yield quangcao()
@Route.register
def list_vavoo1(plugin, nhom=None):
	yield []
	try:
		if nhom is None:
			pass
		else:
			resp = getlink(lista_kpt, lista_kpt, 1000)
			sign = getAuthSignature()
			if (resp is not None):
				result = loads(content_decode(resp.text))
				for k in result:
					group = k['group']
					if group == nhom:
						item = Listitem()
						name = k['name']
						logo = k['logo']
						play = k['url']
						linkplay = f'{play}?n=1&b=5&vavoo_auth={sign}|User-Agent=VAVOO/2.6'
						item.label = name
						item.info['mediatype'] = 'episode'
						item.art['thumb'] = item.art['poster'] = logo if 'http' in logo else 'https://mi3s.top/thumb/vavoo.png'
						item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), linkplay, name)
						yield item
			else:
				yield quangcao()
	except:
		yield quangcao()
@Route.register
def list_vavoo2(plugin, nhom=None):
	yield []
	try:
		if nhom is None:
			pass
		else:
			url = f'https://www2.vavoo.to/live2/index'
			resp = getlink(url, url, 1000)
			sign = getAuthSignature()
			if (resp is not None):
				for k in resp.json():
					group = k['group']
					if group == nhom:
						item = Listitem()
						name = k['name']
						logo = k['logo']
						play = k['url']
						linkplay = f'{play}?n=1&b=5&vavoo_auth={sign}|User-Agent=VAVOO/2.6'
						item.label = name
						item.info['mediatype'] = 'episode'
						item.art['thumb'] = item.art['poster'] = logo if 'http' in logo else 'https://mi3s.top/thumb/vavoo.png'
						item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), linkplay, name)
						yield item
			else:
				yield quangcao()
	except:
		yield quangcao()