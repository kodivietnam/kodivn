from codequick import Route, Listitem, run
from resources.lib.kedon import logotv, tb, getlink, stream, ace, play_vnm
import re
@Route.register
def index_90ptv(plugin, **kwargs):
    url = 'http://hoaivnpt.duckdns.org/live-football/live-football.php'
    item = Listitem()
    item.label = 'TẤT CẢ CÁC KÊNH'
    item.info['plot'] = tb
    item.art['thumb'] = item.art['landscape'] = logotv
    item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
    item.set_callback(little_90ptv, url)
    yield item
    resp = getlink(url, url, 15*60)
    rp = resp.text
    group = re.findall('group-title="(.*?)"', rp)
    d = dict.fromkeys(group)
    unique = list(d)
    for tk in unique:
        item = Listitem()
        item.label = tk
        item.info['plot'] = tb
        item.art['thumb'] = item.art['landscape'] = logotv
        item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
        item.set_callback(info_90ptv, url, tk)
        yield item
@Route.register
def info_90ptv(plugin, url, tk, **kwargs):
    resp = getlink(url, url, 15*60)
    rp = resp.text
    kq = '\n'.join([ll.rstrip() for ll in rp.splitlines() if ll.strip()])
    kq = re.sub(r'#h(.*?)\n|#EXTV(.*?)\n|#K(.*?)\n', '', kq)
    ketqua = kq.split('#EXTI')
    for tach in ketqua:
        listplay = re.findall(r'NF(.*)\n(.*)', tach)
        for k in listplay:
            item = Listitem()
            if len(k)>1:
                if 'group-title="%s"' % tk in k[0]:
                    idkenh = re.search('tvg-id="(.*?)"', k[0])
                    if idkenh:
                        idm = idkenh.group(1)
                    else:
                        idm = 'vnm'
                    logo = re.search('tvg-logo="(.*?)"', k[0])
                    if logo:
                        item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = logo.group(1)
                    else:
                        item.art['thumb'] = item.art['landscape'] = logotv
                        item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
                    tenkenh = re.search('[,](?!.*[,])(.*?)$', k[0]).group(1)
                    item.info['plot'] = tenkenh
                    item.label = tenkenh
                    kenh = k[1]
                    if kenh:
                        if 'acestream' in kenh:
                            linkplay = ace(kenh, item.label)
                            item.path = linkplay
                            item.set_callback(item.path)
                        elif ':6878' in kenh:
                            linkplay = ace(kenh, item.label)
                            item.path = linkplay
                            item.set_callback(item.path)
                        else:
                            linkplay = stream(kenh.strip())
                            item.set_callback(play_vnm, linkplay, item.label, '')
                        yield item
@Route.register
def little_90ptv(plugin, url, **kwargs):
    resp = getlink(url, url, 15*60)
    rp = resp.text
    kq = '\n'.join([ll.rstrip() for ll in rp.splitlines() if ll.strip()])
    kq = re.sub(r'#h(.*?)\n|#EXTV(.*?)\n|#K(.*?)\n', '', kq)
    ketqua = kq.split('#EXTI')
    for tach in ketqua:
        listplay = re.findall(r'NF(.*)\n(.*)', tach)
        for k in listplay:
            item = Listitem()
            if len(k)>1:
                idkenh = re.search('tvg-id="(.*?)"', k[0])
                if idkenh:
                    idm = idkenh.group(1)
                else:
                    idm = 'vnm'
                logo = re.search('tvg-logo="(.*?)"', k[0])
                if logo:
                    item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = logo.group(1)
                else:
                    item.art['thumb'] = item.art['landscape'] = logotv
                    item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
                tenkenh = re.search('[,](?!.*[,])(.*?)$', k[0]).group(1)
                group = re.search('group-title="(.*?)"', k[0])
                if group:
                    nhomkenh = group.group(1)
                else:
                    nhomkenh = 'TỔNG HỢP'
                item.info['plot'] = '%s - %s' % (nhomkenh, tenkenh)
                item.label = '%s - %s' % (tenkenh, nhomkenh)
                kenh = k[1]
                if kenh:
                    if 'acestream' in kenh:
                        linkplay = ace(kenh, item.label)
                        item.path = linkplay
                        item.set_callback(item.path)
                    elif ':6878' in kenh:
                        linkplay = ace(kenh, item.label)
                        item.path = linkplay
                        item.set_callback(item.path)
                    else:
                        linkplay = stream(kenh.strip())
                        item.set_callback(play_vnm, linkplay, item.label, '')
                    yield item