from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from resources.lib.kedon import getlink
from resources.lib.mkd.onyoutube.video import youtube_thinhhanh, youtube_thinhhanhnext, youtube_topvideo
from resources.lib.mkd.onyoutube.tim import search_karaoke, search_youtube
import re, html
@Route.register
def index_youtube(plugin, **kwargs):
	Trendingyt = {'label': 'TOP THỊNH HÀNH',
	'info':{'plot':'Top video nhiều lượt tương tác (xem, thích, bình luận…) trên Youtube'},
	'art':{'thumb':'https://cdn.tgdd.vn//GameApp/1311257//cach-xem-top-thinh-hanh-tren-youtube-cac-nuoc-bang-dien-thoai-thumb-800x450.jpg',
	'fanart':'https://cdn.tgdd.vn//GameApp/1311257//cach-xem-top-thinh-hanh-tren-youtube-cac-nuoc-bang-dien-thoai-thumb-800x450.jpg'},
	'callback':youtube_thinhhanh}
	Topyt = {'label': 'TOP VIDEO CỦA NĂM',
	'info':{'plot':'Top video được xem nhiều nhất trên Youtube'},
	'art':{'thumb':'https://millardayo.com/wp-content/uploads/2018/01/topvideo-550x285.jpg',
	'fanart':'https://millardayo.com/wp-content/uploads/2018/01/topvideo-550x285.jpg'},
	'callback':youtube_topvideo}
	yield Listitem.search(search_youtube)
	yield timkaraoke()
	yield Listitem.from_dict(**Trendingyt)
	yield Listitem.from_dict(**Topyt)
	url = 'https://www.googleapis.com/youtube/v3/videos?part=snippet&chart=mostPopular&videoCategoryId=1&regionCode=VN&key=AIzaSyBBbFFBo8xg7GkSdhTu1WzFYdlm89XN87w&maxResults=50&order=rating'
	resp = getlink(url, url, 15*60)
	parsed = resp.json()
	for k in parsed['items']:
		if k['snippet']['thumbnails']:
			item = Listitem()
			tenvd = html.unescape(k['snippet']['title'])
			anhvd = k['snippet']['thumbnails']['high']['url']
			motavd = k['snippet']['description']
			idvd = k['id']
			item.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=%s' % idvd
			item.label = tenvd
			item.info['plot'] = motavd
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = anhvd
			item.set_callback(item.path)
			yield item
	if 'nextPageToken' in parsed:
		item1 = Listitem()
		token = parsed['nextPageToken']
		item1.label = 'Trang tiếp'
		item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
		item1.set_callback(youtube_thinhhanhnext, token)
		yield item1
def timkaraoke():
	item = Listitem()
	item.label = 'Tìm karaoke'
	item.info['plot'] = 'Tiện ích tìm kiếm karaoke'
	item.path = search_karaoke
	item.art['thumb'] = item.art['landscape'] = 'https://png.pngtree.com/png-vector/20190223/ourlarge/pngtree-karaoke-logo-vector-illustration-png-image_691264.jpg'
	item.art['fanart'] = 'https://image.freepik.com/free-vector/karaoke-logo_114055-38.jpg'
	item.set_callback(search_karaoke, item.path)
	return item