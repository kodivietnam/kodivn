from codequick import Route, Listitem, run, Script
from resources.lib.kedon import getlink, get_user_input, get_info_fs, play_fs, __addonnoti__
from resources.lib.mkd.onfshare.ifshare import index_fs
import re
import xbmcgui
import urllib
@Route.register
def searchnumber(plugin,search_query):
	search_query = get_user_input()
	if not search_query:
		return []
	dp = xbmcgui.DialogProgress()
	dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
	search_query = urllib.parse.quote_plus(search_query)
	z = 'http://gg.gg/' + search_query
	resp = getlink(z, z, 48*60*60)
	x = resp.url
	item = Listitem()
	if 'folder' in x:
		if '?' in x:
			match = re.search(r'folder/(.*?)\?', x)
			idfd = match.group(1)
		else:
			tach = x.split('folder/')
			idfd = tach[1]
		item.label = z
		item.info['plot'] = 'Mã CODE ' + search_query + ' được tạo từ trang rút gọn http://gg.gg'
		next_page = 1
		item.art['thumb'] = 'https://static.mservice.io/placebrand/s/momo-upload-api-200424091506-637233165063699729.png'
		item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
		item.set_callback(index_fs, idfd, next_page)
		yield item
	elif 'file' in x:
		item.label = get_info_fs(x)
		item.art['thumb'] = 'https://static.mservice.io/placebrand/s/momo-upload-api-200424091506-637233165063699729.png'
		item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
		item.set_callback(play_fs, x, item.label)
		yield item