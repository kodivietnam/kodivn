from codequick import Route, Listitem, run
from resources.lib.kedon import getlink, stream, referer, play_vnm, tiengruoi, quangcao
from urllib.parse import urlparse
import datetime
a = urlparse(tiengruoi()[1])
vebo = '%s://%s' % (a.scheme, a.netloc)
@Route.register
def index_vebo(plugin, **kwargs):
	url = 'https://api.vebo.xyz/api/match/featured'
	resp = getlink(url, vebo, 15*60)
	if resp is not None:
		kq = resp.json()
		for k in kq['data']:
			item = Listitem()
			time = datetime.datetime.fromtimestamp(int(k['timestamp'])/1000).strftime('%H:%M %d-%m')
			idk = k['id']
			item.label = '%s %s' % (time, k['name'])
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = '%s/static/img/logo.png' % vebo
			item.set_callback(list_vebo, idk, item.label)
			yield item
	else:
		yield quangcao()
@Route.register
def list_vebo(plugin, idk, title, **kwargs):
	url = 'https://live.vebo.xyz/api/match/%s/meta' % idk
	resp = getlink(url, vebo, 5*60)
	if resp is not None:
		if '.m3u8' in resp.text:
			kq = resp.json()
			for k in kq['data']['play_urls']:
				item = Listitem()
				item.label = '%s - %s' % (k['name'], title)
				linktrandau = '%s%s' % (stream(k['url']), referer(vebo))
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = '%s/static/img/logo.png' % vebo
				item.set_callback(play_vnm, linktrandau, item.label, '')
				yield item
		else:
			yield quangcao()
	else:
		yield quangcao()