from codequick import Route, Listitem, run
from resources.lib.kedon import getlink, stream, ace, play_vnm, quangcao
import urllib.parse
@Route.register
def index_vnm(plugin, **kwargs):
	url = 'https://mi3s.top/vnmedia'
	resp = getlink(url, url, 5*60)
	if resp is not None:
		tach = resp.text.split('\n')
		for k in tach:
			item = Listitem()
			tachhat = k.split('|')
			if len(tachhat)>1:
				kenh = urllib.parse.unquote(tachhat[1])
				item.label = item.info['plot'] = tachhat[0].replace('*','')
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = tachhat[3]
				if 'acestream' in kenh:
					linkplay = ace(kenh, item.label)
					item.path = linkplay
					item.set_callback(item.path)
				elif ':6878' in kenh:
					linkplay = ace(kenh, item.label)
					item.path = linkplay
					item.set_callback(item.path)
				else:
					linkplay = stream(kenh.strip())
					item.set_callback(play_vnm, linkplay, item.label, '')
				yield item
	else:
		yield quangcao()