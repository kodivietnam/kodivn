from codequick import Route, Listitem, run
from resources.lib.kedon import getlink, stream, referer, play_vnm, tiengruoi, quangcao
from urllib.parse import urlparse
import datetime
a = urlparse(tiengruoi()[0])
p90 = '%s://%s' % (a.scheme, a.netloc)
@Route.register
def index_90p(plugin, **kwargs):
	url = 'https://api.vebo.xyz/api/match/featured/mt'
	resp = getlink(url, p90, 15*60)
	if resp is not None:
		kq = resp.json()
		for k in kq['data']:
			item = Listitem()
			time = datetime.datetime.fromtimestamp(int(k['timestamp'])/1000).strftime('%H:%M %d-%m')
			idk = k['id']
			item.label = '%s %s' % (time, k['name'])
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://i.imgur.com/jyM3inb.png'
			item.set_callback(list_90p, idk, item.label)
			yield item
	else:
		yield quangcao()
@Route.register
def list_90p(plugin, idk, title, **kwargs):
	url = 'https://api.vebo.xyz/api/match/%s/meta' % idk
	resp = getlink(url, p90, 5*60)
	if resp is not None:
		if '.m3u8' in resp.text:
			kq = resp.json()
			for k in kq['data']['play_urls']:
				item = Listitem()
				item.label = '%s - %s' % (k['name'], title)
				linktrandau = '%s%s' % (stream(k['url']), referer(p90))
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://i.imgur.com/jyM3inb.png'
				item.set_callback(play_vnm, linktrandau, item.label, '')
				yield item
		else:
			yield quangcao()
	else:
		yield quangcao()