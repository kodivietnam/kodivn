from codequick import Route, Listitem, run
from resources.lib.kedon import tb
from resources.lib.mkd.onthethao.tinthethao import index_tinthethao
from resources.lib.mkd.acest import index_acestream
from resources.lib.mkd.ontruyenhinh.listiptv import list_iptv_sport
from resources.lib.mkd.onthethao.phut90 import index_90p
from resources.lib.mkd.onthethao.cakhia import index_cakhia
from resources.lib.mkd.onthethao.rakhoi import index_rakhoi
from resources.lib.mkd.onthethao.xoilacco import index_xoilacco
from resources.lib.mkd.onthethao.xoilac import index_xoilac
from resources.lib.mkd.onthethao.mitom import index_mitom
from resources.lib.mkd.onthethao.net90p import index_net90p
from resources.lib.mkd.onthethao.saoke import index_saoke
from resources.lib.mkd.onthethao.bongdahomnay import index_bongdahomnay
from resources.lib.mkd.onthethao.binhluan import index_binhluan
from resources.lib.mkd.onthethao.xembd import index_xembd
from resources.lib.mkd.onthethao.vebo import index_vebo
from resources.lib.mkd.onthethao.banhkhuc import index_banhkhuc
from resources.lib.mkd.onthethao.xoilacxyz import index_xoilacxyz
from resources.lib.mkd.onthethao.xembong import index_xembong
from resources.lib.mkd.onthethao.socolive import index_socolive
CATEGORIESsport = {
'Sport IPTV': 'https://iptv-org.github.io/iptv/categories/sports.m3u'}
@Route.register
def index_thethao(plugin, content_type='segment'):
	wtinthethao = {'label': r'Tin thể thao',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://thethao360.tv/wp-content/uploads/2020/12/logo-3.png',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_tinthethao}
	wnhomacs = {'label': 'Nhóm ACESTREAM',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg',
	'fanart':'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg'},
	'callback':index_acestream}
	yield Listitem.from_dict(**wtinthethao)
	yield Listitem.from_dict(**wnhomacs)
	for tenlist, urllist in list(CATEGORIESsport.items()):
		item = Listitem()
		item.label = tenlist
		item.info['plot'] = tb
		item.art['thumb'] = 'https://i.imgur.com/x0V60BO.png'
		item.art['fanart'] = 'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'
		item.set_callback(list_iptv_sport, url=urllist)
		yield item
	w90phut = {'label': '90PHUT.TV',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://i.imgur.com/jyM3inb.png',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_90p}
	wcakhia = {'label': 'CAKHIA TV',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://cakhiastatic.fastlycdnlive.xyz/cakhia/cakhia33/user/img/ckstrim.png',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_cakhia}
	wrakhoi = {'label': 'RAKHOI TV',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://rakhoi-tv.com/wp-content/uploads/2021/12/rakhoiTVremake.png',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_rakhoi}
	wxoilacco = {'label': 'XOILAC.CO',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://media.cdnandroid.com/item_images/1139044/imagen-xoilac-tv-xem-bong-da-tivi-truc-tuyen-0big.jpg',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_xoilacco}
	wxoilac = {'label': 'XOILAC2.COM',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://xoilac2.com/wp-content/themes/bongda/dist/images/xoilac2.com.png',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_xoilac}
	wmitom = {'label': 'MITOM1.TV',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://mitom1.tv/wp-content/themes/bongda2/dist/images/mitom1.tv.png',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_mitom}
	wnet90p = {'label': '90PHUT.NET',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://90phut.net/wp-content/themes/bongda/public/images/90phutnet.png',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_net90p}
	wsaoke = {'label': 'SAOKE.LIVE',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://9767a59e2b.vws.vegacdn.vn/template/logo1.png',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_saoke}
	wbongdahomnay = {'label': 'BONGDAHOMNAY',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://i.imgur.com/TlXaeKj.png',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_bongdahomnay}
	wbinhluantv = {'label': 'BINHLUANTV',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://xoilac.90phutttttttt.xyz/imgs/logo.png',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_binhluan}
	wxembd = {'label': r'XEMBD.LIVE',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://xembd.live/wp-content/themes/v2.1/assets/images/logo.png',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_xembd}
	wvebo = {'label': r'VEBO.TOP',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://bem2.vn/wp-content/uploads/2021/12/bieu-tuong-vebotv.jpg',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_vebo}
	wbanhkhuc = {'label': r'BANHKHUC.LIVE',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://banhkhuc.live/bk/static/img/banhkhuctv.png',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_banhkhuc}
	wxoilacxyz = {'label': r'XOILAC.XYZ',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://xoilac.xyz/xl/static/img/logo.png',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_xoilacxyz}
	wxembong = {'label': r'XEMBONGDA.NET',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://xembong.io/themes/frontend/default/img/logo.png',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_xembong}
	wsocolive = {'label': r'SOCOLIVE.ORG',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://sta.cvndnss.com/web/assets/soco/img/logo2.png',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_socolive}
	yield Listitem.from_dict(**wvebo)
	yield Listitem.from_dict(**wbanhkhuc)
	yield Listitem.from_dict(**wxoilacxyz)
	yield Listitem.from_dict(**w90phut)
	yield Listitem.from_dict(**wbongdahomnay)
	yield Listitem.from_dict(**wbinhluantv)
	yield Listitem.from_dict(**wcakhia)
	yield Listitem.from_dict(**wrakhoi)
	yield Listitem.from_dict(**wxoilacco)
	yield Listitem.from_dict(**wxoilac)
	yield Listitem.from_dict(**wmitom)
	yield Listitem.from_dict(**wnet90p)
	yield Listitem.from_dict(**wsaoke)
	yield Listitem.from_dict(**wxembd)
	yield Listitem.from_dict(**wxembong)
	yield Listitem.from_dict(**wsocolive)