from codequick import Route, Resolver, Listitem
from importlib import import_module
from xbmc import executebuiltin
from xbmcgui import getCurrentWindowId
@Route.register
def root(plugin):
    executebuiltin('UpdateAddonRepos()')
    return generic_menu(plugin, 'root')
@Route.register
def generic_menu(plugin, item_id=None, **kwargs):
    if item_id is not None:
        menu_id = item_id
        plugin.redirect_single_item = True
        menu = import_module('resources.lib.menu_utils').get_sorted_menu(plugin, menu_id)
        if not menu:
            yield False
        for k in menu:
            item = Listitem()
            w =  import_module('resources.lib.addon_utils')
            item.label = import_module('resources.lib.addon_utils').get_item_label(k[1], k[2])
            if 'thumb' in k[2]:
                item.art['thumb'] = w.get_item_media_path(k[2]['thumb'])
            if 'fanart' in k[2]:
                item.art['fanart'] = w.get_item_media_path(k[2]['fanart'])
            item.params['item_id'] = k[1]
            if 'route' in k[2]:
                item.set_callback((Route.ref(k[2]['route'])))
            elif 'resolver' in k[2]:
                item.set_callback((Resolver.ref(k[2]['resolver'])))
            else:
                continue
            yield item
    else:
        executebuiltin(f'Action(Back,{getCurrentWindowId()})')
        yield False