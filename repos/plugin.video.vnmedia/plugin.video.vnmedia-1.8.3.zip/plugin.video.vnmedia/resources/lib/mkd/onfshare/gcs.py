from codequick import Route, Listitem, run
@Route.register
def index_gcs(plugin, dataUrl='TextURL'):
    import xbmcaddon
    from resources.lib.kedon import quangcao, getrow, tb, getlink, play_fs, yttk
    urltext = xbmcaddon.Addon().getSetting(dataUrl)
    if urltext == '':
        u = 'https://docs.google.com/spreadsheets/d/1PBi7p8orE-mjHHleXsgQ5YmHwnomyCiD2nMVIZCgcBA/htmlview'
    else:
        u = urltext
    respx = getlink(u, u, 7200)
    if respx is not None:
        x = respx.url
        if 'docs.google.com' in x:
            import re
            if 'gid' in x:
                timid = re.findall(r'/d/(.*?)/.*?gid=(\d+)', x)
                sid = timid[0][0]
                gid = timid[0][1]
            else:
                sid = re.findall(r'/d/(.*?)/', x)[0]
                gid = '0'
            url = 'https://docs.google.com/spreadsheets/d/' + \
                sid + '/gviz/tq?gid=' + gid + '&headers=1'
            resp = getlink(url, url, 7200)
            if resp is not None:
                import json
                from resources.lib.mkd.onfshare.ifshare import index_fs, tfavo
                nd = re.search(r'\((.*?)}\)', resp.text).group(1) + '}'
                m = json.loads(nd)
                if 'http' in m['table']['cols'][1]['label']:
                    item = Listitem()
                    kenh = m['table']['cols'][1]['label']
                    item.context.script(tfavo, 'Thêm vào Fshare Favorite', kenh)
                    item.label = m['table']['cols'][0]['label']
                    item.info['mediatype'] = 'episode'
                    item.info['rating'] = 10.0
                    item.info['trailer'] = yttk(item.label)
                    if len(m['table']['cols']) > 2:
                        item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = m['table']['cols'][2]['label']
                    else:
                        item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://i.imgur.com/EpIPQXR.png'
                    if len(m['table']['cols']) > 3:
                        item.info['plot'] = f"{m['table']['cols'][3]['label']}\n{tb}"
                    else:
                        item.info['plot'] = tb
                    if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                        thumuc = kenh.split('folder/')
                        z = thumuc[1]
                        item.set_callback(index_fs, z, 1)
                    elif r'file' in kenh:
                        if xbmcaddon.Addon().getSetting("taifshare") == "true":
                            from resources.lib.download import downloadfs
                            item.context.script(downloadfs, 'Tải về', kenh)
                        item.set_callback(play_fs, kenh, item.label)
                    elif r'docs.google.com' in kenh:
                        item.set_callback(listgg_gcs, kenh, item.label)
                    elif r'VMF' in kenh:
                        l = kenh.replace('VMF-', '')
                        item.set_callback(listvmf_gcs, l, item.label)
                    yield item
                for cow in m['table']['cols']:
                    p = cow['label']
                    if r'|http' in p:
                        item = Listitem()
                        tachhat = p.split('|')
                        if tachhat[1] and len(tachhat) > 1:
                            kenh = tachhat[1]
                            item.label = tachhat[0].translate(str.maketrans({'*': '', '@': ''}))
                            item.info['mediatype'] = 'episode'
                            item.info['rating'] = 10.0
                            item.info['trailer'] = yttk(item.label)
                            item.context.script(tfavo, 'Thêm vào Fshare Favorite', kenh)
                            if len(tachhat) > 3:
                                item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = tachhat[3]
                            else:
                                item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://i.imgur.com/EpIPQXR.png'
                            if len(tachhat) > 4:
                                item.info['plot'] = f'{tachhat[4]}\n{tb}'
                            else:
                                item.info['plot'] = tb
                            if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                                thumuc = kenh.split('folder/')
                                h = thumuc[1]
                                item.set_callback(index_fs, h, 1)
                            elif r'file' in kenh:
                                if xbmcaddon.Addon().getSetting("taifshare") == "true":
                                    from resources.lib.download import downloadfs
                                    item.context.script(downloadfs, 'Tải về', kenh)
                                item.set_callback(play_fs, kenh, item.label)
                            elif r'docs.google.com' in kenh:
                                item.set_callback(listgg_gcs, kenh, item.label)
                            elif r'VMF' in kenh:
                                l = kenh.replace('VMF-', '')
                                item.set_callback(listvmf_gcs, l, item.label)
                            yield item
                for row in m['table']['rows']:
                    k = getrow(row['c'][0])
                    if r'|http' in k:
                        item = Listitem()
                        tachhat = k.split('|')
                        if tachhat[1] and len(tachhat) > 1:
                            kenh = tachhat[1]
                            item.label = tachhat[0].translate(str.maketrans({'*': '', '@': ''}))
                            item.info['mediatype'] = 'episode'
                            item.info['rating'] = 10.0
                            item.info['trailer'] = yttk(item.label)
                            item.context.script(tfavo, 'Thêm vào Fshare Favorite', kenh)
                            if len(tachhat) > 3:
                                item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = tachhat[3]
                            else:
                                item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://i.imgur.com/EpIPQXR.png'
                            if len(tachhat) > 4:
                                item.info['plot'] = f'{tachhat[4]}\n{tb}'
                            else:
                                item.info['plot'] = tb
                            if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                                thumuc = kenh.split('folder/')
                                h = thumuc[1]
                                item.set_callback(index_fs, h, 1)
                            elif r'file' in kenh:
                                if xbmcaddon.Addon().getSetting("taifshare") == "true":
                                    from resources.lib.download import downloadfs
                                    item.context.script(downloadfs, 'Tải về', kenh)
                                item.set_callback(play_fs, kenh, item.label)
                            elif r'docs.google.com' in kenh:
                                item.set_callback(listgg_gcs, kenh, item.label)
                            elif r'VMF' in kenh:
                                l = kenh.replace('VMF-', '')
                                item.set_callback(listvmf_gcs, l, item.label)
                            yield item
                    elif 'http' in getrow(row['c'][1]):
                        item = Listitem()
                        item.label = getrow(row['c'][0])
                        item.info['mediatype'] = 'episode'
                        item.info['rating'] = 10.0
                        item.info['trailer'] = yttk(item.label)
                        kenh = getrow(row['c'][1])
                        item.context.script(tfavo, 'Thêm vào Fshare Favorite', kenh)
                        if len(row['c']) > 2:
                            item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = getrow(row['c'][2])
                        else:
                            item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://i.imgur.com/EpIPQXR.png'
                        if len(row['c']) > 3:
                            item.info['plot'] = f"{getrow(row['c'][3])}\n{tb}"
                        else:
                            item.info['plot'] = tb
                        if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                            thumuc = kenh.split('folder/')
                            a = thumuc[1]
                            item.set_callback(index_fs, a, 1)
                        elif r'file' in kenh:
                            if xbmcaddon.Addon().getSetting("taifshare") == "true":
                                from resources.lib.download import downloadfs
                                item.context.script(downloadfs, 'Tải về', kenh)
                            item.set_callback(play_fs, kenh, item.label)
                        elif r'docs.google.com' in kenh:
                            item.set_callback(listgg_gcs, kenh, item.label)
                        elif r'VMF' in kenh:
                            l = kenh.replace('VMF-', '')
                            item.set_callback(listvmf_gcs, l, item.label)
                        yield item
                    else:
                        yield []
            else:
                yield []
        else:
            kq = '\n'.join([ll.rstrip()
                           for ll in respx.text.splitlines() if ll.strip()])
            tach = kq.split('\n')
            for k in tach:
                item = Listitem()
                tachhat = k.split('|')
                if len(tachhat) > 1:
                    from resources.lib.mkd.onfshare.ifshare import index_fs, tfavo
                    kenh = tachhat[1]
                    item.context.script(tfavo, 'Thêm vào Fshare Favorite', kenh)
                    item.label = tachhat[0].translate(str.maketrans({'*': '', '@': ''}))
                    item.info['mediatype'] = 'episode'
                    item.info['rating'] = 10.0
                    item.info['trailer'] = yttk(item.label)
                    if len(tachhat) > 3:
                        item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = tachhat[3]
                    else:
                        item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://i.imgur.com/EpIPQXR.png'
                    if len(tachhat) > 4:
                        item.info['plot'] = f'{tachhat[4]}\n{tb}'
                    else:
                        item.info['plot'] = tb
                    if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                        thumuc = kenh.split('folder/')
                        f = thumuc[1]
                        item.set_callback(index_fs, f, 1)
                    elif r'file' in kenh:
                        if xbmcaddon.Addon().getSetting("taifshare") == "true":
                            from resources.lib.download import downloadfs
                            item.context.script(downloadfs, 'Tải về', kenh)
                        item.set_callback(play_fs, kenh, item.label)
                    elif r'docs.google.com' in kenh:
                        item.set_callback(listgg_gcs, kenh, item.label)
                    elif r'VMF' in kenh:
                        l = kenh.replace('VMF-', '')
                        item.set_callback(listvmf_gcs, l, item.label)
                    yield item
    else:
        yield quangcao()
@Route.register
def listgg_gcs(plugin, urltext, title):
    import re
    from resources.lib.kedon import getrow, tb, getlink, play_fs, yttk
    if 'gid' in urltext:
        timid = re.findall(r'/d/(.+?)/.+?gid=(\d+)', urltext)
        sid = timid[0][0]
        gid = timid[0][1]
    else:
        sid = re.findall(r'/d/(.*?)/', urltext)[0]
        gid = '0'
    url = 'https://docs.google.com/spreadsheets/d/' + \
        sid + '/gviz/tq?gid=' + gid + '&headers=1'
    resp = getlink(url, url, 7200)
    if resp is not None:
        import json, xbmcaddon
        from resources.lib.mkd.onfshare.ifshare import index_fs, tfavo
        nd = re.search(r'\((.*?)}\)', resp.text).group(1) + '}'
        m = json.loads(nd)
        if 'http' in m['table']['cols'][1]['label']:
            item = Listitem()
            kenh = m['table']['cols'][1]['label']
            item.context.script(tfavo, 'Thêm vào Fshare Favorite', kenh)
            item.label = m['table']['cols'][0]['label']
            item.info['mediatype'] = 'episode'
            item.info['rating'] = 10.0
            item.info['trailer'] = yttk(item.label)
            if len(m['table']['cols']) > 2:
                item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = m['table']['cols'][2]['label']
            else:
                item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://i.imgur.com/EpIPQXR.png'
            if len(m['table']['cols']) > 3:
                item.info['plot'] = f"{m['table']['cols'][3]['label']}\n{tb}"
            else:
                item.info['plot'] = tb
            if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                thumuc = kenh.split('folder/')
                z = thumuc[1]
                item.set_callback(index_fs, z, 1)
            elif r'file' in kenh:
                if xbmcaddon.Addon().getSetting("taifshare") == "true":
                    from resources.lib.download import downloadfs
                    item.context.script(downloadfs, 'Tải về', kenh)
                item.set_callback(play_fs, kenh, item.label)
            elif r'docs.google.com' in kenh:
                item.set_callback(listgg_gcs, kenh, item.label)
            elif r'VMF' in kenh:
                l = kenh.replace('VMF-', '')
                item.set_callback(listvmf_gcs, l, item.label)
            yield item
        for cow in m['table']['cols']:
            p = cow['label']
            if r'|http' in p:
                item = Listitem()
                tachhat = p.split('|')
                if tachhat[1] and len(tachhat) > 1:
                    kenh = tachhat[1]
                    item.label = tachhat[0].translate(str.maketrans({'*': '', '@': ''}))
                    item.info['mediatype'] = 'episode'
                    item.info['rating'] = 10.0
                    item.info['trailer'] = yttk(item.label)
                    item.context.script(tfavo, 'Thêm vào Fshare Favorite', kenh)
                    if len(tachhat) > 3:
                        item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = tachhat[3]
                    else:
                        item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://i.imgur.com/EpIPQXR.png'
                    if len(tachhat) > 4:
                        item.info['plot'] = f'{tachhat[4]}\n{tb}'
                    else:
                        item.info['plot'] = tb
                    if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                        thumuc = kenh.split('folder/')
                        h = thumuc[1]
                        item.set_callback(index_fs, h, 1)
                    elif r'file' in kenh:
                        if xbmcaddon.Addon().getSetting("taifshare") == "true":
                            from resources.lib.download import downloadfs
                            item.context.script(downloadfs, 'Tải về', kenh)
                        item.set_callback(play_fs, kenh, item.label)
                    elif r'docs.google.com' in kenh:
                        item.set_callback(listgg_gcs, kenh, item.label)
                    elif r'VMF' in kenh:
                        l = kenh.replace('VMF-', '')
                        item.set_callback(listvmf_gcs, l, item.label)
                    yield item
        for row in m['table']['rows']:
            k = getrow(row['c'][0])
            if r'|http' in k:
                item = Listitem()
                tachhat = k.split('|')
                if tachhat[1] and len(tachhat) > 1:
                    kenh = tachhat[1]
                    item.label = tachhat[0].translate(str.maketrans({'*': '', '@': ''}))
                    item.info['mediatype'] = 'episode'
                    item.info['rating'] = 10.0
                    item.info['trailer'] = yttk(item.label)
                    item.context.script(tfavo, 'Thêm vào Fshare Favorite', kenh)
                    if len(tachhat) > 3:
                        item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = tachhat[3]
                    else:
                        item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://i.imgur.com/EpIPQXR.png'
                    if len(tachhat) > 4:
                        item.info['plot'] = f'{tachhat[4]}\n{tb}'
                    else:
                        item.info['plot'] = tb
                    if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                        thumuc = kenh.split('folder/')
                        h = thumuc[1]
                        item.set_callback(index_fs, h, 1)
                    elif r'file' in kenh:
                        if xbmcaddon.Addon().getSetting("taifshare") == "true":
                            from resources.lib.download import downloadfs
                            item.context.script(downloadfs, 'Tải về', kenh)
                        item.set_callback(play_fs, kenh, item.label)
                    elif r'docs.google.com' in kenh:
                        item.set_callback(listgg_gcs, kenh, item.label)
                    elif r'VMF' in kenh:
                        l = kenh.replace('VMF-', '')
                        item.set_callback(listvmf_gcs, l, item.label)
                    yield item
            elif 'http' in getrow(row['c'][1]):
                item = Listitem()
                item.label = getrow(row['c'][0])
                item.info['mediatype'] = 'episode'
                item.info['rating'] = 10.0
                item.info['trailer'] = yttk(item.label)
                kenh = getrow(row['c'][1])
                item.context.script(tfavo, 'Thêm vào Fshare Favorite', kenh)
                if len(row['c']) > 2:
                    item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = getrow(row['c'][2])
                else:
                    item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://i.imgur.com/EpIPQXR.png'
                if len(row['c']) > 3:
                    item.info['plot'] = f"{getrow(row['c'][3])}\n{tb}"
                else:
                    item.info['plot'] = tb
                if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                    thumuc = kenh.split('folder/')
                    a = thumuc[1]
                    item.set_callback(index_fs, a, 1)
                elif r'file' in kenh:
                    if xbmcaddon.Addon().getSetting("taifshare") == "true":
                        from resources.lib.download import downloadfs
                        item.context.script(downloadfs, 'Tải về', kenh)
                    item.set_callback(play_fs, kenh, item.label)
                elif r'docs.google.com' in kenh:
                    item.set_callback(listgg_gcs, kenh, item.label)
                elif r'VMF' in kenh:
                    l = kenh.replace('VMF-', '')
                    item.set_callback(listvmf_gcs, l, item.label)
                yield item
            else:
                yield []
    else:
        yield []
@Route.register
def listvmf_gcs(plugin, url, title):
    from resources.lib.kedon import quangcao, tb, getlink, play_fs, yttk
    resp = getlink(url, url, 7200)
    if resp is not None:
        kq = '\n'.join([ll.rstrip()
                       for ll in resp.text.splitlines() if ll.strip()])
        tach = kq.split('\n')
        for k in tach:
            import xbmcaddon
            from resources.lib.mkd.onfshare.ifshare import index_fs, tfavo
            item = Listitem()
            tachhat = k.split('|')
            if len(tachhat) > 1:
                kenh = tachhat[1]
                item.context.script(tfavo, 'Thêm vào Fshare Favorite', kenh)
                item.label = tachhat[0].translate(str.maketrans({'*': '', '@': ''}))
                item.info['mediatype'] = 'episode'
                item.info['rating'] = 10.0
                item.info['trailer'] = yttk(item.label)
                if len(tachhat) > 3:
                    item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = tachhat[3]
                else:
                    item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://i.imgur.com/EpIPQXR.png'
                if len(tachhat) > 4:
                    item.info['plot'] = f'{tachhat[4]}\n{tb}'
                else:
                    item.info['plot'] = tb
                if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                    thumuc = kenh.split('folder/')
                    t = thumuc[1]
                    item.set_callback(index_fs, t, 1)
                elif r'file' in kenh:
                    if xbmcaddon.Addon().getSetting("taifshare") == "true":
                        from resources.lib.download import downloadfs
                        item.context.script(downloadfs, 'Tải về', kenh)
                    item.set_callback(play_fs, kenh, item.label)
                elif r'docs.google.com' in kenh:
                    item.set_callback(listgg_gcs, kenh, item.label)
                elif r'VMF' in kenh:
                    l = kenh.replace('VMF-', '')
                    item.set_callback(listvmf_gcs, l, item.label)
                yield item
    else:
        yield quangcao()