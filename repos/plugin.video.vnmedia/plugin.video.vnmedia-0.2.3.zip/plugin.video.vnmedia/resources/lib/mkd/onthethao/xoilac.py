from __future__ import unicode_literals
from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from resources.lib.kedon import qc, tb, getlink, stream, referer, play_vnm, ifr_xoilac
@Route.register
def index_xoilac(plugin, content_type='segment'):
	url = 'https://xoilac2.com/wp-admin/admin-ajax.php?action=filter_match&filter=all'
	resp = getlink(url, url, 15*60)
	soup = BeautifulSoup(resp.json()['data'], 'html.parser')
	episodes = soup.select('a.link-match')
	for episode in episodes:
		item = Listitem()
		linktrandau = episode.get('href')
		item.label = episode.get('title')
		item.art['thumb'] = 'https://xoilac2.com/wp-content/themes/bongda/dist/images/xoilac2.com.png'
		item.art['fanart'] = 'https://xoilac2.com/wp-content/themes/bongda/dist/images/xoilac2.com.png'
		item.set_callback(list_xoilac, linktrandau, item.label)
		yield item

@Route.register
def list_xoilac(plugin, url, title):
	resp = getlink(url, url, 0)
	soup = BeautifulSoup(resp.text, 'html.parser')
	episodes = soup.select('div[class="link-video"] a')
	found = False
	if len(episodes) > 1:
		for episode in episodes:
			item1 = Listitem()
			linktrandau1 = episode.get('href')
			item1.label = episode.text.strip()
			item1.art['thumb'] = 'https://xoilac2.com/wp-content/themes/bongda/dist/images/xoilac2.com.png'
			item1.art['fanart'] = 'https://xoilac2.com/wp-content/themes/bongda/dist/images/xoilac2.com.png'
			item1.set_callback(ifr_xoilac, linktrandau1, item1.label)
			yield item1
	if not found:
		item2 = Listitem()
		item2.label = 'Default - ' + title
		item2.art['thumb'] = 'https://xoilac2.com/wp-content/themes/bongda/dist/images/xoilac2.com.png'
		item2.art['fanart'] = 'https://xoilac2.com/wp-content/themes/bongda/dist/images/xoilac2.com.png'
		item2.set_callback(ifr_xoilac, url, item2.label)
		yield item2