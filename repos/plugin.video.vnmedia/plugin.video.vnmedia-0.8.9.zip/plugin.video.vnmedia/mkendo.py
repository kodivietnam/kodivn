import importlib, xbmc
from codequick import run
xbmc.executebuiltin('UpdateAddonRepos')
xbmc.executebuiltin('UpdateLocalAddons')
def main():
    exception = run()
    if isinstance(exception, Exception):
        main = importlib.import_module('resources.lib.main')
        main.error_handler(exception)
if __name__ == "__main__":
    main()