from codequick import Route, Listitem, run, Script
from resources.lib.kedon import getlink, get_user_input, get_info_fs, play_fs, __addonnoti__, quangcao
from resources.lib.mkd.onfshare.ifshare import index_fs, tfavo
from resources.lib.download import downloadfs
import re, xbmcgui, urllib
@Route.register
def searchnumber(plugin,search_query, **kwargs):
	search_query = get_user_input()
	if not search_query:
		Script.notify(__addonnoti__, 'Bạn chưa nhập CODE')
		yield quangcao()
	else:
		dp = xbmcgui.DialogProgress()
		dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
		search_query = urllib.parse.quote_plus(search_query)
		z = 'http://gg.gg/%s' % search_query
		resp = getlink(z, z, 48*60*60)
		x = resp.url
		if 'folder' in x:
			item = Listitem()
			if '?' in x:
				match = re.search(r'folder/(.*?)\?', x)
				idfd = match.group(1)
			else:
				tach = x.split('folder/')
				idfd = tach[1]
			item.label = z
			item.info['plot'] = 'Mã CODE %s được tạo từ trang rút gọn http://gg.gg' % search_query
			next_page = 1
			item.art['thumb'] = item.art['landscape'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=1&size=400x400&ecc=L' % x
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			item.context.script(tfavo, 'Thêm vào Fshare Favorite', x)
			item.set_callback(index_fs, idfd, next_page)
			yield item
		elif 'file' in x:
			item = Listitem()
			item.label = get_info_fs(x)[0]
			item.info['size'] = get_info_fs(x)[1]
			item.art['thumb'] = item.art['landscape'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=1&size=400x400&ecc=L' % x
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			item.context.script(downloadfs, 'Tải về', x)
			item.context.script(tfavo, 'Thêm vào Fshare Favorite', x)
			item.set_callback(play_fs, x, item.label)
			yield item
		else:
			Script.notify(__addonnoti__, 'CODE không đúng')
			yield quangcao()