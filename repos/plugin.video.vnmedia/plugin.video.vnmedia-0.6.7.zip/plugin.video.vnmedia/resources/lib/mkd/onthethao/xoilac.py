from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from resources.lib.kedon import getlink, playsocolive
@Route.register
def index_xoilac(plugin, content_type='segment'):
	url = 'https://xoilac2.net/'
	resp = getlink(url, url, 15*60)
	soup = BeautifulSoup(resp.text, 'html.parser')
	episodes = soup.select('a.redirectPopup')
	for episode in episodes:
		item = Listitem()
		linktrandau = episode.get('href').split('/')[-1]
		item.label = episode.get('title')
		item.art['thumb'] = 'https://xoilac2.net/wp-content/themes/bongda/dist/images/xoilac2.net.png'
		item.art['fanart'] = 'https://xoilac2.net/wp-content/themes/bongda/dist/images/xoilac2.net.png'
		item.set_callback(playsocolive, linktrandau, item.label)
		yield item