from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from resources.lib.kedon import getlink, ifr_khomuc, qc, tb, stream, play_vnm
@Route.register
def index_khomuc(plugin, content_type='segment'):
	url = 'https://khomuc.tv/'
	resp = getlink(url, url, 15*60)
	soup = BeautifulSoup(resp.text, 'html.parser')
	episodes = soup.select('div.item-live-now-match.d-flex.flex-column.me-3 a.d-flex.flex-column.text-black.text-decoration-none')
	if len(episodes) > 0:
		for episode in episodes:
			item = Listitem()
			linktrandau = episode.get('href')
			if episode.select('div.d-flex.align-items-center.bg-white.px-3.py-3 span.flex-1.ms-1.fw-bold'):
				doinha = episode.select_one('div.d-flex.align-items-center.bg-white.px-3.py-3 span.flex-1.ms-1.fw-bold').text.strip()
				doikhach = episode.select_one('div.d-flex.align-items-center.bg-white.px-3.pb-3 span.flex-1.fw-bold.ms-1').text.strip()
				item.label = doinha + ' vs ' + doikhach
				item.art['thumb'] = 'https://khomuc3.com/wp-content/uploads/2021/11/cropped-logo-website-khomuc.jpg'
				item.art['fanart'] = 'https://khomuc3.com/wp-content/uploads/2021/11/cropped-logo-website-khomuc.jpg'
				item.set_callback(ifr_khomuc, linktrandau, item.label)
				yield item
	else:
		item3 = Listitem()
		linkmacdinh = stream(qc)
		item3.label = 'Đang cập nhật'
		item3.info['plot'] = tb
		item3.art['thumb'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.art['fanart'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.set_callback(play_vnm, linkmacdinh, item3.label, '')
		yield item3