from codequick import Route, Listitem, run
from resources.lib.kedon import logotv, tb, getlink, stream, ace, play_vnm
import re
@Route.register
def list_manhkendo(plugin, url):
	resp = getlink(url, url, 60*60)
	tach = resp.text.split('\n')
	for k in tach:
		item = Listitem()
		tachhat = k.split('|')
		if len(tachhat)>1:
			kenh = tachhat[1]
			item.label =tachhat[0].replace('*','')
			item.art['thumb'] = tachhat[3]
			item.art['fanart'] = tachhat[3]
			if 'acestream' in kenh:
				linkplay = ace(kenh, item.label)
				item.path = linkplay
				item.set_callback(item.path)
			elif ':6878' in kenh:
				linkplay = ace(kenh, item.label)
				item.path = linkplay
				item.set_callback(item.path)
			else:
				linkplay = stream(kenh.strip())
				item.set_callback(play_vnm, linkplay, item.label, '')
			item.info['plot'] = tb
			yield item

@Route.register
def list_iptv(plugin, url):
	resp = getlink(url, url, 2*60*60)
	kq = '\n'.join([ll.rstrip() for ll in resp.text.splitlines() if ll.strip()])
	kq = re.sub(r'#h(.*?)\n', '', kq)
	kq = re.sub(r'#EXTV(.*?)\n', '', kq)
	ketqua = kq.split('#EXTI')
	for tach in ketqua:
		item = Listitem()
		listplay = re.findall(r'NF(.*),(.*)\n(.*)', tach)
		for k in listplay:
			if len(k)>2:
				logo = re.search(r'tvg-logo="(.*?)"', k[0])
				if logo:
					item.art['thumb'] = logo.group(1)
					item.art['fanart'] = logo.group(1)
				else:
					item.art['thumb'] = logotv
					item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
				item.label = k[1].strip()
				kenh = k[2]
				if 'acestream' in kenh:
					linkplay = ace(kenh, item.label)
					item.path = linkplay
					item.set_callback(item.path)
				elif ':6878' in kenh:
					linkplay = ace(kenh, item.label)
					item.path = linkplay
					item.set_callback(item.path)
				else:
					linkplay = stream(kenh.strip())
					item.set_callback(play_vnm, linkplay, item.label, '')
				item.info['plot'] = tb
				yield item

@Route.register
def list_iptv_sport(plugin, url):
	resp = getlink(url, url, 15*60)
	kq = '\n'.join([ll.rstrip() for ll in resp.text.splitlines() if ll.strip()])
	kq = re.sub(r'#h(.*?)\n', '', kq)
	kq = re.sub(r'#EXTV(.*?)\n', '', kq)
	ketqua = kq.split('#EXTI')
	for tach in ketqua:
		item = Listitem()
		listplay = re.findall(r'NF(.*),(.*)\n(.*)', tach)
		for k in listplay:
			if len(k)>2:
				logo = re.search(r'tvg-logo="(.*?)"', k[0])
				if logo:
					item.art['thumb'] = logo.group(1)
					item.art['fanart'] = logo.group(1)
				else:
					item.art['thumb'] = logotv
					item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
				item.label = k[1].strip()
				kenh = k[2]
				if 'acestream' in kenh:
					linkplay = ace(kenh, item.label)
					item.path = linkplay
					item.set_callback(item.path)
				elif ':6878' in kenh:
					linkplay = ace(kenh, item.label)
					item.path = linkplay
					item.set_callback(item.path)
				else:
					linkplay = stream(kenh.strip())
					item.set_callback(play_vnm, linkplay, item.label, '')
				item.info['plot'] = tb
				yield item