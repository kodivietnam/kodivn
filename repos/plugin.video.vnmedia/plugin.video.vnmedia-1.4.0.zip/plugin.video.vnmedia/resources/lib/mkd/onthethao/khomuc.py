from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from urllib.parse import urlparse
from resources.lib.kedon import getlink, ifr_khomuc, quangcao, khomuc
import re
l = khomuc()[0]
m = urlparse(l)
url = '%s://%s/' % (m.scheme, m.netloc)
@Route.register
def index_khomuc(plugin, **kwargs):
	resp = getlink(url, url, 5*60)
	soup = BeautifulSoup(resp.content, 'html.parser')
	episodes = soup.select('section.home-live-now div.item-live-now-match a.d-flex.flex-column.text-black')
	if len(episodes) > 0:
		for episode in episodes:
			item = Listitem()
			linktrandau = episode.get('href')
			if episode.select('div.d-flex.align-items-center.bg-white.px-3.py-3 span.flex-1.ms-1.fw-bold'):
				time = '%s:%s' % (linktrandau[-5:-3], linktrandau[-3:-1])
				ngay = linktrandau[-16:-11]
				tran = re.search(r'truc-tiep-(.*?)-%s' % ngay, linktrandau).group(1)
				tran = tran.replace('-', ' ').title().replace('Vs', 'vs')
				item.label = '%s %s: %s' % (time, ngay, tran)
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://khomuc3.com/wp-content/uploads/2021/11/cropped-logo-website-khomuc.jpg'
				item.set_callback(ifr_khomuc, linktrandau, item.label)
				yield item
	else:
		yield quangcao()