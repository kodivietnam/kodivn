from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from resources.lib.kedon import getlink, ifr_xembong
@Route.register
def index_vaoroi(plugin, **kwargs):
	resp = getlink('https://hqth.me/vaoroi', 'https://hqth.me/vaoroi', 15*60)
	url = resp.url
	soup = BeautifulSoup(resp.content, 'html.parser')
	episodes = soup.select('div.panel.panel-default div.matches-lst-tr.clearfix')
	for episode in episodes:
		item = Listitem()
		item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = '%s/themes/frontend/default/img/vaoroi-logo.png' % url
		linktrandau = '%s%s' % (url, episode.select_one('a').get('href'))
		time = episode.select_one('p.mltt-up.live_nows').get_text()
		title = episode.select_one('a.mlt-info').get_text()
		title = '\n'.join([ll.rstrip() for ll in title.splitlines() if ll.strip()])
		title = title.replace('\n', ' ')
		item.label = '%s: %s' % (time, title)
		item.set_callback(ifr_xembong, linktrandau, item.label)
		yield item