from codequick import Route, Listitem, Resolver
from urllib.parse import urlparse
from importlib import import_module
from datetime import datetime
from json import loads
import re
@Route.register
def index_mannhan(plugin, **kwargs):
    w = import_module('resources.lib.kedon')
    url = w.mannhan()[0]
    resp = w.getlink(url, url, -1)
    if (resp is not None) and ('.m3u8' in resp.text):
        ll = re.search(r',lives=(.*?)</script>', resp.text).group(1)
        nd = re.sub('([{,:])(\w+)([},:])','\\1\"\\2\"\\3',ll)
        thaythe = {
            "'[":"[",
            "]'":"]"
            }
        m = loads(w.replace_all(thaythe, nd))
        for b1 in m:
            tg = datetime.fromtimestamp(int(b1['time'])/1000).strftime('%H:%M %d-%m')
            if 'hlsUrlsManNhan' in b1:
                for b2 in b1['hlsUrlsManNhan']:
                    item1 = Listitem()
                    if b2['url']:
                        item1.info['plot'] = w.tb
                        item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://mannhan.net/template/logo.png'
                        ten2 = b1['titleManNhan'].split(':')[1].strip()
                        tentrandau2 = f"{tg} {b2['name']}: {ten2}"
                        if b1['blvManNhan']:
                            item1.label = f'{tentrandau2} - BLV: {b1["blvManNhan"]}'
                        else:
                            item1.label = tentrandau2
                        item1.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), f'{w.stream(b2["url"])}{w.referer(url)}', item1.label, '')
                        yield item1
            for k2 in b1['hlsUrls']:
                item2 = Listitem()
                if k2['url']:
                    item2.info['plot'] = w.tb
                    item2.art['thumb'] = item2.art['landscape'] = item2.art['fanart'] = 'https://9767a59e2b.vws.vegacdn.vn/template/seo/images/Logo_150-01.png'
                    ten1 = b1['title'].split(':')[1].strip()
                    tentrandau1 = f'{tg} {k2["name"]}: {ten1}'
                    if b1['blv']:
                        item2.label = f'{tentrandau1} - BLV: {b1["blv"]}'
                    else:
                        item2.label = tentrandau1
                    item2.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), f'{w.stream(k2["url"])}{w.referer(url)}', item2.label, '')
                    yield item2
    else:
        yield w.quangcao()