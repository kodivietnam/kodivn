from codequick import Route, Listitem, Script, Resolver
from importlib import import_module
from bs4 import BeautifulSoup
from xbmcgui import DialogProgress
from urllib.parse import quote_plus
from xbmcaddon import Addon
from requests import Session
from concurrent.futures import ThreadPoolExecutor, as_completed
from functools import lru_cache
import re
@Route.register
def search_thuvienhd(plugin,search_query, **kwargs):
	w = import_module('resources.lib.kedon')
	dp = DialogProgress()
	dp.create(w.__addonnoti__, 'Đang lấy dữ liệu...')
	dp.update(5)
	sr = quote_plus(search_query)
	resp = w.getlink(f'https://thuvienhd.com/?s={sr.replace(" ","+")}', 'https://thuvienhd.com', 7200)
	if (resp is not None):
		kiem = re.search(r'"nonce":"(.*?)"', resp.text).group(1)
		r = w.getlink(f'https://thuvienhd.com/wp-json/dooplay/search/?nonce={kiem}&keyword={sr}', 'https://thuvienhd.com', 7200)
		if 'No results' in r.text:
			yield w.quangcao()
		else:
			urls = [k['url'] for k in r.json().values()]
			length = len(urls)
			dialog = DialogProgress()
			dialog.create(w.__addonnoti__, 'Đang lấy dữ liệu...')
			dialog.update(5, f'Đang giải mã {length} dữ liệu...')
			if length>0:
				with ThreadPoolExecutor(length) as ex:
					future_to_url = {ex.submit(get_tvhd_source, url): url for url in urls}
					for future in as_completed(future_to_url):
						link = future_to_url[future]
						data = future.result()
						item = Listitem()
						item.label = data[0]
						item.info['plot'] = f'{data[2]}\n{w.tb}'
						item.info['mediatype'] = 'episode'
						item.info['rating'] = 10.0
						item.info['trailer'] = w.yttk(item.label)
						item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = data[1]
						item.set_callback(thuvienhd_link, data[3], item.art['thumb'], item.info['plot'])
						yield item
						dialog.update(50)
			else:
				yield []
			dialog.update(100)
			dialog.close()
	else:
		yield w.quangcao()
	dp.update(100)
	dp.close()
@Route.register
def index_thuvienhd(plugin, **kwargs):
	w = import_module('resources.lib.kedon')
	yield Listitem.search(search_thuvienhd)
	url = 'http://thuvienhd.com/'
	resp = w.getlink(url, url, 7200)
	if (resp is not None):
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('ul.genres.falsescroll li a')
		for episode in episodes:
			item = Listitem()
			if 'thuvienhd.com' in episode.get('href'):
				item.label = episode.get_text(strip=True)
				item.info['plot'] = w.tb
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://thuvienhd.com/wp-content/uploads/2020/10/THUVIENHD.NET_.png'
				item.set_callback(thuvienhd_page, f'{episode.get("href")}/page/', 1)
				yield item
	else:
		yield w.quangcao()
@Route.register
def thuvienhd_page(plugin, url, next_page, **kwargs):
	w = import_module('resources.lib.kedon')
	trangtiep = f'{url}{next_page}'
	resp = w.getlinkvnm(trangtiep, trangtiep).data.decode('utf-8')
	soup = BeautifulSoup(resp, 'html.parser')
	urls = [k.get('href') for k in soup.select('div.items article div.data a')]
	length = len(urls)
	if length>0:
		with ThreadPoolExecutor(length) as ex:
			future_to_url = {ex.submit(get_tvhd_source, url): url for url in urls}
			for future in as_completed(future_to_url):
				link = future_to_url[future]
				data = future.result()
				item = Listitem()
				item.label = data[0]
				item.info['plot'] = f'{data[2]}\n{w.tb}'
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = w.yttk(item.label)
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = data[1]
				item.set_callback(thuvienhd_link, data[3], item.art['thumb'], item.info['plot'])
				yield item
		checkpages = soup.select('div.pagination a')
		for checkpage in checkpages:
			if str(next_page + 1) in checkpage.get_text(strip=True):
				item1 = Listitem()
				item1.label = f'Trang {next_page + 1}'
				item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://cdn-icons-png.flaticon.com/512/6559/6559088.png'
				item1.set_callback(thuvienhd_page, url, next_page + 1)
				yield item1
	else:
		yield w.quangcao()
@Route.register
def thuvienhd_link(plugin, url, linkanh, noidung, **kwargs):
	w = import_module('resources.lib.kedon')
	resp = w.getlinkvnm(url, url).data.decode('utf-8')
	urls = re.findall(r'https?://(?:www\.)?fshare\.vn/(?:file|folder)/[^\s\'"]+', resp)
	length = len(urls)
	dialog = DialogProgress()
	dialog.create(w.__addonnoti__, 'Đang lấy dữ liệu...')
	dialog.update(5, f'Đang giải mã {length} dữ liệu...')
	if length>0:
		with ThreadPoolExecutor(length) as ex:
			future_to_url = {ex.submit(w.get_info_fs, url): url for url in urls}
			for future in as_completed(future_to_url):
				link = future_to_url[future]
				data = future.result()
				item = Listitem()
				if 'folder' in link:
					item.label = data[0]
					item.info['plot'] = w.tb
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = w.yttk(item.label)
					item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={link}&qzone=1&margin=1&size=400x400&ecc=L'
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
					item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), link.split('folder/')[1], 1)
					yield item
				elif 'file' in link:
					item.label = data[0]
					item.info['plot'] = w.tb
					item.info['size'] = data[1]
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = w.yttk(item.label)
					item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={link}&qzone=1&margin=1&size=400x400&ecc=L'
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					if Addon().getSetting('taifshare') == 'true':
						item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', link)
					item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
					item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), link, item.label)
					yield item
				dialog.update(50)
	else:
		yield w.quangcao()
	dialog.update(100)
	dialog.close()
@lru_cache(maxsize=None)
def get_tvhd_source(url):
	w = import_module('resources.lib.kedon')
	with Session() as s:
		r = s.get(url, headers={'user-agent':w.useragentdf,'origin': 'https://thuvienhd.com','referer':'https://thuvienhd.com/'}, timeout=15)
		episode = BeautifulSoup(r.content, 'html.parser').select('div.content')
		for k in episode:
			try:
				ten = k.select_one('div.data h1').get_text(strip=True)
			except:
				ten = k.select_one('header.pos h1').get_text(strip=True)
			try:
				anh = k.select_one('div.poster img').get('src')
			except:
				anh = 'https://thuvienhd.com/wp-content/uploads/2020/10/THUVIENHD.NET_.png'
			try:
				diem = f"Điểm IMDb: {k.select_one('b#repimdb strong').get_text(strip=True)}"
			except:
				diem = 'Điểm IMDb: N/A'
			try:
				mota = f"{diem}\n{k.select_one('div#info div.cnnn p').get_text(strip=True)}"
			except:
				mota = f"{diem}\n{k.select_one('div.wp-content').get_text(strip=True)}"
			linktai = k.select_one('a#download-button.download').get('href')
		return (ten, anh, mota, linktai)