from codequick import Route, Listitem
from importlib import import_module
@Route.register
def listiptv_root(plugin, **kwargs):
	tb = import_module('resources.lib.kedon').tb
	T = {'Truyền hình FPT1': 'http://bit.ly/iptvfptlist',
	'Truyền hình FPT2': 'https://raw.githubusercontent.com/thanh51/repository.thanh51/master/ONETV.m3u',
	'Truyền hình FPT3': 'https://pastebin.com/raw/y8E0J0FZ',
	'Truyền hình FPT4': 'https://pastebin.com/raw/UYbpP0Gi',
	'Truyền hình VNPT': 'http://bit.ly/iptvmytvlist',
	'Truyền hình Viettel': 'http://bit.ly/iptvvietteltvlist',
	'VietSimpleTV': 'http://vietcago.tk/tv.m3u',
	'KIPTV SPORT': 'http://hqth.me/kiptvs',
	'CV Media': 'https://raw.githubusercontent.com/chivy141206/cvmedia/main/main',
	'VthanhTV': 'https://vthanhtivi.pw',
	'PhapSonyTx5': 'https://raw.githubusercontent.com/rupanh123-phap/rupanh123-phap/main/Phaptx5.mp4',
	'Coocaa': 'http://hqth.me/coca',
	'Nguyễn Kiệt': 'https://raw.githubusercontent.com/ytpit20218/kiptv/main/kiptv.m3u',
	'VietNgaTV': 'https://raw.githubusercontent.com/phuhdtv/vietngatv/master/vietngatv.m3u',
	'Beartv': 'http://bit.ly/beartvplay',
	'PCRTV': 'http://hqth.me/pcriptv',
	'NguyenHoaiTV': 'http://hoaivnpt.duckdns.org/live-football/live_football.php',
	'36Sport': 'http://hqth.me/90p',
	'Phim miễn phí': 'http://iptvvn.xyz/phimiptv',
	'Phim lẻ': 'http://hqth.me/phimle',
	'Phim lẻ tvhay': 'http://hqth.me/tvhayphimle',
	'Phim lẻ vieon': 'http://tbtv.us/api/film',
	'Phim lẻ fptplay': 'http://hqth.me/fptphimle',
	'Phim bộ': 'http://hqth.me/phimbo',
	'ChinaTV': 'http://hqth.me/china-tv',
	'Quốc tế': 'https://raw.githubusercontent.com/thanh51/repository.thanh51/master/IPTV.m3u'}
	yield Listitem.from_dict(**{'label': 'Xem lại truyền hình',
	'info':{'plot':tb},
	'art':{'thumb':'https://c.clc2l.com/t/r/e/replay-video-capture-v75OEs.png',
	'fanart':'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'},
	'callback':Route.ref('/resources/lib/mkd/ontruyenhinh/replayvtv:index_vtv')})
	yield Listitem.from_dict(**{'label': r'VTVGO',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://superrepo.org/static/images/icons/original/xplugin.video.4vn.vtvgo.png.pagespeed.ic.ZtUoZF4MTw.png',
	'fanart':'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'},
	'callback':Route.ref('/resources/lib/mkd/ontruyenhinh/vtvgo:index_vtvgo')})
	for k in T:
		item = Listitem()
		item.label = k
		item.info['plot'] = tb
		item.art['thumb'] = item.art['landscape'] = 'https://i.imgur.com/Mnuw95h.png'
		item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
		item.set_callback(Route.ref('/resources/lib/mkd/ontruyenhinh/listiptv:list_iptv'), T[k])
		yield item