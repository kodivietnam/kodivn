from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from resources.lib.kedon import tb, getlink, play_fs, __addonnoti__, __addon__, quangcao, yttk
from resources.lib.mkd.onfshare.ifshare import index_fs, tfavo
from resources.lib.download import downloadfs
import xbmcgui, urllib, re
@Route.register
def search_thuviencine(plugin,search_query, **kwargs):
	dp = xbmcgui.DialogProgress()
	dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
	dp.update(0)
	search_query = urllib.parse.quote_plus(search_query)
	url = f'https://thuviencine.com/?s={search_query.replace(" ","+")}'
	resp = getlink(url, url, 43200)
	if resp is not None:
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('div.item-container a')
		for episode in episodes:
			item = Listitem()
			anh = episode.select('img')
			ndp = episode.select('p.movie-description')
			for inf in ndp:
				noidung = inf.get_text()
			linkphim = episode.get('href')
			for poster in anh:
				linkanh = poster.get('data-src')
			ten = episode.get('title')
			if ten:
				item.label = ten
				item.info['plot'] = noidung
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = yttk(item.label)
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = linkanh
				item.set_callback(thuviencine_link, linkphim)
				yield item
		if 'resppages' in resp.text:
			yield Listitem.next_page(search_query, 2, callback=search_thuviencinenext)
	else:
		yield quangcao()
	dp.update(100)
	dp.close()

@Route.register
def search_thuviencinenext(plugin,search_query, next_page, **kwargs):
	search_query = urllib.parse.quote_plus(search_query)
	url = f'https://thuviencine.com/page/{next_page}?s={search_query.replace(" ","+")}'
	resp = getlink(url, url, 43200)
	if resp is not None:
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('div.item-container a')
		for episode in episodes:
			item = Listitem()
			anh = episode.select('img')
			ndp = episode.select('p.movie-description')
			for inf in ndp:
				noidung = inf.get_text()
			linkphim = episode.get('href')
			for poster in anh:
				linkanh = poster.get('data-src')
			ten = episode.get('title')
			if ten:
				item.label = ten
				item.info['plot'] = noidung
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = yttk(item.label)
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = linkanh
				item.set_callback(thuviencine_link, linkphim)
				yield item
		if 'resppages' in resp.text:
			item1 = Listitem()
			item1.label = f'Trang {next_page + 1}'
			item1.art['thumb'] = item1.art['landscape']  = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
			item1.set_callback(search_thuviencinenext, search_query, next_page + 1)
			yield item1
	else:
		yield quangcao()

@Route.register
def index_thuviencine(plugin, **kwargs):
	yield Listitem.search(search_thuviencine)
	url = 'https://thuviencine.com'
	resp = getlink(url, url, 43200)
	if resp is not None:
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('div.sidebar.sb-left a')
		for episode in episodes:
			item = Listitem()
			phim = episode.get('href')
			item.label = episode.get_text()
			item.info['plot'] = tb
			next_page = 1
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://thuviencine.com/wp-content/uploads/2021/09/logo-red.png'
			item.set_callback(thuviencine_page, phim, next_page)
			yield item
		nhomtheloais = soup.select('nav.filters a')
		for nhomtheloai in nhomtheloais:
			item1 = Listitem()
			nhom = nhomtheloai.get('href')
			tennhom = nhomtheloai.get_text()
			if tennhom:
				item1.label = tennhom
				item1.info['plot'] = tb
				next_page = 1
				item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://thuviencine.com/wp-content/uploads/2021/09/logo-red.png'
				item1.set_callback(thuviencine_page, nhom, next_page)
				yield item1
	else:
		yield quangcao()

@Route.register
def thuviencine_page(plugin, url, next_page, **kwargs):
	trangtiep = f'{url}page/{next_page}'
	resp = getlink(trangtiep, trangtiep, 43200)
	if resp is not None:
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('div.item-container a')
		for episode in episodes:
			item = Listitem()
			anh = episode.select('img')
			ndp = episode.select('p.movie-description')
			for inf in ndp:
				noidung = inf.get_text()
			linkphim = episode.get('href')
			for poster in anh:
				linkanh = poster.get('data-src')
			ten = episode.get('title')
			if ten:
				item.label = ten
				item.info['plot'] = noidung
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = yttk(item.label)
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = linkanh
				item.set_callback(thuviencine_link, linkphim)
				yield item
		if 'resppages' in resp.text:
			item1 = Listitem()
			item1.label = f'Trang {next_page + 1}'
			item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
			item1.set_callback(thuviencine_page, url, next_page + 1)
			yield item1
	else:
		yield quangcao()
@Route.register
def thuviencine_link(plugin, url, **kwargs):
	resp = getlink(url, url, 43200)
	if resp is not None:
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('li#download-button a')
		for episode in episodes:
			linktai = episode.get('href')
			respx = getlink(linktai, linktai, 43200)
			web = BeautifulSoup(respx.content, 'html.parser')
			nhomlinktai = web.select('div.movie-actions a')
			for nhomlinktaix in nhomlinktai:
				item = Listitem()
				link = nhomlinktaix.get('href')
				tenx = nhomlinktaix.select('span')
				dl = nhomlinktaix.select('i')
				for ten in tenx:
					tenphim = ten.get_text()
				for dlx in dl:
					dungluongphim = dlx.get_text()
					tach = dungluongphim.split('|')
					dlp = tach[1]
				if 'folder' in link:
					item.label = f'{tenphim}{dlp}'
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(item.label)
					thumuc = link.split('folder/')
					item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={link}&qzone=1&margin=1&size=400x400&ecc=L'
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					item.context.script(tfavo, 'Thêm vào Fshare Favorite', link)
					item.set_callback(index_fs, thumuc[1], 1)
					yield item
				elif 'file' in link:
					item.label = f'{tenphim}{dlp}'
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(item.label)
					item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={link}&qzone=1&margin=1&size=400x400&ecc=L'
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					if __addon__.getSetting("taifshare") == "true":
						item.context.script(downloadfs, 'Tải về', link)
					item.set_callback(play_fs, link, item.label)
					item.context.script(tfavo, 'Thêm vào Fshare Favorite', link)
					yield item
	else:
		yield quangcao()