from codequick import Route, Listitem, Resolver
from importlib import import_module
from json import loads
from calendar import timegm
from time import gmtime
import re
@Route.register
def index_socolive(plugin, **kwargs):
	w = import_module('resources.lib.kedon')
	urlr = 'http://bit.ly/socolive'
	respr = w.getlink(urlr, urlr, 1000)
	if (respr is not None):
		linkref = respr.url
	timestamp = timegm(gmtime())
	url = f'http://json.vnres.co/all_live_rooms.json?v={timestamp}'
	resp = w.getlink(url, url, 600)
	if (resp is not None):
		nd = re.search(r'(\{.*\})', resp.text, re.DOTALL).group()
		m = loads(nd)
		for k in m['data']['hot']:
			item = Listitem()
			item.label = f'{k["title"]} ({k["anchor"]["nickName"]})'
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = k['cover']
			item.info['plot'] = f'{k["notice"]}\n{w.tb}'
			item.set_callback(Resolver.ref('/resources/lib/kedon:playsocolive'), k['roomNum'], timestamp, linkref, item.label)
			yield item
	else:
		yield w.quangcao()