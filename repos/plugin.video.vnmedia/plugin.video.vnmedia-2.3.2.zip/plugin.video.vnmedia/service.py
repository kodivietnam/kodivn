from resources.lib.kedon import getlinkvnm
from xbmc import executebuiltin
from xbmcaddon import Addon
from json import loads
def autorun_addon():
    executebuiltin('UpdateAddonRepos()')
    if Addon().getSetting('auto_run') == 'true':
        executebuiltin('RunAddon(plugin.video.vnmedia)')
    if Addon().getSetting('auto_noti') == 'true':
        url = 'https://speedtest.vn/get-ip-info'
        r = getlinkvnm(url, url).data.decode('utf-8')
        a = ' '.join([c for c in reversed(loads(r).values())]) if r else 'VNNIC error'
        executebuiltin(f'Notification("KODI VIỆT NAM", {a}, 10000, {Addon().getAddonInfo("icon")})')
    return
autorun_addon()