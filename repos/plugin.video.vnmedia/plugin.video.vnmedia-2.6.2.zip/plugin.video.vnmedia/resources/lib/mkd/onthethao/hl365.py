from codequick import Route, Listitem
from resources.lib.kedon import getlink, quangcao, ace
from datetime import datetime, timedelta, date
from bs4 import BeautifulSoup
@Route.register
def index_highlights365(plugin, **kwargs):
	url = 'http://highlights365.com/broadcasts'
	resp = getlink(url, url, 1000)
	if (resp is not None):
		soup = BeautifulSoup(resp.content, 'html.parser')
		for episode in soup.select('div.broadcast-item'):
			linktrans = episode.select('div.team-info a')
			for linktran in linktrans:
				link = linktran.get('href')
				ten = linktran.get_text(strip=True)
			times = episode.select('div.time')
			for time in times:
				item = Listitem()
				timex = time.get_text(strip=True)
				if len(timex)==4:
					y = f'{date.today()}T0{timex}'
				else:
					y = f'{date.today()}T{timex}'
				item.label = f'{(datetime.fromisoformat(y) + timedelta(hours=7)).strftime("%H:%M")} {ten}'
				item.art['thumb'] = item.art['fanart'] = f"https:{episode.select_one('div.c-flag img').get('data-src')}"
				item.set_callback(laylink_highlights365, f'https://highlights365.com{link}', item.label)
				yield item
	else:
		yield quangcao()
@Route.register
def laylink_highlights365(plugin, url, ten, **kwargs):
	resp = getlink(url, url, 1000)
	if (resp is not None) and ('acestream://' in resp.text):
		soup = BeautifulSoup(resp.content, 'html.parser')
		for index, number in enumerate(soup.select('div.link-list.acestream a')):
			item = Listitem()
			item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/acestream.png'
			item.label = f'Link {index+1}-{ten}'
			linkplay = ace(number.get('href'), item.label)
			item.path = linkplay
			item.set_callback(item.path)
			yield item
	else:
		yield quangcao()