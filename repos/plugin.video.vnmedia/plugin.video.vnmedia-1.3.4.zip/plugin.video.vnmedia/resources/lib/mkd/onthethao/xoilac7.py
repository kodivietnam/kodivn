from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from resources.lib.kedon import getlink, ifr_bongda
mx = 'https://xoilac7.tv/'
@Route.register
def index_xoilac7(plugin, **kwargs):
	url = '%svb-ajax.php?action=filter_match&filter=all&league=' % mx
	resp = getlink(url, mx, 15*60)
	soup = BeautifulSoup(resp.json()['data']['html'], 'html.parser')
	episodes = soup.select('div.grid-match')
	for episode in episodes:
		item = Listitem()
		linktrandau = episode.select_one('a.redirectPopup').get('href')
		ten = episode.select_one('a.redirectPopup').get('title')
		blv = episode.select_one('div.grid-match__commentator').get_text().strip()
		if blv:
			item.label = '%s - %s' % (ten, blv)
		else:
			item.label = ten
		item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = '%swp-content/themes/bongda/dist/images/xoilac7.net.png' % mx
		item.set_callback(list_xoilac7, linktrandau, item.label)
		yield item
@Route.register
def list_xoilac7(plugin, url, title, **kwargs):
	resp = getlink(url, url, 5*60)
	soup = BeautifulSoup(resp.content, 'html.parser')
	episodes = soup.select('div#tv_links a.text-center')
	for episode in episodes:
		item = Listitem()
		linktrandau = episode.get('href')
		item.label = '%s - %s' % (episode.get_text().strip(), title)
		item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = '%swp-content/themes/bongda/dist/images/xoilac7.net.png' % mx
		item.set_callback(ifr_bongda, linktrandau, item.label)
		yield item