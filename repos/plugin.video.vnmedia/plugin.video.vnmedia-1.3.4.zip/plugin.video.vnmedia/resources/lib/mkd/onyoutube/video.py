from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from resources.lib.kedon import getlink
import re, html
@Route.register
def youtube_tatcavideo(plugin, idupload, **kwargs):
	url = 'https://www.googleapis.com/youtube/v3/playlistItems?playlistId=%s&regionCode=VN&key=AIzaSyBBbFFBo8xg7GkSdhTu1WzFYdlm89XN87w&part=snippet&maxResults=50' % idupload
	resp = getlink(url, url, 15*60)
	parsed = resp.json()
	for k in parsed['items']:
		if 'standard' in k['snippet']['thumbnails']:
			item = Listitem()
			tenvd = html.unescape(k['snippet']['title'])
			motavd = k['snippet']['description']
			anhvd = k['snippet']['thumbnails']['standard']['url']
			idvd = k['snippet']['resourceId']['videoId']
			item.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=%s' % idvd
			item.label = tenvd
			item.info['plot'] = motavd
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = anhvd
			item.set_callback(item.path)
			yield item
	if 'nextPageToken' in parsed:
		item1 = Listitem()
		trangtiep = parsed['nextPageToken']
		item1.label = 'Trang tiếp'
		item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
		item1.set_callback(youtube_tatcavideonext, idupload, trangtiep)
		yield item1
@Route.register
def youtube_tatcavideonext(plugin, idupload, token, **kwargs):
	url = 'https://www.googleapis.com/youtube/v3/playlistItems?playlistId=%s&regionCode=VN&key=AIzaSyBBbFFBo8xg7GkSdhTu1WzFYdlm89XN87w&part=snippet&pageToken=%s&maxResults=50' % (idupload, token)
	resp = getlink(url, url, 15*60)
	parsed = resp.json()
	for k in parsed['items']:
		if 'standard' in k['snippet']['thumbnails']:
			item = Listitem()
			tenvd = html.unescape(k['snippet']['title'])
			motavd = k['snippet']['description']
			anhvd = k['snippet']['thumbnails']['standard']['url']
			idvd = k['snippet']['resourceId']['videoId']
			item.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=%s' % idvd
			item.label = tenvd
			item.info['plot'] = motavd
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = anhvd
			item.set_callback(item.path)
			yield item
	if 'nextPageToken' in parsed:
		item1 = Listitem()
		trangtiep = parsed['nextPageToken']
		item1.label = 'Trang tiếp'
		item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
		item1.set_callback(youtube_tatcavideonext, idupload, trangtiep)
		yield item1
@Route.register
def youtube_topvideo(plugin, **kwargs):
	url = 'https://youtube.googleapis.com/youtube/v3/search?part=snippet&regionCode=VN&order=viewCount&type=video&fields=*&key=AIzaSyBBbFFBo8xg7GkSdhTu1WzFYdlm89XN87w&maxResults=50'
	resp = getlink(url, url, 12*60*60)
	parsed = resp.json()
	for k in parsed['items']:
		if 'medium' in k['snippet']['thumbnails']:
			item = Listitem()
			tenvd = html.unescape(k['snippet']['title'])
			motavd = k['snippet']['description']
			anhvd = k['snippet']['thumbnails']['medium']['url']
			idvd = k['id']['videoId']
			item.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=%s' % idvd
			item.label = tenvd
			item.info['plot'] = motavd
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = anhvd
			item.set_callback(item.path)
			yield item
	if 'nextPageToken' in parsed:
		item1 = Listitem()
		trangtiep = parsed['nextPageToken']
		item1.label = 'Trang tiếp'
		item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
		item1.set_callback(youtube_topvideonext, trangtiep)
		yield item1
@Route.register
def youtube_topvideonext(plugin, token, **kwargs):
	url = 'https://youtube.googleapis.com/youtube/v3/search?part=snippet&regionCode=VN&order=viewCount&type=video&fields=*&key=AIzaSyBBbFFBo8xg7GkSdhTu1WzFYdlm89XN87w&pageToken=%s&maxResults=50' % token
	resp = getlink(url, url, 12*60*60)
	parsed = resp.json()
	for k in parsed['items']:
		if 'medium' in k['snippet']['thumbnails']:
			item = Listitem()
			tenvd = html.unescape(k['snippet']['title'])
			motavd = k['snippet']['description']
			anhvd = k['snippet']['thumbnails']['medium']['url']
			idvd = k['id']['videoId']
			item.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=%s' % idvd
			item.label = tenvd
			item.info['plot'] = motavd
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = anhvd
			item.set_callback(item.path)
			yield item
	if 'nextPageToken' in parsed:
		item1 = Listitem()
		trangtiep = parsed['nextPageToken']
		item1.label = 'Trang tiếp'
		item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
		item1.set_callback(youtube_topvideonext, trangtiep)
		yield item1
@Route.register
def youtube_dslist(plugin, channelid, **kwargs):
	url = 'https://www.googleapis.com/youtube/v3/playlists?part=snippet&regionCode=VN&channelId=%s&key=AIzaSyBBbFFBo8xg7GkSdhTu1WzFYdlm89XN87w&maxResults=50' % channelid
	resp = getlink(url, url, 6*60*60)
	kq = resp.text.replace('\\','')
	parsed = resp.json()
	for k in parsed['items']:
		if 'standard' in k['snippet']['thumbnails']:
			item = Listitem()
			tenvd = html.unescape(k['snippet']['title'])
			anhvd = k['snippet']['thumbnails']['standard']['url']
			xx = k['id']
			item.label = tenvd
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = anhvd
			item.set_callback(youtube_tatcavideo, xx)
			yield item
@Route.register
def youtube_thinhhanh(plugin, **kwargs):
	url = 'https://www.googleapis.com/youtube/v3/videos?part=snippet&chart=mostPopular&regionCode=VN&key=AIzaSyBBbFFBo8xg7GkSdhTu1WzFYdlm89XN87w&maxResults=50&order=rating'
	resp = getlink(url, url, 6*60*60)
	parsed = resp.json()
	for k in parsed['items']:
		if 'standard' in k['snippet']['thumbnails']:
			item = Listitem()
			tenvd = html.unescape(k['snippet']['title'])
			anhvd = k['snippet']['thumbnails']['standard']['url']
			motavd = k['snippet']['description']
			idvd = k['id']
			item.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=%s' % idvd
			item.label = tenvd
			item.info['plot'] = motavd
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = anhvd
			item.set_callback(item.path)
			yield item
	if 'nextPageToken' in parsed:
		item1 = Listitem()
		token = parsed['nextPageToken']
		item1.label = 'Trang tiếp'
		item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
		item1.set_callback(youtube_thinhhanhnext, token)
		yield item1
@Route.register
def youtube_thinhhanhnext(plugin, token, **kwargs):
	url = 'https://www.googleapis.com/youtube/v3/videos?part=snippet&chart=mostPopular&videoCategoryId=1&regionCode=VN&key=AIzaSyBBbFFBo8xg7GkSdhTu1WzFYdlm89XN87w&pageToken=%s&maxResults=50&order=rating' % token
	resp = getlink(url, url, 6*60*60)
	parsed = resp.json()
	for k in parsed['items']:
		if 'standard' in k['snippet']['thumbnails']:
			item = Listitem()
			tenvd = html.unescape(k['snippet']['title'])
			anhvd = k['snippet']['thumbnails']['standard']['url']
			motavd = k['snippet']['description']
			idvd = k['id']
			item.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=%s' % idvd
			item.label = tenvd
			item.info['plot'] = motavd
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = anhvd
			item.set_callback(item.path)
			yield item
	if 'nextPageToken' in parsed:
		item1 = Listitem()
		tokennext = parsed['nextPageToken']
		item1.label = 'Trang tiếp'
		item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
		item1.set_callback(youtube_thinhhanhnext, tokennext)
		yield item1
@Route.register
def youtube_kenh(plugin, channelid, **kwargs):
	urlx = 'https://www.googleapis.com/youtube/v3/channels?id=%s&key=AIzaSyBBbFFBo8xg7GkSdhTu1WzFYdlm89XN87w&regionCode=VN&part=contentDetails' % channelid
	respx = getlink(urlx, urlx, 15*60)
	parsed = respx.json()
	for k in parsed['items']:
		item1 = Listitem()
		idupload = k['contentDetails']['relatedPlaylists']['uploads']
		item1.label = 'Tất cả Video'
		item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.youtube.com/img/desktop/yt_1200.png'
		item1.set_callback(youtube_tatcavideo, idupload)
		yield item1
	item2 = Listitem()
	item2.label = 'Danh sách phát'
	item2.art['thumb'] = 'https://www.youtube.com/img/desktop/yt_1200.png'
	item2.art['fanart'] = 'https://www.youtube.com/img/desktop/yt_1200.png'
	item2.set_callback(youtube_dslist, channelid)
	yield item2
	url3 = 'https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&regionCode=VN&key=AIzaSyBBbFFBo8xg7GkSdhTu1WzFYdlm89XN87w&maxResults=50&channelId=%s' % channelid
	resp3 = getlink(url3, url3, 12*60*60)
	parsed3 = resp3.json()
	for k3 in parsed3['items']:
		if 'medium' in k3['snippet']['thumbnails']:
			item3 = Listitem()
			tenvd3 = html.unescape(k3['snippet']['title'])
			anhvd3 = k3['snippet']['thumbnails']['medium']['url']
			motavd3 = k3['snippet']['description']
			idvd3 = k3['id']['videoId']
			item3.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=%s' % idvd3
			item3.label = tenvd3
			item3.info['plot'] = motavd3
			item3.art['thumb'] = item3.art['landscape'] = item3.art['fanart'] = anhvd3
			item3.set_callback(item3.path)
			yield item3