from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from resources.lib.kedon import getlink, ifr_bongda
mx = 'https://vebo1.com/'
@Route.register
def index_vebolive(plugin, **kwargs):
	url = '%svb-ajax.php?action=load_more_live&page=0&key=home&posts_per_page=30' % mx
	resp = getlink(url, url, 15*60)
	soup = BeautifulSoup(resp.json()['data']['html'], 'html.parser')
	episodes = soup.select('div.position-relative.match')
	for episode in episodes:
		item = Listitem()
		linktrandau = episode.select_one('a.btn-view.btn.btn-primary').get('href')
		thoigian = episode.select_one('p.match-date').get_text().strip()
		doinha = episode.select_one('div.text-center.match-team.team-home').get_text().strip()
		doikhach = episode.select_one('div.text-center.match-team.team-away').get_text().strip()
		giaidau = episode.select_one('div.match-league').get_text().strip()
		tentrandau = '%s: %s vs %s (%s)' % (thoigian, doinha, doikhach, giaidau)
		if episode.select_one('div.d-flex.flex-column p'):
			ten = episode.select_one('div.d-flex.flex-column p').get_text().strip()
			item.label = '%s - %s' % (tentrandau, ten)
		else:
			item.label = tentrandau
		item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = '%swp-content/themes/bongda/public/images/logo.png' % mx
		item.set_callback(list_vebolive, linktrandau, item.label)
		yield item
@Route.register
def list_vebolive(plugin, url, title, **kwargs):
	resp = getlink(url, url, 5*60)
	soup = BeautifulSoup(resp.content, 'html.parser')
	episodes = soup.select('div.link-video a')
	for episode in episodes:
		item = Listitem()
		linktrandau = episode.get('href')
		item.label = '%s - %s' % (episode.get_text().strip(), title)
		item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = '%swp-content/themes/bongda/public/images/logo.png' % mx
		item.set_callback(ifr_bongda, linktrandau, item.label)
		yield item