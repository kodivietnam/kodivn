from codequick import Route, Listitem, run
from resources.lib.kedon import quangcao, getlink, stream, referer, play_vnm, tb, mannhan
from bs4 import BeautifulSoup
from datetime import datetime
import re, json
url = mannhan()[0]
@Route.register
def index_mannhan(plugin, **kwargs):
    resp = getlink(url, url, 5*60)
    if 'm3u8' in resp.text:
        match = re.search(r'lives=(.*?)</script>', resp.text).group(1)
        listplay = re.findall(r'{_id(.*?)primaryId', match)
        for k in listplay:
            ten = re.search(r'Xem trực tiếp bình luận bóng đá hôm nay: (.*?)"', k).group(1)
            tg = re.search(r'time:(.*?),', k).group(1)
            tgjs = json.loads(tg)
            time = datetime.fromtimestamp(tgjs/1000).strftime('%H:%M %d-%m')
            listname = re.findall(r'{name:(.*?)}', k)
            for m in listname:
                item = Listitem()
                if re.search(r'url:"(.*?)"', m).group(1):
                    chatluong = re.search(r'"(.*?)"', m).group(1)
                    linkplay = '%s%s' % (stream(re.search(r'url:"(.*?)"', m).group(1)), referer(url))
                    item.label = '%s %s %s' % (chatluong, time, ten)
                    item.info['plot'] = tb
                    item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://1966649973.slave.anycastapnic.com/template/public/img/logo.png'
                    item.set_callback(play_vnm, linkplay, item.label, '')
                    yield item
    else:
        yield quangcao()