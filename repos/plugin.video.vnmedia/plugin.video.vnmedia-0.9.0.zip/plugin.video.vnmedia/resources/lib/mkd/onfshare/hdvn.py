from codequick import Route, Listitem, run, Script
from bs4 import BeautifulSoup
from urllib.parse import urlparse
from resources.lib.kedon import quangcao, getlink, play_fs, __addonnoti__
from resources.lib.mkd.onfshare.ifshare import index_fs, loginfhdvn, likehdvn, tfavo, FShareVN, AsyncRequest
from resources.lib.download import downloadfs
import xbmcgui, urllib, re, json
nhomhdvn = {
'4K': 'https://hdvietnam.org/forums/4k.337/',
'WEB-DL, HDTV 4K': 'https://hdvietnam.org/forums/web-dl-hdtv-4k.344/',
'Bluray Remux 4K': 'https://hdvietnam.org/forums/bluray-remux-4k.345/',
'Bluray Nguyên Gốc 4K': 'https://hdvietnam.org/forums/bluray-nguyen-goc-4k.346/',
'Fshare.vn': 'https://hdvietnam.org/forums/fshare-vn.33/',
'Fshare-WEB-DL, HDTV': 'https://www.hdvietnam.com/forums/web-dl-hdtv.271/',
'Fshare-Bluray Remux': 'https://www.hdvietnam.com/forums/bluray-remux.324/',
'Fshare-mHD, SD': 'https://www.hdvietnam.com/forums/mhd-sd.77/',
'Fshare-Bluray nguyên gốc': 'https://www.hdvietnam.com/forums/bluray-nguyen-goc.78/',
'Phim có audio Việt': 'https://www.hdvietnam.com/forums/phim-co-audio-viet.265/',
'Phim bộ - Series': 'https://www.hdvietnam.com/forums/phim-bo-series.57/',
'Phim bộ - mHD, SD': 'https://www.hdvietnam.com/forums/mhd-sd.104/',
'Phim hoạt hình': 'https://www.hdvietnam.com/forums/phim-hoat-hinh.123/',
'Phim hoạt hình - mHD, SD': 'https://www.hdvietnam.com/forums/mhd-sd.124/',
'Phim tài liệu - Documentaries': 'https://www.hdvietnam.com/forums/phim-tai-lieu-documentaries.116/',
'Phim 3D': 'https://www.hdvietnam.com/forums/3d.110/',
'Phim cho iOS/Android': 'https://www.hdvietnam.com/forums/phim-cho-ios-android.157/'
}
@Route.register
def search_hdvn(plugin,search_query, **kwargs):
    dp = xbmcgui.DialogProgress()
    dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
    dp.update(0)
    search_query = urllib.parse.quote_plus(search_query)
    url = 'https://hdvietnam.org/search/2022/?page=1&q=%s&t=post&o=date&c[node]=337+344+345+346+33+271+324+77+78' % search_query.replace(' ','+')
    r = getlink(url, url, 2*24*60*60)
    idsearch = re.search(r'search/([0-9]+)', r.url).group(1)
    if 'titleText' in r.text:
        soup = BeautifulSoup(r.content, 'html.parser')
        episodes = soup.select('div.titleText a')
        for episode in episodes:
            item = Listitem()
            item.label = episode.get_text()
            linkphim = episode.get('href')
            item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://hdvietnam.org/images/hd-vietnam-logo.png'
            item.set_callback(hdvn_link, linkphim)
            yield item
        yield Listitem.next_page(search_query, 2, idsearch, callback=search_hdvnnext)
    else:
        Script.notify(__addonnoti__, 'Không tìm thấy kết quả')
        yield quangcao()
    dp.update(100)
    dp.close()

@Route.register
def search_hdvnnext(plugin,search_query, next_page, idsearch, **kwargs):
    search_query = urllib.parse.quote_plus(search_query)
    url = 'https://hdvietnam.org/search/%s/?page=%s&q=%s&t=post&o=date&c[node]=337+344+345+346+33+271+324+77+78' % (idsearch, next_page, search_query.replace(' ','+'))
    r = getlink(url, url, 2*24*60*60)
    if 'titleText' in r.text:
        soup = BeautifulSoup(r.content, 'html.parser')
        episodes = soup.select('div.titleText a')
        for episode in episodes:
            item = Listitem()
            item.label = episode.get_text()
            linkphim = episode.get('href')
            item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://hdvietnam.org/images/hd-vietnam-logo.png'
            item.set_callback(hdvn_link, linkphim)
            yield item
        item1 = Listitem()
        item1.label = 'Trang %s' % (next_page + 1)
        item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
        item1.set_callback(search_hdvnnext, search_query, next_page + 1, idsearch)
        yield item1
    else:
        Script.notify(__addonnoti__, 'Không tìm thấy kết quả')
        yield quangcao()
@Route.register
def index_hdvn(plugin, **kwargs):
    yield Listitem.search(search_hdvn)
    for tenlist, urllist in list(nhomhdvn.items()):
        item = Listitem()
        item.label = tenlist
        item.art['thumb'] = item.art['landscape'] = 'https://hdvietnam.org/images/hd-vietnam-logo.png'
        item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
        item.set_callback(hdvn_page, url=urllist, next_page=1)
        yield item

@Route.register
def hdvn_page(plugin, url, next_page, **kwargs):
    trangtiep = '%spage-%s' % (url, next_page)
    r = getlink(trangtiep, trangtiep, 15*60)
    soup = BeautifulSoup(r.content, 'html.parser')
    episodes = soup.select('a.PreviewTooltip')
    for episode in episodes:
        item = Listitem()
        linkphim = episode.get('href')
        item.label = episode.get_text()
        item.art['thumb'] = item.art['landscape'] = 'https://hdvietnam.org/images/hd-vietnam-logo.png'
        item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
        item.set_callback(hdvn_link, linkphim)
        yield item
    item1 = Listitem()
    item1.label = 'Trang %s' % (next_page + 1)
    item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
    item1.set_callback(hdvn_page, url, next_page + 1)
    yield item1

@Route.register
def hdvn_link(plugin, url, **kwargs):
    likehdvn(url)
    r = loginfhdvn().get('https://hdvietnam.org/%s' % url)
    if 'fshare.vn' in r.text:
        soup = BeautifulSoup(r.content, 'html.parser')
        tukhoa = soup.select("a.externalLink")
        tong = len(tukhoa)
        found_links = []
        info_links = []
        allow_url = ['fshare.vn/']
        for link in tukhoa:
            url = link.get('href')
            if True in map(lambda x: x in url, allow_url) and url not in found_links:
                found_links.append(url)
                info_links.append('https://www.fshare.vn/api/v3/files/folder?linkcode=%s' % FShareVN.extract_code(url))
        arequest = AsyncRequest()
        results = arequest.get(info_links)
        for idx, result in enumerate(results):
            item = Listitem()
            try:
                name = FShareVN.get_asset_info(content=result)[0]
                dungluong = FShareVN.get_asset_info(content=result)[1]
                code = FShareVN.get_asset_info(content=result)[2]
                fol = FShareVN.is_folder(found_links[idx])
            except:
                name = 'Dữ liệu này bị hỏng...'
                dungluong = 0
                code = FShareVN.get_asset_info(content=result)[2]
                fol = FShareVN.is_folder(found_links[idx])
            if fol is False:
                linkfs = 'https://www.fshare.vn/file/%s' % code
                item.label = name
                item.info['size'] = dungluong
                item.art['thumb'] = item.art['landscape'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=1&size=400x400&ecc=L' % link
                item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
                item.context.script(downloadfs, 'Tải về', linkfs)
                item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkfs)
                item.set_callback(play_fs, linkfs, item.label)
                yield item
            else:
                thumuc = code
                linkfs = 'https://www.fshare.vn/folder/%s' % code
                item.label = name
                item.art['thumb'] = item.art['landscape'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=1&size=400x400&ecc=L' % link
                item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
                item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkfs)
                item.set_callback(index_fs, thumuc, 1)
                yield item
    else:
        yield quangcao()