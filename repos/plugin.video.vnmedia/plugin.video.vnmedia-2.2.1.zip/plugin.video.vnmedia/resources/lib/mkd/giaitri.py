from codequick import Route, Listitem, run
from resources.lib.kedon import tb
from resources.lib.mkd.ontintuc.mocha import index_mocha
@Route.register
def index_giaitri(plugin,**kwargs):
	yield ngan()
	yield hai()
	yield ngam()
	yield vuidocla()
	yield vlogs()
	yield tvshow()
def ngan():
	item = Listitem()
	item.label = 'Video Ngắn'
	item.info['plot'] = tb
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://tailieufree.net/wp-content/uploads/2020/09/hinh-nen-mat-cuoi-sieu-cute.jpg'
	item.set_callback(index_mocha, 1000, 0)
	return item
def hai():
	item = Listitem()
	item.label = 'Hài'
	item.info['plot'] = tb
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://tailieufree.net/wp-content/uploads/2020/09/hinh-nen-mat-cuoi-sieu-cute.jpg'
	item.set_callback(index_mocha, 7, 0)
	return item
def ngam():
	item = Listitem()
	item.label = 'Ngắm'
	item.info['plot'] = tb
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://tailieufree.net/wp-content/uploads/2020/09/hinh-nen-mat-cuoi-sieu-cute.jpg'
	item.set_callback(index_mocha, 1042, 0)
	return item
def vuidocla():
	item = Listitem()
	item.label = 'Vui độc lạ'
	item.info['plot'] = tb
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://tailieufree.net/wp-content/uploads/2020/09/hinh-nen-mat-cuoi-sieu-cute.jpg'
	item.set_callback(index_mocha, 1011, 0)
	return item
def vlogs():
	item = Listitem()
	item.label = 'Vlogs'
	item.info['plot'] = tb
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://tailieufree.net/wp-content/uploads/2020/09/hinh-nen-mat-cuoi-sieu-cute.jpg'
	item.set_callback(index_mocha, 1051, 0)
	return item
def tvshow():
	item = Listitem()
	item.label = 'TV Show'
	item.info['plot'] = tb
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://tailieufree.net/wp-content/uploads/2020/09/hinh-nen-mat-cuoi-sieu-cute.jpg'
	item.set_callback(index_mocha, 1039, 0)
	return item