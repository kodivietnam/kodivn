from codequick import Route, Listitem, run
from resources.lib.kedon import getlink, playsocolive, quangcao, tb
import time, calendar, re, json
@Route.register
def index_socolive(plugin, **kwargs):
	urlr = 'http://bit.ly/socolive'
	respr = getlink(urlr, urlr, 1000)
	if respr is not None:
		linkref = respr.url
	timestamp = calendar.timegm(time.gmtime())
	url = f'http://json.cvndnss.com/all_live_rooms.json?v={timestamp}'
	resp = getlink(url, url, 600)
	if resp is not None:
		nd = re.search(r'(\{.*\})', resp.text, re.DOTALL).group()
		m = json.loads(nd)
		for k in m['data']['hot']:
			item = Listitem()
			item.label = f'{k["title"]} ({k["anchor"]["nickName"]})'
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = k['cover']
			item.info['plot'] = f'{k["notice"]}\n{tb}'
			item.set_callback(playsocolive, k['roomNum'], timestamp, linkref, item.label)
			yield item
	else:
		yield quangcao()