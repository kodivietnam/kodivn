from codequick import Route, Listitem, run
from resources.lib.mkd.onyoutube.video import youtube_kenh
@Route.register
def index_tinthethao(plugin, **kwargs):
	T = {
	'VFF': 'http://www.youtube.com/channel/UCndcERoL9eG-XNljgUk1Gag',
	'VPF': 'http://www.youtube.com/channel/UCqOmFFbm6NBv_1u9hnIZJmA',
	'VTV thể thao': 'http://www.youtube.com/channel/UCrI4iNMPZ2vT_G-TqRO6yrw',
	'Tạp chí bóng đá': 'http://www.youtube.com/channel/UCmn1v6lrIDZghUfbxXaorUw',
	'Bongdaplus': 'http://www.youtube.com/channel/UCF0VFBZu-5SRJXMV_FMysEA',
	'FPT bóng đá': 'http://www.youtube.com/channel/UC4LvrpNXujjbGOS4RDvr41g',
	'F Sports': 'http://www.youtube.com/channel/UCAKECJFTsS-QnggdDZD3y4Q',
	'Next Sports': 'http://www.youtube.com/channel/UCisgkf7-vE5k5sVhfSiUEow',
	'K+ Sports': 'http://www.youtube.com/channel/UC9xeuekJd88ku9LDcmGdUOA',
	'On Sports': 'http://www.youtube.com/channel/UCIWo7q6irZUBaoPOrlf5IVw',
	'On Sports Plus': 'http://www.youtube.com/channel/UCOEucCL9r4YfNZ9Es6G-g9Q',
	'FPT bóng đá Việt': 'http://www.youtube.com/channel/UCljFFNaQoJWeP91Bz4m_3bw',
	'Quán thể thao': 'http://www.youtube.com/channel/UCEwAazC_ewgN5PPnR9vxFKA',
	'Việt Nam Sport': 'http://www.youtube.com/channel/UC4FXEYiVVUdibNnqAnzdscw',
	'BLV Quang Huy': 'http://www.youtube.com/channel/UCX_6zvzkYvRM1bDIpz802FA',
	'BLV Anh Quân': 'http://www.youtube.com/channel/UCQqSJr6WYH0Bq7mrlFhzWDw',
	'BLV Tạ Biên Cương': 'http://www.youtube.com/channel/UCbPF5L84DIv7zGg9mCqfGtw',
	'Tuyền văn hoá': 'http://www.youtube.com/channel/UCCgCw-IJYpse4qnOCvvcitA',
	'Cảm bóng đá': 'http://www.youtube.com/channel/UCtowbSVJlDLjgs-5qsznSTA',
	'Nhà báo Minh Hải': 'http://www.youtube.com/channel/UCyIOLARJsMYFbQ-7-P-4DIA',
	'Anh Quân tin mới': 'http://www.youtube.com/channel/UCFEdjI6bdng-T1CWlqwSC1g',
	'Anh Quân bóng đá Việt': 'http://www.youtube.com/channel/UCCBwmJaVIB220c5sWdE28XQ'
	}
	for k in T:
		item = Listitem()
		item.label = k
		item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://thethao360.tv/wp-content/uploads/2020/12/logo-3.png'
		item.set_callback(youtube_kenh, T[k])
		yield item