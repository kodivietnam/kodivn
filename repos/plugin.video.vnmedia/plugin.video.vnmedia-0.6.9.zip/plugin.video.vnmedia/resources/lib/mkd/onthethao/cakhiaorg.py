from codequick import Route, Listitem, run
from datetime import datetime, timedelta
from resources.lib.kedon import quangcao, getlink, stream, referer, play_vnm
from bs4 import BeautifulSoup
@Route.register
def index_cakhiaorg(plugin, content_type='segment'):
	url = 'https://zencdn.xyz/static/json/common/live.json'
	resp = getlink(url, url, 5*60)
	if 'link' in resp.text:
		kq = resp.json()
		for k in kq:
			item = Listitem()
			item.label = k['time'] + ' ' + k['title']
			item.art['thumb'] = 'https://cakhia.org/wp-content/themes/v2.1/assets/images/logo_cakhia_2.png'
			item.art['fanart'] = 'https://cakhia.org/wp-content/themes/v2.1/assets/images/logo_cakhia_2.png'
			item.set_callback(list_cakhiaorg, 'https://cakhia.org' + k['link'], item.label)
			yield item
	else:
		yield quangcao()

@Route.register
def list_cakhiaorg(plugin,url,title):
	resp = getlink(url, url, 15*60)
	if 'm3u8' in resp.text:
		web = BeautifulSoup(resp.text, 'html.parser')
		for k in web.body.select('video-js.video-js source'):
			item = Listitem()
			linktrandau = stream(k.get('src')) + referer('https://cakhia.org')
			item.label = k.get('label') + ' - ' + title
			item.art['thumb'] = 'https://cakhia.org/wp-content/themes/v2.1/assets/images/logo_cakhia_2.png'
			item.art['fanart'] = 'https://cakhia.org/wp-content/themes/v2.1/assets/images/logo_cakhia_2.png'
			item.set_callback(play_vnm, linktrandau, item.label, '')
			yield item
	else:
		yield quangcao()