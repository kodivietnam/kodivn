from codequick import Route, Listitem, run
from resources.lib.kedon import quangcao, getlink, stream, referer, play_vnm, xembd
from bs4 import BeautifulSoup
from urllib.parse import urlparse
l = xembd()[2]
m = urlparse(l)
linkweb = '%s://%s' % (m.scheme, m.netloc)
@Route.register
def index_xoilac3(plugin, **kwargs):
	url = 'https://s2.zencdn.xyz/static/json/common/live.json'
	resp = getlink(url, url, 5*60)
	if 'link' in resp.text:
		kq = resp.json()
		for k in kq:
			item = Listitem()
			if k['cmt']:
				item.label = '%s: %s - BLV %s' % (k['time'], k['title'], k['cmt'])
			else:
				item.label = '%s: %s' % (k['time'], k['title'])
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = '%s%s' % (linkweb, k['cover'])
			item.set_callback(list_xoilac3, '%s%s' % (linkweb, k['link']), item.label)
			yield item
	else:
		yield quangcao()
@Route.register
def list_xoilac3(plugin,url,title, **kwargs):
	resp = getlink(url, url, 15*60)
	if '.m3u8' in resp.text:
		web = BeautifulSoup(resp.content, 'html.parser')
		for k in web.body.select('video-js.video-js source'):
			item = Listitem()
			linktrandau = '%s%s' % (stream(k.get('src')), referer(linkweb))
			item.label = '%s - %s' % (k.get('label'), title)
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = '%s/wp-content/uploads/2022/06/logo-xoilac-tv-1.jpg' % linkweb
			item.set_callback(play_vnm, linktrandau, item.label, '')
			yield item
	else:
		yield quangcao()