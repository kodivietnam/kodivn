from codequick import Route, Listitem, run, Script
from bs4 import BeautifulSoup
from resources.lib.kedon import __addon__, useragent, getlink, __icon__, __addonnoti__, play_fs, userpassfs, useragentvmf, quangcao
from resources.lib.download import downloadfs
from requests import Session
import urlquick, xbmc, xbmcvfs, xbmcgui, re, json, os, pickle, time
ADDON_ID = __addon__.getAddonInfo('id')
addon_data_dir = os.path.join(xbmcvfs.translatePath('special://userdata/addon_data'),ADDON_ID)
hdvn = 'https://www.hdvietnam.xyz'
@Route.register
def index_fs(plugin, idfd, next_page, **kwargs):
	url = 'https://www.fshare.vn/api/v3/files/folder?linkcode=%s&sort=type,name&page=%s' % (idfd, str(next_page))
	kq = getlink(url, url, 60*60)
	if 'items' in kq.text and len(kq.json()['items']) > 0:
		for k in kq.json()['items']:
			item = Listitem()
			if k['type'] == 0:
				item.label = k['name']
				linkfd = k['linkcode']
				linkplay = 'https://www.fshare.vn/folder/%s' % linkfd
				item.art['thumb'] = item.art['landscape'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=1&size=400x400&ecc=L' % linkplay
				item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
				item.set_callback(index_fs, linkfd, 1)
				yield item
			elif k['type'] == 1:
				item.label = k['name']
				item.info['size'] = k['size']
				linkplay = 'https://www.fshare.vn/file/%s' % k['linkcode']
				item.art['thumb'] = item.art['landscape'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=1&size=400x400&ecc=L' % linkplay
				item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item.context.script(downloadfs, 'Tải về', linkplay)
				item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
				item.set_callback(play_fs, linkplay, item.label)
				yield item
	else:
		xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonnoti__, u'Fshare link folder die', 10000, __icon__))
		yield quangcao() 
	if kq.json().get('_links').get('last'):
		last_page = re.search(r'&page=(\d+)', kq.json().get('_links').get('last')).group(1)
		if int(last_page) > next_page:
			item1 = Listitem()
			item1.label = 'Trang %s' % (next_page + 1)
			item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
			item1.set_callback(index_fs, idfd, next_page + 1)
			yield item1
@Route.register
def fs_favorite(plugin, **kwargs):
	try:
		login = userpassfs()
		session_id = login[1]
		headerfsvn = {'User-Agent': useragentvmf, 'Cookie' : 'session_id=%s' % session_id }
		r = urlquick.get('https://api.fshare.vn/api/fileops/listFavorite', timeout=10, max_age=0, headers=headerfsvn)
	except:
		xbmcgui.Dialog().ok(__addonnoti__, 'Đăng nhập không thành công\nKiểm tra lại tài khoản, mật khẩu, đường truyền Internet')
		__addon__.openSettings()
		exit()
	for k in r.json():
		item = Listitem()
		if k['type'] == '0':
			item.label = k['name']
			linkfd = k['linkcode']
			linkplay = 'https://www.fshare.vn/folder/%s' % linkfd
			item.art['thumb'] = item.art['landscape'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=1&size=400x400&ecc=L' % linkplay
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			item.context.script(xfavo, 'Xoá khỏi Fshare Favorite', linkplay)
			item.set_callback(index_fs, linkfd, 1)
			yield item
		elif k['type'] == '1':
			item.label = k['name']
			item.info['size'] = k['size']
			linkplay = 'https://www.fshare.vn/file/%s' % k['linkcode']
			item.art['thumb'] = item.art['landscape'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=1&size=400x400&ecc=L' % linkplay
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			item.context.script(downloadfs, 'Tải về', linkplay)
			item.context.script(xfavo, 'Xoá khỏi Fshare Favorite', linkplay)
			item.set_callback(play_fs, linkplay, item.label)
			yield item
		else:
			yield []
@Route.register
def fs_topfollow(plugin, **kwargs):
	login = userpassfs()
	session_id = login[1]
	headerfsvn = {'User-Agent': useragentvmf, 'Cookie' : 'session_id=%s' % session_id}
	try:
		r = urlquick.get('https://api.fshare.vn/api/fileops/getTopFollowMovie', timeout=10, max_age=7*24*60*60, headers=headerfsvn)
	except:
		xbmcgui.Dialog().ok(__addonnoti__, 'Đăng nhập không thành công\nKiểm tra lại tài khoản, mật khẩu, đường truyền Internet')
		__addon__.openSettings()
		exit()
	for k in r.json():
		item = Listitem()
		item.label = k['name']
		linkfd = k['linkcode']
		linkplay = 'https://www.fshare.vn/folder/%s' % linkfd
		item.art['thumb'] = item.art['landscape'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=1&size=400x400&ecc=L' % linkplay
		item.art['fanart'] = 'https://www.fshare.vn/images/top-follow/title.png'
		item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
		item.set_callback(index_fs, linkfd, 1)
		yield item
@Script.register
def tfavo(plugin, x, **kwargs):
	if 'file' in x:
		if '?' in x:
			match = re.search(r'file/(.*?)\?', x)
			idfd = match.group(1)
		else:
			tach = x.split('file/')
			idfd = tach[1]
	elif 'folder' in x:
		if '?' in x:
			match = re.search(r'folder/(.*?)\?', x)
			idfd = match.group(1)
		else:
			tach = x.split('folder/')
			idfd = tach[1]
	login = userpassfs()
	token = login[0]
	session_id = login[1]
	headerfsvn = {'User-Agent': useragentvmf, 'Cookie' : 'session_id=%s' % session_id}
	payload = '{"items":["%s"],"status":1,"token":"%s"}' % (idfd, token)
	r = urlquick.post('https://api.fshare.vn/api/fileops/ChangeFavorite', timeout=10, max_age=0, data=payload, headers=headerfsvn)
	Script.notify(__addonnoti__, 'Đã thêm vào Fshare Favorite')
@Script.register
def xfavo(plugin, x, **kwargs):
	if 'file' in x:
		if '?' in x:
			match = re.search(r'file/(.*?)\?', x)
			idfd = match.group(1)
		else:
			tach = x.split('file/')
			idfd = tach[1]
	elif 'folder' in x:
		if '?' in x:
			match = re.search(r'folder/(.*?)\?', x)
			idfd = match.group(1)
		else:
			tach = x.split('folder/')
			idfd = tach[1]
	login = userpassfs()
	token = login[0]
	session_id = login[1]
	headerfsvn = {'User-Agent': useragentvmf, 'Cookie' : 'session_id=%s' % session_id}
	payload = '{"items":["%s"],"status":0,"token":"%s"}' % (idfd, token)
	r = urlquick.post('https://api.fshare.vn/api/fileops/ChangeFavorite', timeout=10, max_age=0, data=payload, headers=headerfsvn)
	Script.notify(__addonnoti__, 'Đã xoá khỏi Fshare Favorite')
	xbmc.executebuiltin('Container.Refresh()')
def get_file_path(filename):
	return os.path.join(addon_data_dir, filename)
def has_file_path(filename):
	return os.path.exists(get_file_path(filename))
def get_last_modified_time_file(filename):
	return int(os.path.getmtime(get_file_path(filename)))
def remove_file(filename):
	if has_file_path(filename):
		os.remove(get_file_path(filename))
def write_file(name, content, binary=False):
	if not os.path.exists(addon_data_dir):
		log("********************** create dir path %s" % addon_data_dir)
		os.makedirs(addon_data_dir)
	path = get_file_path(name)
	try:
		write_mode = 'wb+' if binary else 'w+'
		f = open(path, mode=write_mode)
		f.write(content)
		f.close()
	except:
		pass
	return path
def read_file(name, binary=False):
	content = None
	read_mode = 'rb' if binary else 'r'
	try:
		path = get_file_path(name)
		f = open(path, mode=read_mode)
		content = f.read()
		f.close()
	except:
		pass
	return content
def loginfcine():
	if has_file_path('fcine.bin') and get_last_modified_time_file('fcine.bin') + 43200 < int(time.time()):
		remove_file('fcine.bin')
	if has_file_path('fcine.bin'):
		return pickle.loads(read_file('fcine.bin', True))
	else:
		with Session() as s:
			site = s.get('https://fcine.net/login/')
			token = re.search('csrfKey: "(.*)",', site.text).group(1)
			headers = {'user-agent':useragent,'origin': 'https://fcine.net','referer':'https://fcine.net/login/'}
			login_data = {'login__standard_submitted':1,'csrfKey':token,'auth':'romvemot@gmail.com','password':'bimozie','remember_me':1,'remember_me_checkbox':1}
			s.post('https://fcine.net/login/', data=login_data, headers=headers)
			write_file('fcine.bin', pickle.dumps(s), True)
			return s
def loginfhdvn():
	if has_file_path('hdvietnam.bin') and get_last_modified_time_file('hdvietnam.bin') + 3600 < int(time.time()):
		remove_file('hdvietnam.bin')
	if has_file_path('hdvietnam.bin'):
		return pickle.loads(read_file('hdvietnam.bin', True))
	else:
		with Session() as s:
			site = s.get('%s/forums/' % hdvn)
			headers = {'user-agent':useragent,'origin':hdvn,'referer':'%s/' % hdvn}
			login_data = {'login':'romvemot@gmail.com','register':0,'password':'bimozie','remember':1,'cookie_check':1,'_xfToken':'','redirect':'/forums/'}
			s.post('%s/login/login' % hdvn, data=login_data, headers=headers)
			write_file('hdvietnam.bin', pickle.dumps(s), True)
			return s
def likehdvn(url):
	s = loginfhdvn()
	r = s.get('%s/%s' % (hdvn, url))
	soup = BeautifulSoup(r.content, 'html.parser')
	token = soup.select_one('input[name="_xfToken"]').get('value')
	like = '%s/%s' % (hdvn, soup.select_one('div.publicControls a.LikeLink.item.control').get('href'))
	if 'like' in like:
		data_like = {'_xfRequestUri':'/%s' % url,'_xfToken':token,'_xfNoRedirect':1,'_xfResponseType': 'json'}
		s.post(like, data=data_like)
		return