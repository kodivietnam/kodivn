from codequick import Route, Listitem, run
from resources.lib.kedon import userpassfs
from resources.lib.qrplay import qrplay
from resources.lib.mkd.onfshare.codenumber import searchnumber
from resources.lib.mkd.onfshare.ifshare import fs_favorite, fs_topfollow
from resources.lib.mkd.onfshare.thuvienhd import index_thuvienhd
from resources.lib.mkd.onfshare.timfshare import searchfs
from resources.lib.mkd.onfshare.thuviencine import index_thuviencine
@Route.register
def index_fshare(plugin, **kwargs):
	Fsharefavorite = {'label': 'Fshare Favorite',
	'info':{'plot':'Yêu thích'},
	'art':{'thumb':'https://banner2.cleanpng.com/20180319/ikq/kisspng-heart-love-brand-logo-favourites-5ab0468bbe3665.1130427115215018357791.jpg',
	'fanart':'https://fsharetv.com/img/fsharetv.png'},
	'callback':fs_favorite}
	Fsharefollow = {'label': 'TOP FSHARE',
	'info':{'plot':'Top 15 thư mục theo dõi nhiều nhất'},
	'art':{'thumb':'https://www.fshare.vn/images/top-follow/title.png',
	'fanart':'https://fsharetv.com/img/fsharetv.png'},
	'callback':fs_topfollow}
	Thuvienhdp = {'label': 'Thư viện HD',
	'info':{'plot':'Thư viện dữ liệu phim Fshare'},
	'art':{'thumb':'https://thuvienhd.com/wp-content/uploads/2020/10/THUVIENHD.NET_.png',
	'fanart':'https://fsharetv.com/img/fsharetv.png'},
	'callback':index_thuvienhd}
	Thuviencinep = {'label': 'Thư viện Cine',
	'info':{'plot':'Thư viện dữ liệu phim Fshare'},
	'art':{'thumb':'https://thuviencine.com/wp-content/uploads/2021/09/logo-red.png',
	'fanart':'https://fsharetv.com/img/fsharetv.png'},
	'callback':index_thuviencine}
	yield Listitem.search(searchfs)
	yield makeQrPlayItem()
	yield PlayNumberCode()
	yield Listitem.from_dict(**Fsharefavorite)
	yield Listitem.from_dict(**Fsharefollow)
	yield Listitem.from_dict(**Thuvienhdp)
	yield Listitem.from_dict(**Thuviencinep)
def PlayNumberCode():
    item = Listitem()
    item.label = 'Play NumberCode'
    item.info['plot'] = 'Mã CODE được tạo từ trang rút gọn http://gg.gg'
    item.path = searchnumber
    item.art['thumb'] = 'https://reference.vn/wp-content/uploads/2019/04/lic-su-so-tu-nhien.jpg'
    item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
    item.set_callback(searchnumber, item.path)
    return item
def makeQrPlayItem():
    item = Listitem()
    item.label = 'Mobile Play'
    item.info['plot'] = 'Dùng điện thoại để nhập link Fshare hoặc nhập từ khóa tìm kiếm thuận tiện'
    item.path = qrplay
    item.art['thumb'] = 'https://banner2.cleanpng.com/20180616/jao/kisspng-computer-icons-qr-code-download-mobile-phones-qrcode-5b255cd1736764.9771995515291752494727.jpg'
    item.art['fanart'] = 'https://banner2.cleanpng.com/20180303/leq/kisspng-template-download-mobile-phone-qr-code-vector-creative-hand-phone-5a9aa86bd143f0.9505955915200850998572.jpg'
    item.set_callback(qrplay)
    return item