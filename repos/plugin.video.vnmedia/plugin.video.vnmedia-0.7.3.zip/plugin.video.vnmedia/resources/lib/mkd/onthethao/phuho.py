from codequick import Route, Listitem, run
from datetime import datetime, timedelta
from resources.lib.kedon import quangcao, getlink, stream, referer, play_vnm, tb
@Route.register
def index_phuho(plugin, **kwargs):
	url = 'https://phuho2.tv/node-cache/get-lives-home'
	resp = getlink(url, url, 5*60)
	if 'm3u8' in resp.text:
		kq = resp.json()
		for k1 in kq['data']['liveMatchings']:
			for k2 in k1['hlsUrlsPhuHo']:
				item1 = Listitem()
				if 'm3u8' in k2['url']:
					time1 = (datetime.fromisoformat(k1['time'][:-1]) + timedelta(hours=7)).strftime('%H:%M %d-%m')
					linktrandau1 = stream(k2['url']) + referer('https://xem.phuho2.tv/')
					item1.label = k2['name'] + ' ' + time1 + ' ' + k1['teamA']['name'] + '-' + k1['teamB']['name']
					item1.info['plot'] = tb
					item1.art['thumb'] = 'https://cakhiastatic.fastlycdnlive.xyz/cakhia/phuho7/template/user/img/phuho.png'
					item1.art['fanart'] = 'https://cakhiastatic.fastlycdnlive.xyz/cakhia/phuho7/template/user/img/phuho.png'
					item1.set_callback(play_vnm, linktrandau1, item1.label, '')
					yield item1
				
		for b1 in kq['data']['livesSapDienRa']:
			if 'hlsUrlsPhuHo' in b1:
				for b2 in b1['hlsUrlsPhuHo']:
					item2 = Listitem()
					if 'm3u8' in b2['url']:
						time2 = (datetime.fromisoformat(b1['time'][:-1]) + timedelta(hours=7)).strftime('%H:%M %d-%m')
						linktrandau2 = stream(b2['url']) + referer('https://xem.phuho2.tv/')
						item2.label = b2['name'] + ' ' + time2 + ' ' + b1['teamA']['name'] + '-' + b1['teamB']['name']
						item2.info['plot'] = tb
						item2.art['thumb'] = 'https://cakhiastatic.fastlycdnlive.xyz/cakhia/phuho7/template/user/img/phuho.png'
						item2.art['fanart'] = 'https://cakhiastatic.fastlycdnlive.xyz/cakhia/phuho7/template/user/img/phuho.png'
						item2.set_callback(play_vnm, linktrandau2, item2.label, '')
						yield item2
					
	else:
		yield quangcao()