from codequick import Route, Listitem, run
from resources.lib.kedon import getlink
import re
@Route.register
def youtube_tatcavideo(plugin, url, **kwargs):
	resp = getlink(url, url, 15*60)
	kq = resp.text.replace('\\','')
	listplay = re.findall(r'gridVideoRenderer(.*?)navigationEndpoint', kq)
	for k in listplay:
		item = Listitem()
		tenvd = re.search(r'{"text":"(.*?)"}', k).group(1)
		idvd = re.search(r'"videoId":"(.*?)"', k).group(1)
		anhvd = re.search(r'url":"(.*?)"', k).group(1)
		item.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=' + idvd
		item.label = tenvd
		item.art["thumb"] = anhvd
		item.art["fanart"] = anhvd
		item.set_callback(item.path)
		yield item

@Route.register
def youtube_dslist(plugin, url, **kwargs):
	resp = getlink(url, url, 15*60)
	kq = resp.text.replace('\\','')
	listplay = re.findall(r'gridPlaylistRenderer(.*?)webPageType', kq)
	for k in listplay:
		item = Listitem()
		tenvd = re.search(r'text":"(.*?)",', k).group(1)
		idvd = re.search(r'webCommandMetadata":{"url":"(.*?)"', k).group(1)
		anhvd = re.search(r'url":"(.*?)"', k).group(1)
		xx = 'https://www.youtube.com' + idvd.replace('u0026','&')
		item.label = tenvd
		item.art["thumb"] = anhvd
		item.art["fanart"] = anhvd
		item.set_callback(youtube_list, xx)
		yield item

@Route.register
def youtube_list(plugin, url, **kwargs):
	resp = getlink(url, url, 15*60)
	kq = resp.text.replace('\\','')
	listplay = re.findall(r'playlistPanelVideoRenderer(.*?)playlistId', kq)
	for k in listplay:
		item = Listitem()
		tenvd = re.search(r'simpleText":"(.*?)"}', k).group(1)
		idvd = re.search(r'videoId":"(.*?)"', k).group(1)
		anhvd = re.search(r'thumbnails":\[{"url":"(.*?)"', k).group(1)
		item.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=' + idvd
		item.label = tenvd
		item.art["thumb"] = anhvd
		item.art["fanart"] = anhvd
		item.set_callback(item.path)
		yield item

@Route.register
def youtube_thinhhanh(plugin, **kwargs):
	url = 'https://www.youtube.com/feed/trending'
	resp = getlink(url, url, 24*60*60)
	kq = resp.text.replace('\\','')
	listplay = re.findall(r'videoRenderer(.*?)accessibility', kq)
	for k in listplay:
		item = Listitem()
		tenvd = re.search(r'text":"(.*?)"}', k).group(1)
		idvd = re.search(r'videoId":"(.*?)"', k).group(1)
		anhvd = re.search(r'url":"(.*?)"', k).group(1)
		item.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=' + idvd
		item.label = tenvd
		item.art["thumb"] = anhvd
		item.art["fanart"] = anhvd
		item.set_callback(item.path)
		yield item

@Route.register
def youtube_kenh(plugin, url, **kwargs):
	item2 = Listitem()
	item2.label = 'Danh sách phát'
	item2.art['thumb'] = 'https://www.youtube.com/img/desktop/yt_1200.png'
	item2.art['fanart'] = 'https://www.youtube.com/img/desktop/yt_1200.png'
	item2.set_callback(youtube_dslist, url+'/playlists')
	item1 = Listitem()
	item1.label = 'Tất cả Video'
	item1.art['thumb'] = 'https://www.youtube.com/img/desktop/yt_1200.png'
	item1.art['fanart'] = 'https://www.youtube.com/img/desktop/yt_1200.png'
	item1.set_callback(youtube_tatcavideo, url+'/videos')
	yield item2
	yield item1
	resp = getlink(url, url, 15*60)
	kq = resp.text.replace('\\','')
	listplay = re.findall(r'gridVideoRenderer(.*?)navigationEndpoint', kq)
	for k in listplay:
		item = Listitem()
		tenvd = re.search(r'simpleText":"(.*?)"}', k).group(1)
		idvd = re.search(r'"videoId":"(.*?)"', k).group(1)
		anhvd = re.search(r'url":"(.*?)"', k).group(1)
		item.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=' + idvd
		item.label = tenvd
		item.art["thumb"] = anhvd
		item.art["fanart"] = anhvd
		item.set_callback(item.path)
		yield item