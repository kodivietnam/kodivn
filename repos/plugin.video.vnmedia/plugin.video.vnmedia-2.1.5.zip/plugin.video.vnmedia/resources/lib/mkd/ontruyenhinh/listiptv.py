from codequick import Route, Listitem, run
from resources.lib.kedon import logotv, tb, getlinkip, quangcao, streamiptv, ace, play_vnm, useragentott, referer
import re
@Route.register
def list_iptv(plugin, url, **kwargs):
	item = Listitem()
	item.label = 'TẤT CẢ CÁC KÊNH'
	item.info['plot'] = tb
	item.art['thumb'] = item.art['landscape'] = 'https://i.imgur.com/Mnuw95h.png'
	item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
	item.set_callback(little_iptv, url)
	yield item
	try:
		resp = getlinkip(url, url)
		rp = resp.data.decode('utf-8')
		group = re.findall('group-title="(.*?)"', rp)
		um = []
		for tk in list(dict.fromkeys(group)):
			if ';' in tk:
				[um.append(k) for k in tk.split(';') if k not in um]
			else:
				um.append(tk)
		if '' in um:
			um.remove('')
		for p in um:
			item = Listitem()
			item.label = p
			item.info['plot'] = tb
			item.art['thumb'] = item.art['landscape'] = 'https://i.imgur.com/Mnuw95h.png'
			item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
			item.set_callback(info_iptv, url, p)
			yield item
	except:
		pass
@Route.register
def info_iptv(plugin, url, tk, **kwargs):
	resp = getlinkip(url, url)
	ketqua = re.sub('(#EXTM3U|#[^EX])(.*)', '', resp.data.decode('utf-8')).split('#EXTINF')
	sre1 = re.compile('\n((http|https|udp|rtp):(.*?)\n)')
	sre2 = re.compile('[,](?!.*[,])(.*)')
	sre4 = re.compile('tvg-logo="(.*?)"')
	sre5 = re.compile('http-user-agent=(.*?)\n')
	sre6 = re.compile('http-referrer=(.*?)\n')
	for kq in ketqua:
		try:
			s1 = sre1.search(kq)
			s2 = sre2.search(kq)
			s4 = sre4.search(kq)
			s5 = sre5.search(kq)
			s6 = sre6.search(kq)
			if f'group-title="{tk}"' in kq and ';' not in kq and s1:
				item = Listitem()
				kenh = s1.group(1)
				tenkenh = s2.group(1)
				item.label = tenkenh
				item.info['plot'] = tb
				if s4:
					item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = s4.group(1)
				else:
					item.art['thumb'] = item.art['landscape'] = logotv
					item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
				if 'acestream' in kenh:
					linkplay = ace(kenh, item.label)
					item.path = linkplay
					item.set_callback(item.path)
				elif ':6878' in kenh:
					linkplay = ace(kenh, item.label)
					item.path = linkplay
					item.set_callback(item.path)
				else:
					if s5:
						user = s5.group(1)
					else:
						user = useragentott
					if s6:
						refe = s6.group(1)
						linkplay = f'{streamiptv(kenh.strip(), user)}{referer(refe)}'
					else:
						linkplay = streamiptv(kenh.strip(), user)
					item.set_callback(play_vnm, linkplay, item.label, '')
				yield item
			elif tk in kq and ';' in kq and s1:
				item = Listitem()
				kenh = s1.group(1)
				tenkenh = s2.group(1)
				item.label = tenkenh
				item.info['plot'] = tb
				if s4:
					item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = s4.group(1)
				else:
					item.art['thumb'] = item.art['landscape'] = logotv
					item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
				if 'acestream' in kenh:
					linkplay = ace(kenh, item.label)
					item.path = linkplay
					item.set_callback(item.path)
				elif ':6878' in kenh:
					linkplay = ace(kenh, item.label)
					item.path = linkplay
					item.set_callback(item.path)
				else:
					if s5:
						user = s5.group(1)
					else:
						user = useragentott
					if s6:
						refe = s6.group(1)
						linkplay = f'{streamiptv(kenh.strip(), user)}{referer(refe)}'
					else:
						linkplay = streamiptv(kenh.strip(), user)
					item.set_callback(play_vnm, linkplay, item.label, '')
				yield item
		except:
			yield quangcao()
@Route.register
def little_iptv(plugin, url, **kwargs):
	resp = getlinkip(url, url)
	ketqua = re.sub('(#EXTM3U|#[^EX])(.*)', '', resp.data.decode('utf-8')).split('#EXTINF')
	sre1 = re.compile('\n((http|https|udp|rtp):(.*?)\n)')
	sre2 = re.compile('[,](?!.*[,])(.*)')
	sre3 = re.compile('group-title="(.*?)"')
	sre4 = re.compile('tvg-logo="(.*?)"')
	sre5 = re.compile('http-user-agent=(.*?)\n')
	sre6 = re.compile('http-referrer=(.*?)\n')
	for kq in ketqua:
		try:
			s1 = sre1.search(kq)
			s2 = sre2.search(kq)
			s3 = sre3.search(kq)
			s4 = sre4.search(kq)
			s5 = sre5.search(kq)
			s6 = sre6.search(kq)
			if s1:
				item = Listitem()
				kenh = s1.group(1)
				tenkenh = s2.group(1)
				if s3:
					nhomkenh = s3.group(1)
				else:
					nhomkenh = 'TỔNG HỢP'
				item.info['plot'] = f'{nhomkenh} - {tenkenh}'
				item.label = f'{tenkenh} - {nhomkenh}'
				if s4:
					item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = s4.group(1)
				else:
					item.art['thumb'] = item.art['landscape'] = logotv
					item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
				if 'acestream' in kenh:
					linkplay = ace(kenh, item.label)
					item.path = linkplay
					item.set_callback(item.path)
				elif ':6878' in kenh:
					linkplay = ace(kenh, item.label)
					item.path = linkplay
					item.set_callback(item.path)
				else:
					if s5:
						user = s5.group(1)
					else:
						user = useragentott
					if s6:
						refe = s6.group(1)
						linkplay = f'{streamiptv(kenh.strip(), user)}{referer(refe)}'
					else:
						linkplay = streamiptv(kenh.strip(), user)
					item.set_callback(play_vnm, linkplay, item.label, '')
				yield item
		except:
			yield quangcao()