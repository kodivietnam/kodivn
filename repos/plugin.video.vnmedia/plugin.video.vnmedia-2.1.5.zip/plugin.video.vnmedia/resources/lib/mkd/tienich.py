from codequick import Route, Script, Listitem, run
from resources.lib.kedon import getlink, __addonnoti__, __addonnoti__, get_file_path
import xbmcgui, xbmc, urlquick, os
@Route.register
def index_tienich(plugin, **kwargs):
	Myip = {'label': 'Địa chỉ IP',
	'info': {'plot': 'Kiểm tra địa chỉ IP của tôi'},
	'art': {'thumb': 'https://www.elegantthemes.com/blog/wp-content/uploads/2020/03/what-is-an-ip-address-featured-image.jpg',
	'fanart': 'https://www.elegantthemes.com/blog/wp-content/uploads/2020/03/what-is-an-ip-address-featured-image.jpg'},
	'callback': check_myip}
	Mysetting = {'label': 'Cài đặt tiện ích',
	'info': {'plot': 'Cài đặt tiện ích'},
	'art': {'thumb': 'https://cdn.pixabay.com/photo/2018/04/11/19/48/settings-3311592_960_720.png',
	'fanart': 'https://cdn.pixabay.com/photo/2018/04/11/19/48/settings-3311592_960_720.png'},
	'callback': settingaddon}
	Mycache = {'label': 'Xoá bộ nhớ đệm',
	'info': {'plot': 'Xoá bộ nhớ đệm'},
	'art': {'thumb': 'https://us.123rf.com/450wm/lkeskinen/lkeskinen1802/lkeskinen180202962/95571098-clear-cache-rubber-stamp-grunge-design-with-dust-scratches-effects-can-be-easily-removed-for-a-clean.jpg',
	'fanart': 'https://us.123rf.com/450wm/lkeskinen/lkeskinen1802/lkeskinen180202962/95571098-clear-cache-rubber-stamp-grunge-design-with-dust-scratches-effects-can-be-easily-removed-for-a-clean.jpg'},
	'callback': deletecache}
	yield Listitem.from_dict(**Mysetting)
	yield Listitem.from_dict(**Myip)
	yield Listitem.from_dict(**Mycache)
@Script.register
def check_myip(plugin, **kwargs):
	url = 'https://redirector.googlevideo.com/report_mapping?di=no'
	resp = getlink(url, url, -1)
	if resp is not None:
		xbmcgui.Dialog().ok(__addonnoti__, resp.text)
	else:
		xbmcgui.Dialog().ok(__addonnoti__, 'Không có dữ liệu')
@Script.register
def settingaddon(plugin, **kwargs):
	xbmc.executebuiltin('Addon.OpenSettings(plugin.video.vnmedia)')
@Script.register
def deletecache(plugin, **kwargs):
	urlquick.cache_cleanup(-1)
	if os.path.exists(get_file_path('.urlquick.slite3')):
		os.remove(get_file_path('.urlquick.slite3'))
		Script.notify(__addonnoti__, 'Đã xoá bộ nhớ đệm')
	else:
		Script.notify(__addonnoti__, 'Bộ nhớ đệm trống')