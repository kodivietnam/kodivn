from codequick import Script, utils
def get_item_label(item_id, item_infos={}):
    if 'label' in item_infos:
        label = item_infos['label']
    else:
        label = item_id
    return label
def get_item_media_path(item_media_path):
    full_path = ''
    if type(item_media_path) is list:
        import os
        full_path = os.path.join(Script.get_info("path"), "resources", "media",
                                 *(item_media_path))
    elif 'http' in item_media_path:
        full_path = item_media_path
    return utils.ensure_native_str(full_path)