from codequick import Script, Route, Listitem, Resolver
from resources.lib.kedon import getlinkphongblack, postlinktimfs, getlink, quangcao, yttk
from concurrent.futures import ThreadPoolExecutor
from bs4 import BeautifulSoup
from urllib.parse import quote_plus
from json import loads
from functools import lru_cache
import re
def get_tkfs1(search_query):
	return getlinkphongblack(f'http://phongblack.me/search.php?author=phongblack&search={search_query}', 'http://www.google.com', 1000)
def get_tkfs2(search_query):
	return postlinktimfs(f'https://api.timfshare.com/v1/string-query-search?query={search_query}', 'https://timfshare.com/', 1000)
def get_tkfs3(search_query):
	return getlink(f'https://thuvienhd.xyz/?feed=fsharejson&search={search_query}', 'https://thuvienhd.xyz/', 1000)
def get_tkfs4():
	return getlink(f'https://thuvienhd.xyz/?feed=fsharejson&search=', 'https://thuvienhd.xyz/', 1000)
@Route.register
def searchfs(plugin, search_query=None):
	yield []
	if search_query is None:
		pass
	else:
		try:
			search_query = quote_plus(search_query)
			with ThreadPoolExecutor(4) as ex:
				f1 = ex.submit(get_tkfs1, search_query)
				f2 = ex.submit(get_tkfs2, search_query)
				f3 = ex.submit(get_tkfs3, search_query)
				f4 = ex.submit(get_tkfs4)
				result_f1 = f1.result()
				result_f2 = f2.result()
				result_f3 = f3.result()
				result_f4 = f4.result()
			try:
				if result_f3 is not None and result_f4 is not None:
					if result_f3.content != result_f4.content:
						kqtvhd = result_f3.json()
						for t in kqtvhd:
							tenmm = t['title'].replace('&&','-')
							item = Listitem()
							item.label = tenmm
							item.info['mediatype'] = 'tvshow'
							item.info['trailer'] = yttk(tenmm)
							item.art['thumb'] = item.art['poster'] = t['image']
							item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_link'), t['id'])
							yield item
			except:
				if result_f3 is not None and result_f4 is not None:
					if result_f3.content != result_f4.content:
						text = result_f3.text
						data = re.sub(r'<(.*?)\n','',text)
						jsm = loads(data)
						for t in jsm:
							tenmm = t['title'].replace('&&','-')
							item = Listitem()
							item.label = tenmm
							item.info['mediatype'] = 'tvshow'
							item.info['trailer'] = yttk(tenmm)
							item.art['thumb'] = item.art['poster'] = t['image']
							item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_link'), t['id'])
							yield item
			try:
				rj = result_f1.json()['items']
				d = (k for k in rj if k['is_playable'] is False)
				for m in d:
					path = m['path']
					if '/file/' in path:
						item = Listitem()
						item.label = m['label']
						link = re.search(r"url=(\S+)", path)[1]
						item.info['mediatype'] = 'episode'
						item.info['trailer'] = yttk(m['label'])
						item.art['thumb'] = item.art['poster'] = 'https://mi3s.top/thumb/fshare.png'
						item.info['plot'] = m['info']['plot'] if 'info' in m else m['label']
						if Script.setting.get_string('taifshare') == 'true':
							item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', link)
						item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
						item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), link, m['label'])
						yield item
					elif '/folder/' in path:
						item = Listitem()
						item.label = m['label']
						link = re.search(r"url=(\S+)", path)[1]
						item.info['mediatype'] = 'tvshow'
						item.info['trailer'] = yttk(m['label'])
						imgfs = 'https://mi3s.top/thumb/fshare.png'
						item.art['thumb'] = item.art['poster'] = imgfs
						item.info['plot'] = m['info']['plot'] if 'info' in m else m['label']
						item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
						item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), link, 0, imgfs)
						yield item
			except:
				pass
			try:
				j = result_f2.json()
				rj = j['data']
				m = (k for k in rj if 'data' in j)
				for k in m:
					item = Listitem()
					item.label = k['name']
					item.info['trailer'] = yttk(k['name'])
					imgfs = 'https://mi3s.top/thumb/fshare.png'
					item.art['thumb'] = item.art['poster'] = imgfs
					item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', k['url'])
					if 'folder' in k['url']:
						item.info['mediatype'] = 'tvshow'
						item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), k['url'], 0, imgfs)
					else:
						item.info['mediatype'] = 'episode'
						item.info['size'] = k['size']
						if Script.setting.get_string('taifshare') == 'true':
							item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', k['url'])
						item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), k['url'], k['name'])
					yield item
			except:
				pass
		except:
			yield quangcao()
@lru_cache(maxsize=None)
@Route.register
def index_pdx(plugin):
	streams = [
		('Đề xuất', 'https://mi3s.top/thumb/fshare/dexuat.png', index_hn),
		('BXH Thế giới', 'https://mi3s.top/thumb/phim/on.png', Route.ref('/resources/lib/mkd/onfshare/fsmdb:index_fsmdb'))
	]
	for name_key, banner_key, route_key in streams:
		i = Listitem()
		i.label = name_key
		i.info['mediatype'] = 'tvshow'
		i.art['thumb'] = i.art['poster'] = banner_key
		i.set_callback(route_key)
		yield i
	dulieu = {
	'Đặc sắc': -1,
	'Hành động': 76,
	'Phiêu lưu': 86,
	'Hình sự': 77,
	'Trinh thám': 106,
	'Võ thuật': 111,
	'Rùng rợn': 98,
	'Huyền bí': 80,
	'Kinh dị': 81,
	'Viễn tưởng': 109,
	'Hài hước': 74,
	'Lãng mạn': 82,
	'Thần thoại': 100,
	'Cổ trang': 71,
	'Phim TVB': 108,
	'Phim bộ Hàn': 89,
	'Phim bộ Mỹ': 91,
	'Lồng tiếng': 84,
	'Hoạt hình': 78
	}
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.info['mediatype'] = 'tvshow'
		item.art['thumb'] = item.art['poster'] = f'https://mi3s.top/thumb/fshare/dexuat.png'
		item.set_callback(hdo_page, dulieu[k])
		yield item
@Route.register
def index_hn(plugin):
	try:
		resptvhd = get_tkfs3('')
		try:
			kqtvhd = resptvhd.json()
			for t in kqtvhd:
				tenmm = t['title'].replace('&&','-')
				item = Listitem()
				item.label = tenmm
				item.info['plot'] = t['title']
				item.info['mediatype'] = 'tvshow'
				item.info['trailer'] = yttk(tenmm)
				item.art['thumb'] = item.art['poster'] = t['image']
				item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_link'), t['id'])
				yield item
		except:
			text = resptvhd.text
			data = re.sub(r'<(.*?)\n','',text)
			jsm = loads(data)
			for t in jsm:
				tenmm = t['title'].replace('&&','-')
				item = Listitem()
				item.label = tenmm
				item.info['plot'] = t['title']
				item.info['mediatype'] = 'tvshow'
				item.info['trailer'] = yttk(tenmm)
				item.art['thumb'] = item.art['poster'] = t['image']
				item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_link'), t['id'])
				yield item
	except:
		yield quangcao()
@Route.register
def hdo_page(plugin, idp=None):
	yield []
	if idp is None:
		pass
	else:
		try:
			trangtiep = f'https://thuvienhd.xyz/?feed=rss&exclude_cats=250004&category={idp}&posts_per_page=100'
			resp = getlink(trangtiep, trangtiep, 1000)
			if (resp is not None):
				soup = BeautifulSoup(resp.content, 'html.parser')
				it = soup.select('item')
				for k in it:
					item = Listitem()
					tenb = k.select_one('title').get_text(strip=True)
					tenm = tenb.replace('&&','-')
					item.label = tenm
					mota = k.select_one('description').get_text(strip=True)
					anh = k.select_one('enclosure')['url']
					kid = k.select_one('id').get_text(strip=True)
					item.info['plot'] = mota
					item.info['trailer'] = yttk(tenm)
					item.info['mediatype'] = 'tvshow'
					item.art['thumb'] = item.art['poster'] = anh
					item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_link'), kid)
					yield item
			else:
				yield quangcao()
		except:
			yield quangcao()