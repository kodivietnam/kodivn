from codequick import Route, Listitem, run, Script
from bs4 import BeautifulSoup
from resources.lib.kedon import quangcao, getlink, play_fs, __addonnoti__, get_info_fs, __addon__, yttk, tb
from resources.lib.mkd.onfshare.ifshare import index_fs, loginfhdvn, likehdvn, tfavo, hdvn
from resources.lib.download import downloadfs
import xbmcgui, urllib, re, threading
threads = []
dulieu = {}
def get_html(link):
    dulieu[link] = get_info_fs(link)
nhomhdvn = {
'4K': f'{hdvn}/forums/4k.337/',
'WEB-DL, HDTV 4K': f'{hdvn}/forums/web-dl-hdtv-4k.344/',
'Bluray Remux 4K': f'{hdvn}/forums/bluray-remux-4k.345/',
'Bluray Nguyên Gốc 4K': f'{hdvn}/forums/bluray-nguyen-goc-4k.346/',
'Fshare.vn': f'{hdvn}/forums/fshare-vn.33/',
'Fshare-WEB-DL, HDTV': f'{hdvn}/forums/web-dl-hdtv.271/',
'Fshare-Bluray Remux': f'{hdvn}/forums/bluray-remux.324/',
'Fshare-mHD, SD': f'{hdvn}/forums/mhd-sd.77/',
'Fshare-Bluray nguyên gốc': f'{hdvn}/forums/bluray-nguyen-goc.78/',
'Thư viện link Phim': f'{hdvn}/forums/thu-vien-link-phim.150/',
'Phim có audio Việt': f'{hdvn}/forums/phim-co-audio-viet.265/',
'Phim bộ - Series': f'{hdvn}/forums/phim-bo-series.57/',
'Phim bộ - mHD, SD': f'{hdvn}/forums/mhd-sd.104/',
'Phim hoạt hình': f'{hdvn}/forums/phim-hoat-hinh.123/',
'Phim hoạt hình - mHD, SD': f'{hdvn}/forums/mhd-sd.124/',
'Phim tài liệu - Documentaries': f'{hdvn}/forums/phim-tai-lieu-documentaries.116/',
'Phim 3D': f'{hdvn}/forums/3d.110/',
'Phim cho iOS/Android': f'{hdvn}/forums/phim-cho-ios-android.157/',
'Music request': f'{hdvn}/forums/music-request.28/',
'HD Video Clip': f'{hdvn}/forums/hd-video-clip.50/',
'Video nhạc US-EU': f'{hdvn}/forums/us-eu.189/',
'Video nhạc Việt Nam': f'{hdvn}/forums/viet-nam.191/',
'Video nhạc Asia': f'{hdvn}/forums/asia.190/',
'Soundtrack': f'{hdvn}/forums/soundtrack.73/',
'Lossless Albums': f'{hdvn}/forums/lossless-albums.26/',
'Lossless Việt Nam': f'{hdvn}/forums/nhac-viet-nam.183/',
'Lossless Quốc tế': f'{hdvn}/forums/nhac-quoc-te.184/',
'Lossless không lời': f'{hdvn}/forums/nhac-khong-loi.185/',
'Lossy albums': f'{hdvn}/forums/lossy-albums.27/',
'mHD, SD Video Clips': f'{hdvn}/forums/mhd-sd-video-clips.25/'
}
@Route.register
def search_hdvn(plugin,search_query, **kwargs):
    dp = xbmcgui.DialogProgress()
    dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
    dp.update(0)
    search_query = urllib.parse.quote_plus(search_query)
    url = f'{hdvn}/search/2022/?page=1&q={search_query.replace(" ","+")}&t=post&o=date&c[node]=337+344+345+346+33+271+324+77+78'
    r = getlink(url, url, 86400)
    if r is not None:
        idsearch = re.search(r'search/([0-9]+)', r.url).group(1)
        if 'titleText' in r.text:
            soup = BeautifulSoup(r.content, 'html.parser')
            episodes = soup.select('div.titleText a')
            for episode in episodes:
                item = Listitem()
                item.label = episode.get_text()
                item.info['mediatype'] = 'episode'
                item.info['rating'] = 10.0
                item.info['trailer'] = yttk(item.label)
                linkphim = episode.get('href')
                item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = f'{hdvn}/images/hd-vietnam-logo.png'
                item.set_callback(hdvn_link, linkphim)
                yield item
            yield Listitem.next_page(search_query, 2, idsearch, callback=search_hdvnnext)
        else:
            Script.notify(__addonnoti__, 'Không tìm thấy kết quả')
            yield quangcao()
    else:
        yield quangcao()
    dp.update(100)
    dp.close()

@Route.register
def search_hdvnnext(plugin,search_query, next_page, idsearch, **kwargs):
    search_query = urllib.parse.quote_plus(search_query)
    url = f'{hdvn}/search/{idsearch}/?page={next_page}&q={search_query.replace(" ","+")}&t=post&o=date&c[node]=337+344+345+346+33+271+324+77+78'
    r = getlink(url, url, 86400)
    if r is not None:
        if 'titleText' in r.text:
            soup = BeautifulSoup(r.content, 'html.parser')
            episodes = soup.select('div.titleText a')
            for episode in episodes:
                item = Listitem()
                item.label = episode.get_text()
                item.info['mediatype'] = 'episode'
                item.info['rating'] = 10.0
                item.info['trailer'] = yttk(item.label)
                linkphim = episode.get('href')
                item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = f'{hdvn}/images/hd-vietnam-logo.png'
                item.set_callback(hdvn_link, linkphim)
                yield item
            item1 = Listitem()
            item1.label = f'Trang {next_page + 1}'
            item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
            item1.set_callback(search_hdvnnext, search_query, next_page + 1, idsearch)
            yield item1
        else:
            Script.notify(__addonnoti__, 'Không tìm thấy kết quả')
            yield quangcao()
    else:
        yield quangcao()
@Route.register
def index_hdvn(plugin, **kwargs):
    yield Listitem.search(search_hdvn)
    for tenlist, urllist in list(nhomhdvn.items()):
        item = Listitem()
        item.label = tenlist
        item.art['thumb'] = item.art['landscape'] = f'{hdvn}/images/hd-vietnam-logo.png'
        item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
        item.info['plot'] = tb
        item.set_callback(hdvn_page, url=urllist, next_page=1)
        yield item

@Route.register
def hdvn_page(plugin, url, next_page, **kwargs):
    trangtiep = f'{url}page-{next_page}'
    r = getlink(trangtiep, trangtiep, 14400)
    if r is not None:
        soup = BeautifulSoup(r.content, 'html.parser')
        episodes = soup.select('a.PreviewTooltip')
        for episode in episodes:
            item = Listitem()
            linkphim = episode.get('href')
            p = episode.get_text()
            item.label = re.sub('[\[\]\{\}]','|', p)
            item.info['mediatype'] = 'episode'
            item.info['rating'] = 10.0
            item.info['trailer'] = yttk(item.label)
            item.art['thumb'] = item.art['landscape'] = f'{hdvn}/images/hd-vietnam-logo.png'
            item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
            item.set_callback(hdvn_link, linkphim)
            yield item
        item1 = Listitem()
        item1.label = f'Trang {next_page + 1}'
        item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
        item1.set_callback(hdvn_page, url, next_page + 1)
        yield item1
    else:
        yield quangcao()

@Route.register
def hdvn_link(plugin, url, **kwargs):
    likehdvn(url)
    r = loginfhdvn().get(f'{hdvn}/{url}')
    if 'fshare.vn' in r.text:
        soup = BeautifulSoup(r.content, 'html.parser')
        episodes = soup.select('a.externalLink')
        urls = []
        for episode in episodes:
            if 'fshare.vn' in episode.get('href'):
                linkphim = episode.get('href')
                urls.append(linkphim)
        length = len(episodes)
        done = len(urls)
        progress = int(done * 100 / length)
        dialog = xbmcgui.DialogProgress()
        dialog.create(f'{__addonnoti__} đang giải mã...', f'Đang giải mã {length} dữ liệu...')
        dialog.update(progress, f'Đang giải mã {done}/{length} dữ liệu...')
        for link in urls:
            thread = threading.Thread(target=get_html, args=(link, ))
            thread.start()
            threads.append(thread)
        for t in threads:
            t.join()
        for k in urls:
            x = dulieu[k]
            ten = x[0]
            dungluong = x[1]
            diachi = x[2]
            item = Listitem()
            if 'folder' in diachi:
                item.label = ten
                thumuc = diachi.split('folder/')
                item.info['mediatype'] = 'episode'
                item.info['rating'] = 10.0
                item.info['trailer'] = yttk(item.label)
                item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={link}&qzone=1&margin=1&size=400x400&ecc=L'
                item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
                item.context.script(tfavo, 'Thêm vào Fshare Favorite', diachi)
                item.set_callback(index_fs, thumuc[1], 1)
                yield item
            elif 'file' in diachi:
                item.label = ten
                item.info['size'] = dungluong
                item.info['mediatype'] = 'episode'
                item.info['rating'] = 10.0
                item.info['trailer'] = yttk(item.label)
                item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={link}&qzone=1&margin=1&size=400x400&ecc=L'
                item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
                if __addon__.getSetting("taifshare") == "true":
                    item.context.script(downloadfs, 'Tải về', diachi)
                item.context.script(tfavo, 'Thêm vào Fshare Favorite', diachi)
                item.set_callback(play_fs, diachi, item.label)
                yield item
            dialog.update(100)
            dialog.close()
    else:
        yield quangcao()