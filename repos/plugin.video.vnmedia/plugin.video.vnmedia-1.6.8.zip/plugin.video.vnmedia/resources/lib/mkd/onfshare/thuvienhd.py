from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from resources.lib.kedon import tb, getlink, play_fs, __addonnoti__, __addon__, quangcao, yttk
from resources.lib.mkd.onfshare.ifshare import index_fs, tfavo
from resources.lib.download import downloadfs
import xbmcgui, urllib, re
@Route.register
def search_thuvienhd(plugin,search_query, **kwargs):
	dp = xbmcgui.DialogProgress()
	dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
	dp.update(0)
	search_query = urllib.parse.quote_plus(search_query)
	url = f'https://thuvienhd.com/?s={search_query.replace(" ","+")}'
	resp = getlink(url, url, 43200)
	if resp is not None:
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('div.search-page div.result-item')
		for episode in episodes:
			item = Listitem()
			anh = episode.select('img')
			for poster in anh:
				linkanh = poster.get('src')
				ten = poster.get('alt')
			linkphim = episode.select('div.title a')
			for urlphim in linkphim:
				phim = urlphim.get('href')
			ndp = episode.select('div.contenido')
			for inf in ndp:
				noidung = inf.get_text()
			item.label = ten
			next_page = 2
			item.info['plot'] = noidung
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = yttk(item.label)
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = linkanh
			item.set_callback(thuvienhd_linktk, phim, linkanh, noidung)
			yield item
		if 'next page-numbers' in resp.text:
			yield Listitem.next_page(search_query, 2, callback=search_thuvienhdnext)
	else:
		yield quangcao()
	dp.update(100)
	dp.close()
@Route.register
def search_thuvienhdnext(plugin,search_query, next_page, **kwargs):
	search_query = urllib.parse.quote_plus(search_query)
	url = f'https://thuvienhd.com/page/{next_page}?s={search_query.replace(" ","+")}'
	resp = getlink(url, url, 43200)
	if resp is not None:
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('div.search-page div.result-item')
		for episode in episodes:
			item = Listitem()
			anh = episode.select('img')
			for poster in anh:
				linkanh = poster.get('src')
				ten = poster.get('alt')
			linkphim = episode.select('div.title a')
			for urlphim in linkphim:
				phim = urlphim.get('href')
			ndp = episode.select('div.contenido')
			for inf in ndp:
				noidung = inf.get_text()
			item.label = ten
			item.info['plot'] = noidung
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = yttk(item.label)
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = linkanh
			item.set_callback(thuvienhd_linktk, phim, linkanh, noidung)
			yield item
		if 'next page-numbers' in resp.text:
			item1 = Listitem()
			item1.label = f'Trang {next_page + 1}'
			item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
			item1.set_callback(search_thuvienhdnext, search_query, next_page + 1)
			yield item1
	else:
		yield quangcao()
@Route.register
def thuvienhd_linktk(plugin, url, linkanh, noidung, **kwargs):
	respx = getlink(url, url, 43200)
	if respx is not None:
		soupx = BeautifulSoup(respx.content, 'html.parser')
		episodesx = soupx.select('span.box__download a')
		for episodex in episodesx:
			linkid = episodex.get('href')
			resp = getlink(linkid, linkid, 14400)
			soup = BeautifulSoup(resp.content, 'html.parser')
			episodes = soup.select('tbody.tbody.outer a')
			for episode in episodes:
				link = episode.get('href')
				ten = episode.get('title')
				for dungluong in episode.select('div.face-secondary'):
					item = Listitem()
					if 'folder' in link:
						item.label = f'{ten} {dungluong.get_text().strip()}'
						thumuc = link.split('folder/')
						item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = linkanh
						item.info['plot'] = noidung
						item.info['mediatype'] = 'episode'
						item.info['rating'] = 10.0
						item.info['trailer'] = yttk(item.label)
						item.context.script(tfavo, 'Thêm vào Fshare Favorite', link)
						item.set_callback(index_fs, thumuc[1], 1)
						yield item
					elif 'file' in link:
						item.label = f'{ten} {dungluong.get_text().strip()}'
						item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = linkanh
						item.info['plot'] = noidung
						item.info['mediatype'] = 'episode'
						item.info['rating'] = 10.0
						item.info['trailer'] = yttk(item.label)
						if __addon__.getSetting("taifshare") == "true":
							item.context.script(downloadfs, 'Tải về', link)
						item.context.script(tfavo, 'Thêm vào Fshare Favorite', link)
						item.set_callback(play_fs, link, item.label)
						yield item
	else:
		yield quangcao()
@Route.register
def index_thuvienhd(plugin, **kwargs):
	yield Listitem.search(search_thuvienhd)
	url = 'https://thuvienhd.com/'
	resp = getlink(url, url, 43200)
	if resp is not None:
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('ul.genres.falsescroll li a')
		for episode in episodes:
			item = Listitem()
			if 'thuvienhd.com' in episode.get('href'):
				phim = f'{episode.get("href")}/page/'
				item.label = episode.get_text()
				item.info['plot'] = tb
				next_page = 1
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://thuvienhd.com/wp-content/uploads/2020/10/THUVIENHD.NET_.png'
				item.set_callback(thuvienhd_page, phim, next_page)
				yield item
	else:
		yield quangcao()
@Route.register
def thuvienhd_page(plugin, url, next_page, **kwargs):
	trangtiep = f'{url}{next_page}'
	resp = getlink(trangtiep, trangtiep, 43200)
	if resp is not None:
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('div.items article')
		for episode in episodes:
			item = Listitem()
			idtv = episode.get('id')
			anh = episode.select('img')
			if 'texto' in resp.text:
				noidung = episode.select_one('div.texto').get_text()
			else:
				noidung = tb
			linkanh = episode.select_one('img').get('src')
			ten = episode.select_one('img').get('alt')
			item.label = ten
			item.info['plot'] = noidung
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = yttk(item.label)
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = linkanh
			item.set_callback(thuvienhd_link, idtv, linkanh, noidung)
			yield item
		checkpages = soup.select('div.pagination a')
		for checkpage in checkpages:
			if str(next_page + 1) in checkpage.get_text():
				item1 = Listitem()
				item1.label = f'Trang {next_page + 1}'
				item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
				item1.set_callback(thuvienhd_page, url, next_page + 1)
				yield item1
	else:
		yield quangcao()
@Route.register
def thuvienhd_link(plugin, url, linkanh, noidung, **kwargs):
	tach = url.split('-')
	p = tach[1]
	resp = getlink(f'https://thuvienhd.com/download?id={p}', url, 43200)
	if resp is not None:
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('tbody.tbody.outer a')
		for episode in episodes:
			link = episode.get('href')
			ten = episode.get('title')
			if (ten is not None):
				for dungluong in episode.select('div.face-secondary'):
					item = Listitem()
					if 'folder' in link:
						item.label = f'{ten} {dungluong.get_text().strip()}'
						thumuc = link.split('folder/')
						item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = linkanh
						item.info['plot'] = noidung
						item.info['mediatype'] = 'episode'
						item.info['rating'] = 10.0
						item.info['trailer'] = yttk(item.label)
						item.context.script(tfavo, 'Thêm vào Fshare Favorite', link)
						item.set_callback(index_fs, thumuc[1], 1)
						yield item
					elif 'file' in link:
						item.label = f'{ten} {dungluong.get_text().strip()}'
						item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = linkanh
						item.info['plot'] = noidung
						item.info['mediatype'] = 'episode'
						item.info['rating'] = 10.0
						item.info['trailer'] = yttk(item.label)
						if __addon__.getSetting("taifshare") == "true":
							item.context.script(downloadfs, 'Tải về', link)
						item.context.script(tfavo, 'Thêm vào Fshare Favorite', link)
						item.set_callback(play_fs, link, item.label)
						yield item
	else:
		yield quangcao()