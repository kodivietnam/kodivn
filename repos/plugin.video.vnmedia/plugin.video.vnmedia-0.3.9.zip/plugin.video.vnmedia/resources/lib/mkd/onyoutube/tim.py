from __future__ import unicode_literals
from codequick import Route, Listitem, run
from resources.lib.kedon import getlink, get_kara_input, __addonnoti__
from resources.lib.mkd.onyoutube.video import youtube_tatcavideo, youtube_kenh
import re
import xbmcgui
import urllib
@Route.register
def search_youtube(plugin,search_query):
	dp = xbmcgui.DialogProgress()
	dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
	search_query = urllib.parse.quote_plus(search_query)
	url = 'https://www.youtube.com/results?search_query=' + search_query.replace(' ','+')
	resp = getlink(url, url, 15*60)
	kq = resp.text.replace('\\','')
	if 'videoRenderer' in kq:
		listplay = re.findall(r'videoRenderer(.*?)accessibility', kq)
		for k in listplay:
			item = Listitem()
			tenvd = re.search(r'text":"(.*?)"}', k).group(1)
			idvd = re.search(r'videoId":"(.*?)"', k).group(1)
			anhvd = re.search(r'url":"(.*?)"', k).group(1)
			item.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=' + idvd
			item.label = tenvd
			item.art["thumb"] = anhvd
			item.art["fanart"] = anhvd
			item.set_callback(item.path)
			yield item
	elif 'playlistRenderer' in kq:
		listplay1 = re.findall(r'playlistRenderer(.*?)webPageType', kq)
		for k1 in listplay1:
			item1 = Listitem()
			tenvd1 = re.search(r'"simpleText":"(.*?)"}', k1).group(1)
			idvd1 = re.search(r'webCommandMetadata":{"url":"(.*?)"', k1).group(1)
			anhvd1 = re.search(r'url":"(.*?)"', k1).group(1)
			item1.label = tenvd
			item1.art["thumb"] = anhvd1
			item2.art["fanart"] = anhvd1
			item1.set_callback(youtube_tatcavideo, url+idvd1)
			yield item1
	elif 'channelRenderer' in kq:
		listplay2 = re.findall(r'channelRenderer(.*?)webPageType', kq)
		for k2 in listplay2:
			item2 = Listitem()
			tenvd2 = re.search(r'"simpleText":"(.*?)"}', k2).group(1)
			idvd2 = re.search(r'"url":"(.*?)"', k2).group(1)
			anhvd2 = re.search(r'thumbnails":\[{"url":"(.*?)"', k2).group(1)
			item2.label = tenvd2
			item2.art["thumb"] = 'https:' + anhvd2
			item2.art["fanart"] = 'https:' + anhvd2
			item2.set_callback(youtube_kenh, url+idvd2)
			yield item2

@Route.register
def search_karaoke(plugin,search_query):
	search_query = get_kara_input()
	if not search_query:
		return []
	dp = xbmcgui.DialogProgress()
	dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
	search_query = urllib.parse.quote_plus(search_query)
	url = 'https://www.youtube.com/results?search_query=karaoke+' + search_query.replace(' ','+')
	resp = getlink(url, url, 24*60*60)
	kq = resp.text.replace('\\','')
	listplay = re.findall(r'videoRenderer(.*?)accessibility', kq)
	for k in listplay:
		item = Listitem()
		tenvd = re.search(r'text":"(.*?)"}', k).group(1)
		idvd = re.search(r'videoId":"(.*?)"', k).group(1)
		anhvd = re.search(r'url":"(.*?)"', k).group(1)
		item.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=' + idvd
		item.label = tenvd
		item.art["thumb"] = anhvd
		item.art["fanart"] = anhvd
		item.set_callback(item.path)
		yield item