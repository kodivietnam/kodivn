root = 'root'
menu = {'tinthethao': {
        'route': '/resources/lib/mkd/onthethao/tinthethao:index_tinthethao',
        'label': 'Tin thể thao',
        'thumb': 'https://thethao360.tv/wp-content/uploads/2020/12/logo-3.png',
        'enabled': True,
        'order': 1
        },
        'acest': {
        'route': '/resources/lib/mkd/acest:index_acestream',
        'label': 'Nhóm ACESTREAM',
        'thumb': 'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg',
        'enabled': True,
        'order': 2
        },
        'vebo': {
        'route': '/resources/lib/mkd/onthethao/vebo:index_vebo',
        'label': 'VEBO.TOP',
        'thumb': 'https://vebotv.xyz/static/img/logo.png',
        'enabled': True,
        'order': 3
        },
        'banhkhuc': {
        'route': '/resources/lib/mkd/onthethao/banhkhuc:index_banhkhuc',
        'label': 'BANHKHUC.LIVE',
        'thumb': 'https://banhkhuc.live/bk/static/img/banhkhuctv.png',
        'enabled': True,
        'order': 4
        },
        'xoilacxyz': {
        'route': '/resources/lib/mkd/onthethao/xoilacxyz:index_xoilacxyz',
        'label': 'XOILAC.XYZ',
        'thumb': 'https://xoilac2.xyz/xl/static/img/logo.png',
        'enabled': True,
        'order': 5
        },
        'phut90': {
        'route': '/resources/lib/mkd/onthethao/phut90:index_90p',
        'label': '90PHUT.TV',
        'thumb': 'https://i.imgur.com/jyM3inb.png',
        'enabled': True,
        'order': 6
        },
        'binhluan': {
        'route': '/resources/lib/mkd/onthethao/binhluan:index_binhluan',
        'label': 'BINHLUANTV',
        'thumb': 'https://binhluan.90phut2.live/imgs/logo.png',
        'enabled': True,
        'order': 7
        },
        'cakhia': {
        'route': '/resources/lib/mkd/onthethao/cakhia:index_cakhia',
        'label': 'CAKHIA TV',
        'thumb': 'https://cakhiastatic.fastlycdnlive.xyz/cakhia/cakhia33/user/img/ckstrim.png',
        'enabled': True,
        'order': 8
        },
        'rakhoi': {
        'route': '/resources/lib/mkd/onthethao/rakhoi:index_rakhoi',
        'label': 'RA KHOI TV',
        'thumb': 'https://rakhoi-tv.com/wp-content/uploads/2021/12/rakhoiTVremake.png',
        'enabled': True,
        'order': 9
        },
        'caheo': {
        'route': '/resources/lib/mkd/onthethao/caheo:index_caheo',
        'label': 'CAHEO.TV',
        'thumb': 'https://cakhiastatic.fastlycdnlive.xyz/caheo9/user/img/caheo.png',
        'enabled': True,
        'order': 10
        },
        'phuho': {
        'route': '/resources/lib/mkd/onthethao/phuho:index_phuho',
        'label': 'PHUHO.TV',
        'thumb': 'https://cakhiastatic.fastlycdnlive.xyz/cakhia/phuho7/template/user/img/phuho.png',
        'enabled': True,
        'order': 11
        },
        'saoke': {
        'route': '/resources/lib/mkd/onthethao/saoke:index_saoke',
        'label': 'SAOKE.LIVE',
        'thumb': 'https://9767a59e2b.vws.vegacdn.vn/template/logo1.png',
        'enabled': True,
        'order': 12
        },
        'xembd': {
        'route': '/resources/lib/mkd/onthethao/xembd:index_xembd',
        'label': 'XEMBD.LIVE',
        'thumb': 'https://xembd.org/wp-content/themes/v2.1/assets/images/logo.png',
        'enabled': True,
        'order': 13
        },
        'cakhiaorg': {
        'route': '/resources/lib/mkd/onthethao/cakhiaorg:index_cakhiaorg',
        'label': 'CAKHIA.ORG',
        'thumb': 'https://cakhia.org/wp-content/themes/v2.1/assets/images/logo_cakhia_2.png',
        'enabled': True,
        'order': 14
        },
        'khomuc': {
        'route': '/resources/lib/mkd/onthethao/khomuc:index_khomuc',
        'label': 'KHOMUC.TV',
        'thumb': 'https://khomuc3.com/wp-content/uploads/2021/11/cropped-logo-website-khomuc.jpg',
        'enabled': True,
        'order': 15
        },
        'vebolive': {
        'route': '/resources/lib/mkd/onthethao/vebolive:index_vebolive',
        'label': 'VEBO.LIVE',
        'thumb': 'https://vebo1.net/wp-content/themes/bongda/public/images/logo.png',
        'enabled': True,
        'order': 16
        },
        'tructiepdabong': {
        'route': '/resources/lib/mkd/onthethao/tructiepdabong:index_ttdb',
        'label': 'TRUCTIEPDABONG.NET',
        'thumb': 'https://tructiepdabong.net/themes/frontend/default/img/tructiepdabong.png',
        'enabled': True,
        'order': 17
        },
        'xembong': {
        'route': '/resources/lib/mkd/onthethao/xembong:index_xembong',
        'label': 'XEMBONGDA.NET',
        'thumb': 'https://xembong1.com/themes/frontend/default/img/logo.png',
        'enabled': True,
        'order': 18
        },
        'vaoroi': {
        'route': '/resources/lib/mkd/onthethao/vaoroi:index_vaoroi',
        'label': 'VAOROI.CO',
        'thumb': 'https://vaoroi5.com/themes/frontend/default/img/vaoroi-logo.png',
        'enabled': True,
        'order': 19
        },
        'bongdat': {
        'route': '/resources/lib/mkd/onthethao/bongdat:index_bongdat',
        'label': 'BONGDAT.FUN',
        'thumb': 'https://bongdat.life/themes/frontend/default/img/logo.png',
        'enabled': True,
        'order': 20
        },
        'xoilac7': {
        'route': '/resources/lib/mkd/onthethao/xoilac7:index_xoilac7',
        'label': 'XOILAC7.NET',
        'thumb': 'https://xoilac7.net/wp-content/themes/bongda/dist/images/xoilac7.net.png',
        'enabled': True,
        'order': 21
        },
        'socolive': {
        'route': '/resources/lib/mkd/onthethao/socolive:index_socolive',
        'label': 'SOCOLIVE.ORG',
        'thumb': 'https://sta.cvndnss.com/web/assets/soco/img/logo2.png',
        'enabled': True,
        'order': 22
        },
        'cauthu': {
        'route': '/resources/lib/mkd/onthethao/cauthu:index_cauthu',
        'label': 'CAUTHU.TV',
        'thumb': 'https://cauthu.tv/wp-content/uploads/2022/06/cauthu_tv_logo.png',
        'enabled': True,
        'order': 23
        },
        'phut91': {
        'route': '/resources/lib/mkd/onthethao/phut91:index_91phut',
        'label': '91PHUT.NET',
        'thumb': 'https://91phut.net/wp-content/themes/bongda2/dist/images/91phut.net.png',
        'enabled': True,
        'order': 24
        },
        'segay': {
        'route': '/resources/lib/mkd/onthethao/segay:index_segay',
        'label': 'SEGAY.TV',
        'thumb': 'https://segay.tv/wp-content/themes/v2.1/assets/images/logo_sg_3.png',
        'enabled': True,
        'order': 25
        },
        'xoilac3': {
        'route': '/resources/lib/mkd/onthethao/xoilac3:index_xoilac3',
        'label': 'XOILAC3.LIVE',
        'thumb': 'https://xoilac3.live/wp-content/uploads/2022/06/logo-xoilac-tv-1.jpg',
        'enabled': True,
        'order': 26
        }
            }