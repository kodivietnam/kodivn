from codequick import Resolver, Listitem, Script
from urllib.parse import urlparse, quote, urlencode
from requests import Session
from bs4 import BeautifulSoup
from collections import OrderedDict
from urllib3 import PoolManager
from urlquick import get, post
from html import unescape
from xbmc import executebuiltin
from xbmcaddon import Addon
from xbmcvfs import translatePath
from cloudscraper import create_scraper
from xbmcgui import Dialog
from inputstreamhelper import Helper
from os import remove, makedirs
from os.path import join, exists, getmtime
from base64 import b64encode
from json import loads, dumps
from random import randint
from functools import lru_cache
import re, sys
__addonname__ = Addon().getAddonInfo('name')
__version__ = Addon().getAddonInfo('version')
__icon__ = Addon().getAddonInfo('icon')
__addonnoti__ = f'{__addonname__} v{__version__}'
ADDON_ID = Addon().getAddonInfo('id')
mota = Addon().getAddonInfo("disclaimer")
addon_data_dir = f"{translatePath('special://userdata/addon_data')}{ADDON_ID}"
useragent = 'okhttp/4.10.0'
useragentott = 'OTT Navigator/1.6.7.7 (Linux;Android 13) ExoPlayerLib/2.15.1'
useragentvmf = 'Vietmediaf /Kodi1.1.99-092019'
code = f'User-Agent={useragentott}'
tb = f'[COLOR blue]{mota}[/COLOR]'
@lru_cache(maxsize=None)
def ran(a,b,c):
	return f'{randint(a, b):<0{c}}'
useragentdf = f'Dalvik/2.1.0 (Linux; U; Android 13; Pixel 7 Pro Build/TQ2A.23{ran(3,12,2)}05.0{ran(3,12,2)})'
useragentweb = f'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36 Edg/112.0.1722.{ran(40,99,2)}'
@lru_cache(maxsize=None)
def ace(kenh, tenkenh):
	if 'acestream' in kenh:
		tach = kenh.split('//')
		p = tach[1]
	elif ':6878' in kenh:
		p = re.search(r'id=(.*?)&', kenh)[1] if '&' in kenh else kenh.split('id=')[1]
	kenhace = ''.join(("{'label': '", tenkenh.strip(),"', 'action': 'play', 'fanart': '', 'icon': '', 'id': '", p.strip(), "'}"))
	return f"plugin://script.module.horus/?{quote(b64encode(kenhace.encode('utf-8')).decode('utf-8'))}"
def getlink(url, ref, luu):
	try:
		r = get(url, timeout=5, max_age=luu, headers={'user-agent': useragentdf,'referer': ref.encode('utf-8')})
		if ('Cloudflare' in r.text) or ('CloudFront' in r.text):
			scraper = create_scraper(delay=10, disableCloudflareV1=True, browser={'browser':'firefox','platform':'windows','mobile':False})
			rcf = scraper.get(url,headers={'Referer': url})
			rcf.encoding = 'utf-8'
			return rcf
		else:
			r.encoding = 'utf-8'
			return r
	except:
		try:
			r = get(f'http://mi3s.top/web?trang={quote(url)}', max_age=luu, timeout=15)
			r.encoding = 'utf-8'
			return r
		except:
			pass
def getlinkvnm(url, ref):
	try:
		with Session() as s:
			r = s.get(url, timeout=5, headers={'user-agent': useragentdf,'referer': ref.encode('utf-8')})
			if ('Cloudflare' in r.text) or ('CloudFront' in r.text):
				scraper = create_scraper(delay=10, disableCloudflareV1=True, browser={'browser':'firefox','platform':'windows','mobile':False})
				rcf = scraper.get(url,headers={'Referer': url})
				rcf.encoding = 'utf-8'
				return rcf
			else:
				r.encoding = 'utf-8'
				return r
	except:
		try:
			with Session() as s:
				r = get(f'http://mi3s.top/web?trang={quote(url)}', timeout=15)
				r.encoding = 'utf-8'
				return r
		except:
			pass
def getlinkip(url, ref):
	try:
		return PoolManager(timeout=5.0).request('GET', url, headers={'user-agent': useragent,'accept-encoding':'gzip'})
	except:
		try:
			return PoolManager(timeout=15.0).request('GET', f'http://mi3s.top/web?trang={quote(url)}', headers={'user-agent': useragent,'accept-encoding':'gzip'})
		except:
			pass
def getlinkweb(url, ref, luu):
	try:
		r = get(url, timeout=5, max_age=luu, headers={'sec-fetch-site': 'same-origin','user-agent': useragentweb,'referer': ref.encode('utf-8')})
		if ('Cloudflare' in r.text) or ('CloudFront' in r.text):
			scraper = create_scraper(delay=10, disableCloudflareV1=True, browser={'browser':'firefox','platform':'windows','mobile':False})
			rcf = scraper.get(url,headers={'Referer': url})
			rcf.encoding = 'utf-8'
			return rcf
		else:
			r.encoding = 'utf-8'
			return r
	except:
		try:
			r = get(f'http://mi3s.top/web?trang={quote(url)}', max_age=luu, timeout=15)
			r.encoding = 'utf-8'
			return r
		except:
			pass
def getlinkphongblack(urlvmf, ref, luu):
	try:
		r = get(urlvmf, timeout=15, max_age=luu, headers={'user-agent': f'{useragentweb} VietMedia/1.0','referer': ref.encode('utf-8')})
		r.encoding = 'utf-8'
		return r
	except:
		pass
def postlinktimfs(url, ref, luu):
	try:
		r = post(url, timeout=15, max_age=luu, headers={'user-agent': useragentdf, 'referer': ref.encode('utf-8'), 'authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJuYW1lIjoiZnNoYXJlIiwidXVpZCI6IjcxZjU1NjFkMTUiLCJ0eXBlIjoicGFydG5lciIsImV4cGlyZXMiOjAsImV4cGlyZSI6MH0.WBWRKbFf7nJ7gDn1rOgENh1_doPc07MNsKwiKCJg40U'})
		r.encoding = 'utf-8'
		return r
	except:
		pass
@lru_cache(maxsize=None)
def fu(url):
	try:
		return Session().get(url).url
	except:
		return Session().get(f'http://thunghiem.x10.mx/final.php?trang={quote(url)}').text
@lru_cache(maxsize=None)
def stream(url):
	c = re.sub(r'\s+', '%20', url, flags=re.UNICODE)
	return f'{c}&{code}' if '|' in url else f'{c}|{code}'
@lru_cache(maxsize=None)
def streamiptv(url, user):
	b = f'User-Agent={user.strip()}'
	c = re.sub(r'\s+', '%20', url, flags=re.UNICODE)
	return f'{c}&{b}' if '|' in url else f'{c}|{b}'
@lru_cache(maxsize=None)
def referer(url):
	a = urlparse(url.strip())
	return f'&Origin={a.scheme}://{a.netloc}&verifypeer=false&Referer={a.scheme}://{a.netloc}/'
def replace_all(dict, str):
	pattern = re.compile('|'.join(re.escape(key) for key in dict.keys()))
	return pattern.sub(lambda match: dict[match.group()], str)
def ttfs(x):
	with Session() as s:
		idfd = re.search(r'(file|folder)/([A-Z0-9]+)', x)[2]
		return s.get(f'http://fshare.vn/api/v3/files/folder?linkcode={idfd}', headers={'user-agent':useragentdf,'origin': 'https://www.fshare.vn','referer':'https://www.fshare.vn/'}, timeout=15)
@lru_cache(maxsize=None)
def get_info_fs(x):
	r = ttfs(x)
	if 'current' in r.text:
		l = r.json()['current']
		return (l['name'], l['size'])
	else:
		return ('Dữ liệu này bị hỏng...', 0)
def userpassfs():
	if (username := Addon().getSetting('username')) and (password := Addon().getSetting('password')):
		payload = f'{{"app_key":"L2S7R6ZMagggC5wWkQhX2+aDi467PPuftWUMRFSn","user_email":"{username}","password":"{password}"}}'
		head = {'cache-control': 'no-cache', 'User-Agent': useragentvmf}
		try:
			r = post('https://api.fshare.vn/api/user/login', data=payload, headers=head, timeout=15, max_age=18000).json()
			return (r['token'], r['session_id'])
		except:
			Dialog().ok(f'{__addonnoti__} - LỖI ĐĂNG NHẬP', 'Sau 3 lần đăng nhập không thành công, tài khoản sẽ bị khoá 10 phút\nKiểm tra lại tài khoản, mật khẩu, đường truyền Internet...')
			if exists(get_file_path('.urlquick.slite3')):
				remove(get_file_path('.urlquick.slite3'))
			sys.exit()
	else:
		Dialog().ok(__addonnoti__, 'Vui lòng nhập tài khoản đăng nhập Fshare trong cài đặt của VN Media')
		sys.exit()
def getfs(x):
	test = checkfs(x)
	if (test is not None):
		if 'Không tìm thấy' in test.text:
			Script.notify(__addonnoti__, 'Tập tin không tồn tại')
			sys.exit()
		else:
			payload = {'token': userpassfs()[0], 'url': x}
			headerfsvn = {'User-Agent': useragentvmf, 'Cookie' : f'session_id={userpassfs()[1]}'}
			return post('https://api.fshare.vn/api/session/download', timeout=15, json=payload, headers=headerfsvn).json()['location']
	else:
		Script.notify(__addonnoti__, 'Không kết nối được với Fshare')
		sys.exit()
@lru_cache(maxsize=None)
def checkfs(x):
	return getlinkvnm(x, x)
def getrow(row):
	return row['v'] if (row is not None) and (row['v'] is not None) else ''
@lru_cache(maxsize=None)
def qc():
	r = checkfs('http://youtube.com/@vtcnow')
	if r is not None:
		if 'channelFeaturedVideoRenderer' in r.text:
			match = re.search(r'channelFeaturedVideoRenderer\\x22:\\x7b\\x22videoId\\x22:\\x22(.*?)\\', r.text)[1]
		elif 'videoId":"' in r.text:
			match = re.search(r'videoId":"(.*?)"', r.text)[1]
		else:
			match = re.search(r'videoId\\x22:\\x22(.*?)\\', r.text)[1]
		return f'plugin://plugin.video.youtube/play/?video_id={match}'
	else:
		return sys.exit()
@lru_cache(maxsize=None)
def quangcao():
	item = Listitem()
	linkmacdinh = qc()
	item.label = 'Đang cập nhật'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/updating.png'
	item.set_callback(linkmacdinh)
	return item
@lru_cache(maxsize=None)
def ggdich(tk):
	with Session() as s:
		return s.get(f'https://translate.googleapis.com/translate_a/single?ie=UTF-8&oe=UTF-8&client=gtx&sl=en&tl=vi&dt=t&q={tk}', headers={'Referer':'https://translate.google.com/','User-Agent':useragentweb,'Cookie':''}, timeout=15).json()[0][0][0]
@lru_cache(maxsize=None)
def tiengruoi():
	url = 'http://bit.ly/tiengruoi'
	r = getlink(url, url, 1000)
	if (r is not None):
		return [item.get('href') for item in BeautifulSoup(r.content, 'html.parser').select('div.cl_item a')]
	else:
		return
@lru_cache(maxsize=None)
def rakhoi():
	url = 'http://cakhia20.link/'
	r = getlink(url, url, 1000)
	if (r is not None):
		return [item.get('href') for item in BeautifulSoup(r.content, 'html.parser').select('div.layout-4columns a')]
	else:
		return
@lru_cache(maxsize=None)
def cakhia():
	url = 'http://cakhia30.link/'
	r = getlink(url, url, 1000)
	if (r is not None):
		return [item.get('href') for item in BeautifulSoup(r.content, 'html.parser').select('div.layout-4columns a')]
	else:
		return
@lru_cache(maxsize=None)
def caheo():
	url = 'http://caheo10.link/'
	r = getlink(url, url, 1000)
	if (r is not None):
		return [item.get('href') for item in BeautifulSoup(r.content, 'html.parser').select('div.layout-4columns a')]
	else:
		return
@lru_cache(maxsize=None)
def cauthu():
	url = 'http://cauthu.link/'
	r = getlink(url, url, 1000)
	if (r is not None):
		return [item.get('href') for item in BeautifulSoup(r.content, 'html.parser').select('div.layout-4columns a')]
	else:
		return
@lru_cache(maxsize=None)
def saoke():
	url = 'http://saoke6.link/'
	r = getlink(url, url, 1000)
	if (r is not None):
		return [item.get('href') for item in BeautifulSoup(r.content, 'html.parser').select('ul.list a')]
	else:
		return
@lru_cache(maxsize=None)
def mannhan():
	url = 'http://mannhan.net/'
	r = getlink(url, url, 1000)
	if (r is not None):
		return [item.get('href') for item in BeautifulSoup(r.content, 'html.parser').select('ul.list a')]
	else:
		return
@lru_cache(maxsize=None)
def khomuc():
	url = 'http://khomuc2.com/'
	r = getlink(url, url, 1000)
	if (r is not None):
		return [item.get('href') for item in BeautifulSoup(r.content, 'html.parser').select('ul.list a')]
	else:
		return
@lru_cache(maxsize=None)
def yttk(tk):
	tim = re.sub(r"[\W_]+"," ", tk)
	return f'plugin://plugin.video.vnmedia/resources/lib/mkd/onyoutube/tim/trailer_youtube/?search_query={tim}'
def get_file_path(filename):
	return join(addon_data_dir, filename)
def has_file_path(filename):
	return exists(get_file_path(filename))
def get_last_modified_time_file(filename):
	return int(getmtime(get_file_path(filename)))
def remove_file(filename):
	if has_file_path(filename):
		remove(get_file_path(filename))
def write_file(name, content, binary=False):
	if not exists(addon_data_dir):
		makedirs(addon_data_dir)
	path = get_file_path(name)
	try:
		write_mode = 'wb+' if binary else 'w+'
		f = open(path, mode=write_mode)
		f.write(content)
		f.close()
	except:
		pass
	return path
def read_file(name, binary=False):
	content = None
	read_mode = 'rb' if binary else 'r'
	try:
		path = get_file_path(name)
		f = open(path, mode=read_mode)
		content = f.read()
		f.close()
	except:
		pass
	return content
def search_history_save(search_key):
	if not search_key:
		return
	content = read_file('historys.json')
	content = loads(content) if content else []
	idx = next((content.index(i) for i in content if search_key == i), -1)
	if (idx >= 0) and (len(content) > 0):
		del content[idx]
	elif len(content) >= 20:
		content.pop()
	content.insert(0, search_key)
	write_file('historys.json', dumps(content))
def search_history_clear():
	write_file('historys.json', dumps([]))
def search_history_get():
	content = read_file('historys.json')
	content = loads(content) if content else []
	return content
def save_last_watch_movie(data):
	if not data:
		return
	content = read_file('watcheds.json')
	content = loads(content, object_pairs_hook=OrderedDict) if content else OrderedDict()
	cache_id, query = data
	content.update({cache_id: query})
	content.move_to_end(cache_id, last=False)
	write_file('watcheds.json', dumps(content))
def get_last_watch_movie():
	content = read_file('watcheds.json')
	content = loads(content) if content else {}
	return content
@Script.register
def search_history_clear(plugin, **kwargs):
	write_file('historys.json', dumps([]))
	executebuiltin('Container.Refresh()')
@Script.register
def clear_last_watch_movie(plugin, **kwargs):
	write_file('watcheds.json', '')
	executebuiltin('Container.Refresh()')
@Resolver.register
def play_vnm(plugin,url,title,drmKey, **kwargs):
	news = 'http://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/qc.ass'
	if drmKey:
		is_helper = Helper('mpd','com.widevine.alpha')
		if is_helper.check_inputstream():
			return Listitem().from_dict(**{'label': title,'subtitles':{news},'callback':url,'properties':{'inputstream':is_helper.inputstream_addon,'inputstream.adaptive.manifest_type':'mpd','inputstream.adaptive.license_type':'com.widevine.alpha','inputstream.adaptive.license_key':f'{drmKey}|origin={url}&{code}&referer={url}|R{{SSM}}|'}})
	elif '.m3u8' in url:
		if '|' in url:
			d = url.split('|')
			return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':d[0],'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream.adaptive.manifest_headers': d[1],'inputstream.adaptive.stream_headers': d[1],'inputstream':'inputstream.adaptive'}})
		else:
			return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':url,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream.adaptive.manifest_headers': code,'inputstream.adaptive.stream_headers': code,'inputstream':'inputstream.adaptive'}})
	else:
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':url})
@Resolver.register
def ifr_xembong(plugin,url,title, **kwargs):
	news = 'http://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/qc.ass'
	r = getlinkvnm(url, url)
	if (r is not None) ('.m3u8' in r.text):
		match = re.search(r'linkStream = \'(.*?)\'', r.text)
		d = f'{stream(match[1])}{referer(url)}'.split('|')
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':d[0],'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream.adaptive.manifest_headers': d[1],'inputstream.adaptive.stream_headers': d[1],'inputstream':'inputstream.adaptive'}})
	else:
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':qc()})
@Resolver.register
def ifr_bongda(plugin,url,title, **kwargs):
	news = 'http://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/qc.ass'
	resp = getlink(url,url, 600)
	if (resp is not None) and ('allowfullscreen' in resp.text):
		m = urlparse(url)
		linkweb = f'{m.scheme}://{m.netloc}'
		soup = BeautifulSoup(resp.content, 'html.parser')
		ifr = soup.select_one('iframe[allowfullscreen]').get('src')
		ifr = ifr if 'http' in ifr else f'{linkweb}{ifr}'
		r = getlink(ifr, url, 600)
		if (r is not None) and ('.m3u8' in r.text):
			linkstream = re.search(r'(https?://[^\s"]+\.m3u8[^"\']*)', r.text)[1]
			d = getlink(linkstream, linkstream, 600)
			a = re.search(r'(https?://[^\s"]+\.m3u8[^"\']*)', d.text)[1] if (d is not None) and ('.m3u8' in d.text) and ('http' in d.text) else linkstream
			linkplay = f'{stream(a)}{referer(ifr)}'
			if '.m3u8' in linkplay:
				if '|' in linkplay:
					d = linkplay.split('|')
					return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':d[0],'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream.adaptive.manifest_headers': d[1],'inputstream.adaptive.stream_headers': d[1],'inputstream':'inputstream.adaptive'}})
				else:
					return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream.adaptive.manifest_headers': code,'inputstream.adaptive.stream_headers': code,'inputstream':'inputstream.adaptive'}})
			else:
				return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay})
		else:
			return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':qc()})
	else:
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':qc()})
@Resolver.register
def ifr_xoilacme(plugin,url,title, **kwargs):
	news = 'http://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/qc.ass'
	r = getlinkvnm(url, url)
	if (r is not None) and ('.m3u8' in r.text):
		match = re.search(r'let mideoUrl = "(.*?)"', r.text)
		d = f'{stream(match[1].replace("&amp;", "&"))}{referer(url)}'.split('|')
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':d[0],'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream.adaptive.manifest_headers': d[1],'inputstream.adaptive.stream_headers': d[1],'inputstream':'inputstream.adaptive'}})
	else:
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':qc()})
@Resolver.register
def play_fs(plugin,url,title, **kwargs):
	news = 'http://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/qc.ass'
	if Addon().getSetting('block_play_fs') == 'true':
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':qc()})
	else:
		save_last_watch_movie((title, url))
		try:
			return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':getfs(url)})
		except:
			sys.exit()
@Resolver.register
def playsocolive(plugin, numroom, timestamp, linkref, title, **kwargs):
	news = 'http://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/qc.ass'
	url = f'http://json.vnres.co/room/{numroom}/detail.json?v={timestamp}'
	r = getlinkvnm(url, url)
	if r is not None:
		nd = re.search(r'(\{.*\})', r.text, re.DOTALL)[1]
		d = f"{stream(loads(nd)['data']['stream']['hdM3u8'])}{referer(linkref)}".split('|')
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':d[0],'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream.adaptive.manifest_headers': d[1],'inputstream.adaptive.stream_headers': d[1],'inputstream':'inputstream.adaptive'}})
	else:
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':qc()})
@Resolver.register
def ifr_khomuc(plugin,url,title, **kwargs):
	news = 'http://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/qc.ass'
	r = getlinkweb(url, url, 600)
	if (r is not None) and ('.m3u8' in r.text):
		match = re.search(r'(https?://[^\s"]+\.m3u8[^"\']*)', text)
		d = f'{stream(match[1])}{referer(url)}'.split('|')
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':d[0],'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream.adaptive.manifest_headers': d[1],'inputstream.adaptive.stream_headers': d[1],'inputstream':'inputstream.adaptive'}})
	else:
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':qc()})
@Resolver.register
def play_vk(plugin, idvd1, idvd2, title, **kwargs):
	news = 'http://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/qc.ass'
	url = 'https://vk.com/al_video.php?act=show'
	data={'act': 'show', 'al': '1', 'claim': '', 'dmcah': '', 'hd': '', 'list': f'pl_{idvd1}_1', 'module': 'direct', 'playlist_id': f'{idvd1}_-2', 'show_original': '', 't': '', 'video': f'{idvd1}_{idvd2}'}
	headers={'content-type': 'application/x-www-form-urlencoded', 'Referer': 'http://vk.com', 'User-Agent':useragentweb, 'x-requested-with': 'XMLHttpRequest'}
	r = post(url, headers=headers, data=data)
	if (r is not None):
		if 'hls_ondemand' in r.text:
			linkget = re.search(r'hls_ondemand":"(.*?)"', r.text)[1]
			d = unescape(linkget).replace('\\/', '/')
			d = f'{stream(d)}{referer("https://vk.com/")}'.split('|')
			return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':d[0],'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream.adaptive.manifest_headers': d[1],'inputstream.adaptive.stream_headers': d[1],'inputstream':'inputstream.adaptive'}})
		elif 'hls' in r.text:
			linkget = re.search(r'hls":"(.*?)"', r.text)[1]
			done = unescape(linkget).replace("\\/", "/")
			d = f'{stream(done)}{referer("https://vk.com/")}'.split('|')
			return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':d[0],'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream.adaptive.manifest_headers': d[1],'inputstream.adaptive.stream_headers': d[1],'inputstream':'inputstream.adaptive'}})
		else:
			return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':qc()})
	else:
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':qc()})
@Resolver.register
def play_vtvgo(plugin, timekenh, tokenkenh, idkenh, x, title, **kwargs):
	news = 'http://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/qc.ass'
	payload = {'type_id': '1','id': idkenh,'time': timekenh,'token': tokenkenh}
	headx = {'user-agent': useragentweb,
	'x-requested-with': 'XMLHttpRequest',
	'referer': f'https://vtvgo.vn/xem-truc-tuyen-kenh-vtv-{idkenh}.html',
	'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
	'sec-fetch-site': 'same-origin'}
	p = post('https://vtvgo.vn/ajax-get-stream', data=urlencode(payload, quote_via=quote), cookies=x, headers=headx)
	if '.m3u8' in p.text:
		d = f'{stream(p.json()["chromecast_url"])}{referer("https://vtvgo.vn")}'.split('|')
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':d[0],'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream.adaptive.manifest_headers': d[1],'inputstream.adaptive.stream_headers': d[1],'inputstream':'inputstream.adaptive'}})
	else:
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':qc()})
@Resolver.register
def play_bm(plugin,url,title, **kwargs):
	news = 'http://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/qc.ass'
	r = getlinkvnm(url, url)
	if (r is not None) and ('streamingUrl' in r.text):
		match = re.search(r'streamingUrl":"(.*?)"}', r.text)
		linkplay = f'{stream(match[1])}{referer(url)}'
		if '.m3u8' in linkplay:
			if '|' in linkplay:
				d = linkplay.split('|')
				return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':d[0],'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream.adaptive.manifest_headers': d[1],'inputstream.adaptive.stream_headers': d[1],'inputstream':'inputstream.adaptive'}})
			else:
				return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':url,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream.adaptive.manifest_headers': code,'inputstream.adaptive.stream_headers': code,'inputstream':'inputstream.adaptive'}})
		else:
			return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay})
	else:
		Script.notify(__addonnoti__, 'Chưa có dữ liệu')
		sys.exit()