from codequick import Route, Listitem, run
from resources.lib.qrplay import qrplay
from resources.lib.mkd.onfshare.codenumber import index_number
from resources.lib.mkd.onfshare.ifshare import fs_favorite, fs_topfollow, index_daxem
from resources.lib.mkd.onfshare.thuvienhd import index_thuvienhd
from resources.lib.mkd.onfshare.timfshare import searchfs, index_pdx
from resources.lib.mkd.onfshare.thuviencine import index_thuviencine
from resources.lib.mkd.onfshare.hdvn import index_hdvn
from resources.lib.mkd.onfshare.gcs import index_gcs
@Route.register
def index_fshare(plugin, **kwargs):
	yield Listitem.search(searchfs)
	yield Listitem.from_dict(**{'label': 'LỊCH SỬ XEM',
	'info': {'plot': 'Nội dung được xem gần nhất'},
	'art': {'thumb': 'https://apkmodo.net/wp-content/uploads/2022/01/WATCHED-APK.jpg',
	'fanart': 'https://fsharetv.com/img/fsharetv.png'},
	'callback': index_daxem})
	yield makeQrPlayItem()
	yield Listitem.from_dict(**{'label': 'NHẬP CODEPLAY',
	'info': {'plot': 'Nhập MÃ CODE để phát phim'},
	'art': {'thumb': 'https://www.codester.com/static/uploads/items/000/021/21651/preview-xl.jpg',
	'fanart': 'https://fsharetv.com/img/fsharetv.png'},
	'callback': index_number})
	yield Listitem.from_dict(**{'label': 'Fshare Favourite',
	'info':{'plot':'Yêu thích'},
	'art':{'thumb':'https://previews.123rf.com/images/faysalfarhan/faysalfarhan1605/faysalfarhan160502678/56752107-favourite-heart-icon-pink-glossy-round-button.jpg',
	'fanart':'https://fsharetv.com/img/fsharetv.png'},
	'callback':fs_favorite})
	yield Listitem.from_dict(**{'label': 'TOP FSHARE',
	'info':{'plot':'Top 15 thư mục theo dõi nhiều nhất'},
	'art':{'thumb':'https://www.fshare.vn/images/top-follow/title.png',
	'fanart':'https://fsharetv.com/img/fsharetv.png'},
	'callback':fs_topfollow})
	yield Listitem.from_dict(**{'label': 'Xem gì hôm nay',
	'info': {'plot': 'Phim đề xuất'},
	'art': {'thumb': 'https://i.pinimg.com/736x/86/5d/2d/865d2df95b76d5a7655c8e33b18913a1.jpg',
	'fanart': 'https://fsharetv.com/img/fsharetv.png'},
	'callback': index_pdx})
	yield makeNewestItem()
	yield Listitem.from_dict(**{'label': 'Góc Chia Sẻ',
	'info': {'plot': 'Nội dung được chia sẻ từ Hội mê phim'},
	'art': {'thumb': 'https://itseovn.com/data/avatars/l/51/51797.jpg',
	'fanart': 'https://fsharetv.com/img/fsharetv.png'},
	'callback': index_gcs})
	yield Listitem.from_dict(**{'label': 'HdVietNam',
	'info':{'plot':'Thư viện dữ liệu phim Fshare'},
	'art':{'thumb':'https://hdvietnam.xyz/images/hd-vietnam-logo.png',
	'fanart':'https://fsharetv.com/img/fsharetv.png'},
	'callback':index_hdvn})
	yield Listitem.from_dict(**{'label': 'Thư viện HD',
	'info':{'plot':'Thư viện dữ liệu phim Fshare'},
	'art':{'thumb':'https://thuvienhd.com/wp-content/uploads/2020/10/THUVIENHD.NET_.png',
	'fanart':'https://fsharetv.com/img/fsharetv.png'},
	'callback':index_thuvienhd})
	yield Listitem.from_dict(**{'label': 'Thư viện Cine',
	'info':{'plot':'Thư viện dữ liệu phim Fshare'},
	'art':{'thumb':'https://thuviencine.com/wp-content/uploads/2021/09/logo-red.png',
	'fanart':'https://fsharetv.com/img/fsharetv.png'},
	'callback':index_thuviencine})
def makeQrPlayItem():
	item = Listitem()
	item.label = 'Mobile Play'
	item.info['plot'] = 'Dùng điện thoại để nhập link Fshare hoặc nhập từ khóa tìm kiếm thuận tiện'
	item.path = qrplay
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://banner2.cleanpng.com/20180303/leq/kisspng-template-download-mobile-phone-qr-code-vector-creative-hand-phone-5a9aa86bd143f0.9505955915200850998572.jpg'
	item.set_callback(qrplay)
	return item
def makeNewestItem():
	item = Listitem()
	item.label = 'Phim mới đặc sắc'
	item.info['plot'] = 'Nội dung mới nhất được chia sẻ từ hội mê phim'
	item.art['thumb'] = 'https://itseovn.com/data/avatars/l/51/51797.jpg'
	item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
	item.set_callback(index_gcs, 'NewestURL')
	return item