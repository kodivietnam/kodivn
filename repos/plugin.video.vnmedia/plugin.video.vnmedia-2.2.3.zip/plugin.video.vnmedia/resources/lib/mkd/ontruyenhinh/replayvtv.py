from codequick import Route, Listitem, run
from resources.lib.mkd.ontruyenhinh.replaythvl import get_thvl, get_vtv, get_vtvvt
from datetime import date, timedelta
@Route.register
def index_vtv(plugin, **kwargs):
	item = Listitem()
	item.label = 'Hôm nay'
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
	item.set_callback(list_vtv, date.today(), item.label, date.today())
	item1 = Listitem()
	item1.label = 'Hôm qua'
	item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
	item1.set_callback(list_vtv, date.today() - timedelta(days = 1), item1.label, date.today() - timedelta(days = 1))
	item2 = Listitem()
	item2.label = 'Hôm kia'
	item2.art['thumb'] = item2.art['landscape'] = item2.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
	item2.set_callback(list_vtv, date.today() - timedelta(days = 2), item2.label, date.today() - timedelta(days = 2))
	yield item
	yield item1
	yield item2
@Route.register
def list_vtv(plugin, tg, ngay, hom, **kwargs):
	kenhidvt = {
	'VTV2': '3',
	'VTV3': '4',
	'VTV5': '110',
	'VTV Cần Thơ': '98'}
	kenhid = {
	'VTV1': '2',
	'VTV4': '108',
	'VTV7': '6',
	'VTV8': '115',
	'VTV9': '8',
	'VTC1': '16',
	'VTC7': '201',
	'HTV7': '193',
	'HTV9': '194',
	'ANTV': '20',
	'QPVN': '19',
	'Quoc Hoi': '290'}
	kenhidx = {
	'THVL1': 'thvl1',
	'THVL2': 'thvl2',
	'THVL3': 'thvl3',
	'THVL4': 'thvl4'}
	for m in kenhidvt:
		item = Listitem()
		item.label = m
		item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
		item.set_callback(get_vtvvt, kenhidvt[m], hom)
		yield item
	for k in kenhid:
		item = Listitem()
		item.label = k
		item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
		item.set_callback(get_vtv, kenhid[k], hom)
		yield item
	for l in kenhidx:
		item1 = Listitem()
		item1.label = l
		item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
		item1.set_callback(get_thvl, kenhidx[l], hom)
		yield item1