from codequick import Route, Listitem, Resolver
from resources.lib.kedon import getlinkvnm, getlink, replace_all, tb, stream, referer, quangcao
from datetime import datetime
from json import loads
from bs4 import BeautifulSoup
from functools import lru_cache
import re, sys
@lru_cache(maxsize=None)
def saoke():
	url = 'http://mannhan.net'
	r = getlinkvnm(url, url)
	try:
		return BeautifulSoup(r.content, 'html.parser').select_one('main a[target="_blank"]').get('href')
	except:
		sys.exit()
@Route.register
def index_saoke(plugin, **kwargs):
	url = saoke()
	resp = getlink(url, url, 400)
	if (resp is not None) and ('.m3u8' in resp.text):
		hostsPlayer = re.search(r'hostsPlayer:\["(.*?)"', resp.text)
		if hostsPlayer:
			refplay = f'https://{hostsPlayer[1]}'
		else:
			refplay = url
		ll = re.search(r'(?<=,lives=)(.*?)(?=<)', resp.text)[1]
		nd = re.sub(r'([{,:])(\w+)([},:])', r'\1"\2"\3',ll)
		thaythe = {
			"'[":"[",
			"]'":"]"
			}
		m = loads(replace_all(thaythe, nd))
		for k1 in m:
			tg = datetime.fromtimestamp(int(k1['time'])/1000).strftime('%H:%M %d-%m')
			for k2 in k1['hlsUrls']:
				if k2['url']:
					item1 = Listitem()
					item1.info['plot'] = tb
					item1.art['thumb'] = item1.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/saoke.png'
					ten1 = k1['title'].split(':')[1].strip()
					if k1['blv']:
						item1.label = f'{tg} {k2["name"]}: {ten1} - BLV: {k1["blv"]}'
					else:
						item1.label = f'{tg} {k2["name"]}: {ten1}'
					item1.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), f'{stream(k2["url"])}{referer(refplay)}', item1.label, '')
					yield item1
				else:
					yield []
			if 'hlsUrlsManNhan' in k1:
				for b2 in k1['hlsUrlsManNhan']:
					if b2['url']:
						item2 = Listitem()
						item2.info['plot'] = tb
						item2.art['thumb'] = item2.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/mannhan.png'
						ten2 = k1['titleManNhan'].split(':')[1].strip()
						tentrandau2 = f'{tg} {b2["name"]}: {ten2}'
						if k1['blvManNhan']:
							item2.label = f'{tentrandau2} - BLV: {k1["blvManNhan"]}'
						else:
							item2.label = tentrandau2
						item2.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), f'{stream(b2["url"])}{referer(refplay)}', item2.label, '')
						yield item2
					else:
						yield []
	else:
		yield quangcao()