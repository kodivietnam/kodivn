from codequick import Route, Listitem, Resolver
from importlib import import_module
from datetime import datetime
from functools import lru_cache
from requests import Session
@Route.register
def get_thvl(plugin, ten, hom, **kwargs):
	w = import_module('resources.lib.kedon')
	idk_dict = {'thvl1': 'aab94d1f-44e1-4992-8633-6d46da08db42',
		'thvl2': 'bc60bddb-99ac-416e-be26-eb4d0852f5cc',
		'thvl3': 'f2ad2726-d315-4612-b78d-746721788fc8',
		'thvl4': '442692d6-c296-4835-b060-72c4cd235bd2'}
	idk = idk_dict.get(ten, None)
	url = f'http://api.thvli.vn/backend/cm/epg/?channel_id={idk}&platform=web&schedule_date={hom}'
	resp = w.getlinkvnm(url, url)
	if (resp is not None) and ('items' in resp.text):
		for k in resp.json()['items']:
			if '.m3u8' in str(k['link_play']):
				item = Listitem()
				tg = datetime.fromtimestamp(k['start_at']).strftime('%H:%M')
				item.label = f'{tg} {hom}: {k["title"]}'
				linkplay = w.stream(str(k['link_play']))
				item.art['thumb'] = item.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
				item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), linkplay, item.label, '')
				yield item
	else:
		yield w.quangcao()
@Route.register
def get_vtv(plugin, ten, hom, **kwargs):
	w = import_module('resources.lib.kedon')
	idk_dict = {'2': 'vtv1hd_1500',
		'108': 'vtv4_1500',
		'6': 'vtv7hd_1500',
		'115': 'vtv8hd_1500',
		'8': 'vtv9_1500',
		'16': 'vtc1_1500',
		'17': 'vtc14_1500',
		'98': 'vtvcantho_1500',
		'201': 'todaytv_1000',
		'18': 'vtc16_1000',
		'193': 'htv7hd_1000',
		'194': 'htv9hd_1000',
		'20': 'anninhtv_1000',
		'19': 'quocphongvnhd_1000',
		'290': 'quochoivn_1000'}
	idk = idk_dict.get(ten, None)
	url = f'http://api.tv360.vn/public/v1/live/get-live-schedule?id={ten}&datetime={hom}'
	resp = get360(url)
	if (resp is not None) and ('duration' in resp.text):
		for k in resp.json()['data']['schedules']:
			item = Listitem()
			doi = f"{k['datetime']} {k['startTime']}"
			linkget = f"https://tshift.fptplay.net/dvr/{idk}.stream/chunks_dvr_range-{int(datetime.strptime(doi, '%Y-%m-%d %H:%M').timestamp())}-{k['duration']}.m3u8"
			item.label = f"{k['startTime']} {k['date']}: {k['name']}"
			item.art['thumb'] = item.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
			item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), f'{w.stream(linkget)}{w.referer("https://fptplay.vn/")}', item.label, '')
			yield item
	else:
		yield w.quangcao()
@Route.register
def get_vtvvt(plugin, ten, hom, **kwargs):
	w = import_module('resources.lib.kedon')
	idk_dict = {'3': 'dac12e23-ebcc-4c69-aaf5-5b2b8d47c41f',
		'4': 'f86bb850-f6ef-4c9d-b0ad-b8fe16ef27e9',
		'110': '070e2561-5d82-459d-b769-8210fd48fbf4',
		'98': 'd055b75f-05c9-4799-8581-c46b60b878dd'}
	idk = idk_dict.get(ten, None)
	url = f'http://api.tv360.vn/public/v1/live/get-live-schedule?id={ten}&datetime={hom}'
	resp = w.getlinkvnm(url, url)
	if (resp is not None) and ('duration' in resp.text):
		for k in resp.json()['data']['schedules']:
			item = Listitem()
			doi = f"{k['datetime']} {k['startTime']}"
			timebd = int(datetime.strptime(doi, '%Y-%m-%d %H:%M').timestamp())
			linkget = f"http://live.tv360.vn/manifest/{idk}/catchup/720p/720p.m3u8?media=true&start={timebd}&stop={timebd + k['duration']}"
			item.label = f"{k['startTime']} {k['date']}: {k['name']}"
			item.art['thumb'] = item.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
			item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), f'{w.stream(linkget)}{w.referer("http://tv360.vn/")}', item.label, '')
			yield item
	else:
		yield w.quangcao()
@lru_cache(maxsize=None)
def get360(url):
	w = import_module('resources.lib.kedon')
	with Session() as s:
		site = s.get('http://tv360.vn/', headers={'user-agent': w.useragentdf,'referer': 'http://tv360.vn/'.encode('utf-8')})
		r = s.get(url)
		return r