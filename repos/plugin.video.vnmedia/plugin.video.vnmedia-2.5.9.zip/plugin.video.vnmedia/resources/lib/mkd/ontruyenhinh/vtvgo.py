from codequick import Route, Listitem, Resolver, Script
from importlib import import_module
from concurrent.futures import ThreadPoolExecutor
from bs4 import BeautifulSoup
from time import gmtime
from calendar import timegm
from xbmcgui import DialogProgress
from urllib.parse import quote_plus
import re
randstam = timegm(gmtime())
def get_tv1(randstam):
	respget_tv1 = import_module('resources.lib.kedon').getlinkweb(f'https://vtvgo.vn/xem-truc-tuyen?time={randstam}', 'https://vtvgo.vn', -1)
	return respget_tv1
def get_tv2():
	respget_tv2 = import_module('resources.lib.kedon').getlink('https://api.vtvgiaitri.vn/api/v3/channel', 'https://vtvgiaitri.vn', -1)
	return respget_tv2
@Route.register
def search_vgo(plugin,search_query, **kwargs):
	w = import_module('resources.lib.kedon')
	dp = DialogProgress()
	dp.create(w.__addonnoti__, 'Đang lấy dữ liệu...')
	dp.update(0)
	search_query = quote_plus(search_query)
	url = f'https://vtvgo.vn/search?time={randstam}&search-keyword={search_query.replace(" ","+")}'
	r = w.getlinkweb(url, url, 900)
	if (r is not None) and ('news-slide-content-item' in r.text):
		soup = BeautifulSoup(r.content, 'html.parser')
		for episode in soup.select('div.news-slide-content-item'):
			item = Listitem()
			item.label = episode.select_one('h2 a').get_text(strip=True)
			linkphim = episode.select_one('h2 a').get('href').replace('.html','')
			finallink = f'{linkphim}?time={randstam}'
			item.art['thumb'] = item.art['fanart'] = episode.select_one('img').get('src')
			item.set_callback(Resolver.ref('/resources/lib/kedon:ifr_khomuc'), finallink, item.label)
			yield item
	else:
		Script.notify(w.__addonnoti__, 'Không tìm thấy kết quả')
		yield w.quangcao()
	dp.update(100)
	dp.close()
@Route.register
def index_vtvgo(plugin, **kwargs):
	yield Listitem.search(search_vgo)
	khovideo = {'label': 'KHO VIDEO',
	'info': {'plot': 'Kho Video'},
	'art': {'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/vtvgo.png',
	'fanart': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/vtvgo.png'},
	'callback': index_khovd}
	tructuyenvtvgo = {'label': 'XEM TRỰC TUYẾN',
	'info': {'plot': 'Xem trực tuyến'},
	'art': {'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/vtvgo.png',
	'fanart': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/vtvgo.png'},
	'callback': list_truyenhinhvtvgo}
	yield Listitem.from_dict(**tructuyenvtvgo)
	yield Listitem.from_dict(**khovideo)
@Route.register
def list_truyenhinhvtvgo(plugin, **kwargs):
	w = import_module('resources.lib.kedon')
	with ThreadPoolExecutor(2) as ex:
		f1 = ex.submit(get_tv1, randstam)
		f2 = ex.submit(get_tv2)
	if (f1.result() is not None):
		kqf1 = f1.result()
		x = kqf1.cookies.get_dict()
		g = re.findall(r"var (time|token) = '(.*?)'", kqf1.text)
		sre = re.compile(r'\d+')
		timekenh = g[0][1]
		tokenkenh = g[1][1]
		soup = BeautifulSoup(kqf1.content, 'html.parser')
		for episode in soup.select('div.list_channel a'):
			item = Listitem()
			linkkenh = episode.get('href')
			idkenh = sre.findall(linkkenh)[-1]
			anh = episode.select_one('img').get('src')
			item.label = f'{episode.get("alt")} - sv1'
			item.info['plot'] = w.tb
			item.art['thumb'] = item.art['fanart'] = anh
			item.set_callback(Resolver.ref('/resources/lib/kedon:play_vtvgo'), timekenh, tokenkenh, idkenh, x, item.label)
			yield item
	else:
		yield []
	if (f2.result() is not None):
		m = f2.result().json()['data']
		for k in m:
			item = Listitem()
			linkkenh = k['url']
			linktrandau = f'{w.stream(linkkenh)}{w.referer("https://vtvgiaitri.vn")}'
			anh = k['mobile_logo']
			item.label = f'{k["name"]} - sv2'
			item.info['plot'] = w.tb
			item.art['thumb'] = item.art['fanart'] = anh
			item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), linktrandau, item.label, '')
			yield item
	else:
		yield []
@Route.register
def index_khovd(plugin, **kwargs):
	w = import_module('resources.lib.kedon')
	url = f'https://vtvgo.vn/kho-video?time={randstam}'
	resp = w.getlinkweb(url, 'https://vtvgo.vn', -1)
	if (resp is not None):
		sre = re.compile(r'(\d+)\.')
		soup = BeautifulSoup(resp.content, 'html.parser')
		for episode in soup.select('a.color-white'):
			item = Listitem()
			linkthumuc = episode.get('href')
			idthumuc = sre.search(linkthumuc)[1].replace('.', '')
			next_page = 1
			item.label = episode.get_text(strip=True)
			item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/vtvgo.png'
			item.set_callback(list_thumucvd, idthumuc, next_page)
			yield item
	else:
		yield w.quangcao()
@Route.register
def list_thumucvd(plugin, idthumuc, next_page, **kwargs):
	w = import_module('resources.lib.kedon')
	url = f'https://vtvgo.vn/ajax-get-more-item-playlist?next_page={next_page}&channel_id={idthumuc}'
	resp = w.getlinkweb(url, 'https://vtvgo.vn', -1)
	if (resp is not None) and ('http' in resp.text):
		soup = BeautifulSoup(resp.content, 'html.parser')
		for episode in soup.select('div.swiper-slide'):
			item = Listitem()
			linkclip = episode.select_one('h2 a').get('href').replace('.html','')
			finallink = f'{linkclip}?time={randstam}'
			tenclip = episode.select_one('h2 a').get_text(strip=True)
			anhclip = episode.select_one('img').get('src')
			item.label = tenclip
			item.art['thumb'] = item.art['fanart'] = anhclip
			item.set_callback(Resolver.ref('/resources/lib/kedon:ifr_khomuc'), finallink, item.label)
			yield item
		item = Listitem()
		item1 = Listitem()
		item1.label = f'Trang {next_page + 1}'
		item1.art['thumb'] = item1.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
		item1.set_callback(list_thumucvd, idthumuc, next_page + 1)
		yield item1
	else:
		yield w.quangcao()