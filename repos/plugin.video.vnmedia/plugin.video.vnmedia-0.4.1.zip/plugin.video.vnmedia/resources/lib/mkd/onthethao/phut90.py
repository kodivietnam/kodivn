from codequick import Route, Listitem, run
from resources.lib.kedon import qc, tb, getlink, stream, referer, play_vnm
from bs4 import BeautifulSoup
import re
tiengruoi = 'https://mitom.90phuttttttt.xyz'
@Route.register
def index_90p(plugin, content_type='segment'):
	resp = getlink(tiengruoi, tiengruoi, 15*60)
	web = BeautifulSoup(resp.text, 'html.parser')
	for chinmuoi in web.body.select('a.item'):
		item = Listitem()
		title = chinmuoi.select_one('div.title').text.strip()
		time =  chinmuoi.select_one('div.time').text.strip()
		time = time.replace('Chưa diễn ra', '')
		linktrandau = chinmuoi.get('href')
		item.label = time + ' ' + title
		item.art['thumb'] = 'https://90phuttttttt.xyz/images/logo-90.png'
		item.art['fanart'] = 'https://90phuttttttt.xyz/images/logo-90.png'
		item.set_callback(list_90p, linktrandau, item.label)
		yield item

@Route.register
def list_90p(plugin,url,title):
	goc = tiengruoi+url
	resp = getlink(goc, goc, 0)
	web = BeautifulSoup(resp.text, 'html.parser')
	dulieu = web.body.select('ul.pull-left li.item')
	found = False
	if len(dulieu) > 1:
		for chinmuoi in dulieu:
			item = Listitem()
			if chinmuoi.get('data-url'):
				linkchatluong = stream(chinmuoi.get('data-url')) + referer(tiengruoi)
				item.label = chinmuoi.select_one('a').text.strip() + ' ' + title
				item.info['plot'] = tb
				item.art['thumb'] = 'https://90phuttttttt.xyz/images/logo-90.png'
				item.art['fanart'] = 'https://90phuttttttt.xyz/images/logo-90.png'
				item.set_callback(play_vnm, linkchatluong, item.label, '')
				yield item
	if not found:
		item = Listitem()
		match = re.search(r'video_url = "(.*?)"', resp.text)
		if 'm3u8' in resp.text:
			linkmacdinh = stream(match.group(1).strip()) + referer(tiengruoi)
		else:
			linkmacdinh = stream(qc)
		item.label = 'Default ' + title
		item.info['plot'] = tb
		item.art['thumb'] = 'https://90phuttttttt.xyz/images/logo-90.png'
		item.art['fanart'] = 'https://90phuttttttt.xyz/images/logo-90.png'
		item.set_callback(play_vnm, linkmacdinh, item.label, '')
		yield item