from codequick import Resolver, Listitem, run, Script
from bs4 import BeautifulSoup
from urllib.parse import urlparse
import inputstreamhelper, urlquick, xbmc, xbmcgui, xbmcaddon, base64, urllib, re, time, os, sys, json
__addon__ = xbmcaddon.Addon()
__addonname__ = __addon__.getAddonInfo('name')
__version__ = __addon__.getAddonInfo('version')
__icon__ = __addon__.getAddonInfo('icon')
__settings__ = xbmcaddon.Addon(id='plugin.video.vnmedia')
__addonnoti__ = '%s v%s' % (__addonname__, __version__)
useragent = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/17.0 Chrome/96.0.4664.104 Safari/537.36'
useragentvmf = 'Vietmediaf /Kodi1.1.99-092019'
code = 'User-Agent=%s' % useragent
qc ='https://qtv.vncdn.vn/qtvlive/tv3live.m3u8'
logotv = 'https://i.imgur.com/Mnuw95h.png'
news = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/qc.ass'
tb = 'Nội dung này được chia sẻ và lưu trữ bởi một ứng dụng bên thứ ba. VNmedia hoạt động giống như một công cụ thu thập tìm kiếm từ Internet. Chúng tôi không sở hữu, không lưu trữ nội dung này và sẽ không chịu trách nhiệm cho các vấn đề liên quan. Đề nghị khán giả cân nhắc trước khi xem.'

def tiengruoi():
	url = 'http://bit.ly/tiengruoi'
	r = getlink(url, url, 15*60)
	match = re.findall(r'cl_item">\n<a href="(.*?)"', r.text)
	return match

def convert_bytes(size):
	for x in ['bytes', 'KB', 'MB', 'GB', 'TB']:
		if size < 1024.0:
			return "%3.1f %s" % (size, x)
		size /= 1024.0
	return size
def ace(kenh, tenkenh):
	if 'acestream' in kenh:
		tach = kenh.split('//')
		p = tach[1]
	elif ':6878' in kenh:
		if '&' in kenh:
			match = re.search(r'id=(.*?)&', kenh)
			p = match.group(1)
		else:
			tach = kenh.split('id=')
			p = tach[1]
	kenhace = ''.join(("{'label': '", tenkenh.strip(),"', 'action': 'play', 'fanart': '', 'icon': '', 'id': '", p.strip(), "'}"))
	mahoa = base64.b64encode(kenhace.encode('utf-8')).decode('utf-8')
	mahoaa = urllib.parse.quote(mahoa)
	eca = 'plugin://script.module.horus/?%s' % mahoaa
	return eca
def getlink(url, ref, luu):
	try:
		resp = urlquick.get(url, timeout=10, max_age=luu, headers={'user-agent': useragent,'referer': ref.encode('utf-8')})
		resp.encoding = 'utf-8'
		return resp
	except:
		Script.notify(__addonnoti__, 'Lỗi kết nối')
		sys.exit()

def postlink(url, ref, luu):
	try:
		resp = urlquick.post(url, timeout=10, max_age=luu, headers={'user-agent': useragent,'referer': ref.encode('utf-8')})
		resp.encoding = 'utf-8'
		return resp
	except:
		Script.notify(__addonnoti__, 'Lỗi kết nối')
		sys.exit()
def postlinktimfs(url, ref, luu):
	try:
		resp = urlquick.post(url, timeout=10, max_age=luu, headers={'user-agent': useragent,
			'referer': ref.encode('utf-8'),
			'authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJuYW1lIjoiZnNoYXJlIiwidXVpZCI6IjcxZjU1NjFkMTUiLCJ0eXBlIjoicGFydG5lciIsImV4cGlyZXMiOjAsImV4cGlyZSI6MH0.WBWRKbFf7nJ7gDn1rOgENh1_doPc07MNsKwiKCJg40U'})
		resp.encoding = 'utf-8'
		return resp
	except:
		Script.notify(__addonnoti__, 'Lỗi kết nối')
		sys.exit()
def stream(url):
	b = 'User-Agent=%s' % useragent
	if '|' in url:
		a = '%s&%s' % (url, b)
	elif '.m3u8' in url:
		a = '%s|%s' % (url, b)
	else:
		a = url
	return a
def referer(url):
	a = urlparse(url)
	x = '&Origin=%s://%s&verifypeer=false&Referer=%s/' % (a.scheme, a.netloc, url)
	return x
def replace_all(dict, str):
	for key in dict:
		str = str.replace(key, dict[key])
	return str
def get_user_input():
	kb = xbmc.Keyboard('', 'NumberCode được chia sẻ bởi facebook Hội mê Phim')
	kb.doModal()
	if not kb.isConfirmed():
		return
	query = kb.getText()
	return query
def get_kara_input():
	kb = xbmc.Keyboard('', 'Nhập tên bài hát')
	kb.doModal()
	if not kb.isConfirmed():
		return
	query = kb.getText()
	return query			
def get_info_fs(url):
	resp = getlink(url, url, 60*60)
	soup = BeautifulSoup(resp.text, 'html.parser')
	if 'Not Found' in soup.title.string:
		return 'Tập tin này bị hỏng - 404'
	else:
		ten = soup.select_one('div.info div#limit-name').text.strip()
		dungluong = soup.select_one('button#login_to_down_cus a').text.split('|')[1]
		info = '%s%s' % (ten, dungluong)
		return info
def userpassfs():
	username = __settings__.getSetting('username')
	password = __settings__.getSetting('password')
	if len(username) == 0 or len(password) == 0:
		__addon__.openSettings()
	else:
		payload = '{"app_key":"L2S7R6ZMagggC5wWkQhX2+aDi467PPuftWUMRFSn","user_email":"%s","password":"%s"}' % (username, password)
		head = {'cache-control': 'no-cache', 'User-Agent': useragentvmf}
		try:
			resp = urlquick.post('https://api.fshare.vn/api/user/login', data=payload, headers=head, timeout=10, max_age=6*60*60)
			resp.raise_for_status()
		except:
			xbmcgui.Dialog().ok(__addonnoti__, 'Sau 3 lần đăng nhập không thành công, tài khoản sẽ bị khoá 10 phút\nKiểm tra lại tài khoản, mật khẩu, đường truyền Internet...')
			__addon__.openSettings()
			sys.exit()
		token = resp.json()['token']
		session_id = resp.json()['session_id']
		return (token,session_id)
def getfs(x):
	session_id = userpassfs()[1]
	token = userpassfs()[0]
	payload = {'token': token, 'url': x}
	headerfsvn = {'User-Agent': useragentvmf, 'Cookie' : 'session_id=%s' % session_id }
	resp = urlquick.post('https://api.fshare.vn/api/session/download', timeout=10, max_age=0, json=payload, headers=headerfsvn)
	return resp.json()['location']
def quangcao():
	item = Listitem()
	linkmacdinh = stream(qc)
	item.label = 'Đang cập nhật'
	item.info['plot'] = tb
	item.art['thumb'] = 'http://tamnguyenviet.vn/wp-content/uploads/2016/07/Icon-cap-nhat.png'
	item.art['fanart'] = 'http://tamnguyenviet.vn/wp-content/uploads/2016/07/Icon-cap-nhat.png'
	item.set_callback(play_vnm, linkmacdinh, item.label, '')
	return item

@Resolver.register
def play_vnm(plugin,url,title,drmKey, **kwargs):
	if drmKey !='':
		is_helper = inputstreamhelper.Helper('mpd','com.widevine.alpha')
		if is_helper.check_inputstream():
			return Listitem().from_dict(**{'label': plugin._title,'subtitles':{news},'callback':url,'properties':{'inputstream':is_helper.inputstream_addon,'inputstream.adaptive.manifest_type':'mpd','inputstream.adaptive.license_type':'com.widevine.alpha','inputstream.adaptive.license_key':'%s||R{SSM}|' % drmKey}})
	elif '.m3u8' in url :
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':url,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
	else:
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':url})
@Resolver.register
def ifr_vebolive(plugin,url,title, **kwargs):
	resp = getlink(url, url, 15*60)
	soup = BeautifulSoup(resp.text, 'html.parser')
	ifr = soup.select_one('iframe.embed-responsive-item').get('src')
	r = getlink(ifr, url, 0)
	match = re.search(r'var urlStream = "(.*?)"', r.text)
	linkplay = '%s%s' % (stream(match.group(1)), referer(ifr))
	return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
@Resolver.register
def ifr_xembong(plugin,url,title, **kwargs):
	resp = getlink(url, url, 15*60)
	if '.m3u8' in resp.text:
		match = re.search(r'linkStream = \'(.*?)\'', resp.text)
		linkplay = '%s%s' % (stream(match.group(1)), referer(url))
	else:
		linkplay = stream(qc)
	return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
@Resolver.register
def ifr_xoilacme(plugin,url,title, **kwargs):
	resp = getlink(url, url, 15*60)
	if '.m3u8' in resp.text:
		match = re.search(r'let mideoUrl = "(.*?)"', resp.text)
		linkplay = '%s%s' % (stream(match.group(1).replace('&amp;', '&')), referer(url))
	else:
		linkplay = stream(qc)
	return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
@Resolver.register
def play_fs(plugin,url,title, **kwargs):
	try:
		return Listitem().from_dict(**{'label': title,'subtitles' : {news},'callback': getfs(url)})
	except:
		xbmcgui.Dialog().ok(__addonnoti__, 'Tập tin này bị hỏng')
@Resolver.register
def play_vtvrep(plugin,idx, title, **kwargs):
	url = 'https://vtvgo.vn/ajax-get-epg-detail?epg_id=%s' % idx
	resp = getlink(url, url, 0)
	if '.m3u8' in resp.text:
		linkplay = stream(resp.json()['data'])
	else:
		linkplay = stream(qc)
	if '.m3u8' in linkplay :
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
	else:
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay})
@Resolver.register
def playsocolive(plugin, numroom, timestamp, title, **kwargs):
	url = 'https://json.cvndnss.com/room/%s/detail.json?v=%s' % (numroom, timestamp)
	resp = getlink(url, url, 10*60)
	nd = '%s}' % re.search(r'\((.*?)}\)', resp.text).group(1)
	m = json.loads(nd)
	l = m['data']['stream']['hdM3u8']
	linkplay = '%s%s' % (stream(l), referer('https://www.soco.live/'))
	return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
@Resolver.register
def play_vtvgo(plugin, url, title, **kwargs):
	r = getlink(url, url, 60*60)
	x = r.cookies.get_dict()
	time = re.search(r"var time = '(.*?)'", r.text)[1]
	token = re.search(r"var token = '(.*?)'", r.text)[1]
	id = re.search(r'var id = (.*?);', r.text)[1]
	urlx = 'https://vtvgo.vn/ajax-get-stream'
	payload = {'type_id': '1','id': id,'time': time,'token': token}
	headx = {'user-agent': useragent,
	'x-requested-with': 'XMLHttpRequest',
	'referer': 'https://vtvgo.vn/xem-truc-tuyen-kenh-vtv-{id}.html',
	'content-type': 'application/x-www-form-urlencoded; charset=UTF-8'}
	resp = urlquick.post(urlx, data=urllib.parse.urlencode(payload, quote_via=urllib.parse.quote), cookies=x, headers=headx, max_age=15*60)
	linkplay = '%s%s' % (stream(resp.json()['chromecast_url']), referer(url))
	return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
@Resolver.register
def ifr_khomuc(plugin,url,title, **kwargs):
	resp = getlink(url, url, 15*60)
	match = re.search(r'manifest-url="(.*?)"', resp.text)
	linkplay = '%s%s' % (stream(match.group(1)), referer(url))
	return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
@Resolver.register
def ifr_xoilac(plugin,url,title, **kwargs):
	resp = getlink(url, url, 15*60)
	soup = BeautifulSoup(resp.text, 'html.parser')
	ifr = soup.select_one('div.embed-responsive-item iframe').get('src')
	layifr = getlink(ifr, url, 0)
	match = re.search(r'urlStream = "(.*?)"', layifr.text)
	linkplay = '%s%s' % (stream(match.group(1)), referer(ifr))
	return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})