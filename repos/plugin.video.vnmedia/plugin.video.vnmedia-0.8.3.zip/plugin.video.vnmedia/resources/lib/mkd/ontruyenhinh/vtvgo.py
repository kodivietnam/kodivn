from codequick import Route, Listitem, run
from resources.lib.kedon import tb, getlink, play_vtvgo
from bs4 import BeautifulSoup
@Route.register
def index_vtvgo(plugin, **kwargs):
	url = 'https://vtvgo.vn/trang-chu.html'
	r = getlink(url, url, 24*60*60)
	soup = BeautifulSoup(r.text, 'html.parser')
	episodes = soup.select('div.list_channel a')
	for episode in episodes:
		item = Listitem()
		linkkenh = episode.get('href')
		anh = episode.select_one('img').get('src')
		item.label = episode.get('alt')
		item.info['plot'] = tb
		item.art['thumb'] = item.art['landscape'] = anh
		item.art['fanart'] = 'https://is3-ssl.mzstatic.com/image/thumb/Purple126/v4/b2/97/48/b2974814-bc6e-3d59-8ea3-86ace210b426/AppIcon-0-0-1x_U007emarketing-0-0-0-7-0-0-sRGB-0-0-0-GLES2_U002c0-512MB-85-220-0-0.png/1200x600wa.png'
		item.set_callback(play_vtvgo, linkkenh, item.label)
		yield item