from codequick import Route, Listitem, run
from resources.lib.kedon import quangcao, getlink, stream, referer, play_vnm, tb
from bs4 import BeautifulSoup
from datetime import datetime
import re, json
@Route.register
def index_saoke(plugin, **kwargs):
	ux = 'https://saoke5.link/'
	r = getlink(ux, ux, 15*60)
	web = BeautifulSoup(r.text, 'html.parser')
	for k in web.body.select('ul.list'):
		url = k.select_one('a').get('href')
		resp = getlink(url, url, 5*60)
		if 'm3u8' in resp.text:
			match = re.search(r'lives=(.*?)</script>', resp.text).group(1)
			listplay = re.findall(r'{_id(.*?)primaryId', match)
			for k in listplay:
				ten = re.search(r'Xem trực tiếp bình luận bóng đá hôm nay: (.*?)"', k).group(1)
				tg = re.search(r'time:(.*?),', k).group(1)
				tgjs = json.loads(tg)
				time = datetime.fromtimestamp(tgjs/1000).strftime('%H:%M %d-%m')
				listname = re.findall(r'{name:(.*?)}', k)
				for m in listname:
					item = Listitem()
					if re.search(r'url:"(.*?)"', m).group(1):
						chatluong = re.search(r'"(.*?)"', m).group(1)
						linkplay = '%s%s' % (stream(re.search(r'url:"(.*?)"', m).group(1)), referer(url))
						item.label = '%s %s %s' % (chatluong, time, ten)
						item.info['plot'] = tb
						item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://9767a59e2b.vws.vegacdn.vn/template/logo1.png'
						item.set_callback(play_vnm, linkplay, item.label, '')
						yield item
		else:
			yield quangcao()