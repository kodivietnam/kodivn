from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from resources.lib.kedon import getlink, ifr_xoilacme
@Route.register
def index_xoilacme(plugin, **kwargs):
	url = 'http://xoilac.me/'
	resp = getlink(url, url, 15*60)
	soup = BeautifulSoup(resp.text, 'html.parser')
	episodes = soup.select('a.match_info')
	for episode in episodes:
		item = Listitem()
		linktrandau = episode.get('href')
		if episode.select('div.home_team_panel div'):
			thoigian = episode.select_one('div.time').text.strip()
			doinha = episode.select_one('div.home_team_panel div').text.strip()
			doikhach = episode.select_one('div.guest_team_panel div').text.strip()
			item.label = '%s: %s vs %s' % (thoigian, doinha, doikhach)
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'http://chaolongtv.org/image/logo_vi.png'
			item.set_callback(ifr_xoilacme, linktrandau, item.label)
			yield item