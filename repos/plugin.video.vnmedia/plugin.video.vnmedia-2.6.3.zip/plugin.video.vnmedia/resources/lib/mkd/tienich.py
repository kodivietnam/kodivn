from codequick import Route, Script, Listitem
from resources.lib.kedon import __addonnoti__, get_file_path
from xbmcgui import Dialog
from xbmc import executebuiltin
from os.path import exists
from os import remove
from sys import version
from urlquick import get, cache_cleanup
@Route.register
def index_tienich(plugin, **kwargs):
	yield Listitem.from_dict(**{'label': 'Cài đặt tiện ích',
	'info': {'plot': 'Cài đặt tiện ích'},
	'art': {'thumb': 'https://cdn.pixabay.com/photo/2018/04/11/19/48/settings-3311592_960_720.png',
	'fanart': 'https://cdn.pixabay.com/photo/2018/04/11/19/48/settings-3311592_960_720.png'},
	'callback': settingaddon})
	yield Listitem.from_dict(**{'label': 'Địa chỉ IP',
	'info': {'plot': 'Kiểm tra địa chỉ IP của tôi'},
	'art': {'thumb': 'https://www.elegantthemes.com/blog/wp-content/uploads/2020/03/what-is-an-ip-address-featured-image.jpg',
	'fanart': 'https://www.elegantthemes.com/blog/wp-content/uploads/2020/03/what-is-an-ip-address-featured-image.jpg'},
	'callback': check_myip})
	yield Listitem.from_dict(**{'label': 'Xoá bộ nhớ đệm',
	'info': {'plot': 'Xoá bộ nhớ đệm'},
	'art': {'thumb': 'https://us.123rf.com/450wm/lkeskinen/lkeskinen1802/lkeskinen180202962/95571098-clear-cache-rubber-stamp-grunge-design-with-dust-scratches-effects-can-be-easily-removed-for-a-clean.jpg',
	'fanart': 'https://us.123rf.com/450wm/lkeskinen/lkeskinen1802/lkeskinen180202962/95571098-clear-cache-rubber-stamp-grunge-design-with-dust-scratches-effects-can-be-easily-removed-for-a-clean.jpg'},
	'callback': deletecache})
@Script.register
def check_myip(plugin, **kwargs):
	resp = get('https://redirector.googlevideo.com/report_mapping?di=no', max_age=-1, timeout=15, headers={'user-agent': 'okhttp/4.10.0'})
	if resp is not None:
		Dialog().ok(__addonnoti__, f'{version}\n{resp.text}')
	else:
		Dialog().ok(__addonnoti__, 'Không có dữ liệu')
@Script.register
def settingaddon(plugin, **kwargs):
	executebuiltin('Addon.OpenSettings(plugin.video.vnmedia)')
@Script.register
def deletecache(plugin, **kwargs):
	cache_cleanup(-1)
	if exists(get_file_path('.urlquick.slite3')):
		remove(get_file_path('.urlquick.slite3'))
		Script.notify(__addonnoti__, 'Đã xoá bộ nhớ đệm')
	else:
		Script.notify(__addonnoti__, 'Bộ nhớ đệm trống')