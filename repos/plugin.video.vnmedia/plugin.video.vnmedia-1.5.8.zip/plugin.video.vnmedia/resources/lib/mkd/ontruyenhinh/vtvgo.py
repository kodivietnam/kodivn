from codequick import Route, Listitem, run
from resources.lib.kedon import tb, play_vtvgo, play_vtvgovod, ifr_khomuc, quangcao
from bs4 import BeautifulSoup
import urlquick
@Route.register
def index_vtvgo(plugin, **kwargs):
	tructuyenvtvgo = {'label': 'XEM TRỰC TUYẾN',
	'info': {'plot': 'Xem trực tuyến'},
	'art': {'thumb': 'https://wap.vtvgo.vn/vtvgo_all_device.png',
	'fanart': 'https://wap.vtvgo.vn/vtvgo_all_device.png'},
	'callback': list_truyenhinhvtvgo}
	yield Listitem.from_dict(**tructuyenvtvgo)
	data = {"device_type":"4","sign":"1667921823000.af8d052261b24edc6e5de9eb2b5c081f6799dde6","login_type":"","acc_id":"","brand":"asus","lang":"vi","app_id":"jcNDP1vw3BP1ntLUHyW2Usy0AetQmdO7","ANDROID_OS_VERSION":22,"locate":"vi","AdId":"2c348bad-9e2e-4a27-bc43-22d3f21e65d7"}
	resp = urlquick.post('https://vtvgo-api-app-v6.vtvdigital.vn/api/others/GetVersion', timeout=10, max_age=15*60, data=data)
	for k in resp.json()['result']['vod_category']:
		item = Listitem()
		item.label = k['display_name']
		item.info['plot'] = k['category_description']
		item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://cdn.tgdd.vn/2020/07/content/2-cach-xem-vtv-go-tren-may-tinh-don-gian-nhat-thumb-800x450.jpg'
		item.set_callback(index_khovd, k['menu_keyword'], 1)
		yield item
@Route.register
def list_truyenhinhvtvgo(plugin, **kwargs):
	headers = {"device_type":"4","sign":"1667799385000.5cb776ae5e59d15896fb2b30efa163d620c6603c","login_type":"","acc_id":"","brand":"asus","lang":"vi","app_id":"jcNDP1vw3BP1ntLUHyW2Usy0AetQmdO7","ANDROID_OS_VERSION":"22","locate":"vi","full_channel":'1',"AdId":"2c348bad-9e2e-4a27-bc43-22d3f21e65d7"}
	r = urlquick.post('https://vtvgo-api-app-v6.vtvdigital.vn/api/live/GetChannelList', timeout=10, max_age=15*60, headers=headers)
	for k in r.json()['result']['channel']:
		item = Listitem()
		idkenh = k['channel_id']
		codekenh = k['content_code']
		item.label = k['display_name']
		item.info['plot'] = tb
		item.art['thumb'] = item.art['landscape'] = k['logo']
		item.art['fanart'] = 'https://cdn.tgdd.vn/2020/07/content/2-cach-xem-vtv-go-tren-may-tinh-don-gian-nhat-thumb-800x450.jpg'
		item.set_callback(play_vtvgo, idkenh, codekenh, item.label)
		yield item
@Route.register
def index_khovd(plugin, idk, next_page, **kwargs):
	data = f'{{"device_type":"4","sign":"1667917776000.abed330af0fa131a14c54256f6ee45487f30810a","login_type":"","acc_id":"","brand":"asus","lang":"vi","app_id":"jcNDP1vw3BP1ntLUHyW2Usy0AetQmdO7","ANDROID_OS_VERSION":22,"locate":"vi","category_id":"{idk}","page":"{next_page}","AdId":"2c348bad-9e2e-4a27-bc43-22d3f21e65d7"}}'
	resp = urlquick.post('https://vtvgo-api-app-v6.vtvdigital.vn/api/vod/GetListChannelInCategoryById', timeout=10, max_age=15*60, data=data)
	if '"data"' in resp.text:
		for k in resp.json()['result']['data']:
			item = Listitem()
			item.label = k['channel_name']
			idkenh = k['id']
			if k['channel_banner']:
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = k['channel_banner']
			else:
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://cdn.tgdd.vn/2020/07/content/2-cach-xem-vtv-go-tren-may-tinh-don-gian-nhat-thumb-800x450.jpg'
			item.set_callback(list_thumucvd, idkenh, 1)
			yield item
		item1 = Listitem()
		item1.label = f'Trang {next_page + 1}'
		item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
		item1.set_callback(index_khovd, idk, next_page + 1)
		yield item1
	else:
		yield []
@Route.register
def list_thumucvd(plugin, idthumuc, next_page, **kwargs):
	data = f'{{"device_type":"4","vod_channel_id":{idthumuc},"sign":"1667920793000.e0a9d26c95e3d4db173fcaee3ab5c87468ae1201","app_id":"jcNDP1vw3BP1ntLUHyW2Usy0AetQmdO7","AdId":"2c348bad-9e2e-4a27-bc43-22d3f21e65d7","login_type":"","acc_id":"","brand":"asus","lang":"vi","ANDROID_OS_VERSION":22,"locate":"vi","category_id":0,"page":{next_page}}}'
	resp = urlquick.post('https://vtvgo-api-app-v6.vtvdigital.vn/api/vod/VodListByChannel', timeout=10, max_age=15*60, data=data)
	if '"vod"' in resp.text:
		for k in resp.json()['result']['vod']:
			item = Listitem()
			idkenh = k['vod_id']
			codekenh = k['content_code']
			item.label = k['vod_title']
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = k['vod_image']
			item.info['plot'] = k['vod_desc']
			item.set_callback(play_vtvgovod, idkenh, codekenh, item.label)
			yield item
		item1 = Listitem()
		item1.label = f'Trang {next_page + 1}'
		item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
		item1.set_callback(list_thumucvd, idthumuc, next_page + 1)
		yield item1
	else:
		yield []