from codequick import Route, Listitem, run
from datetime import datetime, timedelta
from resources.lib.kedon import quangcao, getlink, stream, ace
import re, json
@Route.register
def index_streamthunder(plugin, **kwargs):
	url = 'https://widget.streamthunder.org/list.php?id=21&sport=&sp=&r=&l=&l2='
	resp = getlink(url, url, 15*60)
	if resp is not None:
		if 'acestream' in resp.text:
			nd = re.search(r'var chan_arr = (.*?);\n', resp.text).group(1)
			m = json.loads(nd)
			for v in m:
				match = re.search(f'{{"id":"{v}(.*?)"date":"(.*?)","match":"(.*?)"', resp.text)
				tentran = match.group(3)
				tg = match.group(2)
				z = (datetime.fromisoformat(tg) + timedelta(hours=6)).strftime('%H:%M')
				for index, number in enumerate(m[v]):
					item = Listitem()
					if 'acestream' in number['link']:
						item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg'
						item.label = f'Link {index+1}-{z} {tentran}'
						linkplay = ace(number['link'], item.label)
						item.path = linkplay
						item.set_callback(item.path)
						yield item
		else:
			yield quangcao()
	else:
		yield quangcao()