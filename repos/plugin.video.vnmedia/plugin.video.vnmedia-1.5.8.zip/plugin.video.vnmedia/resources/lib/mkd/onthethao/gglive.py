from codequick import Route, Listitem, run
from resources.lib.kedon import getlink, stream, referer, quangcao, play_vnm
@Route.register
def index_gglive(plugin, **kwargs):
	ref = 'https://gglive.vn/'
	url = 'https://gglive.vn/api/livestream/list?page=1&page_size=1000'
	resp = getlink(url, ref, 15*60)
	if resp is not None:
		for m in resp.json()['data']:
			item = Listitem()
			linkplay = f'{stream(m["hls"])}{referer(ref)}'
			item.label = f'{m["title"]} ({m["user"]["fullname"]})'
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = m['thumb']
			item.set_callback(play_vnm, linkplay, item.label, '')
			yield item
	else:
		yield quangcao()