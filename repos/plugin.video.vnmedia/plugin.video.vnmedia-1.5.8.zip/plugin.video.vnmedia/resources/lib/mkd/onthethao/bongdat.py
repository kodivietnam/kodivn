from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from resources.lib.kedon import getlink, ifr_xembong, quangcao
@Route.register
def index_bongdat(plugin, **kwargs):
	url = 'https://bongdat1.net/'
	resp = getlink(url, url, 15*60)
	if resp is not None:
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('ul.box_timeList_table_ul li')
		for episode in episodes:
			item = Listitem()
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = f'{url}themes/frontend/default/img/logo.png'
			linktrandau = f'{url}{episode.select_one("a").get("href")}'
			tentran = episode.get_text()
			tentran = '\n'.join([ll.rstrip() for ll in tentran.splitlines() if ll.strip()])
			tentran = tentran.replace('\n', ' ')
			tentran = tentran.strip()
			item.label = tentran
			item.set_callback(ifr_xembong, linktrandau, item.label)
			yield item
	else:
		yield quangcao()