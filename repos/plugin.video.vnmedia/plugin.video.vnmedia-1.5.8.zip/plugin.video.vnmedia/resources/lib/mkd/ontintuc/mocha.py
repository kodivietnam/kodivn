from codequick import Route, Listitem, run
from resources.lib.kedon import getlink, stream, play_vnm, quangcao
@Route.register
def index_mocha(plugin, next_page, **kwargs):
	resp = getlink(f'http://apivideo.mocha.com.vn:8081/onMediaBackendBiz/mochavideo/listVideoByCate?categoryid=1&limit=50&offset={next_page}0&lastIdStr=&token=', 'http://m.video.mocha.com.vn/more', 5*60)
	if resp is not None:
		kq = resp.json()
		for k in kq['data']['listVideo']:
			item = Listitem()
			linkplay = stream(k['original_path'])
			item.label = k['name']
			item.info['plot'] = k['description']
			item.art['thumb'] = item.art['landscape'] = k['image_path']
			item.art['fanart'] = k['image_path']
			item.set_callback(play_vnm, linkplay, item.label, '')
			yield item
		item1 = Listitem()
		item1.label = 'Trang tiếp'
		item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
		item1.set_callback(index_mocha, next_page + 5)
		yield item1
	else:
		yield quangcao()