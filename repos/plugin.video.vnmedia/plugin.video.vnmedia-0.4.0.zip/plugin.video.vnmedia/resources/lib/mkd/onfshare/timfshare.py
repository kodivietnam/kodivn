from codequick import Route, Listitem, run
from resources.lib.kedon import tb, getlink, play_fs, __addonnoti__
from resources.lib.mkd.onfshare.ifshare import index_fs
import xbmcgui
import urllib
@Route.register
def searchfs(plugin, search_query):
	dp = xbmcgui.DialogProgress()
	dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
	page = 0
	search_query = urllib.parse.quote_plus(search_query)
	url = 'https://timfshare.com/search?start=' + str(page)+ '1&q=inurl%3Afshare+' + search_query
	resp = getlink(url, url, 48*60*60)
	kq = resp.json()
	for k in kq['items']:
		item = Listitem()
		if 'folder' in k['link']:
			item.label = k['title']
			thumuc = k['link'].split('folder/')
			item.info['plot'] = tb
			item.art['thumb'] = 'https://static.mservice.io/placebrand/s/momo-upload-api-200424091506-637233165063699729.png'
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			item.set_callback(index_fs, thumuc[1], 1)
			yield item
		elif 'file' in k['link']:
			item.label = k['title']
			linkplay = k['link']
			item.info['plot'] = k['snippet']
			item.art['thumb'] = 'https://static.mservice.io/placebrand/s/momo-upload-api-200424091506-637233165063699729.png'
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			item.set_callback(play_fs, linkplay, item.label)
			yield item
	yield Listitem.next_page(search_query, page + 1, callback=searchfspage)

@Route.register
def searchfspage(plugin, search_query, page):
	search_query = urllib.parse.quote_plus(search_query)
	url = 'https://timfshare.com/search?start=' + str(page)+ '1&q=inurl%3Afshare+' + search_query
	resp = getlink(url, url, 48*60*60)
	kq = resp.json()
	for k in kq['items']:
		item = Listitem()
		if 'folder' in k['link']:
			item.label = k['title']
			thumuc = k['link'].split('folder/')
			item.art['thumb'] = 'https://static.mservice.io/placebrand/s/momo-upload-api-200424091506-637233165063699729.png'
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			item.set_callback(index_fs, thumuc[1], 1)
			yield item
		elif 'file' in k['link']:
			item.label = k['title']
			linkplay = k['link']
			item.art['thumb'] = 'https://static.mservice.io/placebrand/s/momo-upload-api-200424091506-637233165063699729.png'
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			item.set_callback(play_fs, linkplay, item.label)
			yield item
	yield Listitem.next_page(search_query, page + 1, callback=searchfspage)