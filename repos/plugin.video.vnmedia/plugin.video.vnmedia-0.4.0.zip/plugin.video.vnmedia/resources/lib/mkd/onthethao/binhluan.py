from codequick import Route, Listitem, run
from resources.lib.kedon import qc, tb, getlink, stream, referer, play_vnm

binhluantv = 'https://xoilac.90phuttttt.xyz'
@Route.register
def index_binhluan(plugin, content_type='segment'):
	url = binhluantv + '/api/matches-in-home?id=0'
	resp = getlink(url, url, 10*60)
	kq = resp.json()
	for k in kq[0]['data']:
		item1 = Listitem()
		ten = '[LIVE]' + k['title']
		linktran = binhluantv + '/api/match/' + k['_id']
		item1.info['plot'] = tb
		item1.label = ten
		item1.art['thumb'] = 'https://xoilac.90phuttttt.xyz/imgs/logo.png'
		item1.art['fanart'] = 'https://xoilac.90phuttttt.xyz/imgs/logo.png'
		item1.set_callback(list_binhluantv, linktran, item1.label)
		yield item1
	for m in kq[1]['data']:
		item2 = Listitem()
		time = m['timeStartPlayMod']
		ngay = m['dayinweek']
		ten = m['title']
		linktran = binhluantv + '/api/match/' + m['_id']
		item2.info['plot'] = tb
		item2.label = time + ' ' + ngay + ' ' + ten
		item2.art['thumb'] = 'https://xoilac.90phuttttt.xyz/imgs/logo.png'
		item2.art['fanart'] = 'https://xoilac.90phuttttt.xyz/imgs/logo.png'
		item2.set_callback(list_binhluantv, linktran, item2.label)
		yield item2

@Route.register
def list_binhluantv(plugin, url, title):
	resp = getlink(url, url, 0)
	kq = resp.json()
	if 'm3u8' in resp.text:
		for k in kq['streamsLink']:
			item = Listitem()
			ten = k['label'] + ' ' + title
			linktran = stream(k['link']) + referer(url)
			item.info['plot'] = tb
			item.label = ten
			item.art['thumb'] = 'https://xoilac.90phuttttt.xyz/imgs/logo.png'
			item.art['fanart'] = 'https://xoilac.90phuttttt.xyz/imgs/logo.png'
			item.set_callback(play_vnm, linktran, item.label, '')
			yield item
	else:
		item3 = Listitem()
		linkmacdinh = stream(qc)
		item3.label = 'Đang cập nhật'
		item3.info['plot'] = tb
		item3.art['thumb'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.art['fanart'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.set_callback(play_vnm, linkmacdinh, item3.label, '')
		yield item3