from codequick import Route, Listitem, run
from resources.lib.kedon import tb, getlink, stream, play_vieon
import json
@Route.register
def index_vieonsukien(plugin, content_type='segment'):
	url = 'https://api.vieon.vn/backend/cm/v5/ribbon/4bdad485-9048-4c15-970e-e94ce4a595b9?page=0&limit=30&platform=web&ui=012021'
	resp = getlink(url, url, 15*60)
	kq = resp.text
	data = json.loads(kq)['items']
	for k in data:
		item = Listitem()
		item.label = k['title']
		hls = k['seo']['share_url']
		item.info['plot'] = tb
		item.art['thumb'] = k['images']['thumbnail_v4']
		item.art['fanart'] = k['images']['thumbnail_v4']
		item.set_callback(play_vieon, hls, item.label)
		yield item