from codequick import Route, Listitem, Resolver
from resources.lib.kedon import getlinkweb, quangcao
from random import choice
import re, requests
def getAuthSignature():
	veclist=getlinkweb('https://raw.githubusercontent.com/michaz1988/michaz1988.github.io/master/data.json', 'https://raw.githubusercontent.com/', 1000).json()
	vec = {"vec": choice(veclist)}
	req = requests.post('https://www.vavoo.tv/api/box/ping2', data=vec).json()
	if req.get('signed'):
		sig = req['signed']
	elif req.get('data', {}).get('signed'):
		sig = req['data']['signed']
	elif req.get('response', {}).get('signed'):
		sig = req['response']['signed']
	return sig
@Route.register
def index_vavoo(plugin):
	yield []
	try:
		url = f'https://www2.vavoo.to/live2/index'
		resp = getlinkweb(url, url, 1000)
		sign = getAuthSignature()
		if (resp is not None):
			for k in resp.json():
				item = Listitem()
				name = k['name']
				group = k['group']
				ten = f'{name} - {group}'
				logo = k['logo']
				play = k['url']
				linkplay = f'{play}?n=1&b=5&vavoo_auth={sign}|User-Agent=VAVOO/2.6'
				item.label = ten
				item.info['mediatype'] = 'episode'
				item.art['thumb'] = item.art['poster'] = logo
				item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), linkplay, ten)
				yield item
		else:
			yield quangcao()
	except:
		yield quangcao()