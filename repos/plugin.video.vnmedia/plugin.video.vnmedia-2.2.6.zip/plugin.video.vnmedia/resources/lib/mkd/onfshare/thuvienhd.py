from codequick import Route, Listitem, Script, Resolver
from importlib import import_module
from bs4 import BeautifulSoup
from xbmcgui import DialogProgress
from urllib.parse import quote_plus
from xbmcaddon import Addon
import re
@Route.register
def search_thuvienhd(plugin,search_query, **kwargs):
	w = import_module('resources.lib.kedon')
	dp = DialogProgress()
	dp.create(w.__addonnoti__, 'Đang lấy dữ liệu...')
	dp.update(5)
	sr = quote_plus(search_query)
	url = f'https://thuvienhd.com/?s={sr.replace(" ","+")}'
	urlrf = 'https://thuvienhd.com'
	resp = w.getlink(url, urlrf, 7200)
	if resp is not None:
		match = re.search(r'"nonce":"(.*?)"', resp.text).group(1)
		urltv = f'https://thuvienhd.com/wp-json/dooplay/search/?nonce={match}&keyword={sr}'
		r = w.getlink(urltv, urlrf, 7200)
		if 'No results' in r.text:
			yield w.quangcao()
		else:
			for k in r.json().values():
				item = Listitem()
				item.label = k['title']
				item.info['plot'] = w.tb
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = w.yttk(item.label)
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = k['img']
				item.set_callback(thuvienhd_linktk, k['url'], linkanh)
				yield item
	else:
		yield w.quangcao()
	dp.update(100)
	dp.close()
@Route.register
def thuvienhd_linktk(plugin, url, linkanh, **kwargs):
	w = import_module('resources.lib.kedon')
	respx = w.getlink(url, url, 7200)
	if respx is not None:
		soupx = BeautifulSoup(respx.content, 'html.parser')
		episodesx = soupx.select('span.box__download a')
		for episodex in episodesx:
			linkid = episodex.get('href')
			resp = w.getlink(linkid, linkid, 14400)
			soup = BeautifulSoup(resp.content, 'html.parser')
			episodes = soup.select('tbody.tbody.outer a')
			for episode in episodes:
				link = episode.get('href')
				ten = episode.get('title')
				for dungluong in episode.select('div.face-secondary'):
					item = Listitem()
					if 'folder' in link:
						item.label = f'{ten} {dungluong.get_text().strip()}'
						item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = linkanh
						item.info['plot'] = w.tb
						item.info['mediatype'] = 'episode'
						item.info['rating'] = 10.0
						item.info['trailer'] = w.yttk(item.label)
						item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
						item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), link.split('folder/')[1], 1)
						yield item
					elif 'file' in link:
						item.label = f'{ten} {dungluong.get_text().strip()}'
						item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = linkanh
						item.info['plot'] = w.tb
						item.info['mediatype'] = 'episode'
						item.info['rating'] = 10.0
						item.info['trailer'] = w.yttk(item.label)
						if Addon().getSetting('taifshare') == 'true':
							item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', link)
						item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
						item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), link, item.label)
						yield item
	else:
		yield w.quangcao()
@Route.register
def index_thuvienhd(plugin, **kwargs):
	w = import_module('resources.lib.kedon')
	yield Listitem.search(search_thuvienhd)
	url = 'http://thuvienhd.com/'
	resp = w.getlink(url, url, 7200)
	if resp is not None:
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('ul.genres.falsescroll li a')
		for episode in episodes:
			item = Listitem()
			if 'thuvienhd.com' in episode.get('href'):
				item.label = episode.get_text()
				item.info['plot'] = w.tb
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://thuvienhd.com/wp-content/uploads/2020/10/THUVIENHD.NET_.png'
				item.set_callback(thuvienhd_page, f'{episode.get("href")}/page/', 1)
				yield item
	else:
		yield w.quangcao()
@Route.register
def thuvienhd_page(plugin, url, next_page, **kwargs):
	w = import_module('resources.lib.kedon')
	trangtiep = f'{url}{next_page}'
	resp = w.getlink(trangtiep, trangtiep, 7200)
	if resp is not None:
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('div.items article')
		for episode in episodes:
			item = Listitem()
			if 'texto' in resp.text:
				noidung = episode.select_one('div.texto').get_text()
			else:
				noidung = w.tb
			linkanh = episode.select_one('img').get('src')
			item.label = episode.select_one('img').get('alt')
			item.info['plot'] = f'{noidung}\n{w.tb}'
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = w.yttk(item.label)
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = linkanh
			item.set_callback(thuvienhd_link, episode.get('id'), linkanh, noidung)
			yield item
		checkpages = soup.select('div.pagination a')
		for checkpage in checkpages:
			if str(next_page + 1) in checkpage.get_text():
				item1 = Listitem()
				item1.label = f'Trang {next_page + 1}'
				item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
				item1.set_callback(thuvienhd_page, url, next_page + 1)
				yield item1
	else:
		yield w.quangcao()
@Route.register
def thuvienhd_link(plugin, url, linkanh, noidung, **kwargs):
	w = import_module('resources.lib.kedon')
	tach = url.split('-')
	p = tach[1]
	resp = w.getlink(f'http://thuvienhd.com/download?id={p}', url, 7200)
	if resp is not None:
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('tbody.tbody.outer a')
		for episode in episodes:
			link = episode.get('href')
			ten = episode.get('title')
			if ten is not None:
				for dungluong in episode.select('div.face-secondary'):
					item = Listitem()
					if 'folder' in link:
						item.label = f'{ten} {dungluong.get_text().strip()}'
						item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = linkanh
						item.info['plot'] = f'{noidung}\n{w.tb}'
						item.info['mediatype'] = 'episode'
						item.info['rating'] = 10.0
						item.info['trailer'] = w.yttk(item.label)
						item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
						item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), link.split('folder/')[1], 1)
						yield item
					elif 'file' in link:
						item.label = f'{ten} {dungluong.get_text().strip()}'
						item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = linkanh
						item.info['plot'] = f'{noidung}\n{w.tb}'
						item.info['mediatype'] = 'episode'
						item.info['rating'] = 10.0
						item.info['trailer'] = w.yttk(item.label)
						if Addon().getSetting('taifshare') == 'true':
							item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', link)
						item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
						item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), link, item.label)
						yield item
	else:
		yield w.quangcao()