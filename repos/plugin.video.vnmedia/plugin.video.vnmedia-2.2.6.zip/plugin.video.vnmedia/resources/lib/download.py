from codequick import Script
from urllib.parse import urlparse, unquote
from importlib import import_module
from requests import get
from codequick.utils import ensure_unicode
from xbmcgui import DialogProgress, Dialog
from xbmcvfs import translatePath
from time import time
from os.path import join, basename, exists
from os import unlink
@Script.register
def downloadfs(plugin, x, **kwargs):
    qw = import_module('resources.lib.kedon')
    url = qw.getfs(x)
    dp = DialogProgress()
    if Script.setting.get_string('dl_folder'):
        pathx = ensure_unicode(Script.setting.get_string('dl_folder'))
    else:
        pathx = join(translatePath('special://home/media/'))
    filename = unquote(basename(urlparse(url).path))
    zippath = join(pathx + filename)
    if exists(zippath):
        unlink(zippath)
    dp.create(f'{qw.__addonnoti__} đang tải...', f'Đang tải tệp {filename}')
    dp.update(0, f'Đang tải tệp {filename}')
    f = open(zippath, 'wb')
    zipresp = get(url, stream=True)
    if not zipresp:
        Dialog().ok(qw.__addonnoti__, 'Tập tin này bị hỏng')
        return
    else:
        total = zipresp.headers.get('content-length')
    if total is None:
        f.write(zipresp.content)
    else:
        downloaded = 0
        total = int(total)
        start_time = time()
        mb = 1024*1024
        for chunk in zipresp.iter_content(chunk_size=max(int(total/512), mb)):
            downloaded += len(chunk)
            f.write(chunk)
            done = int(100 * downloaded/total)
            kbps_speed = downloaded/(time() - start_time)
            if kbps_speed > 0 and not done >= 100:
                eta = (total - downloaded)/kbps_speed
            else:
                eta = 0
            kbps_speed = kbps_speed/1024
            type_speed = 'KB'
            if kbps_speed >= 1024:
                kbps_speed = kbps_speed/1024
                type_speed = 'MB'
            currently_downloaded = f'Đã tải: {downloaded/mb:.02f}MB / {total/mb:.02f}MB'
            speed = f'Tốc độ tải: {kbps_speed:.02f} {type_speed}/s'
            div = divmod(eta, 60)
            speed += f' - Còn: {int(div[0]):02}:{int(div[1]):02}'
            dp.update(done, f'{filename}\n{currently_downloaded}\n{speed}')