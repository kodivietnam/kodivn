from codequick import Route, Listitem, Resolver
from resources.lib.kedon import quangcao, replace_all, getlink, stream, referer, tb, saoke
from datetime import datetime
from json import loads
import re
@Route.register
def index_saoke(plugin, **kwargs):
	url = saoke()[0]
	resp = getlink(url, url, 400)
	if resp is not None:
		if '.m3u8' in resp.text:
			ll = re.search(r',lives=(.*?)</script>', resp.text).group(1)
			nd = re.sub('([{,:])(\w+)([},:])','\\1\"\\2\"\\3',ll)
			thaythe = {
				"'[":"[",
				"]'":"]"
				}
			m = loads(replace_all(thaythe, nd))
			for k1 in m:
				tg = datetime.fromtimestamp(int(k1['time'])/1000).strftime('%H:%M %d-%m')
				for k2 in k1['hlsUrls']:
					item1 = Listitem()
					if k2['url']:
						item1.info['plot'] = tb
						item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://9767a59e2b.vws.vegacdn.vn/template/logo1.png'
						ten1 = k1['title'].split(':')[1].strip()
						if k1['blv']:
							item1.label = f'{tg} {k2["name"]}: {ten1} - BLV: {k1["blv"]}'
						else:
							item1.label = f'{tg} {k2["name"]}: {ten1}'
						item1.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), f'{stream(k2["url"])}{referer(url)}', item1.label, '')
						yield item1
				if 'hlsUrlsManNhan' in k1:
					for b2 in k1['hlsUrlsManNhan']:
						item2 = Listitem()
						if b2['url']:
							item2.info['plot'] = tb
							item2.art['thumb'] = item2.art['landscape'] = item2.art['fanart'] = 'https://i.imgur.com/Dbez5bc.png'
							ten2 = k1['titleManNhan'].split(':')[1].strip()
							tentrandau2 = f'{tg} {b2['name']}: {ten2}'
							if k1['blvManNhan']:
								item2.label = f'{tentrandau2} - BLV: {k1["blvManNhan"]}'
							else:
								item2.label = tentrandau2
							item2.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), f'{stream(b2["url"])}{referer(url)}', item2.label, '')
							yield item2
		else:
			yield quangcao()
	else:
		yield quangcao()