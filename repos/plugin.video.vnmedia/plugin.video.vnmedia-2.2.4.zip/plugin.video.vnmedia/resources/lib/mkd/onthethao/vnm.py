from codequick import Route, Listitem, Resolver
from resources.lib.kedon import getlinkvnm, quangcao, tb
from urllib.parse import unquote
@Route.register
def index_vnm(plugin, **kwargs):
	url = 'https://mi3s.top/vnmedia'
	resp = getlinkvnm(url, url).data.decode('utf-8')
	if resp:
		tach = resp.split('\n')
		for k in tach:
			item = Listitem()
			tachhat = k.split('|')
			if len(tachhat)>1:
				item.label = tachhat[0].replace('*','')
				item.info['plot'] = tb
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = tachhat[3]
				item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), unquote(tachhat[1]).strip(), item.label, '')
				yield item
	else:
		yield quangcao()