from codequick import Route, Listitem
from importlib import import_module
@Route.register
def index_tintuc(plugin,**kwargs):
	tb = import_module('resources.lib.kedon').tb
	yield Listitem.from_dict(**{'label': 'Báo Nói - Đọc Báo Giúp Bạn',
	'info':{'plot':tb},
	'art':{'thumb':'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png',
	'fanart':'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'},
	'callback':Route.ref('/resources/lib/mkd/ontintuc/baomoi:index_baomoi')})
	yield Listitem.from_dict(**{'label': 'Tin thể thao',
	'info':{'plot':tb},
	'art':{'thumb':'https://thethao360.tv/wp-content/uploads/2020/12/logo-3.png',
	'fanart':'https://thethao360.tv/wp-content/uploads/2020/12/logo-3.png'},
	'callback':Route.ref('/resources/lib/mkd/onthethao/tinthethao:index_tinthethao')})
	yield mocha()
	yield Listitem.youtube('UCabsTV34JwALXKGMqHpvUiA', label="VTV24")
	yield Listitem.youtube('UCL9-pEHNBs3N4r2bMoXdLJA', label="VTC Now")
	yield Listitem.youtube('UCUmRGR3a-g13O6pG927KQmg',label="TV24h")
	yield Listitem.youtube('UCRjzfa1E0gA50lvDQipbDMg',label="60 giây")
	yield Listitem.youtube('UCinkijG72G87sn-mtaFJTbA',label="Thời tiết-Môi trường")
	yield Listitem.youtube('UCZ7cd8K5jo7fHUksCgMfpeg',label="Văn hoá-Du lịch")
	yield Listitem.youtube('UC7723FqVehXq2zeRb3tP0hQ',label="Kinh tế-Tài chính")
	yield Listitem.youtube('UCIg56SgvoZF8Qg0Jx_gh6Pg',label="An ninh")
	yield Listitem.youtube('UCmBT5CqUxf3-K5_IU9tVtBg',label="Thông tấn xã")
	yield Listitem.youtube('UCTJ-FDgxR3NxurDQxNiWWVQ',label="Quốc hội")
	yield Listitem.youtube('UCPJfjHrW3-zIeSaZTgmckmg',label="Nhân dân")
	yield Listitem.youtube('UCZnhEIF8a5Uv4GMPwT6KafQ',label="Nông nghiệp-nông thôn")
	yield Listitem.youtube('UCHPzpxcYhxkb0fMJKeSe66g',label="Thế giới đó đây")
	yield Listitem.youtube('UCZcCmWhvK0gfThyWRmRerDQ',label="VTC tin mới")
	yield Listitem.youtube('UC7_mgS3z22z0WhR7COJ8E2w',label="Hà Nội tin tức")
	yield Listitem.youtube('UCZYKmEA2iQOSbyKc6xj5Vfw',label="HTV tin tức")
	yield Listitem.youtube('UC1K9R0YwYrp7auy6fPbnnIQ',label="THVL tổng hợp")
	yield Listitem.youtube('UC0OX9WL_PxOlX0HQbu45JfA',label="Luật giao thông")
	yield Listitem.youtube('UCtfsYfpS3KoRTEbCMc6l85w',label="Tuấn tiền tỉ")
	yield Listitem.youtube('UCaJ6YgNkAlRsl8nWZS2sjtg',label="Dương địa lý")
def mocha():
	item = Listitem()
	item.label = 'Tin mới'
	item.info['plot'] = import_module('resources.lib.kedon').tb
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(Route.ref('/resources/lib/mkd/ontintuc/mocha:index_mocha'), 1, 0)
	return item