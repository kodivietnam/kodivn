from codequick import Route, Listitem, run
@Route.register
def search_thuviencine(plugin,search_query, **kwargs):
	from resources.lib.kedon import getlink, tb, __addonnoti__, quangcao, yttk
	import xbmcgui, urllib
	dp = xbmcgui.DialogProgress()
	dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
	dp.update(0)
	search_query = urllib.parse.quote_plus(search_query)
	url = 'https://thuviencine.com'
	resp = getlink(url, url, 7200)
	if resp is not None:
		import re
		match = re.search(r'"nonce":"(.*?)"', resp.text).group(1)
		urltv = f'https://thuviencine.com/wp-json/moviewp/search/?nonce={match}&keyword={search_query}'
		r = getlink(urltv, url, 7200)
		if 'No results' in r.text:
			yield quangcao()
		else:
			for k in r.json().values():
				item = Listitem()
				ten = k['title']
				phim = k['url']
				linkanh = k['img']
				item.label = ten
				item.info['plot'] = tb
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = yttk(item.label)
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = linkanh
				item.set_callback(thuviencine_link, phim)
				yield item
	else:
		yield quangcao()
	dp.update(100)
	dp.close()
@Route.register
def index_thuviencine(plugin, **kwargs):
	from resources.lib.kedon import getlink, tb, quangcao
	yield Listitem.search(search_thuviencine)
	url = 'http://thuviencine.com'
	resp = getlink(url, url, 7200)
	if resp is not None:
		from bs4 import BeautifulSoup
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('div.sidebar.sb-left a')
		for episode in episodes:
			item = Listitem()
			phim = episode.get('href')
			item.label = episode.get_text()
			item.info['plot'] = tb
			next_page = 1
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://thuviencine.com/wp-content/uploads/2021/09/logo-red.png'
			item.set_callback(thuviencine_page, phim, next_page)
			yield item
		nhomtheloais = soup.select('nav.filters a')
		for nhomtheloai in nhomtheloais:
			item1 = Listitem()
			nhom = nhomtheloai.get('href')
			tennhom = nhomtheloai.get_text()
			if tennhom:
				item1.label = tennhom
				item1.info['plot'] = tb
				next_page = 1
				item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://thuviencine.com/wp-content/uploads/2021/09/logo-red.png'
				item1.set_callback(thuviencine_page, nhom, next_page)
				yield item1
	else:
		yield quangcao()

@Route.register
def thuviencine_page(plugin, url, next_page, **kwargs):
	from resources.lib.kedon import getlink, tb, quangcao, yttk
	trangtiep = f'{url}page/{next_page}'
	resp = getlink(trangtiep, trangtiep, 7200)
	if resp is not None:
		from bs4 import BeautifulSoup
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('div.item-container a')
		for episode in episodes:
			item = Listitem()
			anh = episode.select('img')
			ndp = episode.select('p.movie-description')
			for inf in ndp:
				noidung = inf.get_text()
			linkphim = episode.get('href')
			for poster in anh:
				linkanh = poster.get('data-src')
			ten = episode.get('title')
			if ten:
				item.label = ten
				item.info['plot'] = f'{noidung}\n{tb}'
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = yttk(item.label)
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = linkanh
				item.set_callback(thuviencine_link, linkphim)
				yield item
		if 'resppages' in resp.text:
			item1 = Listitem()
			item1.label = f'Trang {next_page + 1}'
			item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
			item1.set_callback(thuviencine_page, url, next_page + 1)
			yield item1
	else:
		yield quangcao()
@Route.register
def thuviencine_link(plugin, url, **kwargs):
	from resources.lib.kedon import getlink, tb, play_fs, quangcao, yttk
	resp = getlink(url, url, 7200)
	if resp is not None:
		from bs4 import BeautifulSoup
		from resources.lib.mkd.onfshare.ifshare import index_fs, tfavo
		import xbmcaddon
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('li#download-button a')
		for episode in episodes:
			linktai = episode.get('href')
			respx = getlink(linktai, linktai, 7200)
			web = BeautifulSoup(respx.content, 'html.parser')
			nhomlinktai = web.select('div.movie-actions a')
			for nhomlinktaix in nhomlinktai:
				item = Listitem()
				link = nhomlinktaix.get('href')
				tenx = nhomlinktaix.select('span')
				dl = nhomlinktaix.select('i')
				for ten in tenx:
					tenphim = ten.get_text()
				for dlx in dl:
					dungluongphim = dlx.get_text()
					tach = dungluongphim.split('|')
					dlp = tach[1]
				if 'folder' in link:
					item.label = f'{tenphim}{dlp}'
					item.info['plot'] = tb
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(item.label)
					thumuc = link.split('folder/')
					item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={link}&qzone=1&margin=1&size=400x400&ecc=L'
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					item.context.script(tfavo, 'Thêm vào Fshare Favorite', link)
					item.set_callback(index_fs, thumuc[1], 1)
					yield item
				elif 'file' in link:
					item.label = f'{tenphim}{dlp}'
					item.info['plot'] = tb
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(item.label)
					item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={link}&qzone=1&margin=1&size=400x400&ecc=L'
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					if xbmcaddon.Addon().getSetting("taifshare") == "true":
						from resources.lib.download import downloadfs
						item.context.script(downloadfs, 'Tải về', link)
					item.set_callback(play_fs, link, item.label)
					item.context.script(tfavo, 'Thêm vào Fshare Favorite', link)
					yield item
	else:
		yield quangcao()