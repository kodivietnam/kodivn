from urllib3 import PoolManager
from xbmc import executebuiltin
from xbmcaddon import Addon
from json import loads
def autorun_addon():
    executebuiltin('UpdateAddonRepos()')
    if Addon().getSetting('auto_run') == 'true':
        executebuiltin('RunAddon(plugin.video.vnmedia)')
    if Addon().getSetting('auto_noti') == 'true':
        r = PoolManager().request('GET', 'https://speedtest.vn/get-ip-info', headers={'user-agent': 'okhttp/4.10.0'}).data.decode('utf-8')
        a = ' '.join([c for c in reversed(loads(r).values())]) if r else 'VNNIC error'
        executebuiltin(f'Notification("KODI VIỆT NAM", {a}, 10000, {Addon().getAddonInfo("icon")})')
    return
autorun_addon()