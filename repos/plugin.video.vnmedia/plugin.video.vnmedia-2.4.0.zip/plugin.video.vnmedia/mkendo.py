from codequick import run
from importlib import import_module
from functools import lru_cache
@lru_cache(maxsize=None)
def main():
    exception = run()
    if isinstance(exception, Exception):
        main = import_module('resources.lib.main')
        main.error_handler(exception)
if __name__ == '__main__':
    main()