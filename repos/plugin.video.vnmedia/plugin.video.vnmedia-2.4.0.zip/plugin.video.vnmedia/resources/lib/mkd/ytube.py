from codequick import Route, Listitem
from importlib import import_module
import re
@Route.register
def index_youtube(plugin, **kwargs):
	h = import_module('resources.lib.kedon')
	thaythe = {'\\"':'','\\u0026':'&'}
	yield Listitem.search(Route.ref('/resources/lib/mkd/onyoutube/tim:search_youtube'))
	yield Listitem.from_dict(**{'label': 'TOP VIDEO THỊNH HÀNH',
	'info':{'plot':'Top video nhiều lượt tương tác (xem, thích, bình luận…) trên Youtube'},
	'art':{'thumb':'https://pbs.twimg.com/profile_images/614494084250497024/ubzCDQBm_400x400.png',
	'fanart':'https://cdn.tgdd.vn//GameApp/1311257//cach-xem-top-thinh-hanh-tren-youtube-cac-nuoc-bang-dien-thoai-thumb-800x450.jpg'},
	'callback':Route.ref('/resources/lib/mkd/onyoutube/video:youtube_thinhhanh')})
	yield Listitem.from_dict(**{'label': 'TOP ÂM NHẠC THỊNH HÀNH',
	'info':{'plot':'Top video nhạc nhiều lượt tương tác (xem, thích, bình luận…) trên Youtube'},
	'art':{'thumb':'https://pbs.twimg.com/profile_images/614494084250497024/ubzCDQBm_400x400.png',
	'fanart':'https://cdn.tgdd.vn//GameApp/1311257//cach-xem-top-thinh-hanh-tren-youtube-cac-nuoc-bang-dien-thoai-thumb-800x450.jpg'},
	'callback':Route.ref('/resources/lib/mkd/onyoutube/video:youtube_amnhacthinhhanh')})
	sre1 = re.compile(r'text":"(.*?)"}')
	sre2 = re.compile(r'videoId":"(.*?)"')
	url = 'https://www.youtube.com/?gl=VN&hl=vi'
	listplay = re.findall(r'videoRenderer(.*?)accessibility', h.replace_all(thaythe, h.getlinkweb(url, url, 43200).text))
	for k in listplay:
		item = Listitem()
		idvd = sre2.search(k).group(1)
		item.path = f'plugin://plugin.video.youtube/play/?video_id={idvd}'
		item.label = sre1.search(k).group(1)
		item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = f'https://i.ytimg.com/vi/{idvd}/sddefault.jpg'
		item.set_path(item.path)
		yield item