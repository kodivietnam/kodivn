from codequick import Route, Listitem, Resolver
from importlib import import_module
import re
@Route.register
def list_iptv(plugin, url, **kwargs):
	w = import_module('resources.lib.kedon')
	item = Listitem()
	item.label = 'TẤT CẢ CÁC KÊNH'
	item.info['plot'] = w.tb
	item.art['thumb'] = item.art['landscape'] = 'https://i.imgur.com/Mnuw95h.png'
	item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
	item.set_callback(little_iptv, url)
	yield item
	try:
		resp = w.getlinkip(url, url)
		rp = resp.data.decode('utf-8')
		group = re.findall('group-title="(.*?)"', rp)
		um = []
		for tk in list(dict.fromkeys(group)):
			[um.append(k) for k in tk.split(';') if k not in um] if ';' in tk else um.append(tk)
		if '' in um:
			um.remove('')
		for p in um:
			item = Listitem()
			item.label = p
			item.info['plot'] = w.tb
			item.art['thumb'] = item.art['landscape'] = 'https://i.imgur.com/Mnuw95h.png'
			item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
			item.set_callback(info_iptv, url, item.label)
			yield item
	except:
		pass
@Route.register
def info_iptv(plugin, url, tk, **kwargs):
	w = import_module('resources.lib.kedon')
	resp = w.getlinkip(url, url)
	ketqua = re.sub('(#EXTM3U|#[^EX|^KODI])(.*)', '', resp.data.decode('utf-8')).split('#EXTINF')
	sre1 = re.compile('\n((http|https|udp|rtp|acestream):(.*?)\n)')
	sre2 = re.compile('[,](?!.*[,])(.*)')
	sre4 = re.compile('tvg-logo="(.*?)"')
	sre5 = re.compile('http-user-agent=(.*?)\n')
	sre6 = re.compile('http-referrer=(.*?)\n')
	sre7 = re.compile('license_key=(.*?)\n')
	for kq in ketqua:
		try:
			s1 = sre1.search(kq)
			s2 = sre2.search(kq)
			s4 = sre4.search(kq)
			s5 = sre5.search(kq)
			s6 = sre6.search(kq)
			s7 = sre7.search(kq)
			if f'group-title="{tk}"' in kq and ';' not in kq and s1:
				item = Listitem()
				kenh = s1.group(1)
				item.label = s2.group(1)
				item.info['plot'] = w.tb
				if s4:
					item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = s4.group(1)
				else:
					item.art['thumb'] = item.art['landscape'] = w.logotv
					item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
				if 'acestream' in kenh or ':6878' in kenh:
					item.path = w.ace(kenh, item.label)
					item.set_callback(item.path)
				else:
					user = s5.group(1) if s5 else w.useragentott
					linkplay = f'{w.streamiptv(kenh.strip(), user)}{w.referer(s6.group(1))}' if s6 else w.streamiptv(kenh.strip(), user)
					item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), linkplay, item.label, s7.group(1)) if s7 else item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), linkplay, item.label, '')
				yield item
			elif tk in kq and ';' in kq and s1:
				item = Listitem()
				kenh = s1.group(1)
				item.label = s2.group(1)
				item.info['plot'] = w.tb
				if s4:
					item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = s4.group(1)
				else:
					item.art['thumb'] = item.art['landscape'] = w.logotv
					item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
				if 'acestream' in kenh or ':6878' in kenh:
					item.path = w.ace(kenh, item.label)
					item.set_callback(item.path)
				else:
					user = s5.group(1) if s5 else w.useragentott
					linkplay = f'{w.streamiptv(kenh.strip(), user)}{w.referer(s6.group(1))}' if s6 else w.streamiptv(kenh.strip(), user)
					item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), linkplay, item.label, s7.group(1)) if s7 else item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), linkplay, item.label, '')
				yield item
			else:
				yield []
		except:
			yield w.quangcao()
@Route.register
def little_iptv(plugin, url, **kwargs):
	w = import_module('resources.lib.kedon')
	resp = w.getlinkip(url, url)
	ketqua = re.sub('(#EXTM3U|#[^EX|^KODI])(.*)', '', resp.data.decode('utf-8')).split('#EXTINF')
	sre1 = re.compile('\n((http|https|udp|rtp|acestream):(.*?)\n)')
	sre2 = re.compile('[,](?!.*[,])(.*)')
	sre3 = re.compile('group-title="(.*?)"')
	sre4 = re.compile('tvg-logo="(.*?)"')
	sre5 = re.compile('http-user-agent=(.*?)\n')
	sre6 = re.compile('http-referrer=(.*?)\n')
	sre7 = re.compile('license_key=(.*?)\n')
	for kq in ketqua:
		try:
			s1 = sre1.search(kq)
			s2 = sre2.search(kq)
			s3 = sre3.search(kq)
			s4 = sre4.search(kq)
			s5 = sre5.search(kq)
			s6 = sre6.search(kq)
			s7 = sre7.search(kq)
			if s1:
				item = Listitem()
				kenh = s1.group(1)
				tenkenh = s2.group(1)
				nhomkenh = s3.group(1) if s3 else 'TỔNG HỢP'
				item.info['plot'] = f'{nhomkenh} - {tenkenh}'
				item.label = f'{tenkenh} - {nhomkenh}'
				if s4:
					item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = s4.group(1)
				else:
					item.art['thumb'] = item.art['landscape'] = w.logotv
					item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
				if 'acestream' in kenh or ':6878' in kenh:
					item.path = w.ace(kenh, item.label)
					item.set_callback(item.path)
				else:
					user = s5.group(1) if s5 else w.useragentott
					linkplay = f'{w.streamiptv(kenh.strip(), user)}{w.referer(s6.group(1))}' if s6 else w.streamiptv(kenh.strip(), user)
					item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), linkplay, item.label, s7.group(1))if s7 else item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), linkplay, item.label, '')
				yield item
		except:
			yield w.quangcao()