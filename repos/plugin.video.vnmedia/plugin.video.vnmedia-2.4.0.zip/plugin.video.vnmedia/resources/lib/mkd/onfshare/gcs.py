from codequick import Route, Listitem, Script, Resolver
from importlib import import_module
from xbmcaddon import Addon
from json import loads
import re
@Route.register
def index_gcs(plugin, dataUrl='TextURL'):
    w = import_module('resources.lib.kedon')
    u = Addon().getSetting(dataUrl)
    if u:
        respx = w.getlink(u, u, 6000)
        if (respx is not None):
            x = respx.url
            if 'docs.google.com' in x:
                if 'gid' in x:
                    timid = re.findall(r'/d/(.*?)/.*?gid=(\d+)', x)
                    sid = timid[0][0]
                    gid = timid[0][1]
                else:
                    sid = re.findall(r'/d/(.*?)/', x)[0]
                    gid = '0'
                url = f'https://docs.google.com/spreadsheets/d/{sid}/gviz/tq?gid={gid}&headers=1'
                resp = w.getlink(url, url, 6000)
                if (resp is not None):
                    noi = re.search(r'\((.*?)}\)', resp.text).group(1)
                    m = loads(f'{noi}}}')
                    if 'http' in m['table']['cols'][1]['label']:
                        item = Listitem()
                        kenh = m['table']['cols'][1]['label']
                        item.label = m['table']['cols'][0]['label']
                        item.info['mediatype'] = 'episode'
                        item.info['rating'] = 10.0
                        item.info['trailer'] = w.yttk(item.label)
                        item.art['thumb'] = item.art['landscape'] = m['table']['cols'][2]['label'] if len(m['table']['cols']) > 2 else 'https://i.imgur.com/EpIPQXR.png'
                        item.info['plot'] = f"{m['table']['cols'][3]['label']}\n{w.tb}" if len(m['table']['cols']) > 3 else w.tb
                        item.art['fanart'] = m['table']['cols'][4]['label'] if len(m['table']['cols']) > 4 else (m['table']['cols'][2]['label'] if len(m['table']['cols']) > 2 else 'https://i.imgur.com/EpIPQXR.png')
                        if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                            item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', kenh)
                            item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), kenh.split('folder/')[1], 1)
                        elif r'file' in kenh:
                            item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', kenh)
                            if Addon().getSetting('taifshare') == 'true':
                                item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', kenh)
                            item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), kenh, item.label)
                        elif r'docs.google.com' in kenh:
                            item.set_callback(listgg_gcs, kenh, item.label)
                        elif r'VMF' in kenh:
                            item.set_callback(listvmf_gcs, kenh.replace('VMF-', ''), item.label)
                        yield item
                    for cow in m['table']['cols']:
                        p = cow['label']
                        if r'|http' in p:
                            item = Listitem()
                            tachhat = p.split('|')
                            if tachhat[1] and len(tachhat) > 1:
                                kenh = tachhat[1]
                                item.label = tachhat[0].translate(str.maketrans({'*': '', '@': ''}))
                                item.info['mediatype'] = 'episode'
                                item.info['rating'] = 10.0
                                item.info['trailer'] = w.yttk(item.label)
                                item.art['thumb'] = item.art['landscape'] = tachhat[3] if len(tachhat) > 3 else 'https://i.imgur.com/EpIPQXR.png'
                                item.info['plot'] = f'{tachhat[4]}\n{w.tb}' if len(tachhat) > 4 else w.tb
                                item.art['fanart'] = tachhat[5] if len(tachhat) > 5 else (tachhat[3] if len(tachhat) > 3 else 'https://i.imgur.com/EpIPQXR.png')
                                if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                                    item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', kenh)
                                    item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), kenh.split('folder/')[1], 1)
                                elif r'file' in kenh:
                                    item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', kenh)
                                    if Addon().getSetting('taifshare') == 'true':
                                        item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', kenh)
                                    item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), kenh, item.label)
                                elif r'docs.google.com' in kenh:
                                    item.set_callback(listgg_gcs, kenh, item.label)
                                elif r'VMF' in kenh:
                                    item.set_callback(listvmf_gcs, kenh.replace('VMF-', ''), item.label)
                                yield item
                    for row in m['table']['rows']:
                        k = w.getrow(row['c'][0])
                        if r'|http' in k:
                            item = Listitem()
                            tachhat = k.split('|')
                            if tachhat[1] and len(tachhat) > 1:
                                kenh = tachhat[1]
                                item.label = tachhat[0].translate(str.maketrans({'*': '', '@': ''}))
                                item.info['mediatype'] = 'episode'
                                item.info['rating'] = 10.0
                                item.info['trailer'] = w.yttk(item.label)
                                item.art['thumb'] = item.art['landscape'] = tachhat[3] if len(tachhat) > 3 else 'https://i.imgur.com/EpIPQXR.png'
                                item.info['plot'] = f'{tachhat[4]}\n{w.tb}' if len(tachhat) > 4 else w.tb
                                item.art['fanart'] = tachhat[5] if len(tachhat) > 5 else (tachhat[3] if len(tachhat) > 3 else 'https://i.imgur.com/EpIPQXR.png')
                                if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                                    item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', kenh)
                                    item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), kenh.split('folder/')[1], 1)
                                elif r'file' in kenh:
                                    item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', kenh)
                                    if Addon().getSetting('taifshare') == 'true':
                                        item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', kenh)
                                    item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), kenh, item.label)
                                elif r'docs.google.com' in kenh:
                                    item.set_callback(listgg_gcs, kenh, item.label)
                                elif r'VMF' in kenh:
                                    item.set_callback(listvmf_gcs, kenh.replace('VMF-', ''), item.label)
                                yield item
                        elif 'http' in w.getrow(row['c'][1]):
                            item = Listitem()
                            item.label = w.getrow(row['c'][0])
                            item.info['mediatype'] = 'episode'
                            item.info['rating'] = 10.0
                            item.info['trailer'] = w.yttk(item.label)
                            kenh = w.getrow(row['c'][1])
                            item.art['thumb'] = item.art['landscape'] = w.getrow(row['c'][2]) if len(row['c']) > 2 else 'https://i.imgur.com/EpIPQXR.png'
                            item.info['plot'] = f"{w.getrow(row['c'][3])}\n{w.tb}" if len(row['c']) > 3 else w.tb
                            item.art['fanart'] = w.getrow(row['c'][4]) if len(row['c']) > 4 else (w.getrow(row['c'][2]) if len(row['c']) > 2 else 'https://i.imgur.com/EpIPQXR.png')
                            if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                                item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', kenh)
                                item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), kenh.split('folder/')[1], 1)
                            elif r'file' in kenh:
                                item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', kenh)
                                if Addon().getSetting('taifshare') == 'true':
                                    item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', kenh)
                                item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), kenh, item.label)
                            elif r'docs.google.com' in kenh:
                                item.set_callback(listgg_gcs, kenh, item.label)
                            elif r'VMF' in kenh:
                                item.set_callback(listvmf_gcs, kenh.replace('VMF-', ''), item.label)
                            yield item
                        else:
                            yield []
                else:
                    yield []
            else:
                tach = (ll.rstrip() for ll in respx.text.splitlines() if ll.strip())
                for k in tach:
                    item = Listitem()
                    tachhat = k.split('|')
                    if len(tachhat) > 1:
                        kenh = tachhat[1]
                        item.label = tachhat[0].translate(str.maketrans({'*': '', '@': ''}))
                        item.info['mediatype'] = 'episode'
                        item.info['rating'] = 10.0
                        item.info['trailer'] = w.yttk(item.label)
                        item.art['thumb'] = item.art['landscape'] = tachhat[3] if len(tachhat) > 3 else 'https://i.imgur.com/EpIPQXR.png'
                        item.info['plot'] = f'{tachhat[4]}\n{w.tb}' if len(tachhat) > 4 else w.tb
                        item.art['fanart'] = tachhat[5] if len(tachhat) > 5 else (tachhat[3] if len(tachhat) > 3 else 'https://i.imgur.com/EpIPQXR.png')
                        if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                            item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', kenh)
                            item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), kenh.split('folder/')[1], 1)
                        elif r'file' in kenh:
                            item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', kenh)
                            if Addon().getSetting('taifshare') == 'true':
                                item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', kenh)
                            item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), kenh, item.label)
                        elif r'docs.google.com' in kenh:
                            item.set_callback(listgg_gcs, kenh, item.label)
                        elif r'VMF' in kenh:
                            item.set_callback(listvmf_gcs, kenh.replace('VMF-', ''), item.label)
                        yield item
        else:
            yield w.quangcao()
    else:
        Script.notify(w.__addonnoti__, 'Vui lòng nhập dữ liệu trong cài đặt tiện ích')
        yield w.quangcao()
@Route.register
def listgg_gcs(plugin, urltext, title):
    w = import_module('resources.lib.kedon')
    if 'gid' in urltext:
        timid = re.findall(r'/d/(.+?)/.+?gid=(\d+)', urltext)
        sid = timid[0][0]
        gid = timid[0][1]
    else:
        sid = re.findall(r'/d/(.*?)/', urltext)[0]
        gid = '0'
    url = f'https://docs.google.com/spreadsheets/d/{sid}/gviz/tq?gid={gid}&headers=1'
    resp = w.getlink(url, url, 6000)
    if (resp is not None):
        noi = re.search(r'\((.*?)}\)', resp.text).group(1)
        m = loads(f'{noi}}}')
        if 'http' in m['table']['cols'][1]['label']:
            item = Listitem()
            kenh = m['table']['cols'][1]['label']
            item.label = m['table']['cols'][0]['label']
            item.info['mediatype'] = 'episode'
            item.info['rating'] = 10.0
            item.info['trailer'] = w.yttk(item.label)
            item.art['thumb'] = item.art['landscape'] = m['table']['cols'][2]['label'] if len(m['table']['cols']) > 2 else 'https://i.imgur.com/EpIPQXR.png'
            item.info['plot'] = f"{m['table']['cols'][3]['label']}\n{w.tb}" if len(m['table']['cols']) > 3 else f'{title}\n{w.tb}'
            item.art['fanart'] = m['table']['cols'][4]['label'] if len(m['table']['cols']) > 4 else (m['table']['cols'][2]['label'] if len(m['table']['cols']) > 2 else 'https://i.imgur.com/EpIPQXR.png')
            if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', kenh)
                item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), kenh.split('folder/')[1], 1)
            elif r'file' in kenh:
                item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', kenh)
                if Addon().getSetting('taifshare') == 'true':
                    item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', kenh)
                item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), kenh, item.label)
            elif r'docs.google.com' in kenh:
                item.set_callback(listgg_gcs, kenh, item.label)
            elif r'VMF' in kenh:
                item.set_callback(listvmf_gcs, kenh.replace('VMF-', ''), item.label)
            yield item
        for cow in m['table']['cols']:
            p = cow['label']
            if r'|http' in p:
                item = Listitem()
                tachhat = p.split('|')
                if tachhat[1] and len(tachhat) > 1:
                    kenh = tachhat[1]
                    item.label = tachhat[0].translate(str.maketrans({'*': '', '@': ''}))
                    item.info['mediatype'] = 'episode'
                    item.info['rating'] = 10.0
                    item.info['trailer'] = w.yttk(item.label)
                    item.art['thumb'] = item.art['landscape'] = tachhat[3] if len(tachhat) > 3 else 'https://i.imgur.com/EpIPQXR.png'
                    item.info['plot'] = f'{tachhat[4]}\n{w.tb}' if len(tachhat) > 4 else f'{title}\n{w.tb}'
                    item.art['fanart'] = tachhat[5] if len(tachhat) > 5 else (tachhat[3] if len(tachhat) > 3 else 'https://i.imgur.com/EpIPQXR.png')
                    if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                        item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', kenh)
                        item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), kenh.split('folder/')[1], 1)
                    elif r'file' in kenh:
                        item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', kenh)
                        if Addon().getSetting('taifshare') == 'true':
                            item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', kenh)
                        item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), kenh, item.label)
                    elif r'docs.google.com' in kenh:
                        item.set_callback(listgg_gcs, kenh, item.label)
                    elif r'VMF' in kenh:
                        item.set_callback(listvmf_gcs, kenh.replace('VMF-', ''), item.label)
                    yield item
        for row in m['table']['rows']:
            k = w.getrow(row['c'][0])
            if r'|http' in k:
                item = Listitem()
                tachhat = k.split('|')
                if tachhat[1] and len(tachhat) > 1:
                    kenh = tachhat[1]
                    item.label = tachhat[0].translate(str.maketrans({'*': '', '@': ''}))
                    item.info['mediatype'] = 'episode'
                    item.info['rating'] = 10.0
                    item.info['trailer'] = w.yttk(item.label)
                    item.art['thumb'] = item.art['landscape'] = tachhat[3] if len(tachhat) > 3 else 'https://i.imgur.com/EpIPQXR.png'
                    item.info['plot'] = f'{tachhat[4]}\n{w.tb}' if len(tachhat) > 4 else f'{title}\n{w.tb}'
                    item.art['fanart'] = tachhat[5] if len(tachhat) > 5 else (tachhat[3] if len(tachhat) > 3 else 'https://i.imgur.com/EpIPQXR.png')
                    if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                        item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', kenh)
                        item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), kenh.split('folder/')[1], 1)
                    elif r'file' in kenh:
                        item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', kenh)
                        if Addon().getSetting('taifshare') == 'true':
                            item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', kenh)
                        item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), kenh, item.label)
                    elif r'docs.google.com' in kenh:
                        item.set_callback(listgg_gcs, kenh, item.label)
                    elif r'VMF' in kenh:
                        item.set_callback(listvmf_gcs, kenh.replace('VMF-', ''), item.label)
                    yield item
            elif 'http' in w.getrow(row['c'][1]):
                item = Listitem()
                item.label = w.getrow(row['c'][0])
                item.info['mediatype'] = 'episode'
                item.info['rating'] = 10.0
                item.info['trailer'] = w.yttk(item.label)
                kenh = w.getrow(row['c'][1])
                item.art['thumb'] = item.art['landscape'] = w.getrow(row['c'][2]) if len(row['c']) > 2 else 'https://i.imgur.com/EpIPQXR.png'
                item.info['plot'] = f"{w.getrow(row['c'][3])}\n{w.tb}" if len(row['c']) > 3 else f'{title}\n{w.tb}'
                item.art['fanart'] = w.getrow(row['c'][4]) if len(row['c']) > 4 else (w.getrow(row['c'][2]) if len(row['c']) > 2 else 'https://i.imgur.com/EpIPQXR.png')
                if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                    item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', kenh)
                    item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), kenh.split('folder/')[1], 1)
                elif r'file' in kenh:
                    item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', kenh)
                    if Addon().getSetting('taifshare') == 'true':
                        item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', kenh)
                    item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), kenh, item.label)
                elif r'docs.google.com' in kenh:
                    item.set_callback(listgg_gcs, kenh, item.label)
                elif r'VMF' in kenh:
                    item.set_callback(listvmf_gcs, kenh.replace('VMF-', ''), item.label)
                yield item
            else:
                yield []
    else:
        yield []
@Route.register
def listvmf_gcs(plugin, url, title):
    w = import_module('resources.lib.kedon')
    resp = w.getlink(url, url, 6000)
    if (resp is not None):
        tach = (ll.rstrip() for ll in resp.text.splitlines() if ll.strip())
        for k in tach:
            item = Listitem()
            tachhat = k.split('|')
            if len(tachhat) > 1:
                kenh = tachhat[1]
                item.label = tachhat[0].translate(str.maketrans({'*': '', '@': ''}))
                item.info['mediatype'] = 'episode'
                item.info['rating'] = 10.0
                item.info['trailer'] = w.yttk(item.label)
                item.art['thumb'] = item.art['landscape'] = tachhat[3] if len(tachhat) > 3 else 'https://i.imgur.com/EpIPQXR.png'
                item.info['plot'] = f'{tachhat[4]}\n{w.tb}' if len(tachhat) > 4 else f'{title}\n{w.tb}'
                item.art['fanart'] = tachhat[5] if len(tachhat) > 5 else (tachhat[3] if len(tachhat) > 3 else 'https://i.imgur.com/EpIPQXR.png')
                if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                    item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', kenh)
                    item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), kenh.split('folder/')[1], 1)
                elif r'file' in kenh:
                    item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', kenh)
                    if Addon().getSetting('taifshare') == 'true':
                        item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', kenh)
                    item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), kenh, item.label)
                elif r'docs.google.com' in kenh:
                    item.set_callback(listgg_gcs, kenh, item.label)
                elif r'VMF' in kenh:
                    item.set_callback(listvmf_gcs, kenh.replace('VMF-', ''), item.label)
                yield item
    else:
        yield w.quangcao()