from codequick import Route, Listitem, run
from resources.lib.kedon import quangcao, getlink, stream, referer, play_vnm, tb

binhluantv = 'https://binhluan.90phut2.live'
@Route.register
def index_binhluan(plugin, **kwargs):
	url = '%s/api/matches-in-home?id=0' % binhluantv
	resp = getlink(url, url, 15*60)
	kq = resp.json()
	for k in kq[0]['data']:
		item1 = Listitem()
		ten = '[LIVE]%s' % k['title']
		linktran = '%s/api/match/%s' % (binhluantv, k['_id'])
		item1.info['plot'] = tb
		item1.label = ten
		item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://binhluan.90phut2.live/imgs/logo.png'
		item1.set_callback(list_binhluantv, linktran, item1.label)
		yield item1
	for m in kq[1]['data']:
		item2 = Listitem()
		time = m['timeStartPlayMod']
		ngay = m['dayinweek']
		ten = m['title']
		linktran = '%s/api/match/%s' % (binhluantv, m['_id'])
		item2.info['plot'] = tb
		item2.label = '%s %s %s' % (time, ngay, ten)
		item2.art['thumb'] = item2.art['landscape'] = item2.art['fanart'] = 'https://binhluan.90phut2.live/imgs/logo.png'
		item2.set_callback(list_binhluantv, linktran, item2.label)
		yield item2

@Route.register
def list_binhluantv(plugin, url, title, **kwargs):
	resp = getlink(url, url, 5*60)
	kq = resp.json()
	if 'm3u8' in resp.text:
		for k in kq['streamsLink']:
			item = Listitem()
			ten = '%s %s' % (k['label'], title)
			linktran = '%s%s' % (stream(k['link'].replace('\t','')), referer(url))
			item.info['plot'] = tb
			item.label = ten
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://binhluan.90phut2.live/imgs/logo.png'
			item.set_callback(play_vnm, linktran, item.label, '')
			yield item
	else:
		yield quangcao()