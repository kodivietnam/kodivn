from codequick import Route, Script, Listitem
from resources.lib.kedon import __addonnoti__, remove_file, getlink
from xbmc import executebuiltin
from urlquick import cache_cleanup
from functools import lru_cache
@lru_cache
@Route.register
def index_tienich(plugin):
	streams = [
		('Cài đặt tiện ích', 'https://cdn.pixabay.com/photo/2018/04/11/19/48/settings-3311592_960_720.png', settingaddon),
		('Đo tốc độ mạng', 'https://mi3s.top/thumb/Speedtest.png', Script.ref('/resources/lib/download:speedtestfs')),
		('Địa chỉ IP', 'https://www.elegantthemes.com/blog/wp-content/uploads/2020/03/what-is-an-ip-address-featured-image.jpg', check_myip),
		('Xoá bộ nhớ đệm', 'https://us.123rf.com/450wm/lkeskinen/lkeskinen1802/lkeskinen180202962/95571098-clear-cache-rubber-stamp-grunge-design-with-dust-scratches-effects-can-be-easily-removed-for-a-clean.jpg', deletecache)
	]
	for name_key, banner_key, route_key in streams:
		i = Listitem()
		i.label = name_key
		i.art['thumb'] = i.art['poster'] = banner_key
		i.set_callback(route_key)
		yield i
@Script.register
def check_myip(plugin):
	resp = getlink('https://redirector.googlevideo.com/report_mapping?di=no', 'https://www.google.com.vn/',-1)
	if resp is not None:
		Script.notify(__addonnoti__, resp.text)
	else:
		Script.notify(__addonnoti__, 'Không có dữ liệu')
@lru_cache
@Script.register
def settingaddon(plugin):
	executebuiltin('Addon.OpenSettings(plugin.video.vnmedia)')
@lru_cache
@Script.register
def deletecache(plugin):
	cache_cleanup(-1)
	remove_file('.urlquick.slite3')
	Script.notify(__addonnoti__, 'Đã xoá bộ nhớ đệm')