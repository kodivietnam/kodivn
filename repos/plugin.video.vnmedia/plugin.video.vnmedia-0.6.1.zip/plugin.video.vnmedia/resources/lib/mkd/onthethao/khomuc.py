from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from resources.lib.kedon import getlink, ifr_khomuc, qc, tb, stream, play_vnm
@Route.register
def index_khomuc(plugin, content_type='segment'):
	url = 'https://khomuc.tv/'
	resp = getlink(url, url, 5*60)
	soup = BeautifulSoup(resp.text, 'html.parser')
	episodes = soup.select('div#item-live-now- a.d-flex.flex-column.text-black.text-decoration-none')
	found = False
	if len(episodes) > 0:
		for episode in episodes:
			item = Listitem()
			linktrandau = episode.get('href')
			doinha = episode.select_one('div.d-flex.align-items-center.bg-white.px-3.py-3 span').text.strip()
			doikhach = episode.select_one('div.d-flex.align-items-center.bg-white.px-3.pb-3 span').text.strip()
			item.label = doinha + ' vs ' + doikhach
			item.art['thumb'] = 'https://s3.amazonaws.com/external_clips/users/532418/large/z3188512290769_8464b325761bec97227422f4e55c5958.jpg'
			item.art['fanart'] = 'https://s3.amazonaws.com/external_clips/users/532418/large/z3188512290769_8464b325761bec97227422f4e55c5958.jpg'
			item.set_callback(ifr_khomuc, linktrandau, item.label)
			yield item
	else:
		item3 = Listitem()
		linkmacdinh = stream(qc)
		item3.label = 'Đang cập nhật'
		item3.info['plot'] = tb
		item3.art['thumb'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.art['fanart'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.set_callback(play_vnm, linkmacdinh, item3.label, '')
		yield item3