from codequick import Route, Listitem, run
from datetime import datetime, timedelta, date
from resources.lib.kedon import qc, tb, getlink, stream, ace, play_vnm
from bs4 import BeautifulSoup
@Route.register
def index_highlights365(plugin, content_type='segment'):
	url = 'https://highlights365.com/broadcasts'
	resp = getlink(url, url, 15*60)
	soup = BeautifulSoup(resp.text, 'html.parser')
	episodes = soup.select('div.broadcast-item')
	for episode in episodes:
		item = Listitem()
		linktrans = episode.select('div.team-info a')
		for linktran in linktrans:
			link = linktran.get('href')
			ten = linktran.text
		times = episode.select('div.time')
		for time in times:
			timex = time.text
			if len(timex)==4:
				y = str(date.today())+'T0'+str(timex)
			else:
				y = str(date.today())+'T'+str(timex)
			z = (datetime.fromisoformat(y) + timedelta(hours=7)).strftime('%H:%M')
			item.label = z + ' ' + ten
			anh = episode.select_one('div.c-flag img').get('data-src')
			item.art["thumb"] = 'https:' + anh
			item.art["fanart"] = 'https://highlights365.com/static/images/highlights365/logo_header.png'
			item.set_callback(laylink_highlights365, 'https://highlights365.com' + link, item.label)
			yield item

@Route.register
def laylink_highlights365(plugin, url, ten):
	resp = getlink(url, url, 15*60)
	if 'acestream://' in resp.text:
		soup = BeautifulSoup(resp.text, 'html.parser')
		links = soup.select('div.link-list.acestream a')
		for link in links:
			item = Listitem()
			linktran = link.get('href')
			item.art['thumb'] = 'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg'
			item.art['fanart'] = 'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg'
			item.label = ten
			linkplay = ace(linktran, item.label)
			item.path = linkplay
			item.set_callback(item.path)
			yield item
	else:
		item3 = Listitem()
		linkmacdinh = stream(qc)
		item3.label = 'Đang cập nhật'
		item3.info['plot'] = tb
		item3.art['thumb'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.art['fanart'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.set_callback(play_vnm, linkmacdinh, item3.label, '')
		yield item3