from codequick import Route, Listitem, Resolver
from resources.lib.kedon import getlink, getlinkvnm, quangcao, fu, useragentweb, streamifr, referer
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote_plus
from bs4 import BeautifulSoup
from urllib.parse import urlparse
from requests import Session
from codequick.utils import italic
from functools import lru_cache
import re, sys
def phimmoi():
	url = 'https://phimmoiplus.net'
	r = getlink(url, url, 1000)
	try:
		v = urlparse(fu(r.url))
		return f'{v.scheme}://{v.netloc}'
	except:
		sys.exit()
def get_episode(url):
	r = getlink(url, url, 1000)
	return r
def get_info_phimmoi(x):
	r = getlinkvnm(x,x)
	try:
		soup = BeautifulSoup(r.content, 'html.parser')
		soups = soup.select('div.film-info')
		for k in soups:
			try:
				img = k.select_one('div.image img')['data-src']
			except:
				img = 'https://mi3s.top/thumb/phim/phimmoi.png'
			try:
				title = k.select_one('div.text h1').get_text(strip=True)
				name2 = k.select_one('div.text h2').get_text(strip=True)
				ten = f'{title} - {name2}'
			except:
				pass
			try:
				mota = k.select_one('div#film-content').get_text(strip=True)
			except:
				mota = ten
			return (ten, img, mota)
	except:
		return None
def process_url(url):
	try:
		data = get_info_phimmoi(url)
		return url, data
	except:
		return url, None
@Route.register
def search_phimmoi(plugin, search_query=None):
	yield []
	if search_query is None:
		pass
	else:
		try:
			pm = phimmoi()
			next_page = 1
			sr = quote_plus(search_query)
			url = f'{pm}/tim-kiem/{sr}'
			trangtiep = f'{url}/page-{next_page}'
			r = getlink(trangtiep, url, 1800)
			if (r is not None) and ('item small' in r.text):
				soup = BeautifulSoup(r.content, 'html.parser')
				soups = soup.select('div#binlist ul li.item')
				urls = [item.a['href'] for item in soups if (label_element := item.select_one('.label')) and not re.search(r'trailer', label_element.text, re.IGNORECASE)]
				length = len(urls)
				if length>0:
					with ThreadPoolExecutor(length) as ex:
						results = ex.map(process_url, urls)
					for (l, data) in results:
						if data is not None:
							item = Listitem()
							item.label = data[0]
							item.info['plot'] = data[2]
							item.info['mediatype'] = 'tvshow'
							item.art['thumb'] = item.art['poster'] = data[1]
							item.set_callback(episode_phimmoi, l, data[0], data[2], data[1])
							yield item
					if f'/page-{str(int(next_page) + 1)}' in r.text:
						item1 = Listitem()
						item1.label = f'Trang {str(int(next_page) + 1)}'
						item1.info['mediatype'] = 'tvshow'
						item1.art['thumb'] = item1.art['poster'] = 'https://mi3s.top/thumb/next.png'
						item1.set_callback(ds_phimmoi, url, next_page + 1)
						yield item1
			else:
				yield quangcao()
		except:
			yield quangcao()
@lru_cache
@Route.register
def index_phimmoi(plugin):
	pm = phimmoi()
	yield Listitem.search(search_phimmoi)
	T = {'Thể loại': phimmoi_tl,
	'Quốc gia': phimmoi_qg}
	dulieu = {
	'Phim thịnh hành': f'{pm}/list/phim-hot',
	'Phim bộ': f'{pm}/list/phim-bo',
	'Phim lẻ': f'{pm}/list/phim-le',
	'Phim HD': f'{pm}/list/phim-hd',
	'Chiếu rạp': f'{pm}/genre/phim-chieu-rap',
	'TOP IMDB': f'{pm}/list/top-imdb',
	'Netflix': f'{pm}/list/phim-netflix',
	'Thuyết minh': f'{pm}/genre/phim-thuyet-minh',
	'Hoạt hình': f'{pm}/genre/phim-hoat-hinh'
	}
	for b in T:
		i = Listitem()
		i.label = b
		i.info['mediatype'] = 'tvshow'
		i.art['thumb'] = i.art['poster'] = 'https://mi3s.top/thumb/phim/phimmoi.png'
		i.set_callback(T[b])
		yield i
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.info['mediatype'] = 'tvshow'
		item.art['thumb'] = item.art['poster'] = 'https://mi3s.top/thumb/phim/phimmoi.png'
		item.set_callback(ds_phimmoi, dulieu[k], 1)
		yield item
@lru_cache
@Route.register
def phimmoi_tl(plugin):
	pm = phimmoi()
	dulieu = {
	'Hành động': f'{pm}/genre/phim-hanh-dong',
	'Võ thuật': f'{pm}/genre/phim-vo-thuat',
	'Tình cảm': f'{pm}/genre/phim-tinh-cam',
	'Tâm lý': f'{pm}/genre/phim-tam-ly',
	'Hài': f'{pm}/genre/phim-hai-huoc',
	'Hoạt hình': f'{pm}/genre/phim-hoat-hinh',
	'Anime': f'{pm}/genre/phim-anime',
	'Phiêu lưu': f'{pm}/genre/phim-phieu-luu',
	'Kinh dị': f'{pm}/genre/phim-ma-kinh-di',
	'Hình sự': f'{pm}/genre/phim-hinh-su',
	'Chiến tranh': f'{pm}/genre/phim-chien-tranh',
	'Thần thoại': f'{pm}/genre/phim-than-thoai',
	'Viễn tưởng': f'{pm}/genre/phim-vien-tuong',
	'Cổ trang': f'{pm}/genre/phim-co-trang',
	'Âm nhạc': f'{pm}/genre/phim-am-nhac',
	'Thể thao': f'{pm}/genre/phim-the-thao',
	'Truyền hình': f'{pm}/genre/phim-truyen-hinh',
	'TV Show': f'{pm}/genre/game-show',
	'Khoa học': f'{pm}/genre/phim-khoa-hoc'
	}
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.info['mediatype'] = 'tvshow'
		item.art['thumb'] = item.art['poster'] = 'https://mi3s.top/thumb/phim/phimmoi.png'
		item.set_callback(ds_phimmoi, dulieu[k], 1)
		yield item
@lru_cache
@Route.register
def phimmoi_qg(plugin):
	pm = phimmoi()
	dulieu = {
	'Âu Mỹ': f'{pm}/country/phim-au-my',
	'Hàn Quốc': f'{pm}/country/phim-han-quoc',
	'Trung Quốc': f'{pm}/country/phim-trung-quoc',
	'Hồng Kông': f'{pm}/country/phim-hong-kong',
	'Đài Loan': f'{pm}/country/phim-dai-loan',
	'Nhật Bản': f'{pm}/country/phim-nhat-ban',
	'Ấn Độ': f'{pm}/country/phim-an-do',
	'Thái Lan': f'{pm}/country/phim-thai-lan',
	'Nước Khác': f'{pm}/country/phim-tong-hop'
	}
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.info['mediatype'] = 'tvshow'
		item.art['thumb'] = item.art['poster'] = 'https://mi3s.top/thumb/phim/phimmoi.png'
		item.set_callback(ds_phimmoi, dulieu[k], 1)
		yield item
@Route.register
def ds_phimmoi(plugin, url=None, next_page=None):
	yield []
	if any((url is None,next_page is None)):
		pass
	else:
		try:
			trangtiep = f'{url}/page-{next_page}'
			r = getlink(trangtiep, trangtiep, 1000)
			if (r is not None) and ('item small' in r.text):
				soup = BeautifulSoup(r.content, 'html.parser')
				soups = soup.select('div#binlist ul li.item')
				urls = [item.a['href'] for item in soups if (label_element := item.select_one('.label')) and not re.search(r'trailer', label_element.text, re.IGNORECASE)]
				length = len(urls)
				if length>0:
					with ThreadPoolExecutor(length) as ex:
						results = ex.map(process_url, urls)
					for (l, data) in results:
						if data is not None:
							item = Listitem()
							item.label = data[0]
							item.info['plot'] = data[2]
							item.info['mediatype'] = 'tvshow'
							item.art['thumb'] = item.art['poster'] = data[1]
							item.set_callback(episode_phimmoi, l, data[0], data[2], data[1])
							yield item
					if f'/page-{str(int(next_page) + 1)}' in r.text:
						item1 = Listitem()
						item1.label = f'Trang {str(int(next_page) + 1)}'
						item1.info['mediatype'] = 'tvshow'
						item1.art['thumb'] = item1.art['poster'] = 'https://mi3s.top/thumb/next.png'
						item1.set_callback(ds_phimmoi, url, str(int(next_page) + 1))
						yield item1
			else:
				yield quangcao()
		except:
			yield quangcao()
@Route.register
def episode_phimmoi(plugin, url=None, title=None, info=None, img=None):
	yield []
	if any((url is None,title is None,info is None,img is None)):
		pass
	else:
		try:
			with ThreadPoolExecutor(2) as ex:
				f1 = ex.submit(phimmoi)
				f2 = ex.submit(get_episode, url)
				pm = f1.result()
				r = f2.result()
			if (r is not None) and 'btn-see' in r.text:
				if 'youtube.com/watch?v=' in r.text:
					idvd = re.search(r'youtube\.com/watch\?v=([a-zA-Z0-9_-]+)', r.text)[1]
					item1 = Listitem()
					item1.label = f'TRAILER: {italic(title)}'
					item1.info['mediatype'] = 'episode'
					item1.art['thumb'] = item1.art['poster'] = f'https://i.ytimg.com/vi/{idvd}/sddefault.jpg'
					item1.set_path(f'plugin://plugin.video.youtube/play/?video_id={idvd}')
					yield item1
				soupx = BeautifulSoup(r.content, 'html.parser')
				urlplay = soupx.select_one('ul a.btn-see')['href']
				resp = getlink(urlplay, url, 1000)
				if (resp is not None):
					if 'list_episodes' in resp.text:
						soup = BeautifulSoup(resp.content, 'html.parser')
						soups = soup.select('ul.episodes a')
						for e in soups:
							item = Listitem()
							episode_number = e.get_text(strip=True)
							episode_link = e['href']
							tenm = f"{episode_number} - {title}"
							item.label = tenm
							item.info['mediatype'] = 'tvshow'
							item.info['plot'] = info
							item.art['thumb'] = item.art['poster'] = img
							item.set_callback(play_phimmoi, episode_link, tenm, info, img)
							yield item
					else:
						item = Listitem()
						tenm = f'Tập Full - {title}'
						item.label = tenm
						item.info['mediatype'] = 'tvshow'
						item.info['plot'] = info
						item.art['thumb'] = item.art['poster'] = img
						item.set_callback(play_phimmoi, urlplay, tenm, info, img)
						yield item
				else:
					yield quangcao()
			else:
				yield quangcao()
		except:
			yield quangcao()
@Route.register
def play_phimmoi(plugin, url=None, title=None, info=None, img=None):
	yield []
	if any((url is None,title is None,info is None,img is None)):
		pass
	else:
		try:
			pm = phimmoi()
			matches = re.search(r'pm(\d+)', url)
			data = {'qcao': f'{matches[1]}'}
			headers = {'Referer':url,'User-Agent':useragentweb,'X-Requested-With':'XMLHttpRequest'}
			with Session() as s:
				try:
					r = s.post(f'{pm}/chillsplayer.php', data=data,headers=headers, timeout=20)
				except:
					r = s.post(f'{pm}/chillsplayer.php', data=data,headers=headers, timeout=20, verify=False)
			key = re.search(r'iniPlayers\("([^"]+)"', r.text)[1]
			dulieu = {
			'BN1': f'https://so-trym.idpm.xyz/raw/{key}/index.m3u8',
			'BN2': f'https://so-trym.idpm.xyz/dash/{key}/index.m3u8',
			'PMFAST': f'https://sotrim.topphimmoi.org/raw/{key}/index.m3u8',
			'PMHLS': f'https://so-trym.phimchill.net/raw/{key}/index.m3u8',
			'PMPRO': f'https://so-trym.topphimmoi.org/raw/{key}/index.m3u8',
			'PMBK': f'https://so-trym.phimchill.net/dash/{key}/index.m3u8'
			}
			for k in dulieu:
				tenm = f'{k} - {italic(title)}'
				item = Listitem()
				item.label = tenm
				item.info['mediatype'] = 'episode'
				item.info['plot'] = info
				item.art['thumb'] = item.art['poster'] = img
				item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), f'{streamifr(dulieu[k])}{referer(url)}', tenm)
				yield item
		except:
			yield quangcao()