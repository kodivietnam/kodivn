root = None
menu = {
    'fshare': {
        'route': '/resources/lib/mkd/fshare:index_fshare',
        'label': 'Fshare',
        'thumb': 'https://i.imgur.com/XB3HOOe.png',
        'enabled': True,
        'order': 1
    },
    'ytube': {
        'route': '/resources/lib/mkd/ytube:index_youtube',
        'label': 'Youtube',
        'thumb': 'https://i.imgur.com/0oHqiU3.png',
        'enabled': True,
        'order': 2
    },
    'truyenhinh': {
        'route': '/resources/lib/mkd/truyenhinh:listiptv_root',
        'label': 'Truyền hình',
        'thumb': 'https://i.imgur.com/Mnuw95h.png',
        'enabled': True,
        'order': 3
    },
    'thethao': {
        'route': '/resources/lib/main:generic_menu',
        'label': 'Thể thao',
        'thumb': 'https://i.imgur.com/x0V60BO.png',
        'enabled': True,
        'order': 4
    },
    'tintuc': {
        'route': '/resources/lib/mkd/tintuc:index_tintuc',
        'label': 'Tin tức',
        'thumb': 'https://i.imgur.com/IJJJb8W.png',
        'enabled': True,
        'order': 5
    },
    'amnhac': {
        'route': '/resources/lib/mkd/nhac:index_amnhac',
        'label': 'Âm nhạc',
        'thumb': 'https://i.imgur.com/pHbuVqt.png',
        'enabled': True,
        'order': 6
    },
    'thieunhi': {
        'route': '/resources/lib/mkd/thieunhi:index_thieunhi',
        'label': 'Thiếu nhi',
        'thumb': 'https://i.imgur.com/R6ftjs5.png',
        'enabled': True,
        'order': 7
    },
    'giaitri': {
        'route': '/resources/lib/mkd/giaitri:index_giaitri',
        'label': 'Giải trí',
        'thumb': 'https://i.imgur.com/Rq40MYZ.png',
        'enabled': True,
        'order': 8
    },
    'tienich': {
        'route': '/resources/lib/mkd/tienich:index_tienich',
        'label': 'Tiện ích',
        'thumb': 'https://i.imgur.com/EKNGDtp.png',
        'enabled': True,
        'order': 9
    }
}