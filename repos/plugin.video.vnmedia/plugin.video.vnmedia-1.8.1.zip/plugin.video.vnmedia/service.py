def autorun_addon():
    import xbmc, xbmcaddon
    xbmc.executebuiltin('UpdateAddonRepos()')
    if xbmcaddon.Addon().getSetting('auto_run') == 'true':
        xbmc.executebuiltin('RunAddon(plugin.video.vnmedia)')
    return
autorun_addon()