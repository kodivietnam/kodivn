from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from resources.lib.kedon import getlink, ifr_xoilac
@Route.register
def index_xoilacco(plugin, content_type='segment'):
	url = 'http://www.xoilac.co/'
	resp = getlink(url, url, 15*60)
	soup = BeautifulSoup(resp.text, 'html.parser')
	episodes = soup.select('a.redirectPopup')
	for episode in episodes:
		item = Listitem()
		linktrandau = episode.get('href')
		item.label = episode.get('title')
		item.art['thumb'] = 'https://media.cdnandroid.com/item_images/1139044/imagen-xoilac-tv-xem-bong-da-tivi-truc-tuyen-0big.jpg'
		item.art['fanart'] = 'https://media.cdnandroid.com/item_images/1139044/imagen-xoilac-tv-xem-bong-da-tivi-truc-tuyen-0big.jpg'
		item.set_callback(list_xoilacco, linktrandau, item.label)
		yield item

@Route.register
def list_xoilacco(plugin, url, title):
	resp = getlink(url, url, 0)
	soup = BeautifulSoup(resp.text, 'html.parser')
	episodes = soup.select('div[id="tv_links"] a')
	found = False
	if len(episodes) > 1:
		for episode in episodes:
			item1 = Listitem()
			linktrandau1 = episode.get('href')
			if url in linktrandau1:
				item1.label = episode.text.strip() + ' - ' + title
				item1.art['thumb'] = 'https://media.cdnandroid.com/item_images/1139044/imagen-xoilac-tv-xem-bong-da-tivi-truc-tuyen-0big.jpg'
				item1.art['fanart'] = 'https://media.cdnandroid.com/item_images/1139044/imagen-xoilac-tv-xem-bong-da-tivi-truc-tuyen-0big.jpg'
				item1.set_callback(ifr_xoilac, linktrandau1, item1.label)
				yield item1
	if not found:
		item2 = Listitem()
		item2.label = 'Default - ' + title
		item2.art['thumb'] = 'https://media.cdnandroid.com/item_images/1139044/imagen-xoilac-tv-xem-bong-da-tivi-truc-tuyen-0big.jpg'
		item2.art['fanart'] = 'https://media.cdnandroid.com/item_images/1139044/imagen-xoilac-tv-xem-bong-da-tivi-truc-tuyen-0big.jpg'
		item2.set_callback(ifr_xoilac, url, item2.label)
		yield item2