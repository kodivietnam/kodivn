from codequick import Route, Listitem, run
from resources.lib.kedon import quangcao, getlink, stream, referer, play_vnm
from bs4 import BeautifulSoup
urlmm = 'http://segay.link/'
linkweb = getlink(urlmm, urlmm, 5*60).url
@Route.register
def index_segay(plugin, **kwargs):
	url = 'https://s3.zencdn.xyz/static/json/common/live.json'
	r = getlink(url, url, 5*60)
	if 'link' in r.text:
		kq = r.json()
		for k in kq:
			item = Listitem()
			linktrandau = '%s%s' % (linkweb, k['link'])
			if k['cmt']:
				item.label = '%s: %s - BLV %s' % (k['time'], k['title'], k['cmt'])
			else:
				item.label = '%s: %s' % (k['time'], k['title'])
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = '%s%s' % (linkweb, k['cover'])
			item.set_callback(list_segay, linktrandau, item.label)
			yield item
	else:
		yield quangcao()
@Route.register
def list_segay(plugin,url,title, **kwargs):
	r = getlink(url, url, 15*60)
	if '.m3u8' in r.text:
		soup = BeautifulSoup(r.content, 'html.parser')
		episodes = soup.select('video-js source')
		for episode in episodes:
			item = Listitem()
			ten = episode.get('sl')
			linktran = episode.get('src')
			linktrandau = '%s%s' % (stream(linktran), referer(linkweb))
			item.label = '%s-%s' % (ten, title)
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = '%s/wp-content/themes/v2.1/assets/images/logo_sg_3.png' % linkweb
			item.set_callback(play_vnm, linktrandau, item.label, '')
			yield item
	else:
		yield quangcao()