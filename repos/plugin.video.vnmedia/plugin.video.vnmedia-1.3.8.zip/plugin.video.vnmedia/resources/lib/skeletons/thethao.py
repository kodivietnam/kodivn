root = 'root'
menu = {'vnmsport': {
        'route': '/resources/lib/mkd/onthethao/vnm:index_vnm',
        'label': 'SỰ KIỆN TRỰC TIẾP',
        'thumb': 'https://png.pngtree.com/png-clipart/20210710/ourlarge/pngtree-d-logo-live-broadcast-bold-style-with-play-button-isolated-on-png-image_3582566.jpg',
        'enabled': True,
        'order': 1
        },
        'tinthethao': {
        'route': '/resources/lib/mkd/onthethao/tinthethao:index_tinthethao',
        'label': 'Tin thể thao',
        'thumb': 'https://thethao360.tv/wp-content/uploads/2020/12/logo-3.png',
        'enabled': True,
        'order': 2
        },
        'acest': {
        'route': '/resources/lib/mkd/acest:index_acestream',
        'label': 'Nhóm ACESTREAM',
        'thumb': 'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg',
        'enabled': True,
        'order': 3
        },
        'cvace': {
        'route': '/resources/lib/mkd/onthethao/cvace:index_cvaceplus',
        'label': 'CVmedia',
        'thumb': 'https://cdn.hqth.me/cvmedia.png',
        'enabled': True,
        'order': 4
        },
        'phut901': {
        'route': '/resources/lib/mkd/onthethao/phut90:index_90p',
        'label': '90PHUT.TV',
        'thumb': 'https://i.imgur.com/jyM3inb.png',
        'enabled': True,
        'order': 5
        },
        'phut902': {
        'route': '/resources/lib/mkd/onthethao/phut90tv:index_90ptv',
        'label': 'NGUYENHOAI TV',
        'thumb': 'https://i.imgur.com/jyM3inb.png',
        'enabled': True,
        'order': 6
        },
        'phut903': {
        'route': '/resources/lib/mkd/onthethao/tbsport:index_tbsport',
        'label': 'TUBIEN TV',
        'thumb': 'https://i.imgur.com/jyM3inb.png',
        'enabled': True,
        'order': 7
        },
        'vebo': {
        'route': '/resources/lib/mkd/onthethao/vebo:index_vebo',
        'label': 'VEBO.TOP',
        'thumb': 'https://vebotv.site/static/img/logo.png',
        'enabled': True,
        'order': 8
        },
        'xoilacxyz': {
        'route': '/resources/lib/mkd/onthethao/xoilacxyz:index_xoilacxyz',
        'label': 'XOILAC.XYZ',
        'thumb': 'https://90phut3.live/images/logo-xoilac.png',
        'enabled': True,
        'order': 9
        },
        'binhluan': {
        'route': '/resources/lib/mkd/onthethao/binhluan:index_binhluan',
        'label': 'BINHLUANTV',
        'thumb': 'https://binhluan.90phut3.live/imgs/logo.png',
        'enabled': True,
        'order': 10
        },
        'socolive': {
        'route': '/resources/lib/mkd/onthethao/socolive:index_socolive',
        'label': 'SOCOLIVE.ORG',
        'thumb': 'https://sta.cvndnss.com/web/assets/soco/img/logo2.png',
        'enabled': True,
        'order': 11
        },
        'cakhia': {
        'route': '/resources/lib/mkd/onthethao/cakhia:index_cakhia',
        'label': 'CAKHIA TV',
        'thumb': 'https://i.imgur.com/TTprlUP.png',
        'enabled': True,
        'order': 12
        },
        'rakhoi': {
        'route': '/resources/lib/mkd/onthethao/rakhoi:index_rakhoi',
        'label': 'RA KHOI TV',
        'thumb': 'https://i.imgur.com/8tEAlqc.png',
        'enabled': True,
        'order': 13
        },
        'caheo': {
        'route': '/resources/lib/mkd/onthethao/caheo:index_caheo',
        'label': 'CAHEO.TV',
        'thumb': 'https://i.imgur.com/KdSuVMn.png',
        'enabled': True,
        'order': 14
        },
        'saoke': {
        'route': '/resources/lib/mkd/onthethao/saoke:index_saoke',
        'label': 'SAOKE.LIVE',
        'thumb': 'https://9767a59e2b.vws.vegacdn.vn/template/logo1.png',
        'enabled': True,
        'order': 15
        },
        'mannhan': {
        'route': '/resources/lib/mkd/onthethao/mannhan:index_mannhan',
        'label': 'MANNHAN.LIVE',
        'thumb': 'https://1966649973.slave.anycastapnic.com/template/public/img/logo.png',
        'enabled': True,
        'order': 16
        },
        'xembd': {
        'route': '/resources/lib/mkd/onthethao/xembd:index_xembd',
        'label': 'XEMBD.LIVE',
        'thumb': 'https://xembd.link/wp-content/themes/xbd/assets/images/logo.png',
        'enabled': True,
        'order': 17
        },
        'cakhiaorg': {
        'route': '/resources/lib/mkd/onthethao/cakhiaorg:index_cakhiaorg',
        'label': 'CAKHIA.ORG',
        'thumb': 'https://cakhia.org/wp-content/themes/v2.1/assets/images/logo_cakhia_2.png',
        'enabled': True,
        'order': 18
        },
        'xoilac3': {
        'route': '/resources/lib/mkd/onthethao/xoilac3:index_xoilac3',
        'label': 'XOILAC3.LIVE',
        'thumb': 'https://xoilac3.live/wp-content/uploads/2022/06/logo-xoilac-tv-1.jpg',
        'enabled': True,
        'order': 19
        },
        'segay': {
        'route': '/resources/lib/mkd/onthethao/segay:index_segay',
        'label': 'SEGAY.TV',
        'thumb': 'https://segay.tv/wp-content/themes/v2.1/assets/images/logo_sg_3.png',
        'enabled': True,
        'order': 20
        },
        'khomuc': {
        'route': '/resources/lib/mkd/onthethao/khomuc:index_khomuc',
        'label': 'KHOMUC.TV',
        'thumb': 'https://khomuc3.com/wp-content/uploads/2021/11/cropped-logo-website-khomuc.jpg',
        'enabled': True,
        'order': 21
        },
        'vebolive': {
        'route': '/resources/lib/mkd/onthethao/vebolive:index_vebolive',
        'label': 'VEBO.LIVE',
        'thumb': 'https://vebo1.tv/wp-content/themes/bongda/public/images/logo.png',
        'enabled': True,
        'order': 22
        },
        'xoilac7': {
        'route': '/resources/lib/mkd/onthethao/xoilac7:index_xoilac7',
        'label': 'XOILAC8.NET',
        'thumb': 'https://xoilac8.net/wp-content/themes/bongda/dist/images/xoilac8.net.png',
        'enabled': True,
        'order': 23
        },
        'phut91': {
        'route': '/resources/lib/mkd/onthethao/phut91:index_91phut',
        'label': '91PHUTZ.NET',
        'thumb': 'https://91phutz.net/wp-content/themes/bongda2/dist/images/91phutz.net.png',
        'enabled': True,
        'order': 24
        },
        'tructiepdabong': {
        'route': '/resources/lib/mkd/onthethao/tructiepdabong:index_ttdb',
        'label': 'TRUCTIEPDABONG.NET',
        'thumb': 'https://tructiepdabong1.com/themes/frontend/default/img/tructiepdabong.png',
        'enabled': True,
        'order': 25
        },
        'xembong': {
        'route': '/resources/lib/mkd/onthethao/xembong:index_xembong',
        'label': 'XEMBONGDA.NET',
        'thumb': 'https://xembong.pro/themes/frontend/default/img/logo.png',
        'enabled': True,
        'order': 26
        },
        'vaoroi': {
        'route': '/resources/lib/mkd/onthethao/vaoroi:index_vaoroi',
        'label': 'VAOROI.CO',
        'thumb': 'https://vaoroi5.com/themes/frontend/default/img/vaoroi-logo.png',
        'enabled': True,
        'order': 27
        },
        'bongdat': {
        'route': '/resources/lib/mkd/onthethao/bongdat:index_bongdat',
        'label': 'BONGDAT.FUN',
        'thumb': 'http://ketquaxosotoancau.org/static/image/vnlogo.png',
        'enabled': True,
        'order': 28
        },
        'cauthu': {
        'route': '/resources/lib/mkd/onthethao/cauthu:index_cauthu',
        'label': 'CAUTHU.TV',
        'thumb': 'https://cauthu.tv/wp-content/uploads/2022/06/cauthu_tv_logo.png',
        'enabled': True,
        'order': 29
        },
        'cauthuonline': {
        'route': '/resources/lib/mkd/onthethao/cauthuonline:index_cauthuonline',
        'label': 'CAUTHUTV.ONLINE',
        'thumb': 'https://cauthutv.online/wp-content/uploads/2022/07/cauthu_tv_logo.png',
        'enabled': True,
        'order': 30
        },
        'nocnha': {
        'route': '/resources/lib/mkd/onthethao/nocnha:index_nocnha',
        'label': 'NOCNHA.TV',
        'thumb': 'https://nocnha1.tv/wp-content/uploads/2022/02/logo-NOC-NHA-2.png',
        'enabled': True,
        'order': 31
        }
            }