from codequick import Script, Route, Listitem, Resolver
from importlib import import_module
from concurrent.futures import ThreadPoolExecutor
from xbmcgui import DialogProgress
from urllib.parse import quote_plus
from xbmcaddon import Addon
from json import loads
import re
def get_tkfs1(search_query):
	urlvmf = f'http://phongblack.me/search.php?author=phongblack&search={search_query}'
	respvmf = import_module('resources.lib.kedon').getlinkphongblack(urlvmf, 'http://www.google.com', 21600)
	return respvmf
def get_tkfs2(search_query):
	url = f'https://api.timfshare.com/v1/string-query-search?query={search_query}'
	resp = import_module('resources.lib.kedon').postlinktimfs(url, 'https://timfshare.com/', 21600)
	return resp
@Route.register
def searchfs(plugin, search_query, **kwargs):
	w = import_module('resources.lib.kedon')
	dp = DialogProgress()
	dp.create(w.__addonnoti__, 'Đang lấy dữ liệu...')
	search_query = quote_plus(search_query)
	with ThreadPoolExecutor(3) as ex:
		f1 = ex.submit(get_tkfs1, search_query)
		f2 = ex.submit(get_tkfs2, search_query)
	dp.update(50)
	try:
		sre = re.compile('[\[\]\{\}]')
		x = f1.result().json()['items']
		for m in x:
			item = Listitem()
			ten = sre.sub('|', m['label'])
			if 'info' in m:
				mota = m['info']['plot']
			path = m['path']
			if '/file/' in path:
				item.label = ten
				link = path.split('&url=')[1]
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = w.yttk(item.label)
				item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={path.split("&url=")[1]}&qzone=1&margin=1&size=400x400&ecc=L'
				item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item.info['plot'] = f'{mota}\n{w.tb}'
				if Addon().getSetting('taifshare') == 'true':
					item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', link)
				item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
				item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), link, item.label)
				yield item
			elif '/folder/' in path:
				item.label = ten
				link = path.split("&url=")[1]
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = w.yttk(item.label)
				item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={path.split("&url=")[1]}&qzone=1&margin=1&size=400x400&ecc=L'
				item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item.info['plot'] = f'{mota}\n{w.tb}'
				item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
				item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), link.split("folder/")[1], 1)
				yield item
	except:
		try:
			kq = f2.result().json()
			if 'data' in kq:
				for k in kq['data']:
					item = Listitem()
					if 'folder' in k['url']:
						item.label = k['name']
						item.info['plot'] = w.tb
						item.info['mediatype'] = 'episode'
						item.info['rating'] = 10.0
						item.info['trailer'] = w.yttk(item.label)
						item.art['thumb'] = item.art['landscape'] = f"https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={k['url']}&qzone=1&margin=1&size=400x400&ecc=L"
						item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
						item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', k['url'])
						item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), k['url'].split('folder/')[1], 1)
						yield item
					elif 'file' in k['url']:
						item.label = k['name']
						item.info['plot'] = w.tb
						item.info['size'] = k['size']
						item.info['mediatype'] = 'episode'
						item.info['rating'] = 10.0
						item.info['trailer'] = w.yttk(item.label)
						item.art['thumb'] = item.art['landscape'] = f"https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={k['url']}&qzone=1&margin=1&size=400x400&ecc=L"
						item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
						if Addon().getSetting('taifshare') == 'true':
							item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', k['url'])
						item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', k['url'])
						item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), k['url'], item.label)
						yield item
		except:
			pass
	dp.update(100)
	dp.close()
@Route.register
def index_pdx(plugin, **kwargs):
	w = import_module('resources.lib.kedon')
	urltvhd = 'https://thuvienhd.com/?feed=fsharejson&search='
	resptvhd = w.getlink(urltvhd, 'https://thuvienhd.com/', 3600)
	try:
		kqtvhd = resptvhd.json()
		for dem, t in enumerate(kqtvhd):
			item = Listitem()
			item.label = t['title']
			item.info['plot'] = f'{t["title"]}\n{w.tb}'
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = w.yttk(item.label)
			item.art['thumb'] = item.art['landscape'] = t['image']
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			item.set_callback(timnhanhfs, dem, '')
			yield item
	except:
		text = resptvhd.text
		data = re.sub('<(.*?)\n','',text)
		jsm = loads(data)
		for dem, t in enumerate(jsm):
			item = Listitem()
			item.label = t['title']
			item.info['plot'] = f'{t["title"]}\n{w.tb}'
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = w.yttk(item.label)
			item.art['thumb'] = item.art['landscape'] = t['image']
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			item.set_callback(timnhanhfs, dem, '')
			yield item
@Route.register
def timnhanhfs(plugin, dem, tukhoa):
	w = import_module('resources.lib.kedon')
	urltvhd = f'https://thuvienhd.com/?feed=fsharejson&search={tukhoa}'
	resptvhd = w.getlink(urltvhd, 'https://thuvienhd.com/', 3600)
	try:
		kqtvhd = resptvhd.json()
		for t in kqtvhd[dem]['links']:
			item = Listitem()
			if 'folder' in t['link']:
				item.label = t['title']
				item.info['plot'] = w.tb
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = w.yttk(item.label)
				item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={t["link"]}&qzone=1&margin=1&size=400x400&ecc=L'
				item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', t['link'])
				item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), t['link'].split('folder/')[1], 1)
				yield item
			elif 'file' in t['link']:
				item.label = t['title']
				item.info['plot'] = w.tb
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = w.yttk(item.label)
				item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={t["link"]}&qzone=1&margin=1&size=400x400&ecc=L'
				item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				if Addon().getSetting('taifshare') == 'true':
					item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', t['link'])
				item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', t['link'])
				item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), t['link'], item.label)
				yield item
	except:
		text = resptvhd.text
		data = re.sub('<(.*?)\n','',text)
		jsm = loads(data)
		for t in jsm[dem]['links']:
			item = Listitem()
			if 'folder' in t['link']:
				item.label = t['title']
				item.info['plot'] = w.tb
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = w.yttk(item.label)
				item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={t["link"]}&qzone=1&margin=1&size=400x400&ecc=L'
				item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', t['link'])
				item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), t['link'].split('folder/')[1], 1)
				yield item
			elif 'file' in t['link']:
				item.label = t['title']
				item.info['plot'] = w.tb
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = w.yttk(item.label)
				item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={t["link"]}&qzone=1&margin=1&size=400x400&ecc=L'
				item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				if Addon().getSetting('taifshare') == 'true':
					item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', t['link'])
				item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', t['link'])
				item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), t['link'], item.label)
				yield item