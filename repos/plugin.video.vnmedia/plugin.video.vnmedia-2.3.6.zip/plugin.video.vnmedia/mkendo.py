from codequick import run
from importlib import import_module
def main():
    exception = run()
    if isinstance(exception, Exception):
        main = import_module('resources.lib.main')
        main.error_handler(exception)
if __name__ == '__main__':
    main()