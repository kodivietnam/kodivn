from codequick import Route, Listitem, run
from resources.lib.kedon import userpassfs
from resources.lib.mkd.onfshare.codenumber import searchnumber
from resources.lib.mkd.onfshare.ifshare import fs_favorite, fs_topfollow
from resources.lib.mkd.onfshare.thuvienhd import index_thuvienhd
from resources.lib.mkd.onfshare.timfshare import searchfs
from resources.lib.mkd.onfshare.thuviencine import index_thuviencine
@Route.register
def index_fshare(plugin, content_type='segment'):
	Fsharefavorite = {'label': 'Fshare Favorite',
	'info':{'plot':'Yêu thích'},
	'art':{'thumb':'https://banner2.cleanpng.com/20180319/ikq/kisspng-heart-love-brand-logo-favourites-5ab0468bbe3665.1130427115215018357791.jpg',
	'fanart':'https://fsharetv.com/img/fsharetv.png'},
	'callback':fs_favorite}
	Fsharefollow = {'label': 'TOP FSHARE',
	'info':{'plot':'Top 15 thư mục theo dõi nhiều nhất'},
	'art':{'thumb':'https://www.fshare.vn/images/top-follow/title.png',
	'fanart':'https://fsharetv.com/img/fsharetv.png'},
	'callback':fs_topfollow}
	Thuvienhdp = {'label': 'Thư viện HD',
	'info':{'plot':'Thư viện dữ liệu phim Fshare'},
	'art':{'thumb':'https://thuvienhd.com/wp-content/uploads/2020/10/THUVIENHD.NET_.png',
	'fanart':'https://fsharetv.com/img/fsharetv.png'},
	'callback':index_thuvienhd}
	Thuviencinep = {'label': 'Thư viện Cine',
	'info':{'plot':'Thư viện dữ liệu phim Fshare'},
	'art':{'thumb':'https://thuviencine.com/wp-content/uploads/2021/09/logo-red.png',
	'fanart':'https://fsharetv.com/img/fsharetv.png'},
	'callback':index_thuviencine}
	item1 = Listitem()
	item1.label = 'Play NumberCode'
	item1.info['plot'] = 'Mã CODE được tạo từ trang rút gọn http://gg.gg'
	item1.path = searchnumber
	item1.art['thumb'] = 'https://reference.vn/wp-content/uploads/2019/04/lic-su-so-tu-nhien.jpg'
	item1.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
	item1.set_callback(searchnumber, item1.path)
	yield Listitem.search(searchfs)
	yield item1
	yield Listitem.from_dict(**Fsharefavorite)
	yield Listitem.from_dict(**Fsharefollow)
	yield Listitem.from_dict(**Thuvienhdp)
	yield Listitem.from_dict(**Thuviencinep)