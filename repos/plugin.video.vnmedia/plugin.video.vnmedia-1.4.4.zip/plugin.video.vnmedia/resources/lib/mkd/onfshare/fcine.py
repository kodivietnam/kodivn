from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from resources.lib.kedon import useragent, getlink, play_fs, __addonnoti__, __addon__
from resources.lib.mkd.onfshare.ifshare import index_fs, loginfcine, tfavo
from resources.lib.download import downloadfs
import urlquick, xbmcgui, urllib

@Route.register
def search_fcine(plugin,search_query, **kwargs):
	dp = xbmcgui.DialogProgress()
	dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
	dp.update(0)
	search_query = urllib.parse.quote_plus(search_query)
	url = 'https://fcine.net/findContent/?app=videobox&module=video&controller=quicksearch&do=autoSearch'
	payload = {'term': search_query}
	headx = {'user-agent': useragent,
	'x-requested-with': 'XMLHttpRequest',
	'referer': 'https://fcine.net/findContent/',
	'content-type': 'application/x-www-form-urlencoded; charset=UTF-8'}
	r = urlquick.post(url, data=urllib.parse.urlencode(payload, quote_via=urllib.parse.quote), headers=headx, max_age=2*60*60)
	soup = BeautifulSoup(r.content, 'html.parser')
	episodes = soup.select('li.ipsClearfix')
	for episode in episodes:
		item = Listitem()
		linkphim = episode.select_one('a').get('href')
		item.label = episode.select_one('a').get('title')
		item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = episode.select_one('img').get('src')
		item.set_callback(fcine_link, linkphim)
		yield item
	dp.update(100)
	dp.close()

@Route.register
def index_fcine(plugin, **kwargs):
	yield Listitem.search(search_fcine)
	url = 'https://fcine.net'
	r = getlink(url,url,2*24*60*60)
	soup = BeautifulSoup(r.content, 'html.parser')
	episodes = soup.select('div.col1 a')
	for episode in episodes:
		item = Listitem()
		next_page = 1
		linkphim = '%s?alphabet=all&page=%s' % (episode.get('href'), next_page)
		item.label = episode.get_text()
		item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://fcine.net/uploads/monthly_2019_07/FCINE-LOGO.png.6e9c546f90ccb1b61c0502769b3fe1e8.png'
		item.set_callback(fcine_page, linkphim, next_page)
		yield item

@Route.register
def fcine_page(plugin, url, next_page, **kwargs):
	trangtiep = '%s?alphabet=all&page=%s' % (url, next_page)
	r = getlink(trangtiep, trangtiep, 6*60*60)
	soup = BeautifulSoup(r.content, 'html.parser')
	episodes = soup.select('div.esnList div.esnList_item_border.vbGrid')
	for episode in episodes:
		item = Listitem()
		tenx = episode.select('li.ipsDataItem.ipsPad_half.ipsType_center a')
		for ten in tenx:
			if 'view' in ten.get('href'):
				item.label = ten.get('title')
		linkphim = episode.select_one('div.esnList_item_img a').get('href')
		item.art['thumb'] = item.art['landscape'] = episode.select_one('div.esnList_item_img img').get('src')
		item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
		item.set_callback(fcine_link, linkphim, item.label)
		yield item
	item1 = Listitem()
	item1.label = 'Trang %s' % (next_page + 1)
	item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
	item1.set_callback(fcine_page, url, next_page + 1)
	yield item1

@Route.register
def fcine_link(plugin, url, tenphim, **kwargs):
	resp = loginfcine().get(url)
	soup = BeautifulSoup(resp.content, 'html.parser')
	episodes = soup.select('span.ipsDataItem_main p')
	for episode in episodes:
		item = Listitem()
		if 'fshare' in episode.select_one('a').get('href'):
			link = episode.select_one('a').get('href')
			ten = '%s - %s' % (tenphim, episode.get_text().split('|')[1].strip())
			if 'folder' in link:
				item.label = ten
				thumuc = link.split('folder/')
				item.art['thumb'] = item.art['landscape'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=1&size=400x400&ecc=L' % link
				item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item.context.script(tfavo, 'Thêm vào Fshare Favorite', link)
				item.set_callback(index_fs, thumuc[1], 1)
				yield item
			elif 'file' in link:
				item.label = ten
				item.art['thumb'] = item.art['landscape'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=1&size=400x400&ecc=L' % link
				item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				if __addon__.getSetting("taifshare") == "true":
					item.context.script(downloadfs, 'Tải về', link)
				item.context.script(tfavo, 'Thêm vào Fshare Favorite', link)
				item.set_callback(play_fs, link, item.label)
				yield item