from codequick import Route, Listitem, run, Script
from resources.lib.kedon import getlink, get_info_fs, play_fs, __addonnoti__, quangcao, __addon__
from resources.lib.mkd.onfshare.ifshare import index_fs, tfavo
from resources.lib.download import downloadfs
import re, xbmcgui, urllib
def get_user_input():
	shorturl = __addon__.getSetting('shorten_host')
	search_term = xbmcgui.Dialog().input('%s - NumberCode được chia sẻ bởi facebook Hội mê Phim' % shorturl.upper())
	return search_term
@Route.register
def searchnumber(plugin,search_query, **kwargs):
	shorturl = __addon__.getSetting('shorten_host')
	search_query = get_user_input()
	if search_query == '':
		Script.notify('%s - %s' % (__addonnoti__, shorturl.upper()), 'Bạn chưa nhập CODE')
		yield quangcao()
	else:
		dp = xbmcgui.DialogProgress()
		dp.create(__addonnoti__, 'Đang lấy dữ liệu từ máy chủ %s...' % shorturl.upper())
		dp.update(0)
		search_query = urllib.parse.quote_plus(search_query)
		z = 'https://%s/%s' % (shorturl, search_query)
		resp = getlink(z, z, 48*60*60)
		x = resp.url
		if 'folder' in x:
			item = Listitem()
			dulieu = get_info_fs(x)
			idfd = re.search(r'(file|folder)/([A-Z0-9]+)', x).group(2)
			item.label = dulieu[0]
			next_page = 1
			item.art['thumb'] = item.art['landscape'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=1&size=400x400&ecc=L' % x
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			item.context.script(tfavo, 'Thêm vào Fshare Favorite', x)
			item.set_callback(index_fs, idfd, next_page)
			yield item
		elif 'file' in x:
			item = Listitem()
			dulieu = get_info_fs(x)
			item.label = dulieu[0]
			item.info['size'] = dulieu[1]
			item.art['thumb'] = item.art['landscape'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=1&size=400x400&ecc=L' % x
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			if __addon__.getSetting("taifshare") == "true":
				item.context.script(downloadfs, 'Tải về', x)
			item.context.script(tfavo, 'Thêm vào Fshare Favorite', x)
			item.set_callback(play_fs, x, item.label)
			yield item
		else:
			Script.notify(__addonnoti__, 'CODE không đúng')
			yield quangcao()
		dp.update(100)
		dp.close()