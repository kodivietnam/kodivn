from codequick import Route, Listitem, run, Script
from bs4 import BeautifulSoup
from resources.lib.kedon import ifr_bongda, nocnha, useragent, __addonnoti__
from urllib.parse import urlparse
import re, os, urlquick, sys
l = nocnha()[0]
m = urlparse(l)
linkweb = '%s://%s' % (m.scheme, m.netloc)
@Route.register
def index_nocnha(plugin, **kwargs):
	url = '%s/wp-admin/admin-ajax.php' % linkweb
	payload = {'action': 'filter_match', 'filter': 'allmatch'}
	try:
		resp = urlquick.post(url, timeout=5, max_age=15*60, data=payload, headers={'user-agent': useragent,'referer': linkweb.encode('utf-8'), 'x-requested-with': 'XMLHttpRequest'})
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('li')
		for episode in episodes:
			item = Listitem()
			thoigian = episode.select_one('div.date').get_text().strip()
			linktran = episode.select_one('a').get('href')
			ten = episode.select_one('a').get_text()
			ten = '\n'.join([ll.rstrip() for ll in ten.splitlines() if ll.strip()])
			ten = ten.replace('\n', ' ')
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = '%s/wp-content/uploads/2022/02/logo-NOC-NHA-2.png' % linkweb
			item.label = '%s: %s' % (thoigian, ten)
			item.set_callback(ifr_bongda, linktran, item.label)
			yield item
	except:
		Script.notify(__addonnoti__, 'Lỗi kết nối')
		sys.exit()