from codequick import Route, Listitem, run, Script
from resources.lib.kedon import getlinkweb, tb, getlink, quangcao, __addonnoti__, ifr_khomuc, play_vnm, stream, referer, play_vtvgo
from concurrent.futures import ThreadPoolExecutor
from bs4 import BeautifulSoup
import time, calendar, xbmcgui, urllib, re
randstam = calendar.timegm(time.gmtime())
def get_tv1(randstam):
	respget_tv1 = getlinkweb(f'https://vtvgo.vn/xem-truc-tuyen?time={randstam}', 'https://vtvgo.vn', 900)
	return respget_tv1
def get_tv2():
	respget_tv2 = getlink('https://api.vtvgiaitri.vn/api/v3/channel', 'https://vtvgiaitri.vn', 900)
	return respget_tv2
@Route.register
def search_vgo(plugin,search_query, **kwargs):
	dp = xbmcgui.DialogProgress()
	dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
	dp.update(0)
	search_query = urllib.parse.quote_plus(search_query)
	url = f'https://vtvgo.vn/search?time={randstam}&search-keyword={search_query.replace(" ","+")}'
	r = getlinkweb(url, url, 900)
	if r is not None:
		if 'news-slide-content-item' in r.text:
			soup = BeautifulSoup(r.content, 'html.parser')
			episodes = soup.select('div.news-slide-content-item')
			for episode in episodes:
				item = Listitem()
				item.label = episode.select_one('h2 a').get_text()
				linkphim = episode.select_one('h2 a').get('href').replace('.html','')
				finallink = f'{linkphim}?time={randstam}'
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = episode.select_one('img').get('src')
				item.set_callback(ifr_khomuc, finallink, item.label)
				yield item
		else:
			Script.notify(__addonnoti__, 'Không tìm thấy kết quả')
			yield quangcao()
	else:
		yield quangcao()
	dp.update(100)
	dp.close()
@Route.register
def index_vtvgo(plugin, **kwargs):
	yield Listitem.search(search_vgo)
	khovideo = {'label': 'KHO VIDEO',
	'info': {'plot': 'Kho Video'},
	'art': {'thumb': 'https://wap.vtvgo.vn/vtvgo_all_device.png',
	'fanart': 'https://wap.vtvgo.vn/vtvgo_all_device.png'},
	'callback': index_khovd}
	tructuyenvtvgo = {'label': 'XEM TRỰC TUYẾN',
	'info': {'plot': 'Xem trực tuyến'},
	'art': {'thumb': 'https://wap.vtvgo.vn/vtvgo_all_device.png',
	'fanart': 'https://wap.vtvgo.vn/vtvgo_all_device.png'},
	'callback': list_truyenhinhvtvgo}
	yield Listitem.from_dict(**tructuyenvtvgo)
	yield Listitem.from_dict(**khovideo)
@Route.register
def list_truyenhinhvtvgo(plugin, **kwargs):
	with ThreadPoolExecutor(2) as ex:
		f1 = ex.submit(get_tv1, randstam)
		f2 = ex.submit(get_tv2)
	if f1.result() is not None:
		kqf1 = f1.result()
		x = kqf1.cookies.get_dict()
		g = re.findall(r"var (time|token) = '(.*?)'", kqf1.text)
		sre = re.compile('\d+')
		timekenh = g[0][1]
		tokenkenh = g[1][1]
		soup = BeautifulSoup(kqf1.content, 'html.parser')
		episodes = soup.select('div.list_channel a')
		for episode in episodes:
			item = Listitem()
			linkkenh = episode.get('href')
			idkenh = sre.findall(linkkenh)[-1]
			anh = episode.select_one('img').get('src')
			item.label = f'{episode.get("alt")} - sv1'
			item.info['plot'] = tb
			item.art['thumb'] = item.art['landscape'] = anh
			item.art['fanart'] = 'https://is3-ssl.mzstatic.com/image/thumb/Purple126/v4/b2/97/48/b2974814-bc6e-3d59-8ea3-86ace210b426/AppIcon-0-0-1x_U007emarketing-0-0-0-7-0-0-sRGB-0-0-0-GLES2_U002c0-512MB-85-220-0-0.png/1200x600wa.png'
			item.set_callback(play_vtvgo, timekenh, tokenkenh, idkenh, x, item.label)
			yield item
	else:
		yield []
	if f2.result() is not None:
		m = f2.result().json()['data']
		for k in m:
			item = Listitem()
			linkkenh = k['url']
			linktrandau = f'{stream(linkkenh)}{referer("https://vtvgiaitri.vn")}'
			anh = k['mobile_logo']
			item.label = f'{k["name"]} - sv2'
			item.info['plot'] = tb
			item.art['thumb'] = item.art['landscape'] = anh
			item.art['fanart'] = 'https://is3-ssl.mzstatic.com/image/thumb/Purple126/v4/b2/97/48/b2974814-bc6e-3d59-8ea3-86ace210b426/AppIcon-0-0-1x_U007emarketing-0-0-0-7-0-0-sRGB-0-0-0-GLES2_U002c0-512MB-85-220-0-0.png/1200x600wa.png'
			item.set_callback(play_vnm, linktrandau, item.label, '')
			yield item
	else:
		yield []
@Route.register
def index_khovd(plugin, **kwargs):
	url = f'https://vtvgo.vn/kho-video?time={randstam}'
	resp = getlinkweb(url, 'https://vtvgo.vn', 900)
	if resp is not None:
		sre = re.compile(r'(\d+)\.')
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('a.color-white')
		for episode in episodes:
			item = Listitem()
			linkthumuc = episode.get('href')
			idthumuc = sre.search(linkthumuc).group(1).replace('.', '')
			next_page = 1
			item.label = episode.get_text()
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://wap.vtvgo.vn/vtvgo_all_device.png'
			item.set_callback(list_thumucvd, idthumuc, next_page)
			yield item
	else:
		yield quangcao()
@Route.register
def list_thumucvd(plugin, idthumuc, next_page, **kwargs):
	url = f'https://vtvgo.vn/ajax-get-more-item-playlist?next_page={next_page}&channel_id={idthumuc}'
	resp = getlinkweb(url, 'https://vtvgo.vn', 900)
	if resp is not None:
		if 'http' in resp.text:
			soup = BeautifulSoup(resp.content, 'html.parser')
			episodes = soup.select('div.swiper-slide')
			for episode in episodes:
				item = Listitem()
				linkclip = episode.select_one('h2 a').get('href').replace('.html','')
				finallink = f'{linkclip}?time={randstam}'
				tenclip = episode.select_one('h2 a').get_text()
				anhclip = episode.select_one('img').get('src')
				item.label = tenclip
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = anhclip
				item.set_callback(ifr_khomuc, finallink, item.label)
				yield item
			item = Listitem()
			item1 = Listitem()
			item1.label = f'Trang {next_page + 1}'
			item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
			item1.set_callback(list_thumucvd, idthumuc, next_page + 1)
			yield item1
		else:
			yield []
	else:
		yield quangcao()