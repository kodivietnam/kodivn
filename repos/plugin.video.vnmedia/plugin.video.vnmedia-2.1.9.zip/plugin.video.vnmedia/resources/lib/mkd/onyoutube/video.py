from codequick import Route, Listitem, run
from resources.lib.kedon import getlinkweb, replace_all, quangcao
import re
thaythe = {'\\"':'','\\u0026':'&'}
@Route.register
def youtube_tatcavideo(plugin, url, **kwargs):
	resp = getlinkweb(url, url, 3600)
	if resp is not None:
		sre1 = re.compile(r'{"text":"(.*?)"}')
		sre2 = re.compile(r'"videoId":"(.*?)"')
		kq = replace_all(thaythe, resp.text)
		listplay = re.findall(r'richItemRenderer(.*?)navigationEndpoint', kq)
		for k in listplay:
			item = Listitem()
			tenvd = sre1.search(k).group(1)
			idvd = sre2.search(k).group(1)
			anhvd = f'https://i.ytimg.com/vi/{idvd}/sddefault.jpg'
			item.path = f'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid={idvd}'
			item.label = tenvd
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = anhvd
			item.set_callback(item.path)
			yield item
	else:
		yield quangcao()
@Route.register
def youtube_dslist(plugin, url, **kwargs):
	resp = getlinkweb(url, url, 7200)
	if resp is not None:
		sre1 = re.compile(r'text":"(.*?)",')
		sre2 = re.compile(r'webCommandMetadata":{"url":"(.*?)"')
		sre3 = re.compile(r'thumbnails":\[{"url":"(.*?)"')
		kq = replace_all(thaythe, resp.text)
		listplay = re.findall(r'gridPlaylistRenderer(.*?)webPageType', kq)
		for k in listplay:
			item = Listitem()
			tenvd = sre1.search(k).group(1)
			idvd = sre2.search(k).group(1)
			anhvd = sre3.search(k).group(1)
			xx = f'https://www.youtube.com{idvd.replace("u0026","&")}'
			item.label = tenvd
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = anhvd
			item.set_callback(youtube_list, xx)
			yield item
	else:
		yield quangcao()
@Route.register
def youtube_list(plugin, url, **kwargs):
	resp = getlinkweb(url, url, 3600)
	if resp is not None:
		sre1 = re.compile(r'simpleText":"(.*?)"}')
		sre2 = re.compile(r'videoId":"(.*?)"')
		kq = replace_all(thaythe, resp.text)
		listplay = re.findall(r'playlistPanelVideoRenderer(.*?)playlistId', kq)
		for k in listplay:
			item = Listitem()
			tenvd = sre1.search(k).group(1)
			idvd = sre2.search(k).group(1)
			anhvd = f'https://i.ytimg.com/vi/{idvd}/sddefault.jpg'
			item.path = f'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid={idvd}'
			item.label = tenvd
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = anhvd
			item.set_callback(item.path)
			yield item
	else:
		yield quangcao()
@Route.register
def youtube_thinhhanh(plugin, **kwargs):
	url = 'https://www.youtube.com/feed/trending?gl=VN&hl=vi'
	resp = getlinkweb(url, url, 7200)
	if resp is not None:
		sre1 = re.compile(r'text":"(.*?)"}')
		sre2 = re.compile(r'videoId":"(.*?)"')
		kq = replace_all(thaythe, resp.text)
		listplay = re.findall(r'videoRenderer(.*?)accessibility', kq)
		for k in listplay:
			item = Listitem()
			tenvd = sre1.search(k).group(1)
			idvd = sre2.search(k).group(1)
			anhvd = f'https://i.ytimg.com/vi/{idvd}/sddefault.jpg'
			item.path = f'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid={idvd}'
			item.label = tenvd
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = anhvd
			item.set_callback(item.path)
			yield item
	else:
		yield quangcao()
@Route.register
def youtube_kenh(plugin, url, **kwargs):
	item2 = Listitem()
	item2.label = 'Danh sách phát'
	item2.art['thumb'] = 'https://www.youtube.com/img/desktop/yt_1200.png'
	item2.art['fanart'] = 'https://www.youtube.com/img/desktop/yt_1200.png'
	item2.set_callback(youtube_dslist, f'{url}/playlists')
	item1 = Listitem()
	item1.label = 'Tất cả Video'
	item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.youtube.com/img/desktop/yt_1200.png'
	item1.set_callback(youtube_tatcavideo, f'{url}/videos')
	yield item2
	yield item1
	resp = getlinkweb(url, url, 3600)
	if resp is not None:
		sre1 = re.compile(r'text":"(.*?)"')
		sre2 = re.compile(r'"videoId":"(.*?)"')
		sre3 = re.compile(r'simpleText":"(.*?)"}')
		kq = replace_all(thaythe, resp.text)
		if 'channelVideoPlayerRenderer' in kq:
			listplay0 = re.findall(r'channelVideoPlayerRenderer(.*?)navigationEndpoint', kq)
			for k0 in listplay0:
				item0 = Listitem()
				tenvd0 = sre1.search(k0).group(1)
				idvd0 = sre2.search(k0).group(1)
				anhvd0 = f'https://i.ytimg.com/vi/{idvd0}/sddefault.jpg'
				item0.path = f'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid={idvd0}'
				item0.label = tenvd0
				item0.art['thumb'] = item0.art['landscape'] = item0.art['fanart'] = anhvd0
				item0.set_callback(item0.path)
				yield item0
		listplay = re.findall(r'gridVideoRenderer(.*?)navigationEndpoint', kq)
		for k in listplay:
			item = Listitem()
			tenvd = sre3.search(k).group(1)
			idvd = sre2.search(k).group(1)
			anhvd = f'https://i.ytimg.com/vi/{idvd}/sddefault.jpg'
			item.path = f'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid={idvd}'
			item.label = tenvd
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = anhvd
			item.set_callback(item.path)
			yield item
	else:
		yield quangcao()