from __future__ import unicode_literals
from codequick import Route, Listitem, run
from resources.lib.kedon import qc, tb, getlink, stream, replace_all, play_vnm
import re
import json
@Route.register
def index_fptsukien(plugin, content_type='segment'):
	url = 'https://fptplay.vn/xem-truyen-hinh'
	resp = getlink(url, url, 15*60)
	kq = resp.text
	source = re.search(r'window.__NUXT__=(.*?);<\/script>', kq).group(1)
	if 'Sự kiện' in source:
		x = json.loads(source)['data'][1]['listChanel']
		for row in x:
			item = Listitem()
			if 'Sự kiện' in row['group_name']:
				link = row['_id']
				thaythe = {'su-kien-1':'https://livecdn.fptplay.net/schedule/sukien01_hls.smil/playlist.m3u8','su-kien-2':'https://livecdn.fptplay.net/schedule/sukien02_hls.smil/playlist.m3u8','su-kien-3':'https://livecdn.fptplay.net/schedule/sukien03_hls.smil/playlist.m3u8','su-kien-4':'https://livecdn.fptplay.net/schedule/sukien04_hls.smil/playlist.m3u8','su-kien-5':'https://livecdn.fptplay.net/schedule/sukien05_hls.smil/playlist.m3u8','su-kien-6':'https://livecdn.fptplay.net/schedule/sukien06_hls.smil/playlist.m3u8','su-kien-7':'https://livecdn.fptplay.net/schedule/sukien07_hls.smil/playlist.m3u8','su-kien-8':'https://livecdn.fptplay.net/schedule/sukien08_hls.smil/playlist.m3u8','su-kien-9':'https://livecdn.fptplay.net/schedule/sukien09_hls.smil/playlist.m3u8','su-kien-10':'https://livecdn.fptplay.net/schedule/sukien10_hls.smil/playlist.m3u8','uefa-1': 'https://livecdn.fptplay.net/hdevent/uefa01_vhls.smil/playlist.m3u8','uefa-2': 'https://livecdn.fptplay.net/hdevent/uefa02_vhls.smil/playlist.m3u8','uefa-3': 'https://livecdn.fptplay.net/hdevent/uefa03_vhls.smil/playlist.m3u8','uefa-4': 'https://livecdn.fptplay.net/hdevent/uefa04_vhls.smil/playlist.m3u8','uefa-5': 'https://livecdn.fptplay.net/hdevent/uefa05_vhls.smil/playlist.m3u8','uefa-6': 'https://livecdn.fptplay.net/hdevent/uefa06_vhls.smil/playlist.m3u8','uefa-7': 'https://livecdn.fptplay.net/hdevent/uefa07_vhls.smil/playlist.m3u8','uefa-8': 'https://livecdn.fptplay.net/hdevent/uefa08_vhls.smil/playlist.m3u8','uefa-9': 'https://livecdn.fptplay.net/hdevent/uefa09_vhls.smil/playlist.m3u8','uefa-10': 'https://livecdn.fptplay.net/hdevent/uefa10_vhls.smil/playlist.m3u8','youth-league-1': 'https://livecdn.fptplay.net/hdevent/youth01_vhls.smil/playlist.m3u8','youth-league-2': 'https://livecdn.fptplay.net/hdevent/youth02_vhls.smil/playlist.m3u8','youth-league-3': 'https://livecdn.fptplay.net/hdevent/youth03_vhls.smil/playlist.m3u8','youth-league-4': 'https://livecdn.fptplay.net/hdevent/youth04_vhls.smil/playlist.m3u8','youth-league-5': 'https://livecdn.fptplay.net/hdevent/youth05_vhls.smil/playlist.m3u8','youth-league-6': 'https://livecdn.fptplay.net/hdevent/youth06_vhls.smil/playlist.m3u8','youth-league-7': 'https://livecdn.fptplay.net/hdevent/youth07_vhls.smil/playlist.m3u8','youth-league-8': 'https://livecdn.fptplay.net/hdevent/youth08_vhls.smil/playlist.m3u8','youth-league-9': 'https://livecdn.fptplay.net/hdevent/youth09_vhls.smil/playlist.m3u8','youth-league-10': 'https://livecdn.fptplay.net/hdevent/youth10_vhls.smil/playlist.m3u8','world-cup-1': 'https://livecdn.fptplay.net/hdevent/worldcup01_hls.smil/playlist.m3u8','world-cup-2': 'https://livecdn.fptplay.net/hdevent/worldcup02_hls.smil/playlist.m3u8','world-cup-3': 'https://livecdn.fptplay.net/hdevent/worldcup03_hls.smil/playlist.m3u8','world-cup-4': 'https://livecdn.fptplay.net/hdevent/worldcup04_hls.smil/playlist.m3u8','world-cup-5': 'https://livecdn.fptplay.net/hdevent/worldcup05_hls.smil/playlist.m3u8','world-cup-6': 'https://livecdn.fptplay.net/hdevent/worldcup06_hls.smil/playlist.m3u8','world-cup-7': 'https://livecdn.fptplay.net/hdevent/worldcup07_hls.smil/playlist.m3u8','world-cup-8': 'https://livecdn.fptplay.net/hdevent/worldcup08_hls.smil/playlist.m3u8','world-cup-9': 'https://livecdn.fptplay.net/hdevent/worldcup09_hls.smil/playlist.m3u8','world-cup-10': 'https://livecdn.fptplay.net/hdevent/worldcup10_hls.smil/playlist.m3u8','f-event': 'https://livecdn.fptplay.net/event/eventExpire_2000.stream/playlist.m3u8','pladio':'https://livecdn.fptplay.net/hda3/pladio_vhls.smil/playlist.m3u8'}
				hls = stream(replace_all(thaythe, link))
				item.info['plot'] = tb
				item.label = row['alias_name']
				item.art['thumb'] = row['thumb']
				item.art['fanart'] = row['thumb']
				item.set_callback(play_vnm, hls, item.label, '')
				yield item
	else:
		item3 = Listitem()
		linkmacdinh = stream(qc)
		item3.label = 'Đang cập nhật'
		item3.info['plot'] = tb
		item3.art['thumb'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.art['fanart'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.set_callback(play_vnm, linkmacdinh, item3.label, '')
		yield item3