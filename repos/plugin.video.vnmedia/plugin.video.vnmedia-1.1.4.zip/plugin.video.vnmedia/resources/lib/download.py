from codequick import Script
from codequick.utils import ensure_unicode
from urllib.parse import urlparse, unquote
from resources.lib.kedon import getfs, __addonnoti__
from requests import get
import xbmcvfs, xbmcgui, os, time
@Script.register
def downloadfs(plugin, x, **kwargs):
    url = getfs(x)
    dp = xbmcgui.DialogProgress()
    if Script.setting.get_string('dl_folder'):
        pathx = ensure_unicode(Script.setting.get_string('dl_folder'))
    else:
        pathx = os.path.join(xbmcvfs.translatePath('special://home/media/'))
    filename = unquote(os.path.basename(urlparse(url).path))
    zippath = os.path.join(pathx + filename)
    if os.path.exists(zippath):
        os.unlink(zippath)
    dp.create('%s đang tải...' % __addonnoti__, 'Đang tải tệp %s' % filename)
    dp.update(0, 'Đang tải tệp %s' % filename)
    f = open(zippath, 'wb')
    zipresp = get(url, stream=True)
    if not zipresp:
        xbmcgui.Dialog().ok(__addonnoti__, 'Tập tin này bị hỏng')
        return
    else:
        total = zipresp.headers.get('content-length')
    if total is None:
        f.write(zipresp.content)
    else:
        downloaded = 0
        total = int(total)
        start_time = time.time()
        mb = 1024*1024
        for chunk in zipresp.iter_content(chunk_size=max(int(total/512), mb)):
            downloaded += len(chunk)
            f.write(chunk)
            done = int(100 * downloaded / total)
            kbps_speed = downloaded / (time.time() - start_time)
            if kbps_speed > 0 and not done >= 100:
                eta = (total - downloaded) / kbps_speed
            else:
                eta = 0
            kbps_speed = kbps_speed / 1024
            type_speed = 'KB'
            if kbps_speed >= 1024:
                kbps_speed = kbps_speed / 1024
                type_speed = 'MB'
            currently_downloaded = 'Đã tải: %.02fMB / %.02fMB' % (downloaded/mb, total/mb)
            speed = 'Tốc độ tải: %.02f %s/s ' % (kbps_speed, type_speed)
            div = divmod(eta, 60)
            speed += '- Thời gian tải: %02d:%02d' % (div[0], div[1])
            dp.update(done, '%s\n%s\n%s' % (filename, currently_downloaded, speed))
            dp.close()