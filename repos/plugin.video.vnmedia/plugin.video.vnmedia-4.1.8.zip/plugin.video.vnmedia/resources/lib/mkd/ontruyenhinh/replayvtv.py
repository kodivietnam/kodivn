from codequick import Route, Listitem
from datetime import date, timedelta
@Route.register
def index_vtv(plugin):
	n1 = date.today()
	for i in range(3):
		n = n1-timedelta(i)
		h = n.strftime('%d/%m/%Y')
		item = Listitem()
		item.label = h
		item.info['mediatype'] = 'tvshow'
		item.art['thumb'] = item.art['poster'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
		item.set_callback(list_vtv, n, h)
		yield item
@Route.register
def list_vtv(plugin, tg=None, ngay=None):
	yield []
	if any((tg is None,ngay is None)):
		pass
	else:
		kenhidx = {
		'THVL1':'thvl1',
		'THVL2':'thvl2',
		'THVL3':'thvl3',
		'THVL4':'thvl4'}
		for l in kenhidx:
			item1 = Listitem()
			item1.label = f'{l} - {ngay}'
			item1.info['mediatype'] = 'tvshow'
			item1.art['thumb'] = item1.art['poster'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
			item1.set_callback(Route.ref('/resources/lib/mkd/ontruyenhinh/replaythvl:get_thvl'), kenhidx[l], tg)
			yield item1