from codequick import Route, Listitem, Resolver
from resources.lib.kedon import getlinkvnm, quangcao, stream
import re
@Route.register
def thoitiet_index(plugin):
	yield []
	try:
		u = 'https://player.gliacloud.com/playlist/suckhoedoisong.vn.my%7CCDN'
		resp = getlinkvnm(u, u)
		if (resp is not None):
			try:
				ri = resp.json()['playlists'][0]
				for dem, k in enumerate(ri, start=1):
					item = Listitem()
					tenm = f'Thời tiết {dem}'
					item.label = tenm
					item.info['mediatype'] = 'episode'
					item.art['thumb'] = item.art['poster'] = k['player_info']['thumbnail']
					item.set_callback(Resolver.ref('/resources/lib/kedon:list_xl90p'), stream(k['player_info']['source'][0]['src']), tenm)
					yield item
			except:
				yield quangcao()
	except:
		yield quangcao()