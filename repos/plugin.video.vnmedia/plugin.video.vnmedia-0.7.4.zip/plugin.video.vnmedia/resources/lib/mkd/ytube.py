from codequick import Route, Listitem, run
from resources.lib.kedon import getlink
from resources.lib.mkd.onyoutube.video import youtube_thinhhanh
from resources.lib.mkd.onyoutube.tim import search_karaoke, search_youtube
import re
@Route.register
def index_youtube(plugin, **kwargs):
	Trendingyt = {'label': 'TOP THỊNH HÀNH',
	'info':{'plot':'Top video nhiều lượt tương tác (xem, thích, bình luận…) trên Youtube'},
	'art':{'thumb':'https://cdn.tgdd.vn//GameApp/1311257//cach-xem-top-thinh-hanh-tren-youtube-cac-nuoc-bang-dien-thoai-thumb-800x450.jpg',
	'fanart':'https://cdn.tgdd.vn//GameApp/1311257//cach-xem-top-thinh-hanh-tren-youtube-cac-nuoc-bang-dien-thoai-thumb-800x450.jpg'},
	'callback':youtube_thinhhanh}
	yield Listitem.search(search_youtube)
	yield timkaraoke()
	yield Listitem.from_dict(**Trendingyt)
	url = 'https://www.youtube.com/index?hl=vi'
	resp = getlink(url, url, 60*60)
	kq = resp.text.replace('\\','')
	listplay = re.findall(r'videoRenderer(.*?)accessibility', kq)
	for k in listplay:
		item = Listitem()
		tenvd = re.search(r'text":"(.*?)"}', k).group(1)
		idvd = re.search(r'videoId":"(.*?)"', k).group(1)
		anhvd = re.search(r'url":"(.*?)"', k).group(1)
		item.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=' + idvd
		item.label = tenvd
		item.art["thumb"] = anhvd
		item.art["fanart"] = anhvd
		item.set_callback(item.path)
		yield item
def timkaraoke():
	item = Listitem()
	item.label = 'Tìm karaoke'
	item.info['plot'] = 'Tiện ích tìm kiếm karaoke'
	item.path = search_karaoke
	item.art['thumb'] = 'https://png.pngtree.com/png-vector/20190223/ourlarge/pngtree-karaoke-logo-vector-illustration-png-image_691264.jpg'
	item.art['fanart'] = 'https://image.freepik.com/free-vector/karaoke-logo_114055-38.jpg'
	item.set_callback(search_karaoke, item.path)
	return item