from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from resources.lib.kedon import getlink, ifr_xoilac
@Route.register
def index_xoilac7(plugin, **kwargs):
	url = 'https://xoilac7.net/'
	resp = getlink(url, url, 15*60)
	soup = BeautifulSoup(resp.text, 'html.parser')
	episodes = soup.select('a.redirectPopup')
	for episode in episodes:
		item = Listitem()
		linktrandau = episode.get('href')
		item.label = episode.get('title')
		item.art['thumb'] = 'https://xoilac7.net/wp-content/themes/bongda/dist/images/xoilac7.net.png'
		item.art['fanart'] = 'https://xoilac7.net/wp-content/themes/bongda/dist/images/xoilac7.net.png'
		item.set_callback(list_xoilac7, linktrandau, item.label)
		yield item
@Route.register
def list_xoilac7(plugin, url, title, **kwargs):
	resp = getlink(url, url, 5*60)
	soup = BeautifulSoup(resp.text, 'html.parser')
	episodes = soup.select('div#tv_links a.mb-1.text-uppercase.action')
	for episode in episodes:
		item = Listitem()
		linktrandau = episode.get('href')
		item.label = episode.text.strip() + ' - ' + title
		item.art['thumb'] = 'https://xoilac7.net/wp-content/themes/bongda/dist/images/xoilac7.net.png'
		item.art['fanart'] = 'https://xoilac7.net/wp-content/themes/bongda/dist/images/xoilac7.net.png'
		item.set_callback(ifr_xoilac, linktrandau, item.label)
		yield item