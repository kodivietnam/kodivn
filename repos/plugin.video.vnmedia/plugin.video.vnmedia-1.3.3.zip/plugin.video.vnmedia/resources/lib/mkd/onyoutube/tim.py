from codequick import Route, Listitem, run, Script
from resources.lib.kedon import getlink, get_kara_input, __addonnoti__, quangcao
from resources.lib.mkd.onyoutube.video import youtube_tatcavideo, youtube_kenh
import re, xbmcgui, urllib, html
@Route.register
def search_youtube(plugin,search_query, **kwargs):
	dp = xbmcgui.DialogProgress()
	dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
	search_query = urllib.parse.quote_plus(search_query)
	url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&regionCode=VN&q=%s&type=video&key=AIzaSyBBbFFBo8xg7GkSdhTu1WzFYdlm89XN87w&maxResults=50' % search_query.replace(' ','+')
	resp = getlink(url, url, 12*60*60)
	parsed = resp.json()
	for k in parsed['items']:
		if 'medium' in k['snippet']['thumbnails']:
			item = Listitem()
			tenvd = html.unescape(k['snippet']['title'])
			anhvd = k['snippet']['thumbnails']['medium']['url']
			motavd = k['snippet']['description']
			idvd = k['id']['videoId']
			item.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=%s' % idvd
			item.label = tenvd
			item.info['plot'] = motavd
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = anhvd
			item.set_callback(item.path)
			yield item
	if 'nextPageToken' in parsed:
		item1 = Listitem()
		token = parsed['nextPageToken']
		item1.label = 'Trang tiếp'
		item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
		item1.set_callback(search_youtubenext, search_query, token)
		yield item1
@Route.register
def search_youtubenext(plugin, search_query, token, **kwargs):
	dp = xbmcgui.DialogProgress()
	dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
	search_query = urllib.parse.quote_plus(search_query)
	url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&regionCode=VN&q=%s&type=video&key=AIzaSyBBbFFBo8xg7GkSdhTu1WzFYdlm89XN87w&pageToken=%s&maxResults=50' % (search_query.replace(' ','+'), token)
	resp = getlink(url, url, 12*60*60)
	parsed = resp.json()
	for k in parsed['items']:
		if 'medium' in k['snippet']['thumbnails']:
			item = Listitem()
			tenvd = html.unescape(k['snippet']['title'])
			anhvd = k['snippet']['thumbnails']['medium']['url']
			motavd = k['snippet']['description']
			idvd = k['id']['videoId']
			item.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=%s' % idvd
			item.label = tenvd
			item.info['plot'] = motavd
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = anhvd
			item.set_callback(item.path)
			yield item
	if 'nextPageToken' in parsed:
		item1 = Listitem()
		tokennext = parsed['nextPageToken']
		item1.label = 'Trang tiếp'
		item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
		item1.set_callback(search_youtubenext, search_query, tokennext)
		yield item1

@Route.register
def search_karaoke(plugin,search_query, **kwargs):
	search_query = get_kara_input()
	if search_query == '':
		Script.notify(__addonnoti__, 'Bạn chưa nhập từ khoá tìm kiếm')
		yield quangcao()
	else:
		dp = xbmcgui.DialogProgress()
		dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
		search_query = urllib.parse.quote_plus(search_query)
		url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&regionCode=VN&q=karaoke+%s&type=video&key=AIzaSyBBbFFBo8xg7GkSdhTu1WzFYdlm89XN87w&maxResults=50' % search_query.replace(' ','+')
		resp = getlink(url, url, 12*60*60)
		parsed = resp.json()
		for k in parsed['items']:
			if 'medium' in k['snippet']['thumbnails']:
				item = Listitem()
				tenvd = html.unescape(k['snippet']['title'])
				anhvd = k['snippet']['thumbnails']['medium']['url']
				motavd = k['snippet']['description']
				idvd = k['id']['videoId']
				item.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=%s' % idvd
				item.label = tenvd
				item.info['plot'] = motavd
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = anhvd
				item.set_callback(item.path)
				yield item
		if 'nextPageToken' in parsed:
			item1 = Listitem()
			token = parsed['nextPageToken']
			item1.label = 'Trang tiếp'
			item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
			item1.set_callback(search_youtubenext, search_query, token)
			yield item1