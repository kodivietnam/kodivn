from codequick import Route, Listitem, run
from resources.lib.kedon import tb
from resources.lib.mkd.ontruyenhinh.listiptv import list_iptv
from resources.lib.mkd.onthethao.streamthunder import index_streamthunder
from resources.lib.mkd.onthethao.livetvxs import index_livetvxs
from resources.lib.mkd.onthethao.hl365 import index_highlights365
@Route.register
def index_acestream(plugin, **kwargs):
	item = Listitem()
	kenh = 'https://note.hqth.me/raw/ace-45692'
	item.label = 'Acestream Khampha'
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg'
	item.set_callback(list_iptv, kenh)
	yield item
	wlivetvxs = {'label': 'Livetv.sx',
	'info':{'plot':tb}, 
	'art':{'thumb':'http://cdn.livetv495.me/img/logo_ru.jpg',
	'fanart':'http://cdn.livetv495.me/img/logo_ru.jpg'},
	'callback':index_livetvxs}
	wthunder = {'label': 'Streamthunder.org',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://raw.githubusercontent.com/dw4ss/streamthunder-demo-website/master/images/stream-hd.png',
	'fanart':'https://raw.githubusercontent.com/dw4ss/streamthunder-demo-website/master/images/stream-hd.png'},
	'callback':index_streamthunder}
	w365 = {'label': 'Highlights365.com',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://highlights365.com/static/images/highlights365/logo_header.png',
	'fanart':'https://highlights365.com/static/images/highlights365/logo_header.png'},
	'callback':index_highlights365}
	yield Listitem.from_dict(**wlivetvxs)
	yield Listitem.from_dict(**wthunder)
	yield Listitem.from_dict(**w365)