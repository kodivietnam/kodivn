from codequick import Route, Listitem, run
def get_tkfs1(search_query):
	from resources.lib.kedon import getlinkphongblack
	urlvmf = f'http://phongblack.me/search.php?author=phongblack&search={search_query}'
	respvmf = getlinkphongblack(urlvmf, 'http://www.google.com', 3600)
	return respvmf
def get_tkfs2(search_query):
	from resources.lib.kedon import postlinktimfs
	url = f'https://api.timfshare.com/v1/string-query-search?query={search_query}'
	resp = postlinktimfs(url, 'https://timfshare.com/', 3600)
	return resp
def get_tkfs3(search_query):
	from resources.lib.kedon import getlink
	urltvhd = f'https://thuvienhd.com/?feed=fsharejson&search={search_query}'
	resptvhd = getlink(urltvhd, 'https://thuvienhd.com/', 3600)
	return resptvhd
@Route.register
def searchfs(plugin, search_query, **kwargs):
	from resources.lib.kedon import tb, play_fs, __addonnoti__, yttk
	from concurrent.futures import ThreadPoolExecutor
	import xbmcgui, urllib, re, xbmcaddon
	dp = xbmcgui.DialogProgress()
	dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
	search_query = urllib.parse.quote_plus(search_query)
	with ThreadPoolExecutor(3) as ex:
		f1 = ex.submit(get_tkfs1, search_query)
		f2 = ex.submit(get_tkfs2, search_query)
		f3 = ex.submit(get_tkfs3, search_query)
	try:
		kqtvhd = f3.result().json()
		for dem, t in enumerate(kqtvhd):
			item = Listitem()
			item.label = t['title']
			item.info['plot'] = f'{t["title"]}\n{tb}'
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = yttk(item.label)
			item.art['thumb'] = item.art['landscape'] = t['image']
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			item.set_callback(timnhanhfs, dem, search_query)
			yield item
	except:
		import json
		text = f3.result().text
		data = re.sub('<(.*?)\n','',text)
		jsm = json.loads(data)
		for dem, t in enumerate(jsm):
			item = Listitem()
			item.label = t['title']
			item.info['plot'] = f'{t["title"]}\n{tb}'
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = yttk(item.label)
			item.art['thumb'] = item.art['landscape'] = t['image']
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			item.set_callback(timnhanhfs, dem, search_query)
			yield item
	dp.update(100)
	try:
		from resources.lib.mkd.onfshare.ifshare import index_fs, tfavo
		sre = re.compile('[\[\]\{\}]')
		x = f1.result().json()['items']
		for m in x:
			item1 = Listitem()
			ten = sre.sub('|', m['label'])
			if 'info' in m:
				mota = m['info']['plot']
			path = m['path']
			if '/file/' in path:
				item1.label = ten
				link = path.split('&url=')
				linkplay = link[1]
				item1.info['mediatype'] = 'episode'
				item1.info['rating'] = 10.0
				item1.info['trailer'] = yttk(item1.label)
				item1.art['thumb'] = item1.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
				item1.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item1.info['plot'] = f'{mota}\n{tb}'
				if xbmcaddon.Addon().getSetting('taifshare') == 'true':
					from resources.lib.download import downloadfs
					item1.context.script(downloadfs, 'Tải về', linkplay)
				item1.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
				item1.set_callback(play_fs, linkplay, item1.label)
				yield item1
			elif '/folder/' in path:
				item1.label = ten
				link = path.split('&url=')
				linkplay = link[1]
				thumuc = linkplay.split('folder/')
				item1.info['mediatype'] = 'episode'
				item1.info['rating'] = 10.0
				item1.info['trailer'] = yttk(item1.label)
				item1.art['thumb'] = item1.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
				item1.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item1.info['plot'] = f'{mota}\n{tb}'
				item1.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
				item1.set_callback(index_fs, thumuc[1], 1)
				yield item1
	except:
		try:
			from resources.lib.mkd.onfshare.ifshare import index_fs, tfavo
			kq = f2.result().json()
			if 'data' in kq:
				for k in kq['data']:
					item = Listitem()
					linkplay = k['url']
					if 'folder' in linkplay:
						item.label = k['name']
						thumuc = linkplay.split('folder/')
						item.info['plot'] = tb
						item.info['mediatype'] = 'episode'
						item.info['rating'] = 10.0
						item.info['trailer'] = yttk(item.label)
						item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
						item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
						item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
						item.set_callback(index_fs, thumuc[1], 1)
						yield item
					elif 'file' in linkplay:
						item.label = k['name']
						item.info['plot'] = tb
						item.info['size'] = k['size']
						item.info['mediatype'] = 'episode'
						item.info['rating'] = 10.0
						item.info['trailer'] = yttk(item.label)
						item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
						item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
						if xbmcaddon.Addon().getSetting('taifshare') == 'true':
							from resources.lib.download import downloadfs
							item.context.script(downloadfs, 'Tải về', linkplay)
						item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
						item.set_callback(play_fs, linkplay, item.label)
						yield item
		except:
			pass
	dp.update(100)
	dp.close()
@Route.register
def index_pdx(plugin, **kwargs):
	from resources.lib.kedon import tb, play_fs, getlink, yttk
	urltvhd = 'https://thuvienhd.com/?feed=fsharejson&search='
	resptvhd = getlink(urltvhd, 'https://thuvienhd.com/', 3600)
	try:
		resptvhd = f3.result().json()
		for dem, t in enumerate(kqtvhd):
			item = Listitem()
			item.label = t['title']
			item.info['plot'] = f'{t["title"]}\n{tb}'
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = yttk(item.label)
			item.art['thumb'] = item.art['landscape'] = t['image']
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			item.set_callback(timnhanhfs, dem, '')
			yield item
	except:
		import json, re
		text = resptvhd.text
		data = re.sub('<(.*?)\n','',text)
		jsm = json.loads(data)
		for dem, t in enumerate(jsm):
			item = Listitem()
			item.label = t['title']
			item.info['plot'] = f'{t["title"]}\n{tb}'
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = yttk(item.label)
			item.art['thumb'] = item.art['landscape'] = t['image']
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			item.set_callback(timnhanhfs, dem, '')
			yield item
@Route.register
def timnhanhfs(plugin, dem, tukhoa):
	from resources.lib.kedon import getlink, yttk, play_fs, tb
	from resources.lib.mkd.onfshare.ifshare import index_fs, tfavo
	import xbmcaddon
	urltvhd = f'https://thuvienhd.com/?feed=fsharejson&search={tukhoa}'
	resptvhd = getlink(urltvhd, 'https://thuvienhd.com/', 3600)
	try:
		kqtvhd = resptvhd.json()
		for t in kqtvhd[dem]['links']:
			item = Listitem()
			linkplay = t['link']
			if 'folder' in linkplay:
				item.label = t['title']
				thumuc = linkplay.split('folder/')
				item.info['plot'] = tb
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = yttk(item.label)
				item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
				item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
				item.set_callback(index_fs, thumuc[1], 1)
				yield item
			elif 'file' in linkplay:
				item.label = t['title']
				item.info['plot'] = tb
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = yttk(item.label)
				item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
				item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				if xbmcaddon.Addon().getSetting('taifshare') == 'true':
					from resources.lib.download import downloadfs
					item.context.script(downloadfs, 'Tải về', linkplay)
				item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
				item.set_callback(play_fs, linkplay, item.label)
				yield item
	except:
		import json, re
		text = resptvhd.text
		data = re.sub('<(.*?)\n','',text)
		jsm = json.loads(data)
		for t in jsm[dem]['links']:
			item = Listitem()
			linkplay = t['link']
			if 'folder' in linkplay:
				item.label = t['title']
				thumuc = linkplay.split('folder/')
				item.info['plot'] = tb
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = yttk(item.label)
				item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
				item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
				item.set_callback(index_fs, thumuc[1], 1)
				yield item
			elif 'file' in linkplay:
				item.label = t['title']
				item.info['plot'] = tb
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = yttk(item.label)
				item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
				item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				if xbmcaddon.Addon().getSetting('taifshare') == 'true':
					from resources.lib.download import downloadfs
					item.context.script(downloadfs, 'Tải về', linkplay)
				item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
				item.set_callback(play_fs, linkplay, item.label)
				yield item