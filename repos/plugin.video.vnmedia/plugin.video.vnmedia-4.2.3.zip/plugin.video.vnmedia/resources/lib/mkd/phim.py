from codequick import Route, Script, Listitem
@Route.register
def index_phim(plugin):
	streams = [
		('OPhim', 'https://mi3s.top/thumb/phim/ophim.png', '/resources/lib/mkd/onphim/ophim:index_ophim'),
		('NguonC', 'https://mi3s.top/thumb/phim/nguonc.png', '/resources/lib/mkd/onphim/nguonc:index_nguonc'),
		('KKphim', 'https://mi3s.top/thumb/phim/kkphim.png', '/resources/lib/mkd/onphim/kkphim:index_kkphim'),
		('Fmovies', 'https://mi3s.top/thumb/phim/fmovi.png', '/resources/lib/mkd/onphim/fmovies:index_fm'),
		('FilmPlus', 'https://mi3s.top/thumb/phim/onstream.png', '/resources/lib/mkd/onphim/mdb:index_mdb')
	]
	for name_key, banner_key, route_key in streams:
		item = Listitem()
		item.label = name_key
		item.info['mediatype'] = 'tvshow'
		item.art['thumb'] = item.art['poster'] = banner_key
		item.set_callback(Route.ref(route_key))
		yield item
	if Script.setting.get_string('kenh18') == 'true':
		yield Listitem.from_dict(**{'label': 'JAVHD',
		'art': {'thumb': 'https://mi3s.top/thumb/phim/raphd.jpg',
		'poster': 'https://mi3s.top/thumb/phim/raphd.jpg'},
		'info': {'mediatype':'tvshow'},
		'callback': Route.ref('/resources/lib/mkd/onphim/raphd:index_raphd')})