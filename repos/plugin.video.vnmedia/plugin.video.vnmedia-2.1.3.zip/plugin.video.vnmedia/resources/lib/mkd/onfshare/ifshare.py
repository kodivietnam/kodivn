from codequick import Route, Listitem, run, Script
hdvn = 'https://www.hdvietnam.xyz'
@Route.register
def index_fs(plugin, idfd, next_page, **kwargs):
	from resources.lib.kedon import getlink, quangcao, yttk, play_fs, __icon__, __addonnoti__, tb
	import xbmcaddon
	fstm = xbmcaddon.Addon().getSetting('fstm')
	if fstm == 'Z-A':
		url = f'https://www.fshare.vn/api/v3/files/folder?linkcode={idfd}&sort=type,-name&page={next_page}&per-page=50'
	elif fstm == 'Mới nhất':
		url = f'https://www.fshare.vn/api/v3/files/folder?linkcode={idfd}&sort=type,-modified&page={next_page}&per-page=50'
	elif fstm == 'Cũ nhất':
		url = f'https://www.fshare.vn/api/v3/files/folder?linkcode={idfd}&sort=type,modified&page={next_page}&per-page=50'
	elif fstm == 'Nặng nhất':
		url = f'https://www.fshare.vn/api/v3/files/folder?linkcode={idfd}&sort=type,-size&page={next_page}&per-page=50'
	elif fstm == 'Nhẹ nhất':
		url = f'https://www.fshare.vn/api/v3/files/folder?linkcode={idfd}&sort=type,size&page={next_page}&per-page=50'
	else:
		url = f'https://www.fshare.vn/api/v3/files/folder?linkcode={idfd}&sort=type,name&page={next_page}&per-page=50'
	kq = getlink(url, url, 7200)
	if kq is not None:
		if 'items' in kq.text and len(kq.json()['items']) > 0:
			for k in kq.json()['items']:
				item = Listitem()
				if k['type'] == 0:
					item.label = k['name']
					linkfd = k['linkcode']
					linkplay = f'https://www.fshare.vn/folder/{linkfd}'
					item.info['plot'] = tb
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(item.label)
					item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
					item.set_callback(index_fs, linkfd, 1)
					yield item
				elif k['type'] == 1:
					item.label = k['name']
					item.info['plot'] = tb
					item.info['size'] = k['size']
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(item.label)
					linkplay = f'https://www.fshare.vn/file/{k["linkcode"]}'
					item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					if xbmcaddon.Addon().getSetting('taifshare') == 'true':
						from resources.lib.download import downloadfs
						item.context.script(downloadfs, 'Tải về', linkplay)
					item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
					item.set_callback(play_fs, linkplay, item.label)
					yield item
		else:
			import xbmc
			xbmc.executebuiltin(f'Notification({__addonnoti__}, Fshare link folder die, 10000, {__icon__})')
			yield quangcao()
		if '_links' in kq.json() and 'last' in kq.json().get('_links'):
			import re
			last_page = re.search(r'&page=(\d+)', kq.json().get('_links').get('last')).group(1)
			if int(last_page) > next_page:
				item1 = Listitem()
				item1.label = f'Trang {next_page + 1}'
				item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
				item1.set_callback(index_fs, idfd, next_page + 1)
				yield item1
	else:
		yield quangcao()
@Route.register
def index_daxem(plugin, **kwargs):
	from resources.lib.kedon import get_last_watch_movie, clear_last_watch_movie, tb
	b = get_last_watch_movie()
	if b:
		for m in b:
			from resources.lib.kedon import play_fs, yttk
			import xbmcaddon
			item = Listitem()
			item.label = m
			item.info['plot'] = tb
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = yttk(item.label)
			linkplay = b[m]
			item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			if xbmcaddon.Addon().getSetting('taifshare') == 'true':
				from resources.lib.download import downloadfs
				item.context.script(downloadfs, 'Tải về', linkplay)
			item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
			item.set_callback(play_fs, linkplay, item.label)
			yield item
		Fshareplaydel = {'label': 'Xoá lịch sử xem',
		'info': {'plot': 'Xoá lịch sử xem'},
		'art': {'thumb': 'https://apkmodo.net/wp-content/uploads/2022/01/WATCHED-APK.jpg',
		'fanart': 'https://fsharetv.com/img/fsharetv.png'},
		'callback': clear_last_watch_movie}
		yield Listitem.from_dict(**Fshareplaydel)
	else:
		yield []
@Route.register
def fs_favorite(plugin, **kwargs):
	from resources.lib.kedon import userpassfs, useragentvmf, __addonnoti__, yttk, tb
	import xbmcaddon
	try:
		import urlquick
		login = userpassfs()
		session_id = login[1]
		headerfsvn = {'User-Agent': useragentvmf, 'Cookie' : f'session_id={session_id}'}
		r = urlquick.get('https://api.fshare.vn/api/fileops/listFavorite', timeout=15, max_age=0, headers=headerfsvn)
	except:
		import xbmcgui
		xbmcgui.Dialog().ok(__addonnoti__, 'Đăng nhập không thành công\nKiểm tra lại tài khoản, mật khẩu, đường truyền Internet')
		xbmcaddon.Addon().openSettings()
		exit()
	for k in r.json():
		item = Listitem()
		if k['type'] == '0':
			item.label = k['name']
			linkfd = k['linkcode']
			linkplay = f'https://www.fshare.vn/folder/{linkfd}'
			item.info['plot'] = tb
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = yttk(item.label)
			item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			item.context.script(xfavo, 'Xoá khỏi Fshare Favorite', linkplay)
			item.set_callback(index_fs, linkfd, 1)
			yield item
		elif k['type'] == '1':
			from resources.lib.kedon import play_fs
			item.label = k['name']
			item.info['size'] = k['size']
			linkplay = f'https://www.fshare.vn/file/{k["linkcode"]}'
			item.info['plot'] = tb
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = yttk(item.label)
			item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			if xbmcaddon.Addon().getSetting('taifshare') == 'true':
				from resources.lib.download import downloadfs
				item.context.script(downloadfs, 'Tải về', linkplay)
			item.context.script(xfavo, 'Xoá khỏi Fshare Favorite', linkplay)
			item.set_callback(play_fs, linkplay, item.label)
			yield item
		else:
			yield []
@Route.register
def fs_topfollow(plugin, **kwargs):
	from resources.lib.kedon import userpassfs, useragentvmf, yttk, __addonnoti__, tb
	login = userpassfs()
	session_id = login[1]
	headerfsvn = {'User-Agent': useragentvmf, 'Cookie' : f'session_id={session_id}'}
	try:
		import urlquick
		r = urlquick.get('https://api.fshare.vn/api/fileops/getTopFollowMovie', timeout=15, max_age=7604800, headers=headerfsvn)
	except:
		import xbmcgui, xbmcaddon
		xbmcgui.Dialog().ok(__addonnoti__, 'Đăng nhập không thành công\nKiểm tra lại tài khoản, mật khẩu, đường truyền Internet')
		xbmcaddon.Addon().openSettings()
		exit()
	for k in r.json():
		item = Listitem()
		item.label = k['name']
		linkfd = k['linkcode']
		linkplay = f'https://www.fshare.vn/folder/{linkfd}'
		item.info['plot'] = tb
		item.info['mediatype'] = 'episode'
		item.info['rating'] = 10.0
		item.info['trailer'] = yttk(item.label)
		item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
		item.art['fanart'] = 'https://www.fshare.vn/images/top-follow/title.png'
		item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
		item.set_callback(index_fs, linkfd, 1)
		yield item
@Script.register
def tfavo(plugin, x, **kwargs):
	from resources.lib.kedon import __addonnoti__, userpassfs, useragentvmf
	import urlquick, re
	if 'file' in x:
		if '?' in x:
			match = re.search(r'file/(.*?)\?', x)
			idfd = match.group(1)
		else:
			tach = x.split('file/')
			idfd = tach[1]
	elif 'folder' in x:
		if '?' in x:
			match = re.search(r'folder/(.*?)\?', x)
			idfd = match.group(1)
		else:
			tach = x.split('folder/')
			idfd = tach[1]
	login = userpassfs()
	token = login[0]
	session_id = login[1]
	headerfsvn = {'User-Agent': useragentvmf, 'Cookie' : f'session_id={session_id}'}
	payload = f'{{"items":["{idfd}"],"status":1,"token":"{token}"}}'
	try:
		r = urlquick.post('https://api.fshare.vn/api/fileops/ChangeFavorite', timeout=15, max_age=0, data=payload, headers=headerfsvn)
	except:
		Script.notify(__addonnoti__, 'Không thêm được vào Fshare Favorite')
	else:
		if '200' in r.text:
			Script.notify(__addonnoti__, 'Đã thêm vào Fshare Favorite')
		else:
			Script.notify(__addonnoti__, 'Không thêm được vào Fshare Favorite')
@Script.register
def xfavo(plugin, x, **kwargs):
	from resources.lib.kedon import __addonnoti__, userpassfs, useragentvmf
	import urlquick, xbmc, re
	if 'file' in x:
		if '?' in x:
			match = re.search(r'file/(.*?)\?', x)
			idfd = match.group(1)
		else:
			tach = x.split('file/')
			idfd = tach[1]
	elif 'folder' in x:
		if '?' in x:
			match = re.search(r'folder/(.*?)\?', x)
			idfd = match.group(1)
		else:
			tach = x.split('folder/')
			idfd = tach[1]
	login = userpassfs()
	token = login[0]
	session_id = login[1]
	headerfsvn = {'User-Agent': useragentvmf, 'Cookie' : f'session_id={session_id}'}
	payload = f'{{"items":["{idfd}"],"status":0,"token":"{token}"}}'
	r = urlquick.post('https://api.fshare.vn/api/fileops/ChangeFavorite', timeout=15, max_age=0, data=payload, headers=headerfsvn)
	Script.notify(__addonnoti__, 'Đã xoá khỏi Fshare Favorite')
	xbmc.executebuiltin('Container.Refresh()')
def loginfhdvn():
	from resources.lib.kedon import has_file_path, useragentdf, get_last_modified_time_file, remove_file, write_file, read_file
	import pickle, time
	if has_file_path('hdvietnam.bin') and get_last_modified_time_file('hdvietnam.bin') + 3600 < int(time.time()):
		remove_file('hdvietnam.bin')
	if has_file_path('hdvietnam.bin'):
		return pickle.loads(read_file('hdvietnam.bin', True))
	else:
		from requests import Session
		with Session() as s:
			site = s.get(f'{hdvn}/forums/')
			headers = {'user-agent':useragentdf,'origin':hdvn,'referer':f'{hdvn}/'}
			login_data = {'login':'romvemot@gmail.com','register':0,'password':'bimozie','remember':1,'cookie_check':1,'_xfToken':'','redirect':'/forums/'}
			s.post(f'{hdvn}/login/login', data=login_data, headers=headers)
			write_file('hdvietnam.bin', pickle.dumps(s), True)
			return s
def likehdvn(url):
	from bs4 import BeautifulSoup
	s = loginfhdvn()
	r = s.get(f'{hdvn}/{url}')
	soup = BeautifulSoup(r.content, 'html.parser')
	token = soup.select_one('input[name="_xfToken"]').get('value')
	like = f'{hdvn}/{soup.select_one("div.publicControls a.LikeLink.item.control").get("href")}'
	if 'like' in like:
		data_like = {'_xfRequestUri':f'/{url}','_xfToken':token,'_xfNoRedirect':1,'_xfResponseType': 'json'}
		s.post(like, data=data_like)
		return
def logincsn():
	from resources.lib.kedon import has_file_path, useragentdf, get_last_modified_time_file, remove_file, write_file, read_file
	import pickle, time
	if has_file_path('csn.bin') and get_last_modified_time_file('csn.bin') + 3600 < int(time.time()):
		remove_file('csn.bin')
	if has_file_path('csn.bin'):
		return pickle.loads(read_file('csn.bin', True))
	else:
		from requests import Session
		import re
		with Session() as s:
			site = s.get('https://chiasenhac.vn')
			headers = {'user-agent':useragentdf,'origin':'https://chiasenhac.vn','referer':'https://chiasenhac.vn/login'}
			token = re.search('csrfToken = "(.*)";', site.text).group(1)
			login_data = {'_token':token,'register':0,'email':'vnmedia','password':'Lvwzg9ZNb@2PubD'}
			s.post('https://chiasenhac.vn/login', login_data)
			write_file('csn.bin', pickle.dumps(s), True)
			return s