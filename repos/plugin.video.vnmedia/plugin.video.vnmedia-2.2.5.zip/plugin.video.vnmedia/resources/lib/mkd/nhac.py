from codequick import Route, Listitem, Resolver
from resources.lib.kedon import tb, getlink, quangcao, qc, stream
from resources.lib.mkd.onfshare.ifshare import logincsn
from bs4 import BeautifulSoup
import re
@Route.register
def index_amnhac(plugin, **kwargs):
	yield Listitem.from_dict(**{'label': 'Bảng xếp hạng bài hát',
	'info': {'plot': 'Bảng xếp hạng bài hát'},
	'art': {'thumb': 'https://chiasenhac.vn/images/logo-header.png',
	'fanart': 'https://chiasenhac.vn/images/logo-header.png'},
	'callback': index_bxhmusic})
	yield Listitem.from_dict(**{'label': 'Bảng xếp hạng video',
	'info': {'plot': 'Bảng xếp hạng video'},
	'art': {'thumb': 'https://chiasenhac.vn/images/logo-header.png',
	'fanart': 'https://chiasenhac.vn/images/logo-header.png'},
	'callback': index_bxhvideo})
	yield videomusic()
@Route.register
def index_bxhmusic(plugin, **kwargs):
	M = {'BXH Nhạc Việt Nam': 'http://chiasenhac.vn/nhac-hot/vietnam.html',
	'BXH Nhạc US-UK': 'http://chiasenhac.vn/nhac-hot/us-uk.html',
	'BXH Nhạc Beat - Không lời': 'http://chiasenhac.vn/nhac-hot/beat-playback.html',
	'BXH Nhạc Hoa': 'http://chiasenhac.vn/nhac-hot/chinese.html',
	'BXH Nhạc Hàn': 'http://chiasenhac.vn/nhac-hot/korea.html',
	'BXH Nhạc Nhật': 'http://chiasenhac.vn/nhac-hot/japan.html',
	'BXH Nhạc Pháp': 'http://chiasenhac.vn/nhac-hot/france.html',
	'BXH Nhạc Nước khác': 'http://chiasenhac.vn/nhac-hot/other.html'}
	for k in M:
		item = Listitem()
		item.label = k
		item.info['plot'] = tb
		item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://chiasenhac.vn/images/logo-header.png'
		item.set_callback(list_bxhmusic, M[k])
		yield item
@Route.register
def index_bxhvideo(plugin, **kwargs):
	V = {'BXH Video Việt Nam': 'http://chiasenhac.vn/nhac-hot/video/v-video.html',
	'BXH Video US-UK': 'http://chiasenhac.vn/nhac-hot/video/us-video.html',
	'BXH Video Hoa': 'http://chiasenhac.vn/nhac-hot/video/c-video.html',
	'BXH Video Hàn': 'http://chiasenhac.vn/nhac-hot/video/k-video.html',
	'BXH Video Nhật': 'http://chiasenhac.vn/nhac-hot/video/j-video.html',
	'BXH Video Pháp': 'http://chiasenhac.vn/nhac-hot/video/f-video.html',
	'BXH Video Nước khác': 'http://chiasenhac.vn/nhac-hot/video/o-video.html'}
	for k in V:
		item = Listitem()
		item.label = k
		item.info['plot'] = tb
		item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://chiasenhac.vn/images/logo-header.png'
		item.set_callback(list_bxhvideo, V[k])
		yield item
@Route.register
def list_bxhmusic(plugin, url, **kwargs):
	r = getlink(url, url, 1000)
	if r is not None:
		if 'card-footer' in r.text:
			sre = re.compile("\((.*)\)")
			soup = BeautifulSoup(r.content, 'html.parser')
			episodes = soup.select('div.element.mb-2.card-footer')
			for episode in episodes:
				item = Listitem()
				anh = episode.select_one('div.image').get('style')
				tenbai = episode.select_one('div.content h6').get_text()
				casi = episode.select_one('p.name_singer').get_text()
				chatluong = episode.select_one('p.loss').get_text()
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = sre.search(anh).group(1)
				item.label = f'{tenbai} ({casi}) - {chatluong}'
				item.set_callback(playcsn, episode.select_one('a').get('href'), item.label)
				yield item
		else:
			yield quangcao()
	else:
		yield quangcao()
@Route.register
def list_bxhvideo(plugin, url, **kwargs):
	r = getlink(url, url, 1000)
	if r is not None:
		if 'card-footer' in r.text:
			sre = re.compile("\((.*)\)")
			soup = BeautifulSoup(r.content, 'html.parser')
			episodes = soup.select('div.element.py-3.border-bottom.card-footer')
			for episode in episodes:
				item = Listitem()
				anh = episode.select_one('div.image').get('style')
				tenbai = episode.select_one('div.content h6').get_text()
				casi = episode.select_one('p.name_singer').get_text()
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = sre.search(anh).group(1)
				item.label = f'{tenbai} ({casi})'
				item.set_callback(playcsn, episode.select_one('a').get('href'), item.label)
				yield item
		else:
			yield quangcao()
	else:
		yield quangcao()
@Resolver.register
def playcsn(plugin, url, title, **kwargs):
	news = 'http://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/qc.ass'
	if 'http' in url:
		a = url
	else:
		a = f'https://chiasenhac.vn{url}'
	r = logincsn().get(a)
	if r is not None:
		linkplay = re.findall(r'download_item" href="(.*?)"', r.text)[-2]
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay})
	else:
		linkplay = stream(qc)
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
def videomusic():
	item = Listitem()
	item.label = 'Video Nhạc hay'
	item.info['plot'] = tb
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://png.pngtree.com/element_our/png_detail/20181022/music-and-live-music-logo-with-neon-light-effect-vector-png_199406.jpg'
	item.set_callback(Route.ref('/resources/lib/mkd/ontintuc/mocha:index_mocha'), 4, 0)
	return item