from codequick import Route, Listitem
from resources.lib.kedon import tb
@Route.register
def index_tintuc(plugin,**kwargs):
	T = {
	'VTV24': 'http://www.youtube.com/channel/UCabsTV34JwALXKGMqHpvUiA',
	'VTC Now': 'http://www.youtube.com/channel/UCL9-pEHNBs3N4r2bMoXdLJA',
	'TV24h': 'http://www.youtube.com/channel/UCUmRGR3a-g13O6pG927KQmg',
	'60 giây': 'http://www.youtube.com/channel/UCRjzfa1E0gA50lvDQipbDMg',
	'Thời tiết-Môi trường': 'http://www.youtube.com/channel/UCinkijG72G87sn-mtaFJTbA',
	'Văn hoá-Du lịch': 'http://www.youtube.com/channel/UCZ7cd8K5jo7fHUksCgMfpeg',
	'Kinh tế-Tài chính': 'http://www.youtube.com/channel/UC7723FqVehXq2zeRb3tP0hQ',
	'An ninh': 'http://www.youtube.com/channel/UCIg56SgvoZF8Qg0Jx_gh6Pg',
	'Thông tấn xã': 'http://www.youtube.com/channel/UCmBT5CqUxf3-K5_IU9tVtBg',
	'Quốc hội': 'http://www.youtube.com/channel/UCTJ-FDgxR3NxurDQxNiWWVQ',
	'Nhân dân': 'http://www.youtube.com/channel/UCPJfjHrW3-zIeSaZTgmckmg',
	'Nông nghiệp-nông thôn': 'http://www.youtube.com/channel/UCZnhEIF8a5Uv4GMPwT6KafQ',
	'Thế giới đó đây': 'http://www.youtube.com/channel/UCHPzpxcYhxkb0fMJKeSe66g',
	'VTC tin mới': 'http://www.youtube.com/channel/UCZcCmWhvK0gfThyWRmRerDQ',
	'Hà Nội tin tức': 'http://www.youtube.com/channel/UC7_mgS3z22z0WhR7COJ8E2w',
	'HTV tin tức': 'http://www.youtube.com/channel/UCZYKmEA2iQOSbyKc6xj5Vfw',
	'THVL tổng hợp': 'http://www.youtube.com/channel/UC1K9R0YwYrp7auy6fPbnnIQ',
	'Luật giao thông': 'http://www.youtube.com/channel/UC0OX9WL_PxOlX0HQbu45JfA',
	'Tuấn tiền tỉ': 'http://www.youtube.com/channel/UCtfsYfpS3KoRTEbCMc6l85w',
	'Dương địa lý': 'http://www.youtube.com/channel/UCaJ6YgNkAlRsl8nWZS2sjtg'
	}
	yield Listitem.from_dict(**{'label': 'Báo Nói - Đọc Báo Giúp Bạn',
	'info':{'plot':tb},
	'art':{'thumb':'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png',
	'fanart':'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'},
	'callback':Route.ref('/resources/lib/mkd/ontintuc/baomoi:index_baomoi')})
	yield Listitem.from_dict(**{'label': 'Tin thể thao',
	'info':{'plot':tb},
	'art':{'thumb':'https://thethao360.tv/wp-content/uploads/2020/12/logo-3.png',
	'fanart':'https://thethao360.tv/wp-content/uploads/2020/12/logo-3.png'},
	'callback':Route.ref('/resources/lib/mkd/onthethao/tinthethao:index_tinthethao')})
	yield mocha()
	for k in T:
		item = Listitem()
		item.label = k
		item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
		item.set_callback(Route.ref('/resources/lib/mkd/onyoutube/video:youtube_kenh'), T[k])
		yield item
def mocha():
	item = Listitem()
	item.label = 'Tin mới'
	item.info['plot'] = tb
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(Route.ref('/resources/lib/mkd/ontintuc/mocha:index_mocha'), 1, 0)
	return item