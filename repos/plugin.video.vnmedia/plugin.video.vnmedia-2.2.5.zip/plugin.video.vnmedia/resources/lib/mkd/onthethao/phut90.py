from codequick import Route, Listitem, Resolver
from resources.lib.kedon import getlink, tiengruoi, quangcao, tb, stream, referer
from functools import lru_cache
from datetime import datetime
import re
@lru_cache(maxsize=None)
def respphut90():
	tr0 = tiengruoi()[0]
	resp90 = getlink(tr0, tr0, 0)
	if resp90 is not None:
		ref = re.search(r'  window.base_embed_url(.*?)"(.*?)"', resp90.text).group(2)
	else:
		ref = tr0
	return ref
@Route.register
def index_90p(plugin, **kwargs):
	url = 'http://api.vebo.xyz/api/match/featured/mt'
	ref = respphut90()
	resp = getlink(url, ref, 1000)
	if resp is not None:
		kq = resp.json()
		for k in kq['data']:
			item = Listitem()
			time = datetime.fromtimestamp(int(k['timestamp'])/1000).strftime('%H:%M %d-%m')
			if k['commentators']:
				item.label = f'{time}: {k["name"]} ({k["commentators"][0]["name"]})'
			else:
				item.label = f'{time}: {k["name"]}'
			item.info['plot'] = tb
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://i.imgur.com/jyM3inb.png'
			item.set_callback(list_90p, k['id'], item.label)
			yield item
	else:
		yield quangcao()
@Route.register
def list_90p(plugin, idk, title, **kwargs):
	ref = respphut90()
	url = f'http://api.vebo.xyz/api/match/{idk}/meta'
	resp = getlink(url, ref, 400)
	if resp is not None:
		if '.m3u8' in resp.text:
			kq = resp.json()
			for k in kq['data']['play_urls']:
				item = Listitem()
				item.label = f'{k["name"]} - {title}'
				item.info['plot'] = tb
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://i.imgur.com/jyM3inb.png'
				item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), f'{stream(k["url"])}{referer(ref)}', item.label, '')
				yield item
		else:
			yield quangcao()
	else:
		yield quangcao()