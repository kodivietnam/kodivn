from codequick import Route, Listitem, run
from resources.lib.kedon import qc, tb, getlink, stream, referer, play_vnm
import re
@Route.register
def index_bongdahomnay(plugin, content_type='segment'):
	url = 'https://bongdahomnay.tech/'
	resp = getlink(url, url, 15*60)
	match = re.findall(r',id:(.*?)}', resp.text)
	for k in match:
		item = Listitem()
		idtran = url + 'truc-tiep/vcl-' + re.search(r'"(.*?)"', k).group(1) + '.html'
		time = re.search(r'fulltime:"(.*?)"', k).group(1)
		match_name = re.search(r'match_name:"(.*?)"', k).group(1).replace(r'\t', '')
		item.info['plot'] = tb
		item.label = time + ' ' + match_name
		item.art['thumb'] = 'https://i.imgur.com/TlXaeKj.png'
		item.art['fanart'] = 'https://i.imgur.com/TlXaeKj.png'
		item.set_callback(list_bongdahomnay, idtran, item.label)
		yield item

@Route.register
def list_bongdahomnay(plugin,url,title):
	resp = getlink(url, url, 0)
	if 'm3u8' in resp.text:
		match = re.findall(r'1,url:(.*?)}', resp.text)
		for k in match:
			item = Listitem()
			linktran = stream(re.search(r'"(.*?)"', k).group(1)) + referer(url)
			chatluong = re.search(r'name:"(.*?)"', k).group(1)
			item.info['plot'] = tb
			item.label = chatluong + ' ' + title
			item.art['thumb'] = 'https://i.imgur.com/TlXaeKj.png'
			item.art['fanart'] = 'https://i.imgur.com/TlXaeKj.png'
			item.set_callback(play_vnm, linktran, item.label, '')
			yield item
	else:
		item3 = Listitem()
		linkmacdinh = stream(qc)
		item3.label = 'Đang cập nhật'
		item3.info['plot'] = tb
		item3.art['thumb'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.art['fanart'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.set_callback(play_vnm, linkmacdinh, item3.label, '')
		yield item3