from codequick import Resolver, Listitem, run, Script
from bs4 import BeautifulSoup
from urllib.parse import urlparse
from requests import Session
import inputstreamhelper, urlquick, xbmc, xbmcgui, xbmcaddon, base64, urllib, re, time, os, sys, json
__addon__ = xbmcaddon.Addon()
__addonname__ = __addon__.getAddonInfo('name')
__version__ = __addon__.getAddonInfo('version')
__icon__ = __addon__.getAddonInfo('icon')
shorturl = __addon__.getSetting('shorten_host')
__addonnoti__ = '%s v%s' % (__addonname__, __version__)
useragent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.134 Safari/537.36'
useragentvmf = 'Vietmediaf /Kodi1.1.99-092019'
code = 'User-Agent=%s' % useragent
qc ='https://mi3s.top/qc'
logotv = 'https://i.imgur.com/Mnuw95h.png'
news = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/qc.ass'
tb = 'Nội dung này được chia sẻ và lưu trữ bởi một ứng dụng bên thứ ba. VNmedia hoạt động giống như một công cụ thu thập tìm kiếm từ Internet. Chúng tôi không sở hữu, không lưu trữ nội dung này và sẽ không chịu trách nhiệm cho các vấn đề liên quan. Đề nghị khán giả cân nhắc trước khi xem.'
def ace(kenh, tenkenh):
	if 'acestream' in kenh:
		tach = kenh.split('//')
		p = tach[1]
	elif ':6878' in kenh:
		if '&' in kenh:
			match = re.search(r'id=(.*?)&', kenh)
			p = match.group(1)
		else:
			tach = kenh.split('id=')
			p = tach[1]
	kenhace = ''.join(("{'label': '", tenkenh.strip(),"', 'action': 'play', 'fanart': '', 'icon': '', 'id': '", p.strip(), "'}"))
	mahoa = base64.b64encode(kenhace.encode('utf-8')).decode('utf-8')
	mahoaa = urllib.parse.quote(mahoa)
	eca = 'plugin://script.module.horus/?%s' % mahoaa
	return eca
def getlink(url, ref, luu):
	try:
		resp = urlquick.get(url, timeout=5, max_age=luu, headers={'user-agent': useragent,'referer': ref.encode('utf-8')})
		resp.encoding = 'utf-8'
		return resp
	except:
		Script.notify(__addonnoti__, 'Lỗi kết nối, đang thử lại...')
		r = urlquick.get('https://mi3s.top/web?trang=%s' % url, timeout=5, max_age=luu, headers={'user-agent': useragent,'referer': ref.encode('utf-8')})
		r.encoding = 'utf-8'
		return r
def postlinktimfs(url, ref, luu):
	try:
		resp = urlquick.post(url, timeout=10, max_age=luu, headers={'user-agent': useragent,
			'referer': ref.encode('utf-8'),
			'authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJuYW1lIjoiZnNoYXJlIiwidXVpZCI6IjcxZjU1NjFkMTUiLCJ0eXBlIjoicGFydG5lciIsImV4cGlyZXMiOjAsImV4cGlyZSI6MH0.WBWRKbFf7nJ7gDn1rOgENh1_doPc07MNsKwiKCJg40U'})
	except:
		Script.notify(__addonnoti__, 'Lỗi kết nối')
		sys.exit()
	else:
		resp.encoding = 'utf-8'
		return resp
def stream(url):
	b = 'User-Agent=%s' % useragent
	if '|' in url:
		a = '%s&%s' % (url, b)
	else:
		a = '%s|%s' % (url, b)
	return a
def referer(url):
	a = urlparse(url)
	n = a.scheme
	m = a.netloc
	x = '&Origin=%s://%s&verifypeer=false&Referer=%s://%s/' % (n, m, n, m)
	return x
def replace_all(dict, str):
	for key in dict:
		str = str.replace(key, dict[key])
	return str
def get_user_input():
	search_term = xbmcgui.Dialog().input('%s - NumberCode được chia sẻ bởi facebook Hội mê Phim' % shorturl.upper())
	return search_term
def get_kara_input():
	search_term = xbmcgui.Dialog().input('Nhập tên bài hát')
	return search_term			
def get_info_fs(x):
	with Session() as s:
		idfd = re.search(r'(file|folder)/([A-Z0-9]+)', x).group(2)
		url = 'https://www.fshare.vn/api/v3/files/folder?linkcode=%s' % idfd
		headers = {'user-agent':useragent,'origin': 'https://www.fshare.vn','referer':'https://www.fshare.vn/'}
		r = s.get(url, headers=headers, timeout=10)
		if 'current' in r.text:
			l = r.json()['current']
			ten = re.sub('[\[\]\{\}]','.', l['name'])
			dungluong = l['size']
		else:
			ten = 'Dữ liệu này bị hỏng...'
			dungluong = 0
		return (ten, dungluong, x)
def userpassfs():
	username = __addon__.getSetting('username')
	password = __addon__.getSetting('password')
	if username == '' or password == '':
		__addon__.openSettings()
	else:
		payload = '{"app_key":"L2S7R6ZMagggC5wWkQhX2+aDi467PPuftWUMRFSn","user_email":"%s","password":"%s"}' % (username, password)
		head = {'cache-control': 'no-cache', 'User-Agent': useragentvmf}
		try:
			resp = urlquick.post('https://api.fshare.vn/api/user/login', data=payload, headers=head, timeout=10, max_age=6*60*60)
		except:
			xbmcgui.Dialog().ok(__addonnoti__, 'Sau 3 lần đăng nhập không thành công, tài khoản sẽ bị khoá 10 phút\nKiểm tra lại tài khoản, mật khẩu, đường truyền Internet...')
			__addon__.openSettings()
			sys.exit()
		else:
			token = resp.json()['token']
			session_id = resp.json()['session_id']
			return (token,session_id)
def getfs(x):
	login = userpassfs()
	session_id = login[1]
	token = login[0]
	payload = {'token': token, 'url': x}
	headerfsvn = {'User-Agent': useragentvmf, 'Cookie' : 'session_id=%s' % session_id }
	resp = urlquick.post('https://api.fshare.vn/api/session/download', timeout=10, max_age=0, json=payload, headers=headerfsvn)
	return resp.json()['location']
def getrow(row):
    if row is not None and row['v'] is not None:
        return row['v']
    else:
        return ''
def quangcao():
	item = Listitem()
	linkmacdinh = stream(qc)
	item.label = 'Đang cập nhật'
	item.info['plot'] = tb
	item.art['thumb'] = 'http://tamnguyenviet.vn/wp-content/uploads/2016/07/Icon-cap-nhat.png'
	item.art['fanart'] = 'http://tamnguyenviet.vn/wp-content/uploads/2016/07/Icon-cap-nhat.png'
	item.set_callback(play_vnm, linkmacdinh, item.label, '')
	return item
def tiengruoi():
	url = 'https://bit.ly/tiengruoi'
	r = getlink(url, url, 15*60)
	soup = BeautifulSoup(r.content, 'html.parser')
	subcat = [item.get('href') for item in soup.select('div.cl_item a')]
	return subcat
def xembd():
	url = 'https://xembd.link/'
	r = getlink(url, url, 15*60)
	soup = BeautifulSoup(r.content, 'html.parser')
	subcat = [item.get('href') for item in soup.select('a.mr_ml')]
	return subcat
def rakhoi():
	url = 'https://cakhia10.link/'
	r = getlink(url, url, 15*60)
	soup = BeautifulSoup(r.content, 'html.parser')
	subcat = [item.get('href') for item in soup.select('div.layout-4columns a')]
	return subcat
def cakhia():
	url = 'https://cakhia6.link/'
	r = getlink(url, url, 15*60)
	soup = BeautifulSoup(r.content, 'html.parser')
	subcat = [item.get('href') for item in soup.select('div.layout-4columns a')]
	return subcat
def caheo():
	url = 'https://caheo8.link/'
	r = getlink(url, url, 15*60)
	soup = BeautifulSoup(r.content, 'html.parser')
	subcat = [item.get('href') for item in soup.select('div.layout-4columns a')]
	return subcat
def cauthu():
	url = 'https://cauthu.link/'
	r = getlink(url, url, 15*60)
	soup = BeautifulSoup(r.content, 'html.parser')
	subcat = [item.get('href') for item in soup.select('div.layout-4columns a')]
	return subcat
def nocnha():
	url = 'https://nocnha.link/'
	r = getlink(url, url, 15*60)
	soup = BeautifulSoup(r.content, 'html.parser')
	subcat = [item.get('href') for item in soup.select('div.layout-4columns a')]
	return subcat
def saoke():
	url = 'https://saoke5.link/'
	r = getlink(url, url, 15*60)
	soup = BeautifulSoup(r.content, 'html.parser')
	subcat = [item.get('href') for item in soup.select('ul.list a')]
	return subcat
def mannhan():
	url = 'https://mannhan.tv/'
	r = getlink(url, url, 15*60)
	soup = BeautifulSoup(r.content, 'html.parser')
	subcat = [item.get('href') for item in soup.select('ul.list a')]
	return subcat
def cakhiaorg():
	url = 'https://cakhia18.link/'
	r = getlink(url, url, 15*60)
	soup = BeautifulSoup(r.content, 'html.parser')
	subcat = [item.get('href') for item in soup.select('a.mr_ml')]
	return subcat
@Resolver.register
def play_vnm(plugin,url,title,drmKey, **kwargs):
	if drmKey !='':
		is_helper = inputstreamhelper.Helper('mpd','com.widevine.alpha')
		if is_helper.check_inputstream():
			return Listitem().from_dict(**{'label': plugin._title,'subtitles':{news},'callback':url,'properties':{'inputstream':is_helper.inputstream_addon,'inputstream.adaptive.manifest_type':'mpd','inputstream.adaptive.license_type':'com.widevine.alpha','inputstream.adaptive.license_key':'%s||R{SSM}|' % drmKey}})
	elif '.m3u8' and 'http' in url :
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':url,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
	else:
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':url})
@Resolver.register
def ifr_xembong(plugin,url,title, **kwargs):
	resp = getlink(url, url, 10*60)
	if '.m3u8' and 'http' in resp.text:
		match = re.search(r'linkStream = \'(.*?)\'', resp.text)
		linkplay = '%s%s' % (stream(match.group(1)), referer(url))
	else:
		linkplay = stream(qc)
	return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
@Resolver.register
def ifr_bongda(plugin,url,title, **kwargs):
	r = getlink(url,url, 10*60)
	if 'allowfullscreen' in r.text:
		soup = BeautifulSoup(r.content, 'html.parser')
		ifr = soup.select_one('iframe[allowfullscreen]').get('src')
		resp = getlink(ifr, url, 10*60)
		if '.m3u8' and 'http' in resp.text:
			linkstream = re.search(r'((http|https)?:\/\/[^/\s]+/\S+?\.m3u8([^(\"|\')]*))', resp.text).group(1)
			d = getlink(linkstream, linkstream, 10*60).text
			if '.m3u8' and 'http' in d:
				a = re.search(r'((http|https)?:\/\/[^/\s]+/\S+?\.m3u8([^(\"|\')]*))', d).group(1)
			else:
				a = linkstream
			linkplay = '%s%s' % (stream(a), referer(ifr))
		else:
			linkplay = stream(qc)
	else:
		linkplay = stream(qc)
	return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
@Resolver.register
def ifr_xoilacme(plugin,url,title, **kwargs):
	resp = getlink(url, url, 10*60)
	if '.m3u8' and 'http' in resp.text:
		match = re.search(r'let mideoUrl = "(.*?)"', resp.text)
		linkplay = '%s%s' % (stream(match.group(1).replace('&amp;', '&')), referer(url))
	else:
		linkplay = stream(qc)
	return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
@Resolver.register
def play_fs(plugin,url,title, **kwargs):
	try:
		return Listitem().from_dict(**{'label': title,'subtitles' : {news},'callback': getfs(url)})
	except:
		Script.notify(__addonnoti__, 'Tập tin này bị hỏng hoặc đăng nhập không thành công')
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':stream(qc)})
@Resolver.register
def play_vtvrep(plugin,idx, title, **kwargs):
	url = 'https://vtvgo.vn/ajax-get-epg-detail?epg_id=%s' % idx
	resp = getlink(url, url, 10*60)
	if '.m3u8' and 'http' in resp.text:
		linkplay = stream(resp.json()['data'])
	else:
		linkplay = stream(qc)
	if '.m3u8' and 'http' in linkplay:
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
	else:
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay})
@Resolver.register
def playsocolive(plugin, numroom, timestamp, title, **kwargs):
	url = 'https://json.cvndnss.com/room/%s/detail.json?v=%s' % (numroom, timestamp)
	resp = getlink(url, url, 10*60)
	nd = re.search(r'(\{.*\})', resp.text, re.DOTALL).group(1)
	m = json.loads(nd)
	l = m['data']['stream']['hdM3u8']
	linkplay = '%s%s' % (stream(l), referer('https://www.soco.live/'))
	return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
@Resolver.register
def play_vtvgo(plugin, url, title, **kwargs):
	r = getlink(url, url, 60*60)
	x = r.cookies.get_dict()
	time = re.search(r"var time = '(.*?)'", r.text)[1]
	token = re.search(r"var token = '(.*?)'", r.text)[1]
	id = re.search(r'var id = (.*?);', r.text)[1]
	urlx = 'https://vtvgo.vn/ajax-get-stream'
	payload = {'type_id': '1','id': id,'time': time,'token': token}
	headx = {'user-agent': useragent,
	'x-requested-with': 'XMLHttpRequest',
	'referer': 'https://vtvgo.vn/xem-truc-tuyen-kenh-vtv-{id}.html',
	'content-type': 'application/x-www-form-urlencoded; charset=UTF-8'}
	resp = urlquick.post(urlx, data=urllib.parse.urlencode(payload, quote_via=urllib.parse.quote), cookies=x, headers=headx, max_age=15*60)
	linkplay = '%s%s' % (stream(resp.json()['chromecast_url']), referer(url))
	return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
@Resolver.register
def ifr_khomuc(plugin,url,title, **kwargs):
	resp = getlink(url, url, 10*60)
	match = re.search(r'((http|https)?:\/\/[^/\s]+/\S+?\.m3u8([^(\"|\')]*))', resp.text)
	linkplay = '%s%s' % (stream(match.group(1)), referer(url))
	return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
@Resolver.register
def play_bm(plugin,url,title, **kwargs):
	resp = getlink(url, url, 10*60)
	if 'streamingUrl' in resp.text:
		match = re.search(r'streamingUrl":"(.*?)"}', resp.text)
		linkplay = '%s%s' % (stream(match.group(1)), referer(url))
	else:
		linkplay = stream(qc)
	if '.m3u8' and 'http' in linkplay:
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
	else:
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay})