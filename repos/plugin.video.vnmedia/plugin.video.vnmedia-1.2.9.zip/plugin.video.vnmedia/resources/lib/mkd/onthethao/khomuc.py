from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from resources.lib.kedon import getlink, ifr_khomuc, quangcao
@Route.register
def index_khomuc(plugin, **kwargs):
	url = 'https://khomuc2.tv/'
	resp = getlink(url, url, 5*60)
	soup = BeautifulSoup(resp.content, 'html.parser')
	episodes = soup.select('section.home-live-now.container.position-relative.mt-5 div.item-live-now-match a.d-flex.flex-column.text-black')
	if len(episodes) > 0:
		for episode in episodes:
			item = Listitem()
			linktrandau = episode.get('href')
			if episode.select('div.d-flex.align-items-center.bg-white.px-3.py-3 span.flex-1.ms-1.fw-bold'):
				doinha = episode.select_one('div.d-flex.align-items-center.bg-white.px-3.py-3 span.flex-1.ms-1.fw-bold').get_text().strip()
				doikhach = episode.select_one('div.d-flex.align-items-center.bg-white.px-3.pb-3 span.flex-1.fw-bold.ms-1').get_text().strip()
				item.label = '%s vs %s' % (doinha, doikhach)
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://khomuc3.com/wp-content/uploads/2021/11/cropped-logo-website-khomuc.jpg'
				item.set_callback(ifr_khomuc, linktrandau, item.label)
				yield item
	else:
		yield quangcao()