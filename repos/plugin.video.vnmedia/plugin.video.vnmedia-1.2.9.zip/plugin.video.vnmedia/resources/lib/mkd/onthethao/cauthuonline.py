from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from resources.lib.kedon import getlink, ifr_bongda, quangcao
from datetime import datetime
import re,os
linkweb = 'https://cauthutv.online'
now = datetime.now()
timestamp = datetime.timestamp(now)
@Route.register
def index_cauthuonline(plugin, **kwargs):
	url = '%s/ajax/schedule-data?filter=live&%s' % (linkweb, timestamp)
	r = getlink(url,url, 15*60)
	if 'item-match' in r.text:
		soup = BeautifulSoup(r.content, 'html.parser')
		episodes = soup.select('a.item-match')
		for episode in episodes:
			item = Listitem()
			linktran = episode.get('href')
			thoigian = episode.select_one('div.time-match').get_text().strip()
			tenx = episode.select_one('div.body-web').get_text().rstrip(os.linesep)
			ten = re.sub(r'[\n\r]+', '', tenx).replace('vs', ' vs ')
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = '%s/wp-content/uploads/2022/07/cauthu_tv_logo.png' % linkweb
			item.label = '%s: %s' % (thoigian, ten)
			item.set_callback(ifr_bongda, linktran, item.label)
			yield item
	else:
		yield quangcao()