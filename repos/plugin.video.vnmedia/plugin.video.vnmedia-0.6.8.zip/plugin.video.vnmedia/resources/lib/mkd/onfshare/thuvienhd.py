from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from resources.lib.kedon import tb, replace_all, getlink, play_fs, __addonnoti__
from resources.lib.mkd.onfshare.ifshare import index_fs
from resources.lib.download import downloadfs
import xbmcgui, urllib
@Route.register
def search_thuvienhd(plugin,search_query):
	dp = xbmcgui.DialogProgress()
	dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
	search_query = urllib.parse.quote_plus(search_query)
	url = 'https://thuvienhd.com/?s=' + search_query.replace(' ','+')
	resp = getlink(url, url, 60*60)
	soup = BeautifulSoup(resp.text, 'html.parser')
	episodes = soup.select('div.search-page div.result-item')
	for episode in episodes:
		item = Listitem()
		anh = episode.select('img')
		for poster in anh:
			linkanh = poster.get('src')
			ten = poster.get('alt')
		linkphim = episode.select('div.title a')
		for urlphim in linkphim:
			phim = urlphim.get('href')
		ndp = episode.select('div.contenido')
		for inf in ndp:
			noidung = inf.text
		item.label = ten
		next_page = 2
		item.info['plot'] = noidung
		item.art['thumb'] =  linkanh
		item.art['fanart'] = linkanh
		item.set_callback(thuvienhd_linktk, phim)
		yield item
	if 'next page-numbers' in resp.text:
		yield Listitem.next_page(search_query, 2, callback=search_thuvienhdnext)
	else:
		yield []

@Route.register
def search_thuvienhdnext(plugin,search_query, next_page):
	search_query = urllib.parse.quote_plus(search_query)
	url = 'https://thuvienhd.com/page/' + str(next_page) + '?s=' + search_query.replace(' ','+')
	resp = getlink(url, url, 60*60)
	soup = BeautifulSoup(resp.text, 'html.parser')
	episodes = soup.select('div.search-page div.result-item')
	for episode in episodes:
		item = Listitem()
		anh = episode.select('img')
		for poster in anh:
			linkanh = poster.get('src')
			ten = poster.get('alt')
		linkphim = episode.select('div.title a')
		for urlphim in linkphim:
			phim = urlphim.get('href')
		ndp = episode.select('div.contenido')
		for inf in ndp:
			noidung = inf.text
		item.label = ten
		item.info['plot'] = noidung
		item.art['thumb'] =  linkanh
		item.art['fanart'] = linkanh
		item.set_callback(thuvienhd_linktk, phim)
		yield item
	if 'next page-numbers' in resp.text:
		item1 = Listitem()
		item1.label = 'Trang ' + str(next_page + 1)
		item1.art['thumb'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
		item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
		item1.set_callback(search_thuvienhdnext, search_query, next_page + 1)
		yield item1
	else:
		yield []

@Route.register
def thuvienhd_linktk(plugin, url):
	respx = getlink(url, url, 60*60)
	soupx = BeautifulSoup(respx.text, 'html.parser')
	episodesx = soupx.select('span.box__download a')
	for episodex in episodesx:
		linkid = episodex.get('href')
		resp = getlink(linkid, linkid, 15*60)
		soup = BeautifulSoup(resp.text, 'html.parser')
		episodes = soup.select('tbody.tbody.outer a')
		for episode in episodes:
			item = Listitem()
			link = episode.get('href')
			ten = episode.get('title')
			for dungluong in episode.select('div.face-secondary'):
				if 'folder' in link:
					item.label = ten + ' ' + dungluong.text.strip()
					thumuc = link.split('folder/')
					item.art['thumb'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=' + link + '&qzone=1&margin=1&size=400x400&ecc=L'
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					item.set_callback(index_fs, thumuc[1], 1)
					yield item
				elif 'file' in link:
					item.label = ten + ' ' + dungluong.text.strip()
					item.art['thumb'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=' + link + '&qzone=1&margin=1&size=400x400&ecc=L'
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					item.context.script(downloadfs, 'Tải về', link)
					item.set_callback(play_fs, link, item.label)
					yield item
				else:
					yield []

@Route.register
def index_thuvienhd(plugin,content_type='segment'):
	yield Listitem.search(search_thuvienhd)
	url = 'https://thuvienhd.com/'
	resp = getlink(url, url, 60*60)
	thaythe = {
	'Phần Mềm':'Bluray Nguyên Gốc',
	'genre/software':'genre/bluray-nguyen-goc',
	'MacOS':'ATV',
	'genre/macos':'genre/atv',
	'Game':'Việt Nam',
	'genre/game':'genre/vietnamese'
	}
	goc = replace_all(thaythe, resp.text)
	soup = BeautifulSoup(goc, 'html.parser')
	episodes = soup.select('div.menu-menu-main-container li a')
	for episode in episodes:
		item = Listitem()
		if 'thuvienhd.com' in episode.get('href'):
			phim = episode.get('href') + '/page/'
			item.label = episode.text
			item.info['plot'] = tb
			next_page = 1
			item.art['thumb'] =  'https://thuvienhd.com/wp-content/uploads/2020/10/THUVIENHD.NET_.png'
			item.art['fanart'] = 'https://thuvienhd.com/wp-content/uploads/2020/10/THUVIENHD.NET_.png'
			item.set_callback(thuvienhd_page, phim, next_page)
			yield item
		else:
			yield []

@Route.register
def thuvienhd_page(plugin, url, next_page):
	trangtiep = url + str(next_page)
	resp = getlink(trangtiep, trangtiep, 60*60)
	soup = BeautifulSoup(resp.text, 'html.parser')
	episodes = soup.select('div.items article')
	for episode in episodes:
		item = Listitem()
		idtv = episode.get('id')
		anh = episode.select('img')
		if 'texto' in resp.text:
			nd = episode.select('div.texto')
			for ndp in nd:
				noidung = ndp.text
		else:
			noidung = tb
		for poster in anh:
			linkanh = poster.get('src')
			ten = poster.get('alt')
		item.label = ten
		item.info['plot'] = noidung
		item.art['thumb'] = linkanh
		item.art['fanart'] = linkanh
		item.set_callback(thuvienhd_link, idtv)
		yield item
	item1 = Listitem()
	item1.label = 'Trang ' + str(next_page + 1)
	item1.art['thumb'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
	item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
	item1.set_callback(thuvienhd_page, url, next_page + 1)
	yield item1

@Route.register
def thuvienhd_link(plugin, url):
	tach = url.split('-')
	p = tach[1]
	resp = getlink('https://thuvienhd.com/download?id=' + p, url, 60*60)
	soup = BeautifulSoup(resp.text, 'html.parser')
	episodes = soup.select('tbody.tbody.outer a')
	for episode in episodes:
		item = Listitem()
		link = episode.get('href')
		ten = episode.get('title')
		if (ten is not None):
			for dungluong in episode.select('div.face-secondary'):
				if 'folder' in link:
					item.label = ten + ' ' + dungluong.text.strip()
					thumuc = link.split('folder/')
					item.art['thumb'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=' + link + '&qzone=1&margin=1&size=400x400&ecc=L'
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					item.set_callback(index_fs, thumuc[1], 1)
					yield item
				elif 'file' in link:
					item.label = ten + ' ' + dungluong.text.strip()
					item.art['thumb'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=' + link + '&qzone=1&margin=1&size=400x400&ecc=L'
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					item.context.script(downloadfs, 'Tải về', link)
					item.set_callback(play_fs, link, item.label)
					yield item
				else:
					yield []
		else:
			yield []