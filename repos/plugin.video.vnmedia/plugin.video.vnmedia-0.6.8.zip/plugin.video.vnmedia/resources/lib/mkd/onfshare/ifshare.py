from codequick import Route, Listitem, run, Script
from resources.lib.kedon import __addon__, getlink, __icon__, __addonnoti__, convert_bytes, play_fs, userpassfs, useragentvmf
from resources.lib.download import downloadfs
import urlquick, xbmc, xbmcgui, re
@Route.register
def index_fs(plugin, idfd, next_page):
	url = 'https://www.fshare.vn/api/v3/files/folder?linkcode=%s&sort=type,name&page=%s' % (idfd, str(next_page))
	kq = getlink(url, url, 60*60)
	if 'items' in kq.text and len(kq.json()['items']) > 0:
		for k in kq.json()['items']:
			item = Listitem()
			if k['type'] == 0:
				item.label = k['name']
				linkfd = k['linkcode']
				linkplay = 'https://www.fshare.vn/folder/' + linkfd
				item.art['thumb'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=' + linkplay + '&qzone=1&margin=1&size=400x400&ecc=L'
				item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item.set_callback(index_fs, linkfd, 1)
				yield item
			elif k['type'] == 1:
				item.label = k['name'] + ' (' + convert_bytes(k['size']) + ')'
				linkplay = 'https://www.fshare.vn/file/' + k['linkcode']
				item.art['thumb'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=' + linkplay + '&qzone=1&margin=1&size=400x400&ecc=L'
				item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item.context.script(downloadfs, 'Tải về', linkplay)
				item.set_callback(play_fs, linkplay, item.label)
				yield item
			else:
				yield []
	else:
		xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonnoti__, u'Fshare link folder die', 10000, __icon__))
		xbmc.executebuiltin('Container.Refresh')
	if kq.json().get('_links').get('last'):
		last_page = re.search(r'&page=(\d+)', kq.json().get('_links').get('last')).group(1)
		if int(last_page) > next_page:
			item1 = Listitem()
			item1.label = 'Trang ' + str(next_page + 1)
			item1.art['thumb'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
			item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
			item1.set_callback(index_fs, idfd, next_page + 1)
			yield item1

@Route.register
def fs_favorite(plugin, content_type='segment'):
	try:
		session_id = userpassfs()[1]
		headerfsvn = {'User-Agent': useragentvmf, 'Cookie' : 'session_id=' + session_id }
		resp = urlquick.get('https://api.fshare.vn/api/fileops/listFavorite', timeout=30, max_age=15*60, headers=headerfsvn)
	except:
		xbmcgui.Dialog().ok(__addonnoti__, 'Đăng nhập không thành công\nKiểm tra lại tài khoản, mật khẩu, đường truyền Internet')
		__addon__.openSettings()
		exit()
	for k in resp.json():
		if k['type'] == '0':
			item = Listitem()
			item.label = k['name']
			linkfd = k['linkcode']
			linkplay = 'https://www.fshare.vn/folder/' + linkfd
			item.art['thumb'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=' + linkplay + '&qzone=1&margin=1&size=400x400&ecc=L'
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			item.set_callback(index_fs, linkfd, 1)
			yield item
		elif k['type'] == '1':
			item = Listitem()
			item.label = k['name']
			linkplay = 'https://www.fshare.vn/file/' + k['linkcode']
			item.art['thumb'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=' + linkplay + '&qzone=1&margin=1&size=400x400&ecc=L'
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			item.context.script(downloadfs, 'Tải về', linkplay)
			item.set_callback(play_fs, linkplay, item.label)
			yield item
		else:
			yield []

@Route.register
def fs_topfollow(plugin, content_type='segment'):
	session_id = userpassfs()[1]
	headerfsvn = {'User-Agent': useragentvmf, 'Cookie' : 'session_id=' + session_id }
	try:
		resp = urlquick.get('https://api.fshare.vn/api/fileops/getTopFollowMovie', timeout=30, max_age=7*24*60*60, headers=headerfsvn)
	except:
		xbmcgui.Dialog().ok(__addonnoti__, 'Đăng nhập không thành công\nKiểm tra lại tài khoản, mật khẩu, đường truyền Internet')
		__addon__.openSettings()
		exit()
	for k in resp.json():
		item = Listitem()
		item.label = k['name']
		linkfd = k['linkcode']
		linkplay = 'https://www.fshare.vn/folder/' + linkfd
		item.art['thumb'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=' + linkplay + '&qzone=1&margin=1&size=400x400&ecc=L'
		item.art['fanart'] = 'https://www.fshare.vn/images/top-follow/title.png'
		item.set_callback(index_fs, linkfd, 1)
		yield item