from codequick import Route, Listitem, run
from datetime import datetime, timedelta
from resources.lib.kedon import qc, tb, getlink, stream, referer, play_vnm
from bs4 import BeautifulSoup
@Route.register
def index_xembd(plugin, content_type='segment'):
	url = 'https://zencdn.xyz/static/json/common/live.json'
	resp = getlink(url, url, 5*60)
	if 'link' in resp.text:
		kq = resp.json()
		for k in kq:
			item = Listitem()
			item.label = k['time'] + ' ' + k['title']
			item.art['thumb'] = 'https://xembd1.live/wp-content/themes/v2.1/assets/images/logo.png'
			item.art['fanart'] = 'https://xembd1.live/wp-content/themes/v2.1/assets/images/logo.png'
			item.set_callback(list_xembede, 'https://xembd1.live' + k['link'], item.label)
			yield item
	else:
		item = Listitem()
		linkmacdinh = stream(qc)
		item.label = 'Đang cập nhật'
		item.info['plot'] = tb
		item.art['thumb'] = 'http://tamnguyenviet.vn/wp-content/uploads/2016/07/Icon-cap-nhat.png'
		item.art['fanart'] = 'http://tamnguyenviet.vn/wp-content/uploads/2016/07/Icon-cap-nhat.png'
		item.set_callback(play_vnm, linkmacdinh, item.label, '')
		yield item

@Route.register
def list_xembede(plugin,url,title):
	resp = getlink(url, url, 15*60)
	if 'm3u8' in resp.text:
		web = BeautifulSoup(resp.text, 'html.parser')
		for k in web.body.select('video-js.video-js source'):
			item = Listitem()
			linktrandau = stream(k.get('src')) + referer('https://xembd1.live')
			item.label = k.get('label') + ' - ' + title
			item.art['thumb'] = 'https://xembd1.live/wp-content/themes/v2.1/assets/images/logo.png'
			item.art['fanart'] = 'https://xembd1.live/wp-content/themes/v2.1/assets/images/logo.png'
			item.set_callback(play_vnm, linktrandau, item.label, '')
			yield item
	else:
		item = Listitem()
		linkmacdinh = stream(qc)
		item.label = 'Đang cập nhật'
		item.info['plot'] = tb
		item.art['thumb'] = 'http://tamnguyenviet.vn/wp-content/uploads/2016/07/Icon-cap-nhat.png'
		item.art['fanart'] = 'http://tamnguyenviet.vn/wp-content/uploads/2016/07/Icon-cap-nhat.png'
		item.set_callback(play_vnm, linkmacdinh, item.label, '')
		yield item