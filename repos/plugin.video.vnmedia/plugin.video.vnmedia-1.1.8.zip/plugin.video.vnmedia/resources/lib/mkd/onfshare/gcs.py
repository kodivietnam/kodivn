from codequick import Route, Listitem, run
from resources.lib.kedon import __addon__, getrow, tb, getlink, play_fs
from resources.lib.mkd.onfshare.ifshare import index_fs, tfavo
from resources.lib.download import downloadfs
import re, json
@Route.register
def index_gcs(plugin, dataUrl='TextURL'):
    urltext = __addon__.getSetting(dataUrl)
    respx = getlink(urltext, urltext, 15*60)
    x = respx.url
    if 'docs.google.com' in x:
        if 'gid' in x:
            timid = re.findall(r'/d/(.*?)/.*?gid=(\d+)', x)
            sid = timid[0][0]
            gid = timid[0][1]
        else:
            sid = re.findall(r'/d/(.*?)/', x)[0]
            gid = '0'
        url = 'https://docs.google.com/spreadsheets/d/' + \
            sid + '/gviz/tq?gid=' + gid + '&headers=1'
        resp = getlink(url, url, 15*60)
        nd = re.search(r'\((.*?)}\)', resp.text).group(1) + '}'
        m = json.loads(nd)
        k1 = m['table']['cols'][0]['label']
        if r'|http' in resp.text:
            item1 = Listitem()
            tachhat1 = k1.split('|')
            if len(tachhat1) > 1:
                kenh = tachhat1[1]
                item1.label = tachhat1[0].translate(str.maketrans({'*': '', '@': ''}))
                item1.context.script(tfavo, 'Thêm vào Fshare Favorite', kenh)
                if len(tachhat1) > 3:
                    item1.art['thumb'] = tachhat1[3]
                    item1.art['fanart'] = tachhat1[3]
                else:
                    item1.art['thumb'] = 'https://i.imgur.com/EpIPQXR.png'
                    item1.art['fanart'] = 'https://i.imgur.com/EpIPQXR.png'
                if len(tachhat1) > 4:
                    item1.info['plot'] = tachhat1[4]
                else:
                    item1.info['plot'] = tb
                if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                    thumuc = kenh.split('folder/')
                    item1.set_callback(index_fs, thumuc[1], 1)
                elif r'file' in kenh:
                    item1.context.script(downloadfs, 'Tải về', kenh)
                    item1.set_callback(play_fs, kenh, item1.label)
                elif r'docs.google.com' in kenh:
                    item1.set_callback(listgg_gcs, kenh, item1.label)
                elif r'VMF' in kenh:
                    item1.set_callback(
                        listvmf_gcs, kenh.replace('VMF-', ''), item1.label)
                yield item1
            for row in m['table']['rows']:
                item2 = Listitem()
                k2 = getrow(row['c'][0])
                tachhat2 = k2.split('|')
                if len(tachhat2) > 1:
                    kenh = tachhat2[1]
                    item2.label = tachhat2[0].translate(str.maketrans({'*': '', '@': ''}))
                    item2.context.script(tfavo, 'Thêm vào Fshare Favorite', kenh)
                    if len(tachhat2) > 3:
                        item2.art['thumb'] = tachhat2[3]
                        item2.art['fanart'] = tachhat2[3]
                    else:
                        item2.art['thumb'] = 'https://i.imgur.com/EpIPQXR.png'
                        item2.art['fanart'] = 'https://i.imgur.com/EpIPQXR.png'
                    if len(tachhat2) > 4:
                        item2.info['plot'] = tachhat2[4]
                    else:
                        item2.info['plot'] = tb
                    if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                        thumuc = kenh.split('folder/')
                        item2.set_callback(index_fs, thumuc[1], 1)
                    elif r'file' in kenh:
                        item2.context.script(downloadfs, 'Tải về', kenh)
                        item2.set_callback(play_fs, kenh, item2.label)
                    elif r'docs.google.com' in kenh:
                        item2.set_callback(listgg_gcs, kenh, item2.label)
                    elif r'VMF' in kenh:
                        item2.set_callback(
                            listvmf_gcs, kenh.replace('VMF-', ''), item2.label)
                    yield item2
        else:
            if 'http' in m['table']['cols'][1]['label']:
                item = Listitem()
                kenh = m['table']['cols'][1]['label']
                item.context.script(tfavo, 'Thêm vào Fshare Favorite', kenh)
                item.label = m['table']['cols'][0]['label']
                if len(m['table']['cols']) > 2:
                    item.art['thumb'] = m['table']['cols'][2]['label']
                    item.art['fanart'] = m['table']['cols'][2]['label']
                else:
                    item.art['thumb'] = 'https://i.imgur.com/EpIPQXR.png'
                    item.art['fanart'] = 'https://i.imgur.com/EpIPQXR.png'
                if len(m['table']['cols']) > 3:
                    item.info['plot'] = m['table']['cols'][3]['label']
                else:
                    item.info['plot'] = tb
                if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                    thumuc = kenh.split('folder/')
                    item.set_callback(index_fs, thumuc[1], 1)
                elif r'file' in kenh:
                    item.context.script(downloadfs, 'Tải về', kenh)
                    item.set_callback(play_fs, kenh, item.label)
                elif r'docs.google.com' in kenh:
                    item.set_callback(listgg_gcs, kenh, item.label)
                elif r'VMF' in kenh:
                    item.set_callback(
                        listvmf_gcs, kenh.replace('VMF-', ''), item.label)
                yield item
            for row in m['table']['rows']:
                item = Listitem()
                item.label = getrow(row['c'][0])
                kenh = getrow(row['c'][1])
                item.context.script(tfavo, 'Thêm vào Fshare Favorite', kenh)
                if len(row['c']) > 2:
                    item.art['thumb'] = getrow(row['c'][2])
                    item.art['fanart'] = getrow(row['c'][2])
                else:
                    item.art['thumb'] = 'https://i.imgur.com/EpIPQXR.png'
                    item.art['fanart'] = 'https://i.imgur.com/EpIPQXR.png'
                if len(row['c']) > 3:
                    item.info['plot'] = getrow(row['c'][3])
                else:
                    item.info['plot'] = tb
                if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                    thumuc = kenh.split('folder/')
                    item.set_callback(index_fs, thumuc[1], 1)
                elif r'file' in kenh:
                    item.context.script(downloadfs, 'Tải về', kenh)
                    item.set_callback(play_fs, kenh, item.label)
                elif r'docs.google.com' in kenh:
                    item.set_callback(listgg_gcs, kenh, item.label)
                elif r'VMF' in kenh:
                    item.set_callback(
                        listvmf_gcs, kenh.replace('VMF-', ''), item.label)
                yield item
    else:
        kq = '\n'.join([ll.rstrip()
                       for ll in respx.text.splitlines() if ll.strip()])
        tach = kq.split('\n')
        for k in tach:
            item = Listitem()
            tachhat = k.split('|')
            if len(tachhat) > 1:
                kenh = tachhat[1]
                item.context.script(tfavo, 'Thêm vào Fshare Favorite', kenh)
                item.label = tachhat[0].translate(str.maketrans({'*': '', '@': ''}))
                if len(tachhat) > 3:
                    item.art['thumb'] = tachhat[3]
                    item.art['fanart'] = tachhat[3]
                else:
                    item.art['thumb'] = 'https://i.imgur.com/EpIPQXR.png'
                    item.art['fanart'] = 'https://i.imgur.com/EpIPQXR.png'
                if len(tachhat) > 4:
                    item.info['plot'] = tachhat[4]
                else:
                    item.info['plot'] = tb
                if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                    thumuc = kenh.split('folder/')
                    item.set_callback(index_fs, thumuc[1], 1)
                elif r'file' in kenh:
                    item.context.script(downloadfs, 'Tải về', kenh)
                    item.set_callback(play_fs, kenh, item.label)
                elif r'docs.google.com' in kenh:
                    item.set_callback(listgg_gcs, kenh, item.label)
                elif r'VMF' in kenh:
                    l = kenh.replace('VMF-', '')
                    item.set_callback(listvmf_gcs, l, item.label)
                yield item
@Route.register
def listgg_gcs(plugin, urltext, title):
    if 'gid' in urltext:
        timid = re.findall(r'/d/(.+?)/.+?gid=(\d+)', urltext)
        sid = timid[0][0]
        gid = timid[0][1]
    else:
        sid = re.findall(r'/d/(.*?)/', urltext)[0]
        gid = '0'
    url = 'https://docs.google.com/spreadsheets/d/' + \
        sid + '/gviz/tq?gid=' + gid + '&headers=1'
    resp = getlink(url, url, 15*60)
    nd = re.search(r'\((.*?)}\)', resp.text).group(1) + '}'
    m = json.loads(nd)
    k1 = m['table']['cols'][0]['label']
    if r'|http' in resp.text:
        item1 = Listitem()
        tachhat1 = k1.split('|')
        if len(tachhat1) > 1:
            kenh = tachhat1[1]
            item1.context.script(tfavo, 'Thêm vào Fshare Favorite', kenh)
            item1.label = tachhat1[0].translate(str.maketrans({'*': '', '@': ''}))
            if len(tachhat1) > 3:
                item1.art['thumb'] = tachhat1[3]
                item1.art['fanart'] = tachhat1[3]
            else:
                item1.art['thumb'] = 'https://i.imgur.com/EpIPQXR.png'
                item1.art['fanart'] = 'https://i.imgur.com/EpIPQXR.png'
            if len(tachhat1) > 4:
                item1.info['plot'] = tachhat1[4]
            else:
                item1.info['plot'] = tb
            if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                thumuc = kenh.split('folder/')
                item1.set_callback(index_fs, thumuc[1], 1)
            elif r'file' in kenh:
                item1.context.script(downloadfs, 'Tải về', kenh)
                item1.set_callback(play_fs, kenh, item1.label)
            elif r'docs.google.com' in kenh:
                item1.set_callback(listgg_gcs, kenh, item1.label)
            elif r'VMF' in kenh:
                item1.set_callback(
                    listvmf_gcs, kenh.replace('VMF-', ''), item1.label)
            yield item1
        for row in m['table']['rows']:
            item2 = Listitem()
            k2 = getrow(row['c'][0])
            tachhat2 = k2.split('|')
            if len(tachhat2) > 1:
                kenh = tachhat2[1]
                item2.context.script(tfavo, 'Thêm vào Fshare Favorite', kenh)
                item2.label = tachhat2[0].translate(str.maketrans({'*': '', '@': ''}))
                if len(tachhat2) > 3:
                    item2.art['thumb'] = tachhat2[3]
                    item2.art['fanart'] = tachhat2[3]
                else:
                    item2.art['thumb'] = 'https://i.imgur.com/EpIPQXR.png'
                    item2.art['fanart'] = 'https://i.imgur.com/EpIPQXR.png'
                if len(tachhat2) > 4:
                    item2.info['plot'] = tachhat2[4]
                else:
                    item2.info['plot'] = tb
                if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                    thumuc = kenh.split('folder/')
                    item2.set_callback(index_fs, thumuc[1], 1)
                elif r'file' in kenh:
                    item2.context.script(downloadfs, 'Tải về', kenh)
                    item2.set_callback(play_fs, kenh, item2.label)
                elif r'docs.google.com' in kenh:
                    item2.set_callback(listgg_gcs, kenh, item2.label)
                elif r'VMF' in kenh:
                    item2.set_callback(
                        listvmf_gcs, kenh.replace('VMF-', ''), item2.label)
                yield item2
    else:
        if 'http' in m['table']['cols'][1]['label']:
            item = Listitem()
            kenh = m['table']['cols'][1]['label']
            item.context.script(tfavo, 'Thêm vào Fshare Favorite', kenh)
            item.label = m['table']['cols'][0]['label']
            if len(m['table']['cols']) > 2:
                item.art['thumb'] = m['table']['cols'][2]['label']
                item.art['fanart'] = m['table']['cols'][2]['label']
            else:
                item.art['thumb'] = 'https://i.imgur.com/EpIPQXR.png'
                item.art['fanart'] = 'https://i.imgur.com/EpIPQXR.png'
            if len(m['table']['cols']) > 3:
                item.info['plot'] = m['table']['cols'][3]['label']
            else:
                item.info['plot'] = tb
            if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                thumuc = kenh.split('folder/')
                item.set_callback(index_fs, thumuc[1], 1)
            elif r'file' in kenh:
                item.context.script(downloadfs, 'Tải về', kenh)
                item.set_callback(play_fs, kenh, item.label)
            elif r'docs.google.com' in kenh:
                item.set_callback(listgg_gcs, kenh, item.label)
            elif r'VMF' in kenh:
                item.set_callback(
                    listvmf_gcs, kenh.replace('VMF-', ''), item.label)
            yield item
        for row in m['table']['rows']:
            item = Listitem()
            item.label = getrow(row['c'][0])
            kenh = getrow(row['c'][1])
            item.context.script(tfavo, 'Thêm vào Fshare Favorite', kenh)
            if len(row['c']) > 2:
                item.art['thumb'] = getrow(row['c'][2])
                item.art['fanart'] = getrow(row['c'][2])
            else:
                item.art['thumb'] = 'https://i.imgur.com/EpIPQXR.png'
                item.art['fanart'] = 'https://i.imgur.com/EpIPQXR.png'
            if len(row['c']) > 3:
                item.info['plot'] = getrow(row['c'][3])
            else:
                item.info['plot'] = tb
            if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                thumuc = kenh.split('folder/')
                item.set_callback(index_fs, thumuc[1], 1)
            elif r'file' in kenh:
                item.context.script(downloadfs, 'Tải về', kenh)
                item.set_callback(play_fs, kenh, item.label)
            elif r'docs.google.com' in kenh:
                item.set_callback(listgg_gcs, kenh, item.label)
            elif r'VMF' in kenh:
                l = kenh.replace('VMF-', '')
                item.set_callback(listvmf_gcs, l, item.label)
            yield item
@Route.register
def listvmf_gcs(plugin, url, title):
    resp = getlink(url, url, 15*60)
    kq = '\n'.join([ll.rstrip()
                   for ll in resp.text.splitlines() if ll.strip()])
    tach = kq.split('\n')
    for k in tach:
        item = Listitem()
        tachhat = k.split('|')
        if len(tachhat) > 1:
            kenh = tachhat[1]
            item.context.script(tfavo, 'Thêm vào Fshare Favorite', kenh)
            item.label = tachhat[0].translate(str.maketrans({'*': '', '@': ''}))
            if len(tachhat) > 3:
                item.art['thumb'] = tachhat[3]
                item.art['fanart'] = tachhat[3]
            else:
                item.art['thumb'] = 'https://i.imgur.com/EpIPQXR.png'
                item.art['fanart'] = 'https://i.imgur.com/EpIPQXR.png'
            if len(tachhat) > 4:
                item.info['plot'] = tachhat[4]
            else:
                item.info['plot'] = tb
            if r'folder' in kenh and len(kenh.split('folder/')) > 1:
                thumuc = kenh.split('folder/')
                item.set_callback(index_fs, thumuc[1], 1)
            elif r'file' in kenh:
                item.context.script(downloadfs, 'Tải về', kenh)
                item.set_callback(play_fs, kenh, item.label)
            elif r'docs.google.com' in kenh:
                item.set_callback(listgg_gcs, kenh, item.label)
            elif r'VMF' in kenh:
                l = kenh.replace('VMF-', '')
                item.set_callback(listvmf_gcs, l, item.label)
            yield item