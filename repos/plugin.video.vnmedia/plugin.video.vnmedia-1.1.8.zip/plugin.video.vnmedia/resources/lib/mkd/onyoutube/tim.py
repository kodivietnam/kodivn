from codequick import Route, Listitem, run, Script
from resources.lib.kedon import getlink, get_kara_input, __addonnoti__, quangcao
from resources.lib.mkd.onyoutube.video import youtube_tatcavideo, youtube_kenh
import re, xbmcgui, urllib
@Route.register
def search_youtube(plugin,search_query, **kwargs):
	dp = xbmcgui.DialogProgress()
	dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
	search_query = urllib.parse.quote_plus(search_query)
	url = 'https://www.youtube.com/results?search_query=%s' % search_query.replace(' ','+')
	resp = getlink(url, url, 15*60)
	kq = resp.text.replace('\\','')
	if 'videoRenderer' in kq:
		listplay = re.findall(r'videoRenderer(.*?)accessibility', kq)
		for k in listplay:
			item = Listitem()
			tenvd = re.search(r'text":"(.*?)"}', k).group(1)
			idvd = re.search(r'videoId":"(.*?)"', k).group(1)
			anhvd = 'https://img.youtube.com/vi/%s/0.jpg' % idvd
			item.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=%s' % idvd
			item.label = tenvd
			item.art['thumb'] = item.art['landscape'] = item.art["fanart"] = anhvd
			item.set_callback(item.path)
			yield item
	elif 'playlistRenderer' in kq:
		listplay1 = re.findall(r'playlistRenderer(.*?)webPageType', kq)
		for k1 in listplay1:
			item1 = Listitem()
			tenvd1 = re.search(r'"simpleText":"(.*?)"}', k1).group(1)
			idvd1 = re.search(r'webCommandMetadata":{"url":"(.*?)"', k1).group(1)
			anhvd1 = 'https://img.youtube.com/vi/%s/0.jpg' % idvd1
			item1.label = tenvd
			item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = anhvd1
			item1.set_callback(youtube_tatcavideo, '%s%s' % (url, idvd1))
			yield item1
	elif 'channelRenderer' in kq:
		listplay2 = re.findall(r'channelRenderer(.*?)webPageType', kq)
		for k2 in listplay2:
			item2 = Listitem()
			tenvd2 = re.search(r'"simpleText":"(.*?)"}', k2).group(1)
			idvd2 = re.search(r'"url":"(.*?)"', k2).group(1)
			anhvd2 = 'https://img.youtube.com/vi/%s/0.jpg' % idvd2
			item2.label = tenvd2
			item2.art['thumb'] = item2.art['landscape'] = item2.art['fanart'] = 'https:%s' % anhvd2
			item2.set_callback(youtube_kenh, '%s%s' % (url, idvd2))
			yield item2
	else:
		yield []

@Route.register
def search_karaoke(plugin,search_query, **kwargs):
	search_query = get_kara_input()
	if search_query == '':
		Script.notify(__addonnoti__, 'Bạn chưa nhập từ khoá tìm kiếm')
		yield quangcao()
	else:
		dp = xbmcgui.DialogProgress()
		dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
		search_query = urllib.parse.quote_plus(search_query)
		url = 'https://www.youtube.com/results?search_query=karaoke+%s' % search_query.replace(' ','+')
		resp = getlink(url, url, 48*60*60)
		kq = resp.text.replace('\\','')
		listplay = re.findall(r'videoRenderer(.*?)accessibility', kq)
		for k in listplay:
			item = Listitem()
			tenvd = re.search(r'text":"(.*?)"}', k).group(1)
			idvd = re.search(r'videoId":"(.*?)"', k).group(1)
			anhvd = 'https://img.youtube.com/vi/%s/0.jpg' % idvd
			item.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=%s' % idvd
			item.label = tenvd
			item.art['thumb'] = item.art['landscape'] = item.art['fanart']= anhvd
			item.set_callback(item.path)
			yield item