from codequick import Route, Listitem, Script
@Route.register
def listiptv_root(plugin):
	streams = [
		('Xem lại truyền hình', 'https://mi3s.top/thumb/xemlaitv.png', '/resources/lib/mkd/ontruyenhinh/replayvtv:index_vtv'),
		('VTVGO', 'https://mi3s.top/thumb/vtvgo.png', '/resources/lib/mkd/ontruyenhinh/vtvgo:index_vtvgo')
	]
	T = {'Truyền hình FPT1': 'https://raw.githubusercontent.com/ntd249/ntdiptv/main/fptudp',
	'Truyền hình FPT2': 'https://raw.githubusercontent.com/thanh51/repository.thanh51/master/ONETV.m3u',
	'Truyền hình VNPT': 'https://raw.githubusercontent.com/ntd249/ntdiptv/main/mytvrtp',
	'Truyền hình Viettel': 'https://raw.githubusercontent.com/ntd249/ntdiptv/main/viettelrtp',
	'CVMedia': 'https://cvtv.xyz',
	'VthanhTV': 'http://vthanhtivi.pw',
	'SN-TV': 'https://synguyen.net/tv',
	'KhangPlus': 'https://khanggtivi.xyz',
	'VietNgaTV': 'https://raw.githubusercontent.com/phuhdtv/vietngatv/master/vietngatv.m3u',
	'PhapSonyTx5': 'http://phaptx5.x10.mx/phaptx5.html',
	'BepTV': 'http://b4tv.live/b4tv.m3u',
	'Thanh51': 'https://raw.githubusercontent.com/thanh51/repository.thanh51/master/IPTV.m3u',
	'SN-Sport': 'https://synguyen.net/thethao',
	'AXT 4K Sport': 'https://raw.githubusercontent.com/MrToBun007/AXT/main/4K-UHD.m3u',
	'Phim miễn phí': 'http://iptv.pro.vn/phimiptv',
	'ChinaTV': 'http://hqth.me/china-tv',
	'Quốc tế': 'https://raw.githubusercontent.com/thanh51/repository.thanh51/master/IPTV.m3u',
	'IPTV-ORG All': 'https://iptv-org.github.io/iptv/index.m3u',
	'IPTV-ORG Category': 'https://iptv-org.github.io/iptv/index.category.m3u',
	'IPTV-ORG Language': 'https://iptv-org.github.io/iptv/index.language.m3u',
	'IPTV-ORG Country': 'https://iptv-org.github.io/iptv/index.country.m3u',
	'IPTV-ORG Region': 'https://iptv-org.github.io/iptv/index.region.m3u'}
	if 'http' in Script.setting.get_string('myiptv'):
		iv = Listitem()
		iv.label = 'My List IPTV'
		iv.info['mediatype'] = 'tvshow'
		iv.art['thumb'] = iv.art['poster'] = 'https://mi3s.top/thumb/iptv.png'
		iv.set_callback(Route.ref('/resources/lib/mkd/ontruyenhinh/listiptv:list_iptv'), Script.setting.get_string('myiptv'))
		yield iv
	for name_key, banner_key, route_key in streams:
		i = Listitem()
		i.label = name_key
		i.info['mediatype'] = 'tvshow'
		i.art['thumb'] = i.art['poster'] = banner_key
		i.set_callback(Route.ref(route_key))
		yield i
	for k in T:
		item = Listitem()
		item.label = k
		item.info['mediatype'] = 'tvshow'
		item.art['thumb'] = item.art['poster'] = 'https://mi3s.top/thumb/iptv.png'
		item.set_callback(Route.ref('/resources/lib/mkd/ontruyenhinh/listiptv:list_iptv'), T[k])
		yield item