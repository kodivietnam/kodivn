from codequick import Route, Listitem, run
@Route.register
def index_livetvxs(plugin, **kwargs):
	from resources.lib.kedon import quangcao, getlink, ace
	url = 'http://livetv.sx/export/webmasters.php?lang=en'
	resp = getlink(url, url, 1000)
	if resp is not None:
		if 'acestream' in resp.text:
			from datetime import datetime, timedelta, date
			from bs4 import BeautifulSoup
			soup = BeautifulSoup(resp.content, 'html.parser')
			episodes = soup.select('tr td')
			for episode in episodes:
				z = episode.select('td.time')
				for w in z:
					timex = w.get_text().strip()
					if len(timex)==4:
						y = f'{date.today()}T0{timex}'
					else:
						y = f'{date.today()}T{timex}'
					z = (datetime.fromisoformat(y) + timedelta(hours=6)).strftime('%H:%M')
				a = episode.select('td a.title')
				for b in a:
					tentran = b.get_text()
				anh = episode.select('td img')
				for im in anh:
					img = f'https:{im.get("src")}'
				x = episode.select('div a')
				for index, number in enumerate(x):
					item = Listitem()
					item.art['thumb'] = item.art['landscape'] = img
					item.art['fanart'] = 'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg'
					acex = number.get('href')
					item.label = f'Link {index+1}-{z} {tentran}'
					linkplay = ace(acex, item.label)
					item.path = linkplay
					item.set_callback(item.path)
					yield item
		else:
			yield quangcao()
	else:
		yield quangcao()