from codequick import Route, Listitem, run
from resources.lib.kedon import getlink, stream, referer, playsocolive
from datetime import datetime
import re, json
@Route.register
def index_socolive(plugin, **kwargs):
	now = datetime.now()
	timestamp = datetime.timestamp(now)
	url = 'https://json.cvndnss.com/all_live_rooms.json?v=%s' % timestamp
	resp = getlink(url, url, 10*60)
	nd = re.search(r'(\{.*\})', resp.text, re.DOTALL).group()
	m = json.loads(nd)
	for k in m['data']['hot']:
		item = Listitem()
		blv = k['anchor']['nickName']
		ten = k['title']
		tt = k['notice']
		item.label = '%s - %s' % (blv, ten)
		roomplay = k['roomNum']
		anh = k['cover']
		item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = anh
		item.info['plot'] = tt
		item.set_callback(playsocolive, roomplay, timestamp, item.label)
		yield item