from __future__ import unicode_literals
from codequick import Route, Listitem, run
from resources.lib.mkd.onyoutube.video import youtube_kenh
kenhytsp = {
'VFF': 'https://www.youtube.com/channel/UCndcERoL9eG-XNljgUk1Gag',
'VPF': 'https://www.youtube.com/user/Vpfmedia',
'FPT bóng đá': 'https://www.youtube.com/c/FPTFoxy',
'Next Sports': 'https://www.youtube.com/user/todaytvchannel',
'K+ Sports': 'https://www.youtube.com/channel/UC9xeuekJd88ku9LDcmGdUOA',
'On Sports': 'https://www.youtube.com/channel/UCIWo7q6irZUBaoPOrlf5IVw',
'On Sports Plus': 'https://www.youtube.com/channel/UCOEucCL9r4YfNZ9Es6G-g9Q',
'FPT bóng đá Việt': 'https://www.youtube.com/c/FPTB%C3%B3ng%C4%90%C3%A1Vi%E1%BB%87t',
'Quán thể thao': 'https://www.youtube.com/channel/UCEwAazC_ewgN5PPnR9vxFKA',
'Việt Nam Sport': 'https://www.youtube.com/channel/UC4FXEYiVVUdibNnqAnzdscw',
'BLV Quang Huy': 'https://www.youtube.com/c/blvquanghuy',
'BLV Anh Quân': 'https://www.youtube.com/channel/UCQqSJr6WYH0Bq7mrlFhzWDw',
'BLV Tạ Biên Cương': 'https://www.youtube.com/channel/UCbPF5L84DIv7zGg9mCqfGtw',
'Tuyền văn hoá': 'https://www.youtube.com/channel/UCCgCw-IJYpse4qnOCvvcitA',
'Cảm bóng đá': 'https://www.youtube.com/channel/UCtowbSVJlDLjgs-5qsznSTA',
'Nhà báo Minh Hải': 'https://www.youtube.com/user/donkeynhim',
'Anh Quân tin mới': 'https://www.youtube.com/user/viendongquan',
'Anh Quân bóng đá Việt': 'https://www.youtube.com/channel/UCCBwmJaVIB220c5sWdE28XQ'
}

@Route.register
def index_tinthethao(plugin, content_type='segment'):
	for tenlist, urllist in list(kenhytsp.items()):
		item = Listitem()
		item.label = tenlist
		item.art['thumb'] = 'https://thethao360.tv/wp-content/uploads/2020/12/logo-3.png'
		item.art['fanart'] = 'https://thethao360.tv/wp-content/uploads/2020/12/logo-3.png'
		item.set_callback(youtube_kenh, url=urllist)
		yield item