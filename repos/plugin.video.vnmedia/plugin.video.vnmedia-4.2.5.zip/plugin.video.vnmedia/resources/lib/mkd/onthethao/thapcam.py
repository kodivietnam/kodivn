from codequick import Route, Listitem, Resolver
from resources.lib.kedon import getlink, getlinkvnm, quangcao, stream, referer
from datetime import datetime
from bs4 import BeautifulSoup
from concurrent.futures import ThreadPoolExecutor
from codequick.utils import color
from urllib.parse import urlparse
import re
def thapcamtv():
	url = 'https://thapcam.tv'
	r = getlinkvnm(url, 'https://www.google.com.vn/')
	if 'cl_item' in r.text:
		soup = BeautifulSoup(r.content, 'html.parser')
		veno_links = soup.select('a[target="_blank"]')
		for link in veno_links:
			if re.search('thapcam', link.get_text(), re.IGNORECASE):
				b = urlparse(link['href']).netloc
				bc = b if 'http' in b else f'https://{b}'
				return bc
	else:
		return url
def get_full_url(url):
	utc = thapcamtv()
	if url.startswith('/'):
		return f'{utc}{url}'
	else:
		return url
def resptc():
	utc = thapcamtv()
	resp90 = getlinkvnm(utc, utc)
	if resp90 is not None:
		ref = re.search(r'base_embed_url.*?("|\')([^"\s]+)("|\')', resp90.text)[2]
	else:
		ref = utc
	return ref
def get_list(idk):
	url = f'http://api.thapcam.xyz/api/match/{idk}/meta'
	resp = getlinkvnm(url, url)
	return resp
def xemlai(page):
	utc = thapcamtv()
	url = f'{utc}/xem-lai' if page==1 else f'{utc}/xem-lai/trang-{page}'
	resp = getlink(url, url, 1000)
	return resp
@Route.register
def index_thapcam(plugin):
	yield []
	try:
		utc = 'https://api.thapcam.xyz/api/match/featured/mt'
		resp = getlinkvnm(utc, utc)
		if (resp is not None):
			rd = resp.json()['data']
			for k in rd:
				item = Listitem()
				time = datetime.fromtimestamp(int(k['timestamp'])/1000).strftime('%H:%M %d/%m')
				tg = color(time, 'red') if 'live' in k['match_status'] else time
				tenm = color(k['name'], 'yellow') if k['commentators'] else k['name']
				tenv = f'{tg} {tenm}'
				item.label = tenv
				item.info['mediatype'] = 'tvshow'
				logotour = k['tournament']['logo']
				item.art['thumb'] = item.art['poster'] = logotour if logotour else 'https://mi3s.top/thumb/thethao/thapcamtv.png'
				item.set_callback(list_thapcam, k['id'], tenv)
				yield item
		else:
			yield quangcao()
	except:
		yield quangcao()
@Route.register
def list_thapcam(plugin, idk=None, title=None):
	yield []
	if any((idk is None,title is None)):
		pass
	else:
		try:
			with ThreadPoolExecutor(2) as ex:
				f1 = ex.submit(resptc)
				f2 = ex.submit(get_list, idk)
				ref = f1.result()
				resp = f2.result()
			if (resp is not None) and ('.m3u8' in resp.text or 'youtube.com' in resp.text):
				kq = resp.json()['data']
				kp = kq['play_urls']
				cm = kq['commentators']
				blv = ' - '.join((h['name'] for h in cm or []))
				for k in kp:
					item = Listitem()
					tenm = f'{k["name"]} - {title} ({blv})' if cm else f'{k["name"]} - {title}'
					item.label = tenm
					item.info['mediatype'] = 'episode'
					item.art['thumb'] = item.art['poster'] = 'https://mi3s.top/thumb/thethao/thapcamtv.png'
					linkplay = k['url']
					if 'youtube.com' in linkplay:
						idvd = re.search(r"\?v=([a-zA-Z0-9_-]+)", linkplay)[1]
						item.set_path(f'plugin://plugin.video.youtube/play/?video_id={idvd}')
					else:
						linktrandau = f'{stream(linkplay)}{referer(ref)}'
						item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), linktrandau, tenm, '')
					yield item
			else:
				yield quangcao()
		except:
			pass
@Route.register
def xemlai_tc(plugin, page=None):
	yield []
	if page is None:
		pass
	else:
		try:
			with ThreadPoolExecutor(2) as ex:
				f1 = ex.submit(resptc)
				f2 = ex.submit(xemlai, page)
				ref = f1.result()
				resp = f2.result()
			if (resp is not None) and ('news-title' in resp.text):
				soup = BeautifulSoup(resp.content, 'html.parser')
				s = soup.select('div.box-content div.news-big, div.box-content div.item.item-highlight')
				for k in s:
					item = Listitem()
					tenm = k.select_one('h4.news-title a').get_text(strip=True)
					item.label = tenm
					item.info['mediatype'] = 'episode'
					item.art['thumb'] = item.art['poster'] = k.select_one('a.news-thumb img')['data-src']
					item.set_callback(Resolver.ref('/resources/lib/kedon:list_re90'), get_full_url(k.select_one('h4.news-title a')['href']), ref, tenm)
					yield item
				if 'Trang tiếp' in resp.text:
					item2 = Listitem()
					item2.label = f'Trang {page + 1}'
					item2.info['mediatype'] = 'tvshow'
					item2.art['thumb'] = item2.art['poster'] = f'https://mi3s.top/thumb/next.png'
					item2.set_callback(xemlai_tc, page + 1)
					yield item2
			else:
				yield quangcao()
		except:
			yield quangcao()