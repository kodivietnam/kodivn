from codequick import Route, Listitem, Resolver
from resources.lib.kedon import getlinkvnm, quangcao
from bs4 import BeautifulSoup
from urlquick import get
import re
@Route.register
def index_amnhac(plugin):
	T = {'Bài hát': index_baihat,
	'Playlist': index_playlist,
	'Tuyển tập': index_tuyentap,
	'Video': index_video,
	'Bảng xếp hạng': index_bxhvn,
	'Chủ đề': index_chude,
	'TOP 100': index_top,
	'Nghe gì': nghegi}
	yield Listitem.youtube('PL4fGSI1pDJn5kI81J1fYWK5eZRl1zJ5kM',label="TOP 100 thế giới")
	for k in T:
		item = Listitem()
		item.label = k
		item.info['mediatype'] = 'tvshow'
		item.art['thumb'] = item.art['poster'] = 'https://mi3s.top/thumb/amnhac.png'
		item.set_callback(T[k])
		yield item
	yield videomusic()
@Route.register
def index_baihat(plugin):
	yield []
	try:
		ubaihat = 'http://nhaccuatui.com/bai-hat/bai-hat-moi.html'
		r = getlinkvnm(ubaihat, 'http://nhaccuatui.com/')
		if r is not None:
			soup = BeautifulSoup(r.content, 'html.parser')
			soups = soup.select('div.box_cata_control ul li a')
			ls = ((l.text, l['href']) for l in soups if 'href' in l.attrs)
			i = Listitem()
			i.label = 'Mới nhất'
			i.info['mediatype'] = 'tvshow'
			i.art['thumb'] = i.art['poster'] = 'https://mi3s.top/thumb/amnhac.png'
			i.set_callback(listbai_nct, ubaihat)
			yield i
			for k in ls:
				item = Listitem()
				item.label = k[0]
				item.info['mediatype'] = 'tvshow'
				item.art['thumb'] = item.art['poster'] = 'https://mi3s.top/thumb/amnhac.png'
				item.set_callback(listbai_nct, k[1])
				yield item
		else:
			yield quangcao()
	except:
		yield quangcao()
@Route.register
def nghegi(plugin):
	yield []
	try:
		headers={'x-nct-token': 'eyJhbGciOiJIUzI1NiJ9.eyJsb2dpbk1ldGhvZCI6IjUiLCJleHAiOjE2ODMyMDYyNzEsImV4cGlyZWREYXRlIjoiMCIsIm5iZiI6MTY4MDYxNDI3MSwiZGV2aWNlaW5mbyI6IntcIkRldmljZUlEXCI6XCIzQjBGNDUyNUJDOEQ0NUI0QUQxNjZDNzdBMDQ1NjlFNlwiLFwiT3NOYW1lXCI6XCJBTkRST0lEXCIsXCJPc1ZlcnNpb25cIjpcIjIyXCIsXCJBcHBOYW1lXCI6XCJOQ1RNb2JpbGVcIixcIkFwcFZlcnNpb25cIjpcIjguMS4yXCIsXCJVc2VyTmFtZVwiOlwiXCIsXCJQcm92aWRlclwiOlwiTkNUQ29ycFwiLFwiRGV2aWNlTmFtZVwiOlwiQVNVU19aMDFRRFwiLFwiUXVhbGl0eVBsYXlcIjpcIlwiLFwiUXVhbGl0eURvd25sb2FkXCI6XCJcIixcIlF1YWxpdHlDbG91ZFwiOlwiXCIsXCJOZXR3b3JrXCI6XCJXSUZJXCIsXCJRdWFsaXR5TVZQbGF5XCI6XCJcIixcIlF1YWxpdHlNVkRvd25sb2FkXCI6XCJcIixcIkFkSURcIjpcIlwiLFwiRGV2aWNlVHlwZVwiOlwiU01BUlRfUEhPTkVcIixcImlzVk5cIjp0cnVlfSIsImlhdCI6MTY4MDYxNDI3MSwiZGV2aWNlSWQiOiIzQjBGNDUyNUJDOEQ0NUI0QUQxNjZDNzdBMDQ1NjlFNiJ9.4GAMSL6i72oG52XlpLo0VckBEe37bKjqR5jIuSqSqoo',
		'user-agent':'okhttp/4.10.0-RC1',
		'x-nct-deviceid': '3B0F4525BC8D45B4AD166C77A04569E6',
		'x-nct-version':'8.1.2',
		'x-nct-language':'vi',
		'x-nct-uuid':'a48d89a4d33e9a3c',
		'x-nct-checksum':'ab6eb574836879df6bcb204ea3e3e655121521cfbf21a8959edbd9136d13bd30',
		'x-nct-userid':'33007211',
		'x-nct-os':'android',
		'accept-encoding':'gzip'}
		r = get('https://graph.nhaccuatui.com/api/v1/song/feed', timeout=15,headers=headers)
		if r is not None:
			rl = r.json()['data']['list']
			for k in rl:
				item = Listitem()
				item.label = k['name']
				item.info['mediatype'] = 'episode'
				item.art['thumb'] = item.art['poster'] = k['image']
				item.set_path(k['streamURL'][-1]['stream'])
				yield item
		else:
			yield quangcao()
	except:
		yield quangcao()
@Route.register
def index_playlist(plugin):
	yield []
	try:
		uplaylist = 'http://nhaccuatui.com/playlist/playlist-moi.html'
		r = getlinkvnm(uplaylist, 'http://nhaccuatui.com/')
		if r is not None:
			i = Listitem()
			i.label = 'Mới nhất'
			i.info['mediatype'] = 'tvshow'
			i.art['thumb'] = i.art['poster'] = 'https://mi3s.top/thumb/amnhac.png'
			i.set_callback(albumplaylist_nct, uplaylist)
			yield i
			soup = BeautifulSoup(r.content, 'html.parser')
			soups = soup.select('div.box_cata_control ul li a')
			sl = ((l.text, l['href']) for l in soups if 'href' in l.attrs)
			for k in sl:
				item = Listitem()
				item.label = k[0]
				item.info['mediatype'] = 'tvshow'
				item.art['thumb'] = item.art['poster'] = 'https://mi3s.top/thumb/amnhac.png'
				item.set_callback(albumplaylist_nct, k[1])
				yield item
		else:
			yield quangcao()
	except:
		yield quangcao()
@Route.register
def index_tuyentap(plugin):
	yield []
	try:
		utuyentap = 'http://nhaccuatui.com/playlist/tags'
		r = getlinkvnm(utuyentap, 'http://nhaccuatui.com/')
		if r is not None:
			i = Listitem()
			i.label = 'Mới nhất'
			i.info['mediatype'] = 'tvshow'
			i.art['thumb'] = i.art['poster'] = 'https://mi3s.top/thumb/amnhac.png'
			i.set_callback(tuyentapplaylist_nct, utuyentap)
			yield i
			soup = BeautifulSoup(r.content, 'html.parser')
			soups = soup.select('div.box_menu_tag')
			sl = ((k.h3.get_text(strip=True), l.get_text(strip=True),l['href']) for k in soups for l in k.select('a'))
			for k in sl:
				item = Listitem()
				item.label = f'{k[0]}: {k[1]}'
				item.info['mediatype'] = 'tvshow'
				item.art['thumb'] = item.art['poster'] = 'https://mi3s.top/thumb/amnhac.png'
				item.set_callback(tuyentapplaylist_nct, k[2])
				yield item
		else:
			yield quangcao()
	except:
		yield quangcao()
@Route.register
def index_video(plugin):
	yield []
	try:
		r = getlinkvnm('http://nhaccuatui.com/video.html', 'http://nhaccuatui.com/')
		if r is not None:
			soup = BeautifulSoup(r.content, 'html.parser')
			soups = soup.select('div.box_cata_control ul li a')
			sl = ((l.text, l['href']) for l in soups if 'href' in l.attrs)
			for k in sl:
				item = Listitem()
				item.label = k[0]
				item.info['mediatype'] = 'tvshow'
				item.art['thumb'] = item.art['poster'] = 'https://mi3s.top/thumb/amnhac.png'
				item.set_callback(videoplaylist_nct, k[1])
				yield item
		else:
			yield quangcao()
	except:
		yield quangcao()
@Route.register
def index_bxhvn(plugin):
	yield []
	try:
		r = getlinkvnm('http://nhaccuatui.com/bai-hat/top-20.nhac-viet.html', 'http://nhaccuatui.com/')
		if r is not None:
			soup = BeautifulSoup(r.content, 'html.parser')
			soups = soup.select('ul.search_control_select a')
			for k in soups:
				item = Listitem()
				item.label = k.get_text(strip=True)
				item.info['mediatype'] = 'tvshow'
				item.art['thumb'] = item.art['poster'] = 'https://mi3s.top/thumb/amnhac.png'
				item.set_callback(bxhplaylist_nct, k['href'])
				yield item
		else:
			yield quangcao()
	except:
		yield quangcao()
@Route.register
def index_chude(plugin):
	yield []
	try:
		r = getlinkvnm('http://nhaccuatui.com/chu-de.html', 'http://nhaccuatui.com/')
		if r is not None:
			soup = BeautifulSoup(r.content, 'html.parser')
			soups = soup.select('div.fram_select a.name_song')
			for k in soups:
				item = Listitem()
				item.info['mediatype'] = 'tvshow'
				item.label = k.get_text(strip=True)
				item.art['thumb'] = item.art['poster'] = 'https://mi3s.top/thumb/1792312.jpg'
				item.set_callback(playlist_nct, k['href'])
				yield item
		else:
			yield quangcao()
	except:
		yield quangcao()
@Route.register
def index_top(plugin):
	yield []
	M = {'Việt Nam': 'http://nhaccuatui.com/top100/top-100-nhac-tre.m3liaiy6vVsF.html',
	'Âu Mỹ': 'http://nhaccuatui.com/top100/top-100-pop.zE23R7bc8e9X.html',
	'Châu Á': 'http://nhaccuatui.com/top100/top-100-nhac-han.iciV0mD8L9Ed.html',
	'Không lời': 'http://nhaccuatui.com/top100/top-100-khong-loi.kr9KYNtkzmnA.html'}
	for k in M:
		item = Listitem()
		item.label = k
		item.info['mediatype'] = 'tvshow'
		item.art['thumb'] = item.art['poster'] = 'https://mi3s.top/thumb/amnhac.png'
		item.set_callback(index_top100, M[k])
		yield item
@Route.register
def index_top100(plugin, url=None):
	yield []
	if url is None:
		pass
	else:
		try:
			r = getlinkvnm(url,url)
			if r is not None:
				soup = BeautifulSoup(r.content, 'html.parser')
				soups = soup.select('ul.detail_menu_browsing_dashboard a')
				for k in soups:
					item = Listitem()
					item.label = k.get_text(strip=True)
					item.info['mediatype'] = 'tvshow'
					item.art['thumb'] = item.art['poster'] = 'https://mi3s.top/thumb/amnhac.png'
					item.set_callback(playlist_nct, k['href'])
					yield item
			else:
				yield quangcao()
		except:
			yield quangcao()
@Route.register
def playlist_nct(plugin, url=None):
	yield []
	if url is None:
		pass
	else:
		try:
			if idk:= re.search(r"(?<=\.)([\w-]+)(?=\.\w+$)", url):
				headers={'x-nct-token': 'eyJhbGciOiJIUzI1NiJ9.eyJsb2dpbk1ldGhvZCI6IjUiLCJleHAiOjE2ODMyMDYyNzEsImV4cGlyZWREYXRlIjoiMCIsIm5iZiI6MTY4MDYxNDI3MSwiZGV2aWNlaW5mbyI6IntcIkRldmljZUlEXCI6XCIzQjBGNDUyNUJDOEQ0NUI0QUQxNjZDNzdBMDQ1NjlFNlwiLFwiT3NOYW1lXCI6XCJBTkRST0lEXCIsXCJPc1ZlcnNpb25cIjpcIjIyXCIsXCJBcHBOYW1lXCI6XCJOQ1RNb2JpbGVcIixcIkFwcFZlcnNpb25cIjpcIjguMS4yXCIsXCJVc2VyTmFtZVwiOlwiXCIsXCJQcm92aWRlclwiOlwiTkNUQ29ycFwiLFwiRGV2aWNlTmFtZVwiOlwiQVNVU19aMDFRRFwiLFwiUXVhbGl0eVBsYXlcIjpcIlwiLFwiUXVhbGl0eURvd25sb2FkXCI6XCJcIixcIlF1YWxpdHlDbG91ZFwiOlwiXCIsXCJOZXR3b3JrXCI6XCJXSUZJXCIsXCJRdWFsaXR5TVZQbGF5XCI6XCJcIixcIlF1YWxpdHlNVkRvd25sb2FkXCI6XCJcIixcIkFkSURcIjpcIlwiLFwiRGV2aWNlVHlwZVwiOlwiU01BUlRfUEhPTkVcIixcImlzVk5cIjp0cnVlfSIsImlhdCI6MTY4MDYxNDI3MSwiZGV2aWNlSWQiOiIzQjBGNDUyNUJDOEQ0NUI0QUQxNjZDNzdBMDQ1NjlFNiJ9.4GAMSL6i72oG52XlpLo0VckBEe37bKjqR5jIuSqSqoo',
				'user-agent':'okhttp/4.10.0-RC1',
				'x-nct-deviceid': '3B0F4525BC8D45B4AD166C77A04569E6',
				'x-nct-version':'8.1.2',
				'x-nct-language':'vi',
				'x-nct-uuid':'a48d89a4d33e9a3c',
				'x-nct-checksum':'ab6eb574836879df6bcb204ea3e3e655121521cfbf21a8959edbd9136d13bd30',
				'x-nct-userid':'33007211',
				'x-nct-os':'android',
				'accept-encoding':'gzip'}
				r = get(f'https://graph.nhaccuatui.com/api/v1/playlist/detail/{idk[1]}', headers=headers,timeout=15)
				rl = r.json()['data']['listSong']
				for k in rl:
					item = Listitem()
					item.label = k['name']
					item.info['mediatype'] = 'episode'
					item.art['thumb'] = item.art['poster'] = k['image']
					item.set_path(k['streamURL'][-1]['stream'])
					yield item
			else:
				yield quangcao()
		except:
			yield quangcao()
@Route.register
def albumplaylist_nct(plugin, url=None):
	yield []
	if url is None:
		pass
	else:
		try:
			r = getlinkvnm(url,url)
			if r is not None:
				soup = BeautifulSoup(r.content, 'html.parser')
				if g:=soup.select('div.fram_select ul li'):
					for k in g:
						item = Listitem()
						a = k.select_one('div.info_album a')
						item.label = a.get_text(strip=True)
						item.info['mediatype'] = 'tvshow'
						item.art['thumb'] = item.art['poster'] = k.img['data-src']
						item.set_callback(playlist_nct, a['href'])
						yield item
					if page:=soup.select('div.box_pageview'):
						for k in page:
							i = Listitem()
							a = k.select_one('a[rel="next"]')
							i.label = f'Trang {a.get_text(strip=True)}'
							i.info['mediatype'] = 'tvshow'
							i.art['thumb'] = i.art['poster'] = 'https://mi3s.top/thumb/next.png'
							i.set_callback(albumplaylist_nct, a['href'])
							yield i
				else:
					yield quangcao()
			else:
				yield quangcao()
		except:
			yield quangcao()
@Route.register
def tuyentapplaylist_nct(plugin, url=None):
	yield []
	if url is None:
		pass
	else:
		try:
			r = getlinkvnm(url,url)
			if r is not None:
				soup = BeautifulSoup(r.content, 'html.parser')
				if g:=soup.select('div.list_album.tag ul li'):
					for k in g:
						item = Listitem()
						a = k.select_one('div.info_album a')
						item.label = a.get_text(strip=True)
						item.info['mediatype'] = 'tvshow'
						item.art['thumb'] = item.art['poster'] = k.img['data-src']
						item.set_callback(playlist_nct, a['href'])
						yield item
					if page:=soup.select('div.box_pageview'):
						for k in page:
							i = Listitem()
							a = k.select_one('a[rel="next"]')
							i.label = f'Trang {a.get_text(strip=True)}'
							i.info['mediatype'] = 'tvshow'
							i.art['thumb'] = i.art['poster'] = 'https://mi3s.top/thumb/next.png'
							i.set_callback(tuyentapplaylist_nct, a['href'])
							yield i
				else:
					yield quangcao()
			else:
				yield quangcao()
		except:
			yield quangcao()
@Route.register
def videoplaylist_nct(plugin, url=None):
	yield []
	if url is None:
		pass
	else:
		try:
			r = getlinkvnm(url,url)
			if r is not None:
				soup = BeautifulSoup(r.content, 'html.parser')
				if g:= soup.select('div.list_video ul li'):
					for k in g:
						a = k.select_one('a.name_song')
						item = Listitem()
						tenm = a.get_text(strip=True)
						item.label = tenm
						item.info['mediatype'] = 'episode'
						item.art['thumb'] = item.art['poster'] = k.img['data-src']
						item.set_callback(Resolver.ref('/resources/lib/kedon:playvdnct'), a['href'], tenm)
						yield item
					if page:=soup.select('div.box_pageview'):
						for k in page:
							i = Listitem()
							a = k.select_one('a[rel="next"]')
							i.label = f'Trang {a.get_text(strip=True)}'
							i.info['mediatype'] = 'tvshow'
							i.art['thumb'] = i.art['poster'] = 'https://mi3s.top/thumb/next.png'
							i.set_callback(videoplaylist_nct, a['href'])
							yield i
				else:
					yield quangcao()
			else:
				yield quangcao()
		except:
			yield quangcao()
@Route.register
def bxhplaylist_nct(plugin, url=None):
	yield []
	if url is None:
		pass
	else:
		try:
			if idk:= re.search(r"(?<=\.)([\w-]+)(?=\.\w+$)", url):
				headers={'x-nct-token': 'eyJhbGciOiJIUzI1NiJ9.eyJsb2dpbk1ldGhvZCI6IjUiLCJleHAiOjE2ODMyMDYyNzEsImV4cGlyZWREYXRlIjoiMCIsIm5iZiI6MTY4MDYxNDI3MSwiZGV2aWNlaW5mbyI6IntcIkRldmljZUlEXCI6XCIzQjBGNDUyNUJDOEQ0NUI0QUQxNjZDNzdBMDQ1NjlFNlwiLFwiT3NOYW1lXCI6XCJBTkRST0lEXCIsXCJPc1ZlcnNpb25cIjpcIjIyXCIsXCJBcHBOYW1lXCI6XCJOQ1RNb2JpbGVcIixcIkFwcFZlcnNpb25cIjpcIjguMS4yXCIsXCJVc2VyTmFtZVwiOlwiXCIsXCJQcm92aWRlclwiOlwiTkNUQ29ycFwiLFwiRGV2aWNlTmFtZVwiOlwiQVNVU19aMDFRRFwiLFwiUXVhbGl0eVBsYXlcIjpcIlwiLFwiUXVhbGl0eURvd25sb2FkXCI6XCJcIixcIlF1YWxpdHlDbG91ZFwiOlwiXCIsXCJOZXR3b3JrXCI6XCJXSUZJXCIsXCJRdWFsaXR5TVZQbGF5XCI6XCJcIixcIlF1YWxpdHlNVkRvd25sb2FkXCI6XCJcIixcIkFkSURcIjpcIlwiLFwiRGV2aWNlVHlwZVwiOlwiU01BUlRfUEhPTkVcIixcImlzVk5cIjp0cnVlfSIsImlhdCI6MTY4MDYxNDI3MSwiZGV2aWNlSWQiOiIzQjBGNDUyNUJDOEQ0NUI0QUQxNjZDNzdBMDQ1NjlFNiJ9.4GAMSL6i72oG52XlpLo0VckBEe37bKjqR5jIuSqSqoo',
				'user-agent':'okhttp/4.10.0-RC1',
				'x-nct-deviceid': '3B0F4525BC8D45B4AD166C77A04569E6',
				'x-nct-version':'8.1.2',
				'x-nct-language':'vi',
				'x-nct-uuid':'a48d89a4d33e9a3c',
				'x-nct-checksum':'ab6eb574836879df6bcb204ea3e3e655121521cfbf21a8959edbd9136d13bd30',
				'x-nct-userid':'33007211',
				'x-nct-os':'android',
				'accept-encoding':'gzip'}
				r = get(f'https://graph.nhaccuatui.com/api/v1/playlist/charts/{idk[1]}', headers=headers,timeout=15)
				ri = r.json()['data']['items']
				for k in ri:
					item = Listitem()
					item.label = k['name']
					item.info['mediatype'] = 'episode'
					item.art['thumb'] = item.art['poster'] = k['image']
					item.set_callback(Resolver.ref('/resources/lib/kedon:playnct'), k['linkShare'], k['name'])
					yield item
			else:
				yield quangcao()
		except:
			yield quangcao()
@Route.register
def listbai_nct(plugin, url=None):
	yield []
	if url is None:
		pass
	else:
		try:
			r = getlinkvnm(url,url)
			if r is not None:
				soup = BeautifulSoup(r.content, 'html.parser')
				if g:=soup.select('div.info_song a.avatar_song'):
					for k in g:
						item = Listitem()
						item.label = k['title']
						item.info['mediatype'] = 'episode'
						item.art['thumb'] = item.art['poster'] = k.img['src']
						item.set_callback(Resolver.ref('/resources/lib/kedon:playnct'), k['href'], k['title'])
						yield item
					if page:=soup.select('div.box_pageview'):
						for k in page:
							i = Listitem()
							a = k.select_one('a[rel="next"]')
							i.label = f'Trang {a.get_text(strip=True)}'
							i.info['mediatype'] = 'tvshow'
							i.art['thumb'] = i.art['poster'] = 'https://mi3s.top/thumb/next.png'
							i.set_callback(listbai_nct, a['href'])
							yield i
				else:
					yield quangcao()
			else:
				yield quangcao()
		except:
			yield quangcao()
def videomusic():
	item = Listitem()
	item.label = 'Video nhạc tổng hợp'
	item.info['mediatype'] = 'tvshow'
	item.art['thumb'] = item.art['poster'] = 'https://mi3s.top/thumb/amnhac.png'
	item.set_callback(Route.ref('/resources/lib/mkd/ontintuc/mocha:index_mocha'), 4, 0)
	return item