from codequick import Resolver, Route, Listitem, Script
from resources.lib.kedon import userpassfs, tb, yttk, get_last_watch_movie, clear_last_watch_movie, getlink, quangcao, ggdich, getlinkvnm, get_last_modified_time_file, has_file_path, remove_file, read_file, write_file, useragentdf, __addonnoti__
from requests import Session
from bs4 import BeautifulSoup
from xbmcaddon import Addon
from xbmc import executebuiltin
from pickle import loads, dumps
from time import time
import re
hdvn = 'https://www.hdvietnam.xyz'
@Route.register
def index_fs(plugin, folderfs, next_page, **kwargs):
	token, session_id = userpassfs()[:2]
	payload = {'token': token, 'url': folderfs, 'dirOnly': 0, 'pageIndex': next_page, 'limit':100}
	headerfsvn = {'user-agent': 'VNMedia-6KTBKK', 'cookie' :  f'session_id={session_id}'}
	with Session() as s:
		kq = s.post('https://api.fshare.vn/api/fileops/getFolderList', timeout=20, json=payload, headers=headerfsvn)
	if (kq is not None) and ('furl' in kq.text):
		for k in kq.json():
			item = Listitem()
			item.label = k['name']
			linkfs = k['furl']
			item.info['plot'] = tb
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = yttk(item.label)
			item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkfs}&qzone=1&margin=1&size=400x400&ecc=L'
			item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
			item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkfs)
			if 'file' in k['furl']:
				item.info['size'] = k['size']
				if Addon().getSetting('taifshare') == 'true':
					item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', linkfs)
				item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), linkfs, item.label)
			else:
				item.set_callback(index_fs, linkfs, 0)
			yield item
		if len(kq.json())==100:
			item1 = Listitem()
			item1.label = f'Trang {next_page + 2}'
			item1.art['thumb'] = item1.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
			item1.set_callback(index_fs, folderfs, next_page + 1)
			yield item1
	else:
		yield quangcao()
@Route.register
def index_daxem(plugin, **kwargs):
	if b:= get_last_watch_movie():
		for m in b:
			item = Listitem()
			item.label = m
			item.info['plot'] = tb
			item.info['mediatype'] = 'movie'
			item.info['rating'] = 10.0
			item.info['trailer'] = yttk(item.label)
			item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={b[m]}&qzone=1&margin=1&size=400x400&ecc=L'
			item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
			if Addon().getSetting('taifshare') == 'true':
				item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', b[m])
			item.context.script(Script.ref('/resources/lib/kedon:remove_search_watch_movie'), 'Xoá khỏi lịch sử xem', m)
			item.context.script(Resolver.ref('/resources/lib/kedon:play_fs'), 'Thêm vào Fshare Favorite', b[m])
			item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), b[m], item.label)
			yield item
		Fshareplaydel = {'label': 'Xoá lịch sử xem',
		'info': {'plot': 'Xoá lịch sử xem'},
		'art': {'thumb': 'https://apkmodo.net/wp-content/uploads/2022/01/WATCHED-APK.jpg',
		'fanart': 'https://apkmodo.net/wp-content/uploads/2022/01/WATCHED-APK.jpg'},
		'callback': clear_last_watch_movie}
		yield Listitem.from_dict(**Fshareplaydel)
	else:
		yield []
@Route.register
def top250(plugin, **kwargs):
	response = getlink('https://www.imdb.com/chart/top', 'https://www.imdb.com', 3600)
	if response is not None:
		soup = BeautifulSoup(response.text, 'html.parser')
		for movie in soup.select('tbody.lister-list tr'):
			item = Listitem()
			item.art['thumb'] = item.art['fanart'] = re.sub(r'_(.*?)\.', '', movie.select_one('td.posterColumn a img').get('src'))
			item.label = movie.select_one('td.titleColumn').get_text(strip=True)
			item.info['mediatype'] = 'movie'
			try:
				item.info['rating'] = movie.select_one('td.ratingColumn').get_text(strip=True)
				item.info['plot'] = f'Điểm IMDB: {item.info["rating"]}\n{tb}'
			except:
				item.info['plot'] = tb
			item.set_callback(detailidmb, movie.select_one('a').get('href').split('/')[2], item.art['thumb'])
			yield item
	else:
		yield quangcao()
@Route.register
def topaumy(plugin, **kwargs):
	response = getlink('https://imdb.com/chart/top-english-movies', 'http://imdb.com', 3600)
	if response is not None:
		soup = BeautifulSoup(response.text, 'html.parser')
		for movie in soup.select('tbody.lister-list tr'):
			item = Listitem()
			item.art['thumb'] = item.art['fanart'] = re.sub(r'_(.*?)\.', '', movie.select_one('td.posterColumn a img').get('src'))
			item.label = movie.select_one('td.titleColumn').get_text(strip=True)
			item.info['mediatype'] = 'movie'
			try:
				item.info['rating'] = movie.select_one('td.ratingColumn').get_text(strip=True)
				item.info['plot'] = f'Điểm IMDB: {item.info["rating"]}\n{tb}'
			except:
				item.info['plot'] = tb
			item.set_callback(detailidmb, movie.select_one('a').get('href').split('/')[2], item.art['thumb'])
			yield item
	else:
		yield quangcao()
@Route.register
def trendview(plugin, dang, next_page, **kwargs):
	response = getlinkvnm(f'http://mi3s.top/trendingmovie?{dang}={dang}&page={next_page}', 'http://mi3s.top')
	if response is not None:
		try:
			r = response.json()["results"]
			for k in r:
				item = Listitem()
				item.label = k['title']
				item.info['mediatype'] = 'movie'
				if k['overview']:
					item.info['plot'] = f"Điểm VNM: [COLOR yellow]{k['vote_average']}[/COLOR]\n{k['overview']}\n{tb}"
				else:
					item.info['plot'] = f"Điểm VNM: [COLOR yellow]{k['vote_average']}[/COLOR]\n{tb}"
				item.art['thumb'] = f"https://image.tmdb.org/t/p/w500{k['poster_path']}"
				item.art['fanart'] = f"https://image.tmdb.org/t/p/w1280{k['backdrop_path']}"
				item.set_callback(detailtrend, k['id'], item.art['thumb'], item.art['fanart'], item.label, item.info['plot'])
				yield item
			item1 = Listitem()
			item1.label = f'Trang {next_page + 1}'
			item1.art['thumb'] = item1.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
			item1.set_callback(trendview, dang, next_page + 1)
			yield item1
		except:
			yield quangcao()
	else:
		yield quangcao()
@Route.register
def detailidmb(plugin, idk, anh, **kwargs):
	url = f'http://mi3s.top/imdb?vnm={idk}'
	response = getlinkvnm(url, 'http://mi3s.top/')
	if response is not None:
		if 'Title' in response.text:
			ten = response.json()['Title']
			noidung = f'[COLOR red]VNM chấm: {response.json()["imdbRating"]}[/COLOR]\n{ggdich(response.json()["Plot"])}\n\nDiễn viên: {response.json()["Actors"]}\n{tb}'
		else:
			r1 = getlink(f'https://imdb.com/title/{idk}', 'https://imdb.com/', 1000)
			ten = re.search(r'name":"(.*?)"', r1.text)[1]
			noidung = tb
		item2 = Listitem()
		item2.label = f'TRAILER: [I]{ten}[/I]'
		item2.info['plot'] = noidung
		item2.info['mediatype'] = 'episode'
		item2.art['thumb'] = item2.art['fanart'] = anh
		item2.set_callback(Resolver.ref('/resources/lib/mkd/onyoutube/tim:trailer_youtube'), ten)
		yield item2
		item = Listitem()
		item.label = f'XEM PHIM: [I]{ten}[/I]'
		item.info['plot'] = noidung
		item.art['thumb'] = item.art['fanart'] = anh
		item.set_callback(Route.ref('/resources/lib/mkd/onfshare/timfshare:searchfs'), ten)
		yield item
	else:
		yield quangcao()
@Route.register
def detailtrend(plugin, idk, anh, nen, ten, mota, **kwargs):
	url = f'http://mi3s.top/trendingmovie?id={idk}'
	response = getlinkvnm(url, 'https://mi3s.top')
	if response is not None:
		try:
			title = response.json()["title"]
			item2 = Listitem()
			item2.label = f'TRAILER: [I]{ten}[/I]'
			item2.art['thumb'] = anh
			item2.art['fanart'] = nen
			item2.info['plot'] = mota
			item2.info['mediatype'] = 'episode'
			item2.set_callback(Resolver.ref('/resources/lib/mkd/onyoutube/tim:trailer_youtube'), title)
			yield item2
			item = Listitem()
			item.label = f'XEM PHIM: [I]{ten}[/I]'
			item.art['thumb'] = anh
			item.art['fanart'] = nen
			item.info['plot'] = mota
			item.set_callback(Route.ref('/resources/lib/mkd/onfshare/timfshare:searchfs'), title)
			yield item
		except:
			yield quangcao()
	else:
		yield quangcao()
@Route.register
def fs_favorite(plugin, **kwargs):
	headerfsvn = {'user-agent': 'VNMedia-6KTBKK', 'cookie' : f'session_id={userpassfs()[1]}'}
	with Session() as s:
		r = s.get('https://api.fshare.vn/api/fileops/listFavorite', timeout=20, headers=headerfsvn)
	if 'linkcode' in r.text:
		for k in r.json():
			if k['linkcode']:
				if k['type'] == '0':
					item = Listitem()
					item.label = k['name']
					item.info['plot'] = tb
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(item.label)
					item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=http://fshare.vn/folder/{k["linkcode"]}&qzone=1&margin=1&size=400x400&ecc=L'
					item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
					item.context.script(xfavo, 'Xoá khỏi Fshare Favorite', f"http://fshare.vn/folder/{k['linkcode']}")
					item.set_callback(index_fs, f'https://fshare.vn/folder/{k["linkcode"]}', 0)
					yield item
				else:
					item = Listitem()
					item.label = k['name']
					item.info['size'] = k['size']
					item.info['plot'] = tb
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(item.label)
					item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=http://fshare.vn/file/{k["linkcode"]}&qzone=1&margin=1&size=400x400&ecc=L'
					item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
					if Addon().getSetting('taifshare') == 'true':
						item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', f'https://fshare.vn/file/{k["linkcode"]}')
					item.context.script(xfavo, 'Xoá khỏi Fshare Favorite', f'https://fshare.vn/file/{k["linkcode"]}')
					item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), f'https://fshare.vn/file/{k["linkcode"]}', item.label)
					yield item
	else:
		yield []
@Route.register
def fs_topfollow(plugin, **kwargs):
	headerfsvn = {'user-agent': 'VNMedia-6KTBKK', 'cookie' : f'session_id={userpassfs()[1]}'}
	with Session() as s:
		r = s.get('https://api.fshare.vn/api/fileops/getTopFollowMovie', timeout=20, headers=headerfsvn)
	for k in r.json():
		item = Listitem()
		item.label = k['name']
		linkfs = f'https://fshare.vn/folder/{k["linkcode"]}'
		item.info['plot'] = tb
		item.info['mediatype'] = 'episode'
		item.info['rating'] = 10.0
		item.info['trailer'] = yttk(item.label)
		item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=http://fshare.vn/folder/{k["linkcode"]}&qzone=1&margin=1&size=400x400&ecc=L'
		item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
		item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkfs)
		item.set_callback(index_fs, linkfs, 0)
		yield item
@Script.register
def tfavo(plugin, x, **kwargs):
	idfd = re.search(r'(file|folder)/([A-Z0-9]+)', x)[2]
	token, session_id = userpassfs()[:2]
	headerfsvn = {'user-agent':'VNMedia-6KTBKK', 'cookie' : f'session_id={session_id}'}
	payload = f'{{"token": "{token}", "items": ["{idfd}"], "status": 1}}'
	try:
		with Session() as s:
			r = s.post('https://api.fshare.vn/api/fileops/ChangeFavorite', timeout=20, data=payload, headers=headerfsvn)
		Script.notify(__addonnoti__, 'Đã thêm vào Fshare Favorite') if '200' in r.text else Script.notify(__addonnoti__, 'Không thêm được vào Fshare Favorite')
	except:
		Script.notify(__addonnoti__, 'Không thêm được vào Fshare Favorite')
@Script.register
def xfavo(plugin, x, **kwargs):
	idfd = re.search(r'(file|folder)/([A-Z0-9]+)', x)[2]
	token, session_id = userpassfs()[:2]
	headerfsvn = {'user-agent':'VNMedia-6KTBKK', 'cookie' : f'session_id={session_id}'}
	payload = f'{{"token": "{token}", "items": ["{idfd}"], "status": 0}}'
	with Session() as s:
		s.post('https://api.fshare.vn/api/fileops/ChangeFavorite', timeout=20, data=payload, headers=headerfsvn)
	Script.notify(__addonnoti__, 'Đã xoá khỏi Fshare Favorite')
	executebuiltin('Container.Refresh()')
def loginfhdvn():
	if has_file_path('hdvietnam.bin') and get_last_modified_time_file('hdvietnam.bin') + 3600 < int(time()):
		remove_file('hdvietnam.bin')
	if has_file_path('hdvietnam.bin'):
		return loads(read_file('hdvietnam.bin', True))
	else:
		with Session() as s:
			site = s.get(f'{hdvn}/forums/')
			headers = {'user-agent':useragentdf,'origin':hdvn,'referer':f'{hdvn}/'}
			login_data = {'login':'romvemot@gmail.com','register':0,'password':'bimozie','remember':1,'cookie_check':1,'_xfToken':'','redirect':'/forums/'}
			s.post(f'{hdvn}/login/login', data=login_data, headers=headers)
		write_file('hdvietnam.bin', dumps(s), True)
		return s
def likehdvn(url):
	s = loginfhdvn()
	soup = BeautifulSoup(s.get(f'{hdvn}/{url}').content, 'html.parser')
	token = soup.select_one('input[name="_xfToken"]').get('value')
	like = f'{hdvn}/{soup.select_one("div.publicControls a.LikeLink.item.control").get("href")}'
	if 'like' in like:
		data_like = {'_xfRequestUri':f'/{url}','_xfToken':token,'_xfNoRedirect':1,'_xfResponseType': 'json'}
		s.post(like, data=data_like)
		return
def logincsn():
	if has_file_path('csn.bin') and get_last_modified_time_file('csn.bin') + 3600 < int(time()):
		remove_file('csn.bin')
	if has_file_path('csn.bin'):
		return loads(read_file('csn.bin', True))
	else:
		with Session() as s:
			site = s.get('https://chiasenhac.vn').text
			headers = {'user-agent':useragentdf,'origin':'https://chiasenhac.vn','referer':'https://chiasenhac.vn/login'}
			token = re.search(r'csrfToken = "(.*)";', site)[1]
			login_data = {'_token':token,'register':0,'email':'vnmedia','password':'Lvwzg9ZNb@2PubD'}
			s.post('https://chiasenhac.vn/login', login_data)
		write_file('csn.bin', dumps(s), True)
		return s