root = 'root'
menu = {'vnmsport': {
        'route': '/resources/lib/mkd/onthethao/vnm:index_vnm',
        'label': 'SỰ KIỆN TRỰC TIẾP',
        'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/sukien.png',
        'enabled': True,
        'order': 1
        },
        'replaysport': {
        'route': '/resources/lib/mkd/onthethao/xemlaivk:index_xemlaivk',
        'label': 'XEM LẠI SỰ KIỆN',
        'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/xemlai.png',
        'enabled': True,
        'order': 2
        },
        'tinthethao': {
        'route': '/resources/lib/mkd/onthethao/tinthethao:index_tinthethao',
        'label': 'Tin thể thao',
        'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/tinthethao.png',
        'enabled': True,
        'order': 3
        },
        'acest': {
        'route': '/resources/lib/mkd/acest:index_acestream',
        'label': 'Nhóm ACESTREAM',
        'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/acestream.png',
        'enabled': True,
        'order': 4
        },
        'phut901': {
        'route': '/resources/lib/mkd/onthethao/phut90:index_90p',
        'label': '90PHUT - BONGCAM',
        'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/90p.png',
        'enabled': True,
        'order': 6
        },
        'thapcam': {
        'route': '/resources/lib/mkd/onthethao/thapcam:index_thapcam',
        'label': 'THAPCAM.NET',
        'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/thapcamtv.png',
        'enabled': True,
        'order': 7
        },
        'phut91': {
        'route': '/resources/lib/mkd/onthethao/phut91:index_91phut',
        'label': 'MITOM - XOILAC',
        'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/mitom.png',
        'enabled': True,
        'order': 11
        },
        'cakhia': {
        'route': '/resources/lib/mkd/onthethao/cakhia:index_cakhia',
        'label': 'CAKHIA - CAHEO',
        'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/cakhia.png',
        'enabled': True,
        'order': 13
        },
        'saoke': {
        'route': '/resources/lib/mkd/onthethao/saoke:index_saoke',
        'label': 'SAOKE - MANNHAN',
        'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/saoke.png',
        'enabled': True,
        'order': 16
        },
        'socolive': {
        'route': '/resources/lib/mkd/onthethao/socolive:index_socolive',
        'label': 'SOCOLIVE.ORG',
        'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/soco.png',
        'enabled': True,
        'order': 12
        },
        'gglive': {
        'route': '/resources/lib/mkd/onthethao/gglive:index_gglive',
        'label': 'GGLIVE.TV',
        'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/gglive.png',
        'enabled': True,
        'order': 13
        },
        'nba': {
        'route': '/resources/lib/mkd/onthethao/nba:index_nba',
        'label': 'TRUCTIEPNBA',
        'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/nba.png',
        'enabled': True,
        'order': 19
        }
            }