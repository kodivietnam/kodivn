from codequick import Route, Listitem, run
from resources.lib.kedon import tb
from resources.lib.mkd.ontintuc.mocha import index_mocha
from resources.lib.mkd.onyoutube.video import youtube_kenh
kenhyttt = {
'VTV24': 'https://www.youtube.com/c/vtv24',
'VTCnews': 'https://www.youtube.com/c/vtcnow',
'60 giây': 'https://www.youtube.com/channel/UCRjzfa1E0gA50lvDQipbDMg',
'Thời tiết-Môi trường': 'https://www.youtube.com/user/KenhTruyenHinhVTC14',
'Văn hoá-Du lịch': 'https://www.youtube.com/channel/UCZ7cd8K5jo7fHUksCgMfpeg',
'Kinh tế-Tài chính': 'https://www.youtube.com/user/FBNCVietnam',
'An ninh': 'https://www.youtube.com/c/KenhAnNinh',
'Thông tấn xã': 'https://www.youtube.com/c/VNEWSTRUY%E1%BB%80NH%C3%8CNHTH%C3%94NGT%E1%BA%A4N',
'Quốc hội': 'https://www.youtube.com/channel/UCTJ-FDgxR3NxurDQxNiWWVQ',
'Nhân dân': 'https://www.youtube.com/channel/UCPJfjHrW3-zIeSaZTgmckmg',
'Nông nghiệp-nông thôn': 'https://www.youtube.com/c/K%C3%8ANHVTC16',
'Thế giới đó đây': 'https://www.youtube.com/channel/UCHPzpxcYhxkb0fMJKeSe66g',
'VTC tin mới': 'https://www.youtube.com/user/vtctv',
'Hà Nội tin tức': 'https://www.youtube.com/channel/UC7_mgS3z22z0WhR7COJ8E2w',
'HTV tin tức': 'https://www.youtube.com/c/HTVTinT%E1%BB%A9c',
'THVL tổng hợp': 'https://www.youtube.com/c/THVLTongHop',
'Luật giao thông': 'https://www.youtube.com/channel/UC0OX9WL_PxOlX0HQbu45JfA'
}

@Route.register
def index_tintuc(plugin,content_type='segment'):
	item1 = Listitem()
	page = 0
	item1.label = 'Tin mới'
	item1.info['plot'] = tb
	item1.art['thumb'] =  'https://cdn.baogiaothong.vn/upload/images/2019-4/profile_avatar_img/2019-11-18/tin-tuc-trong-ngay-hom-nay-1574061980-width1004height565.png'
	item1.art['fanart'] = 'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item1.set_callback(index_mocha, page)
	yield item1
	for tenlist, urllist in list(kenhyttt.items()):
		item = Listitem()
		item.label = tenlist
		item.art['thumb'] = 'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
		item.art['fanart'] = 'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
		item.set_callback(youtube_kenh, url=urllist)
		yield item