root = 'root'
menu = {'vnmsport': {
        'route': '/resources/lib/mkd/onthethao/vnm:index_vnm',
        'label': 'SỰ KIỆN TRỰC TIẾP',
        'thumb': 'https://png.pngtree.com/png-clipart/20210710/ourlarge/pngtree-d-logo-live-broadcast-bold-style-with-play-button-isolated-on-png-image_3582566.jpg',
        'enabled': True,
        'order': 1
        },
        'replaysport': {
        'route': '/resources/lib/mkd/onthethao/xemlaivk:index_xemlaivk',
        'label': 'XEM LẠI SỰ KIỆN',
        'thumb': 'https://upload.wikimedia.org/wikipedia/commons/e/e1/Replay-Logo-HD.png',
        'enabled': True,
        'order': 2
        },
        'tinthethao': {
        'route': '/resources/lib/mkd/onthethao/tinthethao:index_tinthethao',
        'label': 'Tin thể thao',
        'thumb': 'https://thethao360.tv/wp-content/uploads/2020/12/logo-3.png',
        'enabled': True,
        'order': 3
        },
        'acest': {
        'route': '/resources/lib/mkd/acest:index_acestream',
        'label': 'Nhóm ACESTREAM',
        'thumb': 'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg',
        'enabled': True,
        'order': 4
        },
        'phut901': {
        'route': '/resources/lib/mkd/onthethao/phut90:index_90p',
        'label': '90PHUT.TV',
        'thumb': 'https://90m.link/images/logo-90.png',
        'enabled': True,
        'order': 6
        },
        'vebo': {
        'route': '/resources/lib/mkd/onthethao/vebo:index_vebo',
        'label': 'VEBO.TOP',
        'thumb': 'https://90m.link/images/logo-01.png',
        'enabled': True,
        'order': 8
        },
        'xoilacxyz': {
        'route': '/resources/lib/mkd/onthethao/xoilacxyz:index_xoilacxyz',
        'label': 'XOILAC.XYZ',
        'thumb': 'https://90m.link/images/logo-xoilac.png',
        'enabled': True,
        'order': 9
        },
        'phut91': {
        'route': '/resources/lib/mkd/onthethao/phut91:index_91phut',
        'label': 'MITOMTV',
        'thumb': 'https://i.pinimg.com/236x/9f/65/4f/9f654f4c01912939a724a53cb745df20.jpg',
        'enabled': True,
        'order': 11
        },
        'socolive': {
        'route': '/resources/lib/mkd/onthethao/socolive:index_socolive',
        'label': 'SOCOLIVE.ORG',
        'thumb': 'https://sta.cvndnss.com/web/assets/soco/img/logo2.png',
        'enabled': True,
        'order': 12
        },
        'cakhia': {
        'route': '/resources/lib/mkd/onthethao/cakhia:index_cakhia',
        'label': 'CAKHIA TV',
        'thumb': 'https://i.imgur.com/TTprlUP.png',
        'enabled': True,
        'order': 13
        },
        'rakhoi': {
        'route': '/resources/lib/mkd/onthethao/rakhoi:index_rakhoi',
        'label': 'RA KHOI TV',
        'thumb': 'https://i.imgur.com/8tEAlqc.png',
        'enabled': True,
        'order': 14
        },
        'caheo': {
        'route': '/resources/lib/mkd/onthethao/caheo:index_caheo',
        'label': 'CAHEO.TV',
        'thumb': 'https://i.imgur.com/KdSuVMn.png',
        'enabled': True,
        'order': 15
        },
        'saoke': {
        'route': '/resources/lib/mkd/onthethao/saoke:index_saoke',
        'label': 'SAOKE.LIVE',
        'thumb': 'https://9767a59e2b.vws.vegacdn.vn/template/seo/images/Logo_150-01.png',
        'enabled': True,
        'order': 16
        },
        'mannhan': {
        'route': '/resources/lib/mkd/onthethao/mannhan:index_mannhan',
        'label': 'MANNHAN.LIVE',
        'thumb': 'https://9767ebd63c.vws.vegacdn.vn/template/public/img/logo.png',
        'enabled': True,
        'order': 17
        },
        'khomuc': {
        'route': '/resources/lib/mkd/onthethao/khomuc:index_khomuc',
        'label': 'KHOMUC.TV',
        'thumb': 'https://khomuc1.com/assets//logo.png',
        'enabled': True,
        'order': 18
        },
        'gglive': {
        'route': '/resources/lib/mkd/onthethao/gglive:index_gglive',
        'label': 'GGLIVE.TV',
        'thumb': 'https://223092959.e.cdneverest.net/boxstudio/default/fb-thumb.jpg',
        'enabled': True,
        'order': 19
        },
        'cauthu': {
        'route': '/resources/lib/mkd/onthethao/cauthu:index_cauthu',
        'label': 'CAUTHU.TV',
        'thumb': 'https://cauthu.link/logo.png',
        'enabled': True,
        'order': 20
        },
        'cauthuonline': {
        'route': '/resources/lib/mkd/onthethao/cauthuonline:index_cauthuonline',
        'label': 'CAUTHUTV.ONLINE',
        'thumb': 'https://cauthutv.online/wp-content/uploads/2022/07/cauthu_tv_logo.png',
        'enabled': True,
        'order': 21
        }
            }