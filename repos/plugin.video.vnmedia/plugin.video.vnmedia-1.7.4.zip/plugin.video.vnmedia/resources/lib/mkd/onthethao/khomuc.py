from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from urllib.parse import urlparse
from resources.lib.kedon import getlink, ifr_khomuc, quangcao, khomuc, tb
import re
l = khomuc()[0]
m = urlparse(l)
url = f'{m.scheme}://{m.netloc}/'
@Route.register
def index_khomuc(plugin, **kwargs):
	resp = getlink(url, url, 400)
	if resp is not None:
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('section.home-live-now div.item-live-now-match a.d-flex.flex-column.text-black')
		if len(episodes) > 0:
			for episode in episodes:
				item = Listitem()
				linktrandau = episode.get('href')
				if episode.select('div.d-flex.align-items-center.bg-white.px-3.py-3 span.flex-1.ms-1.fw-bold'):
					timso = re.findall('-(\d+)',  linktrandau)
					time = f'{timso[3][0:2]}:{timso[3][2:4]}'
					ngay = f'{timso[0]}-{timso[1]}'
					tran = re.search(f'truc-tiep-(.*?)-{ngay}', linktrandau).group(1)
					tran = tran.replace('-', ' ').title().replace('Vs', 'vs')
					item.label = f'{time} {ngay}: {tran}'
					item.info['plot'] = tb
					item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = f'{url}wp-content/uploads/2021/11/cropped-logo-website-khomuc.jpg'
					item.set_callback(ifr_khomuc, linktrandau, item.label)
					yield item
		else:
			yield quangcao()
	else:
		yield quangcao()