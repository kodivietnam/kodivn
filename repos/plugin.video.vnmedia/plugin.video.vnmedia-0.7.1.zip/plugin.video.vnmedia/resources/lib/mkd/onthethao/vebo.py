from codequick import Route, Listitem, run
from resources.lib.kedon import quangcao, getlink, stream, referer, play_vnm
import datetime
today = datetime.date.today()

@Route.register
def index_vebo(plugin, content_type='segment'):
	url1 = 'https://api.vebo.dev/match/live-v2/live'
	resp1 = getlink(url1, url1, 15*60)
	for k in resp1.json()['data']['matches']:
		item = Listitem()
		linktran = k['_id']
		gio = k['show_time']
		ngay = k['show_date']
		doikhach = k['away']['name']
		doinha = k['home']['name']
		item.label = gio + ' ' + ngay + ': ' + doinha + ' - ' + doikhach
		item.art['thumb'] = 'https://vebotv.vip/static/img/logo.png'
		item.art['fanart'] = 'https://vebotv.vip/static/img/logo.png'
		item.set_callback(list_vebo, linktran, item.label)
		yield item
	tg = str(today).replace('-','')
	url2 = 'https://vebotv.vip/ajax/match/fixture/' + tg + '/1'
	resp2 = getlink(url2, url2, 15*60)
	for k in resp2.json()['data'][0]:
		for m in k['matches']:
			item2 = Listitem()
			linktran = m['_id']
			tentran = m['name']
			gio = m['show_time']
			ngay = m['show_date']
			item2.label = gio + ' ' + ngay + ': ' + tentran
			item2.art['thumb'] = 'https://vebotv.vip/static/img/logo.png'
			item2.art['fanart'] = 'https://vebotv.vip/static/img/logo.png'
			item2.set_callback(list_vebo, linktran, item2.label)
			yield item2


@Route.register
def list_vebo(plugin, idtran, title):
	url = 'https://vebotv.vip/ajax/match/detail/' + idtran + '/detail'
	resp = getlink(url, url, 0)
	if 'm3u8' in resp.text:
		for k in resp.json()['play_urls']:
			item = Listitem()
			linktran = stream(k['url'].replace('\t','')) + referer('https://vebotv.vip/')
			item.label = k['name'] + ' ' + title
			item.art['thumb'] = 'https://vebotv.vip/static/img/logo.png'
			item.art['fanart'] = 'https://vebotv.vip/static/img/logo.png'
			item.set_callback(play_vnm, linktran, item.label, '')
			yield item
	else:
		yield quangcao()