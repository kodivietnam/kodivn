from codequick import Route, Listitem, run
from resources.lib.kedon import tb, logotv
from resources.lib.mkd.thethao import index_thethao
from resources.lib.mkd.tintuc import index_tintuc
from resources.lib.mkd.truyenhinh import listiptv_root
from resources.lib.mkd.fshare import index_fshare
from resources.lib.mkd.ytube import index_youtube
@Route.register
def root(plugin, content_type='segment'):
	Truyenhinh = {'label': 'Truyền hình',
	'info':{'plot':tb},
	'art':{'thumb':logotv,
	'fanart':'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'},
	'callback':listiptv_root}
	Thethao = {'label': 'Thể thao',
	'info':{'plot':tb},
	'art':{'thumb':'https://i.imgur.com/x0V60BO.png',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_thethao}
	Tintuc = {'label': 'Tin tức',
	'info':{'plot':tb},
	'art':{'thumb':'https://i.imgur.com/IJJJb8W.png',
	'fanart':'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'},
	'callback':index_tintuc}
	Fshare = {'label': 'Fshare',
	'info':{'plot':tb},
	'art':{'thumb':'https://i.imgur.com/XB3HOOe.png',
	'fanart':'https://fsharetv.com/img/fsharetv.png'},
	'callback':index_fshare}
	Youtube = {'label': 'Youtube',
	'info':{'plot':tb},
	'art':{'thumb':'https://i.imgur.com/0oHqiU3.png',
	'fanart':'https://www.youtube.com/img/desktop/yt_1200.png'},
	'callback':index_youtube}
	yield Listitem.from_dict(**Fshare)
	yield Listitem.from_dict(**Youtube)
	yield Listitem.from_dict(**Truyenhinh)
	yield Listitem.from_dict(**Thethao)
	yield Listitem.from_dict(**Tintuc)