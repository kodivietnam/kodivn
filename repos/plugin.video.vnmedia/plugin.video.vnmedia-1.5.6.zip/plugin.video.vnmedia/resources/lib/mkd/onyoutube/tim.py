from codequick import Route, Listitem, run, Script, Resolver
from resources.lib.kedon import getlinkweb, get_kara_input, __addonnoti__, quangcao, replace_all
from resources.lib.mkd.onyoutube.video import youtube_tatcavideo, youtube_kenh
from xbmc import getInfoLabel
import re, xbmc, xbmcgui, urllib
thaythe = {'\\"':'','\\u0026':'&'}
@Route.register
def search_youtube(plugin,search_query, **kwargs):
	dp = xbmcgui.DialogProgress()
	dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
	search_query = urllib.parse.quote_plus(search_query)
	url = f'https://www.youtube.com/results?gl=VN&hl=vi&search_query={search_query.replace(" ","+")}'
	resp = getlinkweb(url, url, 24*60*60)
	if resp is not None:
		kq = replace_all(thaythe, resp.text)
		if 'videoRenderer' in kq:
			listplay = re.findall(r'videoRenderer(.*?)accessibility', kq)
			for k in listplay:
				item = Listitem()
				tenvd = re.search(r'text":"(.*?)"}', k).group(1)
				idvd = re.search(r'videoId":"(.*?)"', k).group(1)
				anhvd = f'https://i.ytimg.com/vi/{idvd}/sddefault.jpg'
				item.path = f'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid={idvd}'
				item.label = tenvd
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = anhvd
				item.set_callback(item.path)
				yield item
		elif 'playlistRenderer' in kq:
			listplay1 = re.findall(r'playlistRenderer(.*?)webPageType', kq)
			for k1 in listplay1:
				item1 = Listitem()
				tenvd1 = re.search(r'"simpleText":"(.*?)"}', k1).group(1)
				idvd1 = re.search(r'webCommandMetadata":{"url":"(.*?)"', k1).group(1)
				anhvd1 = f'https://i.ytimg.com/vi/{idvd1}/sddefault.jpg'
				item1.label = tenvd
				item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = anhvd1
				item1.set_callback(youtube_tatcavideo, f'{url}{idvd1}')
				yield item1
		elif 'channelRenderer' in kq:
			listplay2 = re.findall(r'channelRenderer(.*?)webPageType', kq)
			for k2 in listplay2:
				item2 = Listitem()
				tenvd2 = re.search(r'"simpleText":"(.*?)"}', k2).group(1)
				idvd2 = re.search(r'"url":"(.*?)"', k2).group(1)
				anhvd2 = f'https://i.ytimg.com/vi/{idvd2}/sddefault.jpg'
				item2.label = tenvd2
				item2.art['thumb'] = item2.art['landscape'] = item2.art['fanart'] = f'https:{anhvd2}'
				item2.set_callback(youtube_kenh, f'{url}{idvd2}')
				yield item2
		else:
			yield []
	else:
		yield quangcao()
@Route.register
def search_karaoke(plugin,search_query, **kwargs):
	search_query = get_kara_input()
	if not search_query:
		Script.notify(__addonnoti__, 'Bạn chưa nhập từ khoá tìm kiếm')
		yield quangcao()
	else:
		dp = xbmcgui.DialogProgress()
		dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
		search_query = urllib.parse.quote_plus(search_query)
		url = f'https://www.youtube.com/results?gl=VN&hl=vi&search_query=Karaoke+{search_query.replace(" ","+")}'
		resp = getlinkweb(url, url, 48*60*60)
		if resp is not None:
			kq = replace_all(thaythe, resp.text)
			listplay = re.findall(r'videoRenderer(.*?)accessibility', kq)
			for k in listplay:
				item = Listitem()
				tenvd = re.search(r'text":"(.*?)"}', k).group(1)
				idvd = re.search(r'videoId":"(.*?)"', k).group(1)
				anhvd = f'https://i.ytimg.com/vi/{idvd}/sddefault.jpg'
				item.path = f'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid={idvd}'
				item.label = tenvd
				item.art['thumb'] = item.art['landscape'] = item.art['fanart']= anhvd
				item.set_callback(item.path)
				yield item
		else:
			yield quangcao
@Resolver.register
def trailer_youtube(plugin, search_query, **kwargs):
	b = urllib.parse.quote_plus(search_query)
	url = f'https://www.youtube.com/results?gl=VN&hl=vi&search_query=Trailer+{b.replace(" ", "+")}'
	resp = getlinkweb(url, url, 24*60*60)
	if resp is not None:
		kq = replace_all(thaythe, resp.text)
		if 'videoRenderer' in kq:
			titles = []
			urls = []
			listplay = re.findall(r'videoRenderer(.*?)accessibility', kq)
			for k in listplay:
				tenvd = re.search(r'text":"(.*?)"}', k).group(1)
				idvd = re.search(r'videoId":"(.*?)"', k).group(1)
				linkplay = f'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid={idvd}'
				urls.append(linkplay)
				titles.append(tenvd)
			ret = xbmcgui.Dialog().select(f'GIỚI THIỆU: {search_query}', titles)
			if ret == -1:
				return False
			else:
				item = Listitem()
				item.path = urls[ret]
				item.label = getInfoLabel('ListItem.Label')
				return item
		else:
			return False