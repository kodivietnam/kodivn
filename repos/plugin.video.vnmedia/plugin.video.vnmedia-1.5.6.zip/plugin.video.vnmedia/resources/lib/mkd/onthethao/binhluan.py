from codequick import Route, Listitem, run
from resources.lib.kedon import quangcao, getlink, stream, referer, play_vnm, tb, tiengruoi
from urllib.parse import urlparse
a = urlparse(tiengruoi()[3])
binhluantv = f'{a.scheme}://{a.netloc}'
@Route.register
def index_binhluan(plugin, **kwargs):
	url = f'{binhluantv}/api/matches-in-home?id=0'
	resp = getlink(url, url, 15*60)
	kq = resp.json()
	for m in kq:
		for k in m['data']:
			item = Listitem()
			time = k['timeStartPlayMod']
			ngay = k['dayinweek']
			ten = k['title']
			giai = k['tournamentInfo']['name']
			linktran = f'{binhluantv}/api/match/{k["_id"]}'
			item.label = f'{time} {ngay}: {ten} ({giai})'
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = k['tournamentInfo']['imageHost']
			item.set_callback(list_binhluantv, linktran, item.label)
			yield item
@Route.register
def list_binhluantv(plugin, url, title, **kwargs):
	resp = getlink(url, url, 5*60)
	kq = resp.json()
	if '.m3u8' in resp.text:
		for k in kq['streamsLink']:
			item = Listitem()
			ten = f'{k["label"]} {title}'
			linkstream = k['link'].replace('\t','')
			linktran = f'{stream(linkstream)}{referer(url)}'
			item.info['plot'] = tb
			item.label = ten
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = f'{binhluantv}/imgs/logo.png'
			item.set_callback(play_vnm, linktran, item.label, '')
			yield item
	else:
		yield quangcao()