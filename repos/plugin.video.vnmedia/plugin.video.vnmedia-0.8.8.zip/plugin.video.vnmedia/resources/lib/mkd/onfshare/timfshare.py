from codequick import Route, Listitem, run
from resources.lib.kedon import tb, postlinktimfs, play_fs, __addonnoti__
from resources.lib.mkd.onfshare.ifshare import index_fs
from resources.lib.download import downloadfs
import xbmcgui, urllib
@Route.register
def searchfs(plugin, search_query, **kwargs):
	dp = xbmcgui.DialogProgress()
	dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
	search_query = urllib.parse.quote_plus(search_query)
	url = 'https://api.timfshare.com/v1/string-query-search?query=%s' % search_query
	resp = postlinktimfs(url, 'https://timfshare.com/', 48*60*60)
	kq = resp.json()
	if kq['data']:
		for k in kq['data']:
			item = Listitem()
			linkplay = k['url']
			if 'folder' in linkplay:
				item.label = k['name']
				thumuc = k['url'].split('folder/')
				item.art['thumb'] = item.art['landscape'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=1&size=400x400&ecc=L' % linkplay
				item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item.set_callback(index_fs, thumuc[1], 1)
				yield item
			elif 'file' in linkplay:
				item.label = k['name']
				item.info['size'] = k['size']
				item.art['thumb'] = item.art['landscape'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=1&size=400x400&ecc=L' % linkplay
				item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item.context.script(downloadfs, 'Tải về', linkplay)
				item.set_callback(play_fs, linkplay, item.label)
				yield item
	else:
		xbmcgui.Dialog().ok(__addonnoti__, 'Không tìm thấy kết quả')
		yield []