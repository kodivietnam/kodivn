from codequick import Resolver, Listitem, run, Script
from bs4 import BeautifulSoup
from urllib.parse import urlparse
from requests import Session
from collections import OrderedDict
import inputstreamhelper, urlquick, xbmc, html, xbmcgui, xbmcvfs, xbmcaddon, base64, urllib, re, time, os, sys, json
__addon__ = xbmcaddon.Addon()
__addonname__ = __addon__.getAddonInfo('name')
__version__ = __addon__.getAddonInfo('version')
__icon__ = __addon__.getAddonInfo('icon')
__addonnoti__ = f'{__addonname__} v{__version__}'
ADDON_ID = __addon__.getAddonInfo('id')
addon_data_dir = os.path.join(xbmcvfs.translatePath('special://userdata/addon_data'),ADDON_ID)
useragent = 'Dalvik/2.1.0 (Linux; U; Android 13; Pixel 7 Pro Build/TD1A.221105.001)'
useragentweb = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36 Edg/107.0.1418.56'
useragentvmf = 'Vietmediaf /Kodi1.1.99-092019'
code = f'User-Agent={useragent}'
qc ='https://vips-livecdn.fptplay.net/hda1/vtc14_vhls.smil/playlist.m3u8'
logotv = 'https://i.imgur.com/Mnuw95h.png'
news = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/qc.ass'
tb = 'Nội dung này được chia sẻ và lưu trữ bởi một ứng dụng bên thứ ba. VNmedia hoạt động giống như một công cụ thu thập tìm kiếm từ Internet. Chúng tôi không sở hữu, không lưu trữ nội dung này và sẽ không chịu trách nhiệm cho các vấn đề liên quan. Đề nghị khán giả cân nhắc trước khi xem.'
def ace(kenh, tenkenh):
	if 'acestream' in kenh:
		tach = kenh.split('//')
		p = tach[1]
	elif ':6878' in kenh:
		if '&' in kenh:
			match = re.search(r'id=(.*?)&', kenh)
			p = match.group(1)
		else:
			tach = kenh.split('id=')
			p = tach[1]
	kenhace = ''.join(("{'label': '", tenkenh.strip(),"', 'action': 'play', 'fanart': '', 'icon': '', 'id': '", p.strip(), "'}"))
	mahoa = base64.b64encode(kenhace.encode('utf-8')).decode('utf-8')
	mahoaa = urllib.parse.quote(mahoa)
	eca = f'plugin://script.module.horus/?{mahoaa}'
	return eca
def getlink(url, ref, luu):
	try:
		r = urlquick.get(url, timeout=15, max_age=luu, headers={'user-agent': useragent,'referer': ref.encode('utf-8')})
	except:
		try:
			r = urlquick.get(f'https://mi3s.top/web?trang={url}', timeout=15, max_age=luu)
		except:
			return
		else:
			r.encoding = 'utf-8'
			return r
	else:
		r.encoding = 'utf-8'
		return r
def getlinkweb(url, ref, luu):
	try:
		r = urlquick.get(url, timeout=15, max_age=luu, headers={'user-agent': useragentweb,'referer': ref.encode('utf-8')})
	except:
		try:
			r = urlquick.get(f'https://mi3s.top/web?trang={url}', timeout=15, max_age=luu)
		except:
			return
		else:
			r.encoding = 'utf-8'
			return r
	else:
		r.encoding = 'utf-8'
		return r
def getlinkphongblack(urlvmf, ref, luu):
	try:
		r = urlquick.get(urlvmf, timeout=15, max_age=luu, headers={'user-agent': 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36 VietMedia/1.0','referer': ref.encode('utf-8')})
	except:
		return
	else:
		r.encoding = 'utf-8'
		return r
def postlinktimfs(url, ref, luu):
	try:
		r = urlquick.post(url, timeout=15, max_age=luu, headers={'user-agent': useragent,
			'referer': ref.encode('utf-8'),
			'authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJuYW1lIjoiZnNoYXJlIiwidXVpZCI6IjcxZjU1NjFkMTUiLCJ0eXBlIjoicGFydG5lciIsImV4cGlyZXMiOjAsImV4cGlyZSI6MH0.WBWRKbFf7nJ7gDn1rOgENh1_doPc07MNsKwiKCJg40U'})
	except:
		return
	else:
		r.encoding = 'utf-8'
		return r
def stream(url):
	b = f'User-Agent={useragent}'
	c = url.strip()
	if '|' in url:
		a = f'{c}&{b}'
	else:
		a = f'{c}|{b}'
	return a
def referer(url):
	a = urlparse(url)
	n = a.scheme
	m = a.netloc
	x = f'&Origin={n}://{m}&verifypeer=false&Referer={n}://{m}/'
	return x
def replace_all(dict, str):
	for key in dict:
		str = str.replace(key, dict[key])
	return str
def get_kara_input():
	search_term = xbmcgui.Dialog().input('Nhập tên bài hát')
	return search_term			
def get_info_fs(x):
	with Session() as s:
		idfd = re.search(r'(file|folder)/([A-Z0-9]+)', x).group(2)
		url = f'https://www.fshare.vn/api/v3/files/folder?linkcode={idfd}'
		headers = {'user-agent':useragent,'origin': 'https://www.fshare.vn','referer':'https://www.fshare.vn/'}
		r = s.get(url, headers=headers, timeout=15)
		v = r.text
		if 'current' in v:
			l = r.json()['current']
			ten = re.sub('[\[\]\{\}]','.', l['name'])
			dungluong = l['size']
		else:
			ten = 'Dữ liệu này bị hỏng...'
			dungluong = 0
		return (ten, dungluong, x)
def userpassfs():
	username = __addon__.getSetting('username')
	password = __addon__.getSetting('password')
	if username == '' or password == '':
		__addon__.openSettings()
	else:
		payload = f'{{"app_key":"L2S7R6ZMagggC5wWkQhX2+aDi467PPuftWUMRFSn","user_email":"{username}","password":"{password}"}}'
		head = {'cache-control': 'no-cache', 'User-Agent': useragentvmf}
		try:
			r = urlquick.post('https://api.fshare.vn/api/user/login', data=payload, headers=head, timeout=15, max_age=21600)
		except:
			xbmcgui.Dialog().ok(__addonnoti__, 'Sau 3 lần đăng nhập không thành công, tài khoản sẽ bị khoá 10 phút\nKiểm tra lại tài khoản, mật khẩu, đường truyền Internet...')
			__addon__.openSettings()
			sys.exit()
		else:
			token = r.json()['token']
			session_id = r.json()['session_id']
			return (token,session_id)
def getfs(x):
	login = userpassfs()
	session_id = login[1]
	token = login[0]
	payload = {'token': token, 'url': x}
	headerfsvn = {'User-Agent': useragentvmf, 'Cookie' : f'session_id={session_id}'}
	r = urlquick.post('https://api.fshare.vn/api/session/download', timeout=15, max_age=0, json=payload, headers=headerfsvn)
	return r.json()['location']
def getrow(row):
    if row is not None and row['v'] is not None:
        return row['v']
    else:
        return ''
def quangcao():
	item = Listitem()
	linkmacdinh = stream(qc)
	item.label = 'Đang cập nhật'
	item.info['plot'] = tb
	item.art['thumb'] = 'http://tamnguyenviet.vn/wp-content/uploads/2016/07/Icon-cap-nhat.png'
	item.art['fanart'] = 'http://tamnguyenviet.vn/wp-content/uploads/2016/07/Icon-cap-nhat.png'
	item.set_callback(play_vnm, linkmacdinh, item.label, '')
	return item
def tiengruoi():
	url = 'https://bit.ly/tiengruoi'
	r = getlink(url, url, 259200)
	if r is not None:
		soup = BeautifulSoup(r.content, 'html.parser')
		subcat = [item.get('href') for item in soup.select('div.cl_item a')]
		return subcat
	else:
		return
def xembd():
	url = 'https://xembd.link/'
	r = getlink(url, url, 1000)
	if r is not None:
		soup = BeautifulSoup(r.content, 'html.parser')
		subcat = [item.get('href') for item in soup.select('a.mr_ml')]
		return subcat
	else:
		return
def rakhoi():
	url = 'https://rakhoi1.link/'
	r = getlink(url, url, 1000)
	if r is not None:
		soup = BeautifulSoup(r.content, 'html.parser')
		subcat = [item.get('href') for item in soup.select('div.layout-4columns a')]
		return subcat
	else:
		return
def cakhia():
	url = 'https://cakhia6.link/'
	r = getlink(url, url, 1000)
	if r is not None:
		soup = BeautifulSoup(r.content, 'html.parser')
		subcat = [item.get('href') for item in soup.select('div.layout-4columns a')]
		return subcat
	else:
		return
def caheo():
	url = 'https://caheo8.link/'
	r = getlink(url, url, 1000)
	if r is not None:
		soup = BeautifulSoup(r.content, 'html.parser')
		subcat = [item.get('href') for item in soup.select('div.layout-4columns a')]
		return subcat
	else:
		return
def cauthu():
	url = 'https://cauthu.link/'
	r = getlink(url, url, 1000)
	if r is not None:
		soup = BeautifulSoup(r.content, 'html.parser')
		subcat = [item.get('href') for item in soup.select('div.layout-4columns a')]
		return subcat
	else:
		return
def nocnha():
	url = 'https://nocnha.link/'
	r = getlink(url, url, 1000)
	if r is not None:
		soup = BeautifulSoup(r.content, 'html.parser')
		subcat = [item.get('href') for item in soup.select('div.layout-4columns a')]
		return subcat
	else:
		return
def saoke():
	url = 'https://saoke6.link/'
	r = getlink(url, url, 1000)
	if r is not None:
		soup = BeautifulSoup(r.content, 'html.parser')
		subcat = [item.get('href') for item in soup.select('ul.list a')]
		return subcat
	else:
		return
def mannhan():
	url = 'https://mannhan.net/'
	r = getlink(url, url, 1000)
	if r is not None:
		soup = BeautifulSoup(r.content, 'html.parser')
		subcat = [item.get('href') for item in soup.select('ul.list a')]
		return subcat
	else:
		return
def cakhiaorg():
	url = 'https://cakhia18.link/'
	r = getlink(url, url, 1000)
	if r is not None:
		soup = BeautifulSoup(r.content, 'html.parser')
		subcat = [item.get('href') for item in soup.select('a.mr_ml')]
		return subcat
	else:
		return
def khomuc():
	url = 'https://khomuc1.com/'
	r = getlink(url, url, 1000)
	if r is not None:
		soup = BeautifulSoup(r.content, 'html.parser')
		subcat = [item.get('href') for item in soup.select('a.social-link')]
		return subcat
	else:
		return
def yttk(tk):
	tim = re.sub(r"[\W_]+"," ", tk)
	return f'plugin://plugin.video.vnmedia/resources/lib/mkd/onyoutube/tim/trailer_youtube/?search_query={tim}'
def get_file_path(filename):
	return os.path.join(addon_data_dir, filename)
def has_file_path(filename):
	return os.path.exists(get_file_path(filename))
def get_last_modified_time_file(filename):
	return int(os.path.getmtime(get_file_path(filename)))
def remove_file(filename):
	if has_file_path(filename):
		os.remove(get_file_path(filename))
def write_file(name, content, binary=False):
	if not os.path.exists(addon_data_dir):
		os.makedirs(addon_data_dir)
	path = get_file_path(name)
	try:
		write_mode = 'wb+' if binary else 'w+'
		f = open(path, mode=write_mode)
		f.write(content)
		f.close()
	except:
		pass
	return path
def read_file(name, binary=False):
	content = None
	read_mode = 'rb' if binary else 'r'
	try:
		path = get_file_path(name)
		f = open(path, mode=read_mode)
		content = f.read()
		f.close()
	except:
		pass
	return content
def search_history_save(search_key):
	if not search_key:
		return
	content = read_file('historys.json')
	if content:
		content = json.loads(content)
	else:
		content = []
	idx = next((content.index(i) for i in content if search_key == i), -1)
	if idx >= 0 and len(content) > 0:
		del content[idx]
	elif len(content) >= 20:
		content.pop()
	content.insert(0, search_key)
	write_file('historys.json', json.dumps(content))
def search_history_clear():
	write_file('historys.json', json.dumps([]))
def search_history_get():
	content = read_file('historys.json')
	if content:
		content = json.loads(content)
	else:
		content = []
	return content
def save_last_watch_movie(data):
	if not data:
		return
	content = read_file('watcheds.json')
	if content:
		content = json.loads(content, object_pairs_hook=OrderedDict)
	else:
		content = OrderedDict()
	cache_id, query = data
	content.update({cache_id: query})
	content.move_to_end(cache_id, last=False)
	write_file('watcheds.json', json.dumps(content))
def get_last_watch_movie():
	content = read_file('watcheds.json')
	if content:
		content = json.loads(content)
	else:
		content = {}
	return content
@Script.register
def search_history_clear(plugin, **kwargs):
	write_file('historys.json', json.dumps([]))
	xbmc.executebuiltin('Container.Refresh()')
@Script.register
def clear_last_watch_movie(plugin, **kwargs):
	write_file('watcheds.json', '')
	xbmc.executebuiltin('Container.Refresh()')
@Resolver.register
def play_vnm(plugin,url,title,drmKey, **kwargs):
	if drmKey !='':
		is_helper = inputstreamhelper.Helper('mpd','com.widevine.alpha')
		if is_helper.check_inputstream():
			return Listitem().from_dict(**{'label': title,'subtitles':{news},'callback':url,'properties':{'inputstream':is_helper.inputstream_addon,'inputstream.adaptive.manifest_type':'mpd','inputstream.adaptive.license_type':'com.widevine.alpha','inputstream.adaptive.license_key':f'{drmKey}|origin={url}&User-Agent={useragent}&referer={url}|R{{SSM}}|'}})
	elif '.m3u8' in url:
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':url,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
	else:
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':url})
@Resolver.register
def ifr_xembong(plugin,url,title, **kwargs):
	r = getlink(url, url, 600)
	if r is not None:
		if '.m3u8' in r.text:
			match = re.search(r'linkStream = \'(.*?)\'', r.text)
			linkplay = f'{stream(match.group(1))}{referer(url)}'
		else:
			linkplay = stream(qc)
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
	else:
		linkplay = stream(qc)
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
@Resolver.register
def ifr_bongda(plugin,url,title, **kwargs):
	resp = getlink(url,url, 600)
	if resp is not None:
		m = urlparse(url)
		linkweb = f'{m.scheme}://{m.netloc}'
		if 'allowfullscreen' in resp.text:
			soup = BeautifulSoup(resp.content, 'html.parser')
			ifr = soup.select_one('iframe[allowfullscreen]').get('src')
			if 'http' in ifr:
				ifr = ifr
			else:
				ifr = f'{linkweb}{ifr}'
			r = getlink(ifr, url, 600)
			if r is not None:
				if '.m3u8' in r.text:
					linkstream = re.search(r'((http|https)?:\/\/[^/\s]+/\S+?\.m3u8([^(\"|\')]*))', r.text).group(1)
					d = getlink(linkstream, linkstream, 600)
					if d is not None:
						if '.m3u8' and 'http' in d.text:
							a = re.search(r'((http|https)?:\/\/[^/\s]+/\S+?\.m3u8([^(\"|\')]*))', d.text).group(1)
						else:
							a = linkstream
						linkplay = f'{stream(a)}{referer(ifr)}'
					else:
						linkplay = stream(qc)
				else:
					linkplay = stream(qc)
			else:
				linkplay = stream(qc)
		else:
			linkplay = stream(qc)
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
	else:
		linkplay = stream(qc)
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
@Resolver.register
def ifr_xoilacme(plugin,url,title, **kwargs):
	r = getlink(url, url, 600)
	if r is not None:
		if '.m3u8' in r.text:
			match = re.search(r'let mideoUrl = "(.*?)"', r.text)
			linkplay = f'{stream(match.group(1).replace("&amp;", "&"))}{referer(url)}'
		else:
			linkplay = stream(qc)
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
	else:
		linkplay = stream(qc)
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
@Resolver.register
def play_fs(plugin,url,title, **kwargs):
	save_last_watch_movie((title, url))
	try:
		return Listitem().from_dict(**{'label': title,'subtitles' : {news},'callback': getfs(url)})
	except:
		Script.notify(__addonnoti__, 'Tập tin này bị hỏng hoặc đăng nhập không thành công')
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':stream(qc)})
@Resolver.register
def play_vtvrep(plugin,idx, title, **kwargs):
	url = f'https://vtvgo.vn/ajax-get-epg-detail?epg_id={idx}'
	r = getlinkweb(url, url, 600)
	if r is not None:
		if '.m3u8' in r.text:
			linkplay = f'{stream(r.json()["data"])}{referer("https://vtvgo.vn/")}'
		else:
			linkplay = stream(qc)
		if '.m3u8' in linkplay:
			return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
		else:
			return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay})
	else:
		linkplay = stream(qc)
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
@Resolver.register
def playsocolive(plugin, numroom, timestamp, linkref, title, **kwargs):
	url = f'https://json.cvndnss.com/room/{numroom}/detail.json?v={timestamp}'
	r = getlink(url, url, 600)
	if r is not None:
		nd = re.search(r'(\{.*\})', r.text, re.DOTALL).group(1)
		m = json.loads(nd)
		l = m['data']['stream']['hdM3u8']
		linkplay = f'{stream(l)}{referer(linkref)}'
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
	else:
		linkplay = stream(qc)
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
@Resolver.register
def play_vtvgo(plugin, timekenh, tokenkenh, idkenh, x, title, **kwargs):
	urlx = 'https://vtvgo.vn/ajax-get-stream'
	payload = {'type_id': '1','id': idkenh,'time': timekenh,'token': tokenkenh}
	headx = {'user-agent': useragentweb,
	'x-requested-with': 'XMLHttpRequest',
	'referer': f'https://vtvgo.vn/xem-truc-tuyen-kenh-vtv-{idkenh}.html',
	'content-type': 'application/x-www-form-urlencoded; charset=UTF-8'}
	p = urlquick.post(urlx, data=urllib.parse.urlencode(payload, quote_via=urllib.parse.quote), cookies=x, headers=headx, max_age=900)
	if '.m3u8' in p.text:
		linkplay = f'{stream(p.json()["chromecast_url"])}{referer("https://vtvgo.vn")}'
	else:
		linkplay = stream(qc)
	if '.m3u8' in linkplay:
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
	else:
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay})
@Resolver.register
def ifr_khomuc(plugin,url,title, **kwargs):
	r = getlinkweb(url, url, 600)
	if r is not None:
		if '.m3u8' in r.text:
			match = re.search(r'((http|https)?:\/\/[^/\s]+/\S+?\.m3u8([^(\"|\')]*))', r.text)
			linkplay = f'{stream(match.group(1))}{referer(url)}'
		else:
			linkplay = stream(qc)
		if '.m3u8' in linkplay:
			return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
		else:
			return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay})
	else:
		linkplay = stream(qc)
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
@Resolver.register
def play_vk(plugin, idvd1, idvd2, title, **kwargs):
	url = 'https://vk.com/al_video.php?act=show'
	data={'act': 'show', 'al': '1', 'claim': '', 'dmcah': '', 'hd': '', 'list': f'pl_{idvd1}_1', 'module': 'direct', 'playlist_id': f'{idvd1}_-2', 'show_original': '', 't': '', 'video': f'{idvd1}_{idvd2}'}
	headers={'content-type': 'application/x-www-form-urlencoded', 'Referer': 'http://vk.com', 'User-Agent':useragentweb, 'x-requested-with': 'XMLHttpRequest'}
	r = urlquick.post(url, headers=headers, data=data, max_age=0)
	if r is not None:
		if 'hls_ondemand' in r.text:
			linkget = re.search(r'hls_ondemand":"(.*?)"', r.text).group(1)
			d = html.unescape(linkget).replace('\\/', '/')
			linkplay = f'{stream(d)}{referer("https://vk.com/")}'
		elif 'hls' in r.text:
			linkget = re.search(r'hls":"(.*?)"', r.text).group(1)
			d = html.unescape(linkget).replace('\\/', '/')
			linkplay = f'{stream(d)}{referer("https://vk.com/")}'
		else:
			linkplay = stream(qc)
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
	else:
		linkplay = stream(qc)
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
@Resolver.register
def play_bm(plugin,url,title, **kwargs):
	r = getlink(url, url, 600)
	if r is not None:
		if 'streamingUrl' in r.text:
			match = re.search(r'streamingUrl":"(.*?)"}', r.text)
			linkplay = f'{stream(match.group(1))}{referer(url)}'
		else:
			linkplay = stream(qc)
		if '.m3u8' in linkplay:
			return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
		else:
			return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay})
	else:
		linkplay = stream(qc)
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})