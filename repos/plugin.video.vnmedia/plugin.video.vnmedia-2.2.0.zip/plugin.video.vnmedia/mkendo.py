from codequick import run
import importlib
def main():
    exception = run()
    if isinstance(exception, Exception):
        main = importlib.import_module('resources.lib.main')
        main.error_handler(exception)
if __name__ == '__main__':
    main()