from resources.lib.kedon import getlinkvnm
import xbmc, xbmcaddon, json
def autorun_addon():
    xbmc.executebuiltin('UpdateAddonRepos()')
    if xbmcaddon.Addon().getSetting('auto_run') == 'true':
        xbmc.executebuiltin('RunAddon(plugin.video.vnmedia)')
    if xbmcaddon.Addon().getSetting('auto_noti') == 'true':
        url = 'https://speedtest.vn/get-ip-info'
        r = getlinkvnm(url, url).data.decode('utf-8')
        if r:
            d = json.loads(r)
            a = ' '.join([c for c in reversed(d.values())])
        else:
            a = 'VNNIC error'
        xbmc.executebuiltin(f'Notification("KODI VIỆT NAM", {a}, 10000, {xbmcaddon.Addon().getAddonInfo("icon")})')
    return
autorun_addon()