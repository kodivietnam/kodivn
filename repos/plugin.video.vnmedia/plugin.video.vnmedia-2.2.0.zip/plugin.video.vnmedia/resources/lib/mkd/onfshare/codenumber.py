from codequick import Route, Listitem, run, Script
from resources.lib.kedon import getlinkvnm, quangcao, __addonnoti__, yttk, get_info_fs, play_fs, search_history_get, search_history_clear, search_history_save
from resources.lib.mkd.onfshare.ifshare import index_fs, tfavo
from resources.lib.download import downloadfs
import xbmcaddon, xbmcgui, re, urllib
def get_user_input():
	shorturl = xbmcaddon.Addon().getSetting('shorten_host')
	search_term = xbmcgui.Dialog().input(f'{shorturl.upper()} - Mã CODE được chia sẻ bởi facebook Hội mê Phim')
	return search_term
@Route.register
def index_number(plugin, **kwargs):
	yield PlayNumberCode()
	yield Listitem.from_dict(**{'label': 'MÃ CODE gần đây',
	'info': {'plot': 'MÃ CODE đã nhập'},
	'art': {'thumb': 'https://apkmodo.net/wp-content/uploads/2022/01/WATCHED-APK.jpg',
	'fanart': 'https://fsharetv.com/img/fsharetv.png'},
	'callback': index_codeganday})
@Route.register
def index_codeganday(plugin, **kwargs):
	b = search_history_get()
	if b:
		for m in b:
			item = Listitem()
			item.label = m.split('/')[-1]
			item.art['thumb'] = item.art['landscape'] = 'https://reference.vn/wp-content/uploads/2019/04/lic-su-so-tu-nhien.jpg'
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			item.set_callback(dulieucode, m)
			yield item
		yield Listitem.from_dict(**{'label': 'Xoá lịch sử CODE',
		'info': {'plot': 'Xoá lịch sử mã code đã nhập'},
		'art': {'thumb': 'https://apkmodo.net/wp-content/uploads/2022/01/WATCHED-APK.jpg',
		'fanart': 'https://fsharetv.com/img/fsharetv.png'},
		'callback': search_history_clear})
	else:
		yield []
@Route.register
def dulieucode(plugin, m, **kwargs):
	x = getlinkvnm(m, m).geturl()
	if 'folder' in x:
		item = Listitem()
		dulieu = get_info_fs(x)
		idfd = re.search(r'(file|folder)/([A-Z0-9]+)', x).group(2)
		item.label = dulieu[0]
		next_page = 1
		item.info['mediatype'] = 'episode'
		item.info['rating'] = 10.0
		item.info['trailer'] = yttk(item.label)
		item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={x}&qzone=1&margin=1&size=400x400&ecc=L'
		item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
		item.context.script(tfavo, 'Thêm vào Fshare Favorite', x)
		item.set_callback(index_fs, idfd, next_page)
		yield item
	elif 'file' in x:
		item = Listitem()
		dulieu = get_info_fs(x)
		item.label = dulieu[0]
		item.info['size'] = dulieu[1]
		item.info['mediatype'] = 'episode'
		item.info['rating'] = 10.0
		item.info['trailer'] = yttk(item.label)
		item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={x}&qzone=1&margin=1&size=400x400&ecc=L'
		item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
		if xbmcaddon.Addon().getSetting('taifshare') == 'true':
			item.context.script(downloadfs, 'Tải về', x)
		item.context.script(tfavo, 'Thêm vào Fshare Favorite', x)
		item.set_callback(play_fs, x, item.label)
		yield item
	else:
		Script.notify(__addonnoti__, 'CODE không đúng')
		yield quangcao()
@Route.register
def searchnumber(plugin,search_query, **kwargs):
	shorturl = xbmcaddon.Addon().getSetting('shorten_host')
	search_query = get_user_input()
	if search_query == '':
		Script.notify(f'{__addonnoti__} - {shorturl.upper()}', 'Bạn chưa nhập CODE')
		yield quangcao()
	else:
		dp = xbmcgui.DialogProgress()
		dp.create(__addonnoti__, f'Đang lấy dữ liệu từ máy chủ {shorturl.upper()}...')
		dp.update(5)
		search_query = urllib.parse.quote_plus(search_query)
		z = f'http://{shorturl}/{search_query}'
		search_history_save(z)
		x = getlinkvnm(z, z).geturl()
		if 'folder' in x:
			item = Listitem()
			dulieu = get_info_fs(x)
			idfd = re.search(r'(file|folder)/([A-Z0-9]+)', x).group(2)
			item.label = dulieu[0]
			next_page = 1
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = yttk(item.label)
			item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={x}&qzone=1&margin=1&size=400x400&ecc=L'
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			item.context.script(tfavo, 'Thêm vào Fshare Favorite', x)
			item.set_callback(index_fs, idfd, next_page)
			yield item
		elif 'file' in x:
			item = Listitem()
			dulieu = get_info_fs(x)
			item.label = dulieu[0]
			item.info['size'] = dulieu[1]
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = yttk(item.label)
			item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={x}&qzone=1&margin=1&size=400x400&ecc=L'
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			if xbmcaddon.Addon().getSetting('taifshare') == 'true':
				item.context.script(downloadfs, 'Tải về', x)
			item.context.script(tfavo, 'Thêm vào Fshare Favorite', x)
			item.set_callback(play_fs, x, item.label)
			yield item
		else:
			Script.notify(__addonnoti__, 'CODE không đúng')
			yield quangcao()
		dp.update(100)
		dp.close()
def PlayNumberCode():
	shorturl = xbmcaddon.Addon().getSetting('shorten_host')
	item = Listitem()
	item.label = 'MÃ CODE'
	item.info['plot'] = f'Mã CODE được chia sẻ bởi nhóm fb Hội mê phim - máy chủ {shorturl.upper()}'
	item.path = searchnumber
	item.art['thumb'] = item.art['landscape'] = 'https://reference.vn/wp-content/uploads/2019/04/lic-su-so-tu-nhien.jpg'
	item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
	item.set_callback(searchnumber, item.path)
	return item