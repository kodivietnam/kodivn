from codequick import Route, Listitem
from functools import lru_cache
@Route.register
def index_fshare(plugin, **kwargs):
	yield Listitem.search(Route.ref('/resources/lib/mkd/onfshare/timfshare:searchfs'))
	yield Listitem.from_dict(**{'label': 'LỊCH SỬ XEM',
	'info': {'plot': 'Nội dung được xem gần nhất'},
	'art': {'thumb': 'https://is3-ssl.mzstatic.com/image/thumb/Purple114/v4/51/23/a1/5123a1fa-91c0-7c77-b821-3a9052a312d8/source/256x256bb.jpg',
	'fanart': 'https://fsharetv.com/img/fsharetv.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/ifshare:index_daxem')})
	yield makeQrPlayItem()
	yield Listitem.from_dict(**{'label': 'NHẬP CODEPLAY',
	'info': {'plot': 'Nhập MÃ CODE để phát phim'},
	'art': {'thumb': 'https://is5-ssl.mzstatic.com/image/thumb/Purple128/v4/f3/f2/50/f3f25075-85a5-b11c-e1f2-fce9f647c22f/source/512x512bb.jpg',
	'fanart': 'https://fsharetv.com/img/fsharetv.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/codenumber:index_number')})
	yield Listitem.from_dict(**{'label': 'Fshare Favourite',
	'info':{'plot':'Yêu thích'},
	'art':{'thumb':'https://previews.123rf.com/images/faysalfarhan/faysalfarhan1605/faysalfarhan160502678/56752107-favourite-heart-icon-pink-glossy-round-button.jpg',
	'fanart':'https://fsharetv.com/img/fsharetv.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/ifshare:fs_favorite')})
	yield moicapnhat()
	yield trending()
	yield phim4k()
	yield bluray()
	yield thuyetminh()
	yield longtieng()
	yield phimle()
	yield phimbo()
	yield anime()
	yield Listitem.from_dict(**{'label': 'TOP 250 IMDb',
	'info':{'plot':'Top 250 phim IMDb'},
	'art':{'thumb':'http://1.bp.blogspot.com/-xXABqhqTx3Q/UO-yBML_2MI/AAAAAAAAA74/A930nVncOPI/s1600/imdb-feature.jpg',
	'fanart':'https://fsharetv.com/img/fsharetv.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/ifshare:top250')})
	yield Listitem.from_dict(**{'label': 'TOP Thịnh hành IMDb',
	'info':{'plot':'Top phim thịnh hành IMDb'},
	'art':{'thumb':'https://res.cloudinary.com/crunchbase-production/image/upload/c_lpad,h_256,w_256,f_auto,q_auto:eco,dpr_1/v1504305313/rzx3lnpczuilzwlmhuxx.png',
	'fanart':'https://fsharetv.com/img/fsharetv.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/ifshare:topmoviemeter')})
	yield Listitem.from_dict(**{'label': 'TOP phòng vé',
	'info':{'plot':'Top phim chiếu rạp tuần này'},
	'art':{'thumb':'https://www.cinemasangeet.com/upload/1370895516.jpg',
	'fanart':'https://fsharetv.com/img/fsharetv.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/ifshare:boxoffice')})
	yield Listitem.from_dict(**{'label': 'TOP Âu Mỹ',
	'info':{'plot':'Top phim Anh ngữ'},
	'art':{'thumb':'https://image.roku.com/developer_channels/prod/705f4fe9f70aec711e4ac20853dacc4997750ae6827b54b9d44ec3a02f01d378.png',
	'fanart':'https://fsharetv.com/img/fsharetv.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/ifshare:topaumy')})
	yield Listitem.from_dict(**{'label': 'Xem gì hôm nay',
	'info': {'plot': 'Phim đề xuất'},
	'art': {'thumb': 'https://styles.redditmedia.com/t5_2qh3s/styles/communityIcon_yq9ah8eniar81.jpg',
	'fanart': 'https://fsharetv.com/img/fsharetv.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/timfshare:index_pdx')})
	yield Listitem.from_dict(**{'label': 'TÔI TỔNG HỢP',
	'info': {'plot': 'Nội dung cá nhân được tạo từ googlesheet'},
	'art': {'thumb': 'https://itseovn.com/data/avatars/l/51/51797.jpg',
	'fanart': 'https://fsharetv.com/img/fsharetv.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/gcs:index_gcs')})
	yield Listitem.from_dict(**{'label': 'HdVietNam',
	'info':{'plot':'Thư viện dữ liệu phim Fshare'},
	'art':{'thumb':'https://hdvietnam.xyz/images/hd-vietnam-logo.png',
	'fanart':'https://fsharetv.com/img/fsharetv.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/hdvn:index_hdvn')})
	yield Listitem.from_dict(**{'label': 'Thư viện HD',
	'info':{'plot':'Thư viện dữ liệu phim Fshare'},
	'art':{'thumb':'https://thuvienhd.com/wp-content/uploads/2020/10/THUVIENHD.NET_.png',
	'fanart':'https://fsharetv.com/img/fsharetv.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/thuvienhd:index_thuvienhd')})
	yield Listitem.from_dict(**{'label': 'Thư viện Cine',
	'info':{'plot':'Thư viện dữ liệu phim Fshare'},
	'art':{'thumb':'https://thuviencine.com/wp-content/uploads/2021/09/logo-red.png',
	'fanart':'https://fsharetv.com/img/fsharetv.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/thuviencine:index_thuviencine')})
	yield Listitem.from_dict(**{'label': 'TOP FSHARE',
	'info':{'plot':'Top 15 thư mục theo dõi nhiều nhất'},
	'art':{'thumb':'https://pbs.twimg.com/profile_images/643472392992505856/wJ6I99cZ_400x400.png',
	'fanart':'https://fsharetv.com/img/fsharetv.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/ifshare:fs_topfollow')})
@lru_cache(maxsize=None)
def makeQrPlayItem():
	item = Listitem()
	item.label = 'Mobile Play'
	item.info['plot'] = 'Dùng điện thoại để nhập link Fshare hoặc nhập từ khóa tìm kiếm thuận tiện'
	item.path = Route.ref('/resources/lib/qrplay:qrplay')
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://banner2.cleanpng.com/20180303/leq/kisspng-template-download-mobile-phone-qr-code-vector-creative-hand-phone-5a9aa86bd143f0.9505955915200850998572.jpg'
	item.set_callback(item.path)
	return item
@lru_cache(maxsize=None)
def moicapnhat():
	item = Listitem()
	item.label = '[COLOR yellow][B]MỚI NHẤT[/B][/COLOR]'
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://w7.pngwing.com/pngs/90/19/png-transparent-film-cinema-movies-miscellaneous-text-logo-thumbnail.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_page'), 'https://thuvienhd.com/recent/page/', 1)
	return item
@lru_cache(maxsize=None)
def phim4k():
	item = Listitem()
	item.label = '4K - H265'
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://t4.ftcdn.net/jpg/02/29/51/71/360_F_229517192_Lzw3E2MvfEJCfqzVZ75mjXA8Fbzb7Q6I.jpg'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_page'), 'https://thuvienhd.com/genre/4k/page/', 1)
	return item
@lru_cache(maxsize=None)
def bluray():
	item = Listitem()
	item.label = 'Bluray nguyên gốc'
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://www.pngkey.com/png/full/112-1123878_blue-ray-disc-logo-blu-ray-disc.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_page'), 'https://thuvienhd.com/genre/bluray-nguyen-goc/page/', 1)
	return item
@lru_cache(maxsize=None)
def thuyetminh():
	item = Listitem()
	item.label = 'Thuyết minh'
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://yuphim.net/themes/bptv/images/icon.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_page'), 'https://thuvienhd.com/genre/thuyet-minh-tieng-viet/page/', 1)
	return item
@lru_cache(maxsize=None)
def longtieng():
	item = Listitem()
	item.label = 'Lồng tiếng'
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://media.cdnandroid.com/item_images/1105169/imagen-tv-hay-xem-phim-thuyao-t-minh-la-ng-tiao-ng-0ori.jpg'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_page'), 'https://thuvienhd.com/genre/long-tieng-tieng-viet/page/', 1)
	return item
@lru_cache(maxsize=None)
def anime():
	item = Listitem()
	item.label = 'Anime'
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://e7.pngegg.com/pngimages/134/869/png-clipart-fairy-tail-sabertooth-guild-logo-tooth-fairy-text-trademark.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_page'), 'https://thuvienhd.com/genre/animation/page/', 1)
	return item
@lru_cache(maxsize=None)
def phimle():
	item = Listitem()
	item.label = 'Phim lẻ'
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://startupxplore.com/uploads/ff8080817ad496ba017ad8bcc28a0250-large.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_page'), 'https://thuvienhd.com/genre/phim-le/page/', 1)
	return item
@lru_cache(maxsize=None)
def phimbo():
	item = Listitem()
	item.label = 'Phim bộ'
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://images.squarespace-cdn.com/content/v1/5507139be4b01d7294fc5130/17f8e193-6b9d-4d62-a2c3-20711bdd5232/FILM_SERIES_LOGO.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_page'), 'https://thuvienhd.com/genre/series/page/', 1)
	return item
@lru_cache(maxsize=None)
def trending():
	item = Listitem()
	item.label = '[COLOR yellow][B]TRENDING[/B][/COLOR]'
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://yt3.googleusercontent.com/YayeRhn0gxJbltXxBt3eIlUxAeLqhAYYS9OiwQ8Slx3E7rBH8JD7rJKc9dK-BWD4DMwbrJW9O2Q=s900-c-k-c0x00ffffff-no-rj'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuviencine:thuviencine_page'), 'https://thuviencine.com/top/', 1)
	return item