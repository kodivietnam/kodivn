from codequick import Route, Listitem, Resolver
from urllib.parse import urlparse
from importlib import import_module
from datetime import datetime, timedelta
@Route.register
def index_caheo(plugin, **kwargs):
	w = import_module('resources.lib.kedon')
	l = w.caheo()[0]
	v = urlparse(w.getlink(l,l,400).url)
	url = f'{v.scheme}://{v.netloc}/'
	ux = f'{url}node-cache/get-lives-home'
	resp = w.getlink(ux, ux, -1)
	if (resp is not None) and ('.m3u8' in resp.text):
		kq = resp.json()
		m = (k for m in kq['data'].values() for k in m)
		for k in m:
			time = (datetime.fromisoformat(k['time'][:-1]) + timedelta(hours=7)).strftime('%H:%M %d-%m')
			doi1 = k['teamA']['name']
			doi2 = k['teamB']['name']
			blv1 = k['commentator']
			blv2 = k['commentatorCaHeo']
			if 'hlsUrlsCaHeo' in k:
				for e in k['hlsUrlsCaHeo']:
					if 'm3u8' in e['url']:
						item2 = Listitem()
						if blv2:
							item2.label = f'{e["name"]}-{time}: {doi1}-{doi2} - BLV: {blv2}'
						else:
							item2.label = f'{e["name"]}-{time}: {doi1}-{doi2}'
						item2.info['plot'] = w.tb
						item2.art['thumb'] = item2.art['landscape'] = item2.art['fanart'] = 'https://i.imgur.com/KdSuVMn.png'
						item2.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), f'{w.stream(e["url"])}{w.referer(url)}', item2.label, '')
						yield item2
			for d in k['hlsUrls']:
				if 'm3u8' in d['url']:
					item1 = Listitem()
					if blv1:
						item1.label = f'{d["name"]}-{time}: {doi1}-{doi2} - BLV: {blv1}'
					else:
						item1.label = f'{d["name"]}-{time}: {doi1}-{doi2}'
					item1.info['plot'] = w.tb
					item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://i.imgur.com/TTprlUP.png'
					item1.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), f'{w.stream(d["url"])}{w.referer(url)}', item1.label, '')
					yield item1
	else:
		yield w.quangcao()