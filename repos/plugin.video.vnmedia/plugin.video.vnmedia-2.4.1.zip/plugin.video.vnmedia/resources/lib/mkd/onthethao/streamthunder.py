from codequick import Route, Listitem
from importlib import import_module
from datetime import datetime, timedelta
from json import loads
import re
@Route.register
def index_streamthunder(plugin, **kwargs):
	w = import_module('resources.lib.kedon')
	url = 'http://widget.streamthunder.org/list.php?id=21&sport=&sp=&r=&l=&l2='
	resp = w.getlink(url, url, 400)
	if (resp is not None) and ('acestream' in resp.text):
		m1 = loads(re.search(r'var chan_arr = (.*?);\n', resp.text).group(1))
		m2 = loads(re.search(r'var ev_arr = (.*?);\n', resp.text).group(1))
		a1 = ((m,x['link'], a) for m in m1 for a, x in enumerate(m1[m]))
		a2 = ((v['id'], v['date'], v['match']) for v in m2)
		for k in a1:
			if 'acestream' in k[1]:
				item = Listitem()
				for l in a2:
					if k[0] == l[0]:
						z = (datetime.fromisoformat(l[1]) + timedelta(hours=6)).strftime('%H:%M')
						item.label = f'Link {k[2]+1}-{z} {l[2]}'
						item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg'
						linkplay = w.ace(k[1], item.label)
						item.path = linkplay
						item.set_callback(item.path)
						yield item
	else:
		yield w.quangcao()