from codequick import Route, Listitem, Resolver
from importlib import import_module
from datetime import datetime
from functools import lru_cache
import re
@lru_cache(maxsize=None)
def respphut90():
	w = import_module('resources.lib.kedon')
	tr1 = w.tiengruoi()[1]
	resp90 = w.getlink(tr1, tr1, 400)
	if (resp90 is not None):
		ref = re.search(r'  window.base_embed_url(.*?)"(.*?)"', resp90.text).group(2)
	else:
		ref = tr1
	return ref
@Route.register
def index_vebo(plugin, **kwargs):
	w = import_module('resources.lib.kedon')
	url = 'http://api.vebo.xyz/api/match/featured'
	ref = respphut90()
	resp = w.getlink(url, ref, 400)
	if (resp is not None):
		kq = resp.json()
		for k in kq['data']:
			item = Listitem()
			time = datetime.fromtimestamp(int(k['timestamp'])/1000).strftime('%H:%M %d-%m')
			if k['commentators']:
				item.label = f'{time}: {k["name"]} ({k["commentators"][0]["name"]})'
			else:
				item.label = f'{time}: {k["name"]}'
			item.info['plot'] = w.tb
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://90m.link/images/logo-01.png'
			item.set_callback(list_vebo, k['id'], item.label)
			yield item
	else:
		yield w.quangcao()
@Route.register
def list_vebo(plugin, idk, title, **kwargs):
	w = import_module('resources.lib.kedon')
	ref = respphut90()
	url = f'http://api.vebo.xyz/api/match/{idk}/meta'
	resp = w.getlink(url, ref, 400)
	if (resp is not None) and ('.m3u8' in resp.text):
		kq = resp.json()
		for k in kq['data']['play_urls']:
			item = Listitem()
			item.label = f'{k["name"]} - {title}'
			linktrandau = f'{w.stream(k["url"])}{w.referer(ref)}'
			item.info['plot'] = w.tb
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://90m.link/images/logo-01.png'
			item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), linktrandau, item.label, '')
			yield item
	else:
		yield w.quangcao()