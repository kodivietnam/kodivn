from codequick import Route, Listitem, run
from resources.lib.kedon import logotv, getlink, stream, ace, play_vnm
import re
@Route.register
def index_90ptv(plugin, **kwargs):
    url = 'http://gg.gg/90phuttv'
    resp = getlink(url, url, 5*60)
    kq = '\n'.join([ll.rstrip() for ll in resp.text.splitlines() if ll.strip()])
    kq = re.sub(r'#h(.*?)\n|#EXTV(.*?)\n|#K(.*?)\n', '', kq)
    ketqua = kq.split('#EXTI')
    for tach in ketqua:
        listplay = re.findall(r'NF(.*)\n(.*)', tach)
        for k in listplay:
            item = Listitem()
            if len(k)>1:
                idkenh = re.search('tvg-id="(.*?)"', k[0])
                if idkenh:
                    idm = idkenh.group(1)
                else:
                    idm = 'vnm'
                logo = re.search('tvg-logo="(.*?)"', k[0])
                if logo:
                    item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = logo.group(1)
                else:
                    item.art['thumb'] = item.art['landscape'] = logotv
                    item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
                tenkenh = re.search('[,](?!.*[,])(.*?)$', k[0]).group(1)
                group = re.search('group-title="(.*?)"', k[0])
                if group:
                    nhomkenh = group.group(1)
                else:
                    nhomkenh = 'TỔNG HỢP'
                item.label = '%s - %s' % (tenkenh, nhomkenh)
                kenh = k[1]
                if 'acestream' in kenh:
                    linkplay = ace(kenh, item.label)
                    item.path = linkplay
                    item.set_callback(item.path)
                elif ':6878' in kenh:
                    linkplay = ace(kenh, item.label)
                    item.path = linkplay
                    item.set_callback(item.path)
                else:
                    linkplay = stream(kenh.strip())
                    item.set_callback(play_vnm, linkplay, item.label, '')
                item.info['plot'] = '%s - %s' % (nhomkenh, tenkenh)
                yield item