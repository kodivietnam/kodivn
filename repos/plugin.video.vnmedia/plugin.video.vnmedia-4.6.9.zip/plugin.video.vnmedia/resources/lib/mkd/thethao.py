from codequick import Route, Listitem
@Route.register
def index_thethao(plugin):
	streams = [
		('XEM LẠI SỰ KIỆN', 'https://mi3s.top/thumb/thethao/xemlai.png', '/resources/lib/mkd/onthethao/xemlaivk:index_xemlaivk'),
		('Tin thể thao', 'https://mi3s.top/thumb/thethao/tinthethao.png', '/resources/lib/mkd/onthethao/tinthethao:index_tinthethao'),
		('ACESTREAM', 'https://mi3s.top/thumb/thethao/acestream.png', '/resources/lib/mkd/acest:index_acestream'),
		('DADDYLIVE', 'https://mi3s.top/thumb/thethao/daddy-live-hd-channels-list.png', '/resources/lib/mkd/onthethao/daddylive:index_daddy'),
		('MECIURI', 'https://mi3s.top/thumb/thethao/sports-channels.png', '/resources/lib/mkd/onthethao/ustream:index_ustream'),
		('90P-VEBO', 'https://mi3s.top/thumb/thethao/90p.png', '/resources/lib/mkd/onthethao/phut90:index_90p'),
		('THAPCAM', 'https://mi3s.top/thumb/thethao/thapcamtv.png', '/resources/lib/mkd/onthethao/thapcam:index_thapcam'),
		('MITOM', 'https://mi3s.top/thumb/thethao/mitom.png', '/resources/lib/mkd/onthethao/phut91:index_91phut'),
		('CAKHIA', 'https://mi3s.top/thumb/thethao/cakhia.png', '/resources/lib/mkd/onthethao/cakhia:index_cakhia'),
		('RAKHOI', 'https://mi3s.top/thumb/thethao/rakhoi.png', '/resources/lib/mkd/onthethao/rakhoi:index_rakhoi'),
		('CAHEO', 'https://mi3s.top/thumb/thethao/caheo.png', '/resources/lib/mkd/onthethao/caheo:index_caheo'),
		('SAOKE', 'https://mi3s.top/thumb/thethao/saoke.png', '/resources/lib/mkd/onthethao/saoke:index_saoke'),
		('GAVANG', 'https://mi3s.top/thumb/thethao/gavang.png', '/resources/lib/mkd/onthethao/gavang:index_gavang'),
		('SOCOLIVE', 'https://mi3s.top/thumb/thethao/soco.png', '/resources/lib/mkd/onthethao/socolive:index_socolive'),
		('TRUCTIEPNBA', 'https://mi3s.top/thumb/thethao/nba.png', '/resources/lib/mkd/onthethao/nba:index_nba')
	]
	i = Listitem()
	i.label = 'SỰ KIỆN TRỰC TIẾP'
	i.info['mediatype'] = 'tvshow'
	i.art['thumb'] = i.art['poster'] = 'https://mi3s.top/thumb/thethao/sukien.png'
	i.set_callback(Route.ref('/resources/lib/mkd/onfshare/gcs:listvmf_gcs'), 'https://mi3s.top/vnmedia', 'SỰ KIỆN TRỰC TIẾP')
	yield i
	for name_key, banner_key, url_key in streams:
		item = Listitem()
		item.label = name_key
		item.info['mediatype'] = 'tvshow'
		item.art['thumb'] = item.art['poster'] = banner_key
		item.set_callback(Route.ref(url_key))
		yield item