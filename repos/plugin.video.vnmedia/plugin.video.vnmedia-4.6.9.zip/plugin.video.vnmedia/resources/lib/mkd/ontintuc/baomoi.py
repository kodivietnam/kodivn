from codequick import Route, Listitem, Resolver
from resources.lib.kedon import getlink, quangcao
import re
@Route.register
def index_baomoi(plugin):
	dulieu = {'Tin Nóng':'home',
	'Tin mới':'new',
	'Thế giới':'the-gioi',
	'Xã hội':'xa-hoi',
	'Văn hoá':'van-hoa',
	'Kinh tế':'kinh-te',
	'Giáo dục':'giao-duc',
	'Thể thao':'the-thao',
	'Giải trí':'giai-tri',
	'Pháp luật':'phap-luat',
	'Công nghệ':'khoa-hoc-cong-nghe',
	'Khoa học':'khoa-hoc',
	'Đời sống':'doi-song',
	'Xe cộ':'xe-co',
	'Nhà đất':'nha-dat'}
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.info['mediatype'] = 'tvshow'
		item.art['thumb'] = item.art['poster'] = 'https://mi3s.top/thumb/news.png'
		item.set_callback(list_baomoi, dulieu[k])
		yield item
@Route.register
def list_baomoi(plugin, ten=None):
	yield []
	if ten is None:
		pass
	else:
		try:
			r = getlink('http://lite.baomoi.com','https://lite.baomoi.com', -1)
			if (r is not None) and ('buildId":"' in r.text):
				idbm = re.search(r'buildId":"(.*?)"', r.text)[1]
				if (ten == 'home') or (ten == 'new'):
					url = f'http://lite.baomoi.com/_next/data/{idbm}/{ten}.json'
				else:
					url = f'http://lite.baomoi.com/_next/data/{idbm}/category/{ten}.json'
				kq = getlink(url, 'http://lite.baomoi.com', -1).json()
				getjs = kq['pageProps']['resp']['data']['content']['items']
				h = (k for k in getjs if 'title' in k)
				for k in h:
					item = Listitem()
					item.label = k['title']
					item.info['mediatype'] = 'episode'
					item.info['plot'] = k['description']
					linkbm = f'http://lite.baomoi.com{k["url"]}'
					item.art['thumb'] = item.art['poster'] = k['thumb']
					item.set_callback(Resolver.ref('/resources/lib/kedon:play_bm'), linkbm, k['title'])
					yield item
			else:
				yield quangcao()
		except:
			yield quangcao()