from codequick import Route, Script, Listitem
from resources.lib.kedon import quangcao
from resources.lib.mkd.onphim.ophim import get_op
from resources.lib.mkd.onphim.nguonc import get_nc
from resources.lib.mkd.onphim.kkphim import get_kk
from codequick.utils import color
from concurrent.futures import ThreadPoolExecutor
from bs4 import BeautifulSoup
from urllib.parse import quote_plus
import re
@Route.register
def search_freefilm(plugin, search_query=None):
	yield []
	if search_query is None:
		pass
	else:
		try:
			next_page = 1
			sr = quote_plus(search_query)
			with ThreadPoolExecutor(3) as ex:
				f1 = ex.submit(get_op, sr, next_page)
				f2 = ex.submit(get_nc, sr, next_page)
				f3 = ex.submit(get_kk, sr, next_page)
				r1 = f1.result()
				r2 = f2.result()
				r3 = f3.result()
				if Script.setting.get_string('kenh18') == 'true':
					try:
						resp1 = r1.json()['data']['items']
						dmimg1 = r1.json()['data']['APP_DOMAIN_CDN_IMAGE']
						for k1 in resp1:
							i1 = Listitem()
							i1.label = f"{color('OP', 'yellow')} {k1['name']}"
							i1.info['mediatype'] = 'tvshow'
							i1.art['thumb'] = i1.art['poster'] = f"{dmimg1}/uploads/movies/{k1['thumb_url']}"
							i1.set_callback(Route.ref('/resources/lib/mkd/onphim/ophim:id_ophim'), k1['slug'])
							yield i1
					except:
						yield []
					try:
						rtext = r2.json()['view_up'][0][1]
						soup = BeautifulSoup(rtext, 'html.parser')
						s = soup.select('tbody td div.flex')
						for k2 in s:
							hr = k2.select_one('a')['href']
							idp = re.search(r'/phim/(.*)', hr)[1]
							i2 = Listitem()
							i2.label = f"{color('NC', 'yellow')} {k2.select_one('a h3').get_text(strip=True)}"
							i2.info['mediatype'] = 'tvshow'
							i2.art['thumb'] = i2.art['poster'] = k2.select_one('img')['data-src']
							i2.set_callback(Route.ref('/resources/lib/mkd/onphim/nguonc:id_nguonc'), idp)
							yield i2
					except:
						yield []
					try:
						resp3 = r3.json()['data']['items']
						dmimg3 = r3.json()['data']['APP_DOMAIN_CDN_IMAGE']
						for k3 in resp3:
							i3 = Listitem()
							i3.label = f"{color('KK', 'yellow')} {k3['name']}"
							i3.info['mediatype'] = 'tvshow'
							i3.art['thumb'] = i3.art['poster'] = f"{dmimg3}/{k3['poster_url']}"
							i3.set_callback(Route.ref('/resources/lib/mkd/onphim/kkphim:id_kkphim'), k3['slug'])
							yield i3
					except:
						yield []
				else:
					try:
						resp1 = r1.json()['data']['items']
						dmimg1 = r1.json()['data']['APP_DOMAIN_CDN_IMAGE']
						for k1 in resp1:
							if 'phim-18' not in str(k1):
								i1 = Listitem()
								i1.label = f"{color('OP', 'yellow')} {k1['name']}"
								i1.info['mediatype'] = 'tvshow'
								i1.art['thumb'] = i1.art['poster'] = f"{dmimg1}/uploads/movies/{k1['thumb_url']}"
								i1.set_callback(Route.ref('/resources/lib/mkd/onphim/ophim:id_ophim'), k1['slug'])
								yield i1
					except:
						yield []
					try:
						rtext = r2.json()['view_up'][0][1]
						soup = BeautifulSoup(rtext, 'html.parser')
						s = soup.select('tbody td div.flex')
						for k2 in s:
							if '18+' not in str(k2):
								hr = k2.select_one('a')['href']
								idp = re.search(r'/phim/(.*)', hr)[1]
								i2 = Listitem()
								i2.label = f"{color('NC', 'yellow')} {k2.select_one('a h3').get_text(strip=True)}"
								i2.info['mediatype'] = 'tvshow'
								i2.art['thumb'] = i2.art['poster'] = k2.select_one('img')['data-src']
								i2.set_callback(Route.ref('/resources/lib/mkd/onphim/nguonc:id_nguonc'), idp)
								yield i2
					except:
						yield []
					try:
						resp3 = r3.json()['data']['items']
						dmimg3 = r3.json()['data']['APP_DOMAIN_CDN_IMAGE']
						for k3 in resp3:
							if '18+' not in str(k3):
								i3 = Listitem()
								i3.label = f"{color('KK', 'yellow')} {k3['name']}"
								i3.info['mediatype'] = 'tvshow'
								i3.art['thumb'] = i3.art['poster'] = f"{dmimg3}/{k3['poster_url']}"
								i3.set_callback(Route.ref('/resources/lib/mkd/onphim/kkphim:id_kkphim'), k3['slug'])
								yield i3
					except:
						yield []
			i4 = Listitem()
			i4.label = f'Trang {next_page + 1}'
			i4.info['mediatype'] = 'tvshow'
			i4.art['thumb'] = i4.art['poster'] = 'https://mi3s.top/thumb/next.png'
			i4.set_callback(ds_freefilm, sr, next_page + 1)
			yield i4
		except:
			yield quangcao()
@Route.register
def ds_freefilm(plugin, sr=None, next_page=None):
	yield []
	if any((sr is None,next_page is None)):
		pass
	else:
		try:
			with ThreadPoolExecutor(2) as ex:
				f1 = ex.submit(get_op, sr, next_page)
				f2 = ex.submit(get_nc, sr, next_page)
				r1 = f1.result()
				r2 = f2.result()
				if Script.setting.get_string('kenh18') == 'true':
					try:
						resp1 = r1.json()['data']['items']
						dmimg1 = r1.json()['data']['APP_DOMAIN_CDN_IMAGE']
						for k1 in resp1:
							i1 = Listitem()
							i1.label = f"{color('OP', 'yellow')} - {k1['name']}"
							i1.info['mediatype'] = 'tvshow'
							i1.art['thumb'] = i1.art['poster'] = f"{dmimg1}/uploads/movies/{k1['thumb_url']}"
							i1.set_callback(Route.ref('/resources/lib/mkd/onphim/ophim:id_ophim'), k1['slug'])
							yield i1
					except:
						yield []
					try:
						rtext = r2.json()['view_up'][0][1]
						soup = BeautifulSoup(rtext, 'html.parser')
						s = soup.select('tbody td div.flex')
						for k2 in s:
							hr = k2.select_one('a')['href']
							idp = re.search(r'/phim/(.*)', hr)[1]
							i2 = Listitem()
							i2.label = f"{color('NC', 'yellow')} {k2.select_one('a h3').get_text(strip=True)}"
							i2.info['mediatype'] = 'tvshow'
							i2.art['thumb'] = i2.art['poster'] = k2.select_one('img')['data-src']
							i2.set_callback(Route.ref('/resources/lib/mkd/onphim/nguonc:id_nguonc'), idp)
							yield i2
					except:
						yield []
				else:
					try:
						resp1 = r1.json()['data']['items']
						dmimg1 = r1.json()['data']['APP_DOMAIN_CDN_IMAGE']
						for k1 in resp1:
							if 'phim-18' not in str(k1):
								i1 = Listitem()
								i1.label = f"{color('OP', 'yellow')} - {k1['name']}"
								i1.info['mediatype'] = 'tvshow'
								i1.art['thumb'] = i1.art['poster'] = f"{dmimg1}/uploads/movies/{k1['thumb_url']}"
								i1.set_callback(Route.ref('/resources/lib/mkd/onphim/ophim:id_ophim'), k1['slug'])
								yield i1
					except:
						yield []
					try:
						rtext = r2.json()['view_up'][0][1]
						soup = BeautifulSoup(rtext, 'html.parser')
						s = soup.select('tbody td div.flex')
						for k2 in s:
							if '18+' not in str(k2):
								hr = k2.select_one('a')['href']
								idp = re.search(r'/phim/(.*)', hr)[1]
								i2 = Listitem()
								i2.label = f"{color('NC', 'yellow')} {k2.select_one('a h3').get_text(strip=True)}"
								i2.info['mediatype'] = 'tvshow'
								i2.art['thumb'] = i2.art['poster'] = k2.select_one('img')['data-src']
								i2.set_callback(Route.ref('/resources/lib/mkd/onphim/nguonc:id_nguonc'), idp)
								yield i2
					except:
						yield []
			i4 = Listitem()
			i4.label = f'Trang {next_page + 1}'
			i4.info['mediatype'] = 'tvshow'
			i4.art['thumb'] = i4.art['poster'] = 'https://mi3s.top/thumb/next.png'
			i4.set_callback(ds_freefilm, sr, next_page + 1)
			yield i4
		except:
			yield quangcao()
@Route.register
def index_phim(plugin):
	yield Listitem.search(search_freefilm)
	streams = [
		('OPhim', 'https://mi3s.top/thumb/phim/ophim.png', '/resources/lib/mkd/onphim/ophim:index_ophim'),
		('NguonC', 'https://mi3s.top/thumb/phim/nguonc.png', '/resources/lib/mkd/onphim/nguonc:index_nguonc'),
		('KKphim', 'https://mi3s.top/thumb/phim/kkphim.png', '/resources/lib/mkd/onphim/kkphim:index_kkphim'),
		('PhimMoi', 'https://mi3s.top/thumb/phim/phimmoi.png', '/resources/lib/mkd/onphim/phimmoi:index_phimmoi'),
		('Phim1080', 'https://mi3s.top/thumb/phim/phim1080.png', '/resources/lib/mkd/onphim/phim1080:index_1080'),
		('Fmovies', 'https://mi3s.top/thumb/phim/fmovi.png', '/resources/lib/mkd/onphim/fmovies:index_fm'),
		('FilmPlus', 'https://mi3s.top/thumb/phim/onstream.png', '/resources/lib/mkd/onphim/mdb:index_mdb')
	]
	for name_key, banner_key, route_key in streams:
		item = Listitem()
		item.label = name_key
		item.info['mediatype'] = 'tvshow'
		item.art['thumb'] = item.art['poster'] = banner_key
		item.set_callback(Route.ref(route_key))
		yield item
	if Script.setting.get_string('kenh18') == 'true':
		yield Listitem.from_dict(**{'label': 'NguonX',
		'art': {'thumb': 'https://mi3s.top/thumb/phim/nguonx.png',
		'poster': 'https://mi3s.top/thumb/phim/nguonx.png'},
		'info': {'mediatype':'tvshow'},
		'callback': Route.ref('/resources/lib/mkd/onphim/nguonx:index_nguonx')})
		yield Listitem.from_dict(**{'label': 'JAVHD',
		'art': {'thumb': 'https://mi3s.top/thumb/phim/raphd.jpg',
		'poster': 'https://mi3s.top/thumb/phim/raphd.jpg'},
		'info': {'mediatype':'tvshow'},
		'callback': Route.ref('/resources/lib/mkd/onphim/raphd:index_raphd')})