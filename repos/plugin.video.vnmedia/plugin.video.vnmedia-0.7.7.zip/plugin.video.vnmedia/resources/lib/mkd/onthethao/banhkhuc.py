from codequick import Route, Listitem, run
from resources.lib.kedon import quangcao, getlink, stream, referer, play_vnm
import datetime
today = datetime.date.today()

@Route.register
def index_banhkhuc(plugin, **kwargs):
	url1 = 'https://api.vebo.dev/match/live-v2/live'
	resp1 = getlink(url1, url1, 15*60)
	for k in resp1.json()['data']['matches']:
		item = Listitem()
		linktran = k['_id']
		gio = k['show_time']
		ngay = k['show_date']
		doikhach = k['away']['name']
		doinha = k['home']['name']
		item.label = gio + ' ' + ngay + ': ' + doinha + ' - ' + doikhach
		item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://banhkhuc.live/bk/static/img/banhkhuctv.png'
		item.set_callback(list_banhkhuc, linktran, item.label)
		yield item
	tg = str(today).replace('-','')
	url2 = 'https://banhkhuc.live/ajax/match/fixture/' + tg + '/1'
	resp2 = getlink(url2, url2, 15*60)
	for k in resp2.json()['data'][0]:
		for m in k['matches']:
			item2 = Listitem()
			linktran = m['_id']
			tentran = m['name']
			gio = m['show_time']
			ngay = m['show_date']
			item2.label = gio + ' ' + ngay + ': ' + tentran
			item2.art['thumb'] = item2.art['landscape'] = item2.art['fanart'] = 'https://banhkhuc.live/bk/static/img/banhkhuctv.png'
			item2.set_callback(list_banhkhuc, linktran, item2.label)
			yield item2


@Route.register
def list_banhkhuc(plugin, idtran, title, **kwargs):
	url = 'https://banhkhuc.live/ajax/match/detail/' + idtran + '/detail'
	resp = getlink(url, url, 0)
	if 'm3u8' in resp.text:
		for k in resp.json()['play_urls']:
			item = Listitem()
			linktran = stream(k['url'].replace('\t','')) + referer('https://banhkhuc.live/')
			item.label = k['name'] + ' ' + title
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://banhkhuc.live/bk/static/img/banhkhuctv.png'
			item.set_callback(play_vnm, linktran, item.label, '')
			yield item
	else:
		yield quangcao()