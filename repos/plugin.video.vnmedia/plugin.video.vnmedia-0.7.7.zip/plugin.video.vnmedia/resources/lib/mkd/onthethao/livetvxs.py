from codequick import Route, Listitem, run
from datetime import datetime, timedelta, date
from resources.lib.kedon import quangcao, getlink, stream, ace
from bs4 import BeautifulSoup
@Route.register
def index_livetvxs(plugin, **kwargs):
	url = 'http://livetv.sx/export/webmasters.php?lang=en'
	resp = getlink(url, url, 15*60)
	if 'acestream' in resp.text:
		soup = BeautifulSoup(resp.text, 'html.parser')
		episodes = soup.select('tr td')
		for episode in episodes:
			item = Listitem()
			z = episode.select('td.time')
			for w in z:
				timex = w.text.strip()
				if len(timex)==4:
					y = str(date.today())+'T0'+str(timex)
				else:
					y = str(date.today())+'T'+str(timex)
				z = (datetime.fromisoformat(y) + timedelta(hours=6)).strftime('%H:%M')
			a = episode.select('td a.title')
			for b in a:
				tentran = b.text
			anh = episode.select('td img')
			for im in anh:
				img = 'https:' + im.get('src')
			x = episode.select('div a')
			for y in x:
				item.art['thumb'] = item.art['landscape'] = img
				item.art['fanart'] = 'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg'
				acex = y.get('href')
				item.label = z + ' ' + tentran
				linkplay = ace(acex, item.label)
				item.path = linkplay
				item.set_callback(item.path)
				yield item
	else:
		yield quangcao()