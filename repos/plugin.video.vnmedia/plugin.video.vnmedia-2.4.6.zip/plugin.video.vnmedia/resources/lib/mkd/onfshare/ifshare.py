from codequick import Resolver, Route, Listitem, Script
from importlib import import_module
from requests import Session
from bs4 import BeautifulSoup
from xbmcaddon import Addon
from urlquick import get, post
from xbmc import executebuiltin
from pickle import loads, dumps
from time import time
from functools import lru_cache
import re
hdvn = 'https://www.hdvietnam.xyz'
@Route.register
def index_fs(plugin, idfd, next_page, **kwargs):
	w = import_module('resources.lib.kedon')
	fstm = Addon().getSetting('fstm')
	sort_options = {
	'Z-A': '-name',
	'Mới nhất': '-modified',
	'Cũ nhất': 'modified',
	'Nặng nhất': '-size',
	'Nhẹ nhất': 'size',
	}
	sort_option = sort_options.get(fstm, 'name')
	url = f'https://www.fshare.vn/api/v3/files/folder?sort=type,{sort_option}&page={next_page}&per-page=50&linkcode={idfd}'
	kq = w.checkfs(url)
	if kq is not None:
		if ('items' in kq.text) and (len(kq.json()['items']) > 0):
			for k in kq.json()['items']:
				item = Listitem()
				item.label = k['name']
				item.info['plot'] = w.tb
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = w.yttk(item.label)
				item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=https://www.fshare.vn/file/{k["linkcode"]}&qzone=1&margin=1&size=400x400&ecc=L'
				item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
				item.context.script(tfavo, 'Thêm vào Fshare Favorite', f'https://www.fshare.vn/folder/{k["linkcode"]}')
				if k['type'] == 0:
					item.set_callback(index_fs, k['linkcode'], 1)
					yield item
				elif k['type'] == 1:
					item.info['size'] = k['size']
					if Addon().getSetting('taifshare') == 'true':
						item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', f'https://www.fshare.vn/file/{k["linkcode"]}')
					item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), f'https://www.fshare.vn/file/{k["linkcode"]}', item.label)
				yield item
		else:
			executebuiltin(f'Notification({w.__addonnoti__}, Fshare link folder die, 10000, {w.__icon__})')
			yield w.quangcao()
		if ('_links' in kq.json()) and ('last' in kq.json().get('_links')):
			last_page = re.search(r'&page=(\d+)', kq.json().get('_links').get('last'))[1]
			if int(last_page) > next_page:
				item = Listitem()
				item.label = f'Trang {next_page + 1}'
				item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
				item.set_callback(index_fs, idfd, next_page + 1)
				yield item
	else:
		yield w.quangcao()
@Route.register
def index_daxem(plugin, **kwargs):
	w = import_module('resources.lib.kedon')
	if b:= w.get_last_watch_movie():
		for m in b:
			item = Listitem()
			item.label = m
			item.info['plot'] = w.tb
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = w.yttk(item.label)
			item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={b[m]}&qzone=1&margin=1&size=400x400&ecc=L'
			item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
			if Addon().getSetting('taifshare') == 'true':
				item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', b[m])
			item.context.script(tfavo, 'Thêm vào Fshare Favorite', b[m])
			item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), b[m], item.label)
			yield item
		Fshareplaydel = {'label': 'Xoá lịch sử xem',
		'info': {'plot': 'Xoá lịch sử xem'},
		'art': {'thumb': 'https://apkmodo.net/wp-content/uploads/2022/01/WATCHED-APK.jpg',
		'fanart': 'https://apkmodo.net/wp-content/uploads/2022/01/WATCHED-APK.jpg'},
		'callback': w.clear_last_watch_movie}
		yield Listitem.from_dict(**Fshareplaydel)
	else:
		yield []
@Route.register
def top250(plugin, **kwargs):
	w = import_module('resources.lib.kedon')
	response = w.checkfs('https://www.imdb.com/chart/top')
	if response is not None:
		soup = BeautifulSoup(response.text, 'html.parser')
		for movie in soup.select('tbody.lister-list tr'):
			item = Listitem()
			item.art['thumb'] = item.art['fanart'] = re.sub(r'_(.*?)\.', '', movie.select_one('td.posterColumn a img').get('src'))
			item.label = movie.select_one('td.titleColumn').get_text(strip=True)
			try:
				item.info['rating'] = movie.select_one('td.ratingColumn').get_text(strip=True)
				item.info['plot'] = f'Điểm IMDB: {item.info["rating"]}\n{w.tb}'
			except:
				item.info['plot'] = w.tb
			item.set_callback(detailidmb, movie.select_one('a').get('href').split('/')[2], item.art['thumb'])
			yield item
	else:
		yield w.quangcao()
@Route.register
def topaumy(plugin, **kwargs):
	w = import_module('resources.lib.kedon')
	response = w.checkfs('https://www.imdb.com/chart/top-english-movies')
	if response is not None:
		soup = BeautifulSoup(response.text, 'html.parser')
		for movie in soup.select('tbody.lister-list tr'):
			item = Listitem()
			item.art['thumb'] = item.art['fanart'] = re.sub(r'_(.*?)\.', '', movie.select_one('td.posterColumn a img').get('src'))
			item.label = movie.select_one('td.titleColumn').get_text(strip=True)
			try:
				item.info['rating'] = movie.select_one('td.ratingColumn').get_text(strip=True)
				item.info['plot'] = f'Điểm IMDB: {item.info["rating"]}\n{w.tb}'
			except:
				item.info['plot'] = w.tb
			item.set_callback(detailidmb, movie.select_one('a').get('href').split('/')[2], item.art['thumb'])
			yield item
	else:
		yield w.quangcao()
@Route.register
def topmoviemeter(plugin, **kwargs):
	w = import_module('resources.lib.kedon')
	response = w.checkfs('https://www.imdb.com/chart/moviemeter')
	if response is not None:
		sre = re.compile(r'[^,\.\w\s]')
		soup = BeautifulSoup(response.text, 'html.parser')
		for movie in soup.select('tbody.lister-list tr'):
			item = Listitem()
			item.art['thumb'] = item.art['fanart'] = re.sub(r'_(.*?)\.', '', movie.select_one('td.posterColumn a img').get('src'))
			ten = movie.select_one('td.titleColumn a').get_text(strip=True)
			nam = movie.select_one('td.titleColumn span.secondaryInfo').get_text(strip=True)
			item.label = f'{ten} {nam}'
			if velocity:= movie.select_one("div.velocity span.secondaryInfo"):
				xh = velocity.previous_sibling.strip()
				up_down = velocity.select_one("span.global-sprite.titlemeter").get("class")
				if 'up' in up_down:
					change = velocity.select_one("span.global-sprite").next_sibling.strip()
					thuhang = f'Số {xh} - Tăng [COLOR yellow]{sre.sub("", change)}[/COLOR] bậc'
				else:
					change = velocity.select_one("span.global-sprite").next_sibling.strip()
					thuhang = f'Số {xh} - Giảm [COLOR yellow]{sre.sub("", change)}[/COLOR] bậc'
			else:
				thuhang = 'Không thay đổi'
			if diem:= movie.select_one('td.ratingColumn').get_text(strip=True):
				item.info['plot'] = f'{thuhang}\nĐiểm IMDB: [COLOR yellow]{diem}[/COLOR]\n{w.tb}'
			else:
				item.info['plot'] = f'{thuhang}\n{w.tb}'
			item.set_callback(detailidmb, movie.select_one('a').get('href').split('/')[2], item.art['thumb'])
			yield item
	else:
		yield w.quangcao()
@Route.register
def boxoffice(plugin, **kwargs):
	w = import_module('resources.lib.kedon')
	response = w.checkfs('https://www.imdb.com/chart/boxoffice')
	if response is not None:
		soup = BeautifulSoup(response.text, 'html.parser')
		for movie in soup.select('tbody tr'):
			item = Listitem()
			item.art['thumb'] = item.art['fanart'] = re.sub(r'_(.*?)\.', '', movie.select_one('td.posterColumn a img').get('src'))
			item.label = movie.select_one('td.titleColumn a').get_text(strip=True)
			diemtuan = movie.select_one('td.ratingColumn').get_text(strip=True)
			tuan = movie.select_one('span.secondaryInfo').get_text(strip=True)
			phathanh = movie.select_one('td.weeksColumn').get_text(strip=True)
			item.info['plot'] = f'Doanh thu tuần: [COLOR yellow]{diemtuan}[/COLOR]\nTổng thu: [COLOR yellow]{tuan}/{phathanh} tuần[/COLOR]\n{w.tb}'
			item.set_callback(detailidmb, movie.select_one('a').get('href').split('/')[2], item.art['thumb'])
			yield item
	else:
		yield w.quangcao()
@Route.register
def detailidmb(plugin, idk, anh, **kwargs):
	w = import_module('resources.lib.kedon')
	url = f'http://mi3s.top/imdb?vnm={idk}'
	response = w.checkfs(url)
	if response is not None:
		if 'Title' in response.text:
			ten = response.json()['Title']
			noidung = f'[COLOR red]VNM chấm: {response.json()["imdbRating"]}[/COLOR]\n{w.ggdich(response.json()["Plot"])}\n\nDiễn viên: {response.json()["Actors"]}'
		else:
			r1 = w.checkfs(f'https://www.imdb.com/title/{idk}')
			ten = re.search(r'name":"(.*?)"', r1.text)[1]
			noidung = w.tb
		item2 = Listitem()
		item2.label = f'TRAILER: [I]{ten}[/I]'
		item2.info['plot'] = noidung
		item2.art['thumb'] = item2.art['fanart'] = anh
		item2.set_callback(Resolver.ref('/resources/lib/mkd/onyoutube/tim:trailer_youtube'), ten)
		yield item2
		item = Listitem()
		item.label = f'XEM PHIM: [I]{ten}[/I]'
		item.info['plot'] = noidung
		item.art['thumb'] = item.art['fanart'] = anh
		item.set_callback(Route.ref('/resources/lib/mkd/onfshare/timfshare:searchfs'), ten)
		yield item
	else:
		yield w.quangcao()
@Route.register
def fs_favorite(plugin, **kwargs):
	w = import_module('resources.lib.kedon')
	session_id = w.userpassfs()[1]
	headerfsvn = {'User-Agent': w.useragentvmf, 'Cookie' : f'session_id={session_id}'}
	r = get('https://api.fshare.vn/api/fileops/listFavorite', timeout=15, headers=headerfsvn)
	for k in r.json():
		if k['type'] == '0':
			item = Listitem()
			item.label = k['name']
			item.info['plot'] = w.tb
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = w.yttk(item.label)
			item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=https://www.fshare.vn/folder/{k["linkcode"]}&qzone=1&margin=1&size=400x400&ecc=L'
			item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
			item.context.script(xfavo, 'Xoá khỏi Fshare Favorite', f"https://www.fshare.vn/folder/{k['linkcode']}")
			item.set_callback(index_fs, k['linkcode'], 1)
			yield item
		elif k['type'] == '1':
			item = Listitem()
			item.label = k['name']
			item.info['size'] = k['size']
			item.info['plot'] = w.tb
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = w.yttk(item.label)
			item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=https://www.fshare.vn/file/{k["linkcode"]}&qzone=1&margin=1&size=400x400&ecc=L'
			item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
			if Addon().getSetting('taifshare') == 'true':
				item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', f'https://www.fshare.vn/file/{k["linkcode"]}')
			item.context.script(xfavo, 'Xoá khỏi Fshare Favorite', f'https://www.fshare.vn/file/{k["linkcode"]}')
			item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), f'https://www.fshare.vn/file/{k["linkcode"]}', item.label)
			yield item
		else:
			yield []
@Route.register
def fs_topfollow(plugin, **kwargs):
	w = import_module('resources.lib.kedon')
	session_id = w.userpassfs()[1]
	headerfsvn = {'User-Agent': w.useragentvmf, 'Cookie' : f'session_id={session_id}'}
	r = get('https://api.fshare.vn/api/fileops/getTopFollowMovie', timeout=15, max_age=86400, headers=headerfsvn)
	for k in r.json():
		item = Listitem()
		item.label = k['name']
		item.info['plot'] = w.tb
		item.info['mediatype'] = 'episode'
		item.info['rating'] = 10.0
		item.info['trailer'] = w.yttk(item.label)
		item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=https://www.fshare.vn/folder/{k["linkcode"]}&qzone=1&margin=1&size=400x400&ecc=L'
		item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
		item.context.script(tfavo, 'Thêm vào Fshare Favorite', f'https://www.fshare.vn/folder/{k["linkcode"]}')
		item.set_callback(index_fs, k['linkcode'], 1)
		yield item
@Script.register
def tfavo(plugin, x, **kwargs):
	w = import_module('resources.lib.kedon')
	idfd = re.search(r'(file|folder)/([A-Z0-9]+)', x)[2]
	headerfsvn = {'User-Agent': w.useragentvmf, 'Cookie' : f'session_id={w.userpassfs()[1]}'}
	payload = f'{{"items":["{idfd}"],"status":1,"token":"{w.userpassfs()[0]}"}}'
	try:
		r = post('https://api.fshare.vn/api/fileops/ChangeFavorite', timeout=15, data=payload, headers=headerfsvn)
		Script.notify(w.__addonnoti__, 'Đã thêm vào Fshare Favorite') if '200' in r.text else Script.notify(w.__addonnoti__, 'Không thêm được vào Fshare Favorite')
	except:
		Script.notify(w.__addonnoti__, 'Không thêm được vào Fshare Favorite')
@Script.register
def xfavo(plugin, x, **kwargs):
	w = import_module('resources.lib.kedon')
	idfd = re.search(r'(file|folder)/([A-Z0-9]+)', x)[2]
	headerfsvn = {'User-Agent': w.useragentvmf, 'Cookie' : f'session_id={w.userpassfs()[1]}'}
	payload = f'{{"items":["{idfd}"],"status":0,"token":"{w.userpassfs()[0]}"}}'
	r = post('https://api.fshare.vn/api/fileops/ChangeFavorite', timeout=15, data=payload, headers=headerfsvn)
	Script.notify(w.__addonnoti__, 'Đã xoá khỏi Fshare Favorite')
	executebuiltin('Container.Refresh()')
def loginfhdvn():
	w = import_module('resources.lib.kedon')
	if w.has_file_path('hdvietnam.bin') and w.get_last_modified_time_file('hdvietnam.bin') + 3600 < int(time()):
		w.remove_file('hdvietnam.bin')
	if w.has_file_path('hdvietnam.bin'):
		return loads(w.read_file('hdvietnam.bin', True))
	else:
		with Session() as s:
			site = s.get(f'{hdvn}/forums/')
			headers = {'user-agent':w.useragentdf,'origin':hdvn,'referer':f'{hdvn}/'}
			login_data = {'login':'romvemot@gmail.com','register':0,'password':'bimozie','remember':1,'cookie_check':1,'_xfToken':'','redirect':'/forums/'}
			s.post(f'{hdvn}/login/login', data=login_data, headers=headers)
			w.write_file('hdvietnam.bin', dumps(s), True)
			return s
@lru_cache(maxsize=None)
def likehdvn(url):
	s = loginfhdvn()
	soup = BeautifulSoup(s.get(f'{hdvn}/{url}').content, 'html.parser')
	token = soup.select_one('input[name="_xfToken"]').get('value')
	like = f'{hdvn}/{soup.select_one("div.publicControls a.LikeLink.item.control").get("href")}'
	if 'like' in like:
		data_like = {'_xfRequestUri':f'/{url}','_xfToken':token,'_xfNoRedirect':1,'_xfResponseType': 'json'}
		s.post(like, data=data_like)
		return
def logincsn():
	w = import_module('resources.lib.kedon')
	if w.has_file_path('csn.bin') and w.get_last_modified_time_file('csn.bin') + 3600 < int(time()):
		w.remove_file('csn.bin')
	if w.has_file_path('csn.bin'):
		return loads(w.read_file('csn.bin', True))
	else:
		with Session() as s:
			site = s.get('https://chiasenhac.vn').text
			headers = {'user-agent':w.useragentdf,'origin':'https://chiasenhac.vn','referer':'https://chiasenhac.vn/login'}
			token = re.search(r'csrfToken = "(.*)";', site)[1]
			login_data = {'_token':token,'register':0,'email':'vnmedia','password':'Lvwzg9ZNb@2PubD'}
			s.post('https://chiasenhac.vn/login', login_data)
			w.write_file('csn.bin', dumps(s), True)
			return s