from __future__ import unicode_literals
from codequick import Route, Resolver, Listitem, run
from bs4 import BeautifulSoup
from datetime import datetime, timedelta, date
import urllib
import urlquick
import xbmc, xbmcgui, xbmcaddon
import re
import base64
import inputstreamhelper
import json
__addon__ = xbmcaddon.Addon()
__addonname__ = __addon__.getAddonInfo('name')
__version__ = __addon__.getAddonInfo('version')
__icon__ = __addon__.getAddonInfo('icon')
__settings__ = xbmcaddon.Addon(id='plugin.video.vnmedia')
__addonnoti__ = __addonname__ + ' v' + __version__
binhluantv = 'https://xoilac.90phuttttt.xyz'
tiengruoi = 'https://mitom.90phuttttt.xyz'
cakhia = 'https://cakhiaz.live'
vebo = 'https://vebotv.top'
useragent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.84 Safari/537.36'
code = 'User-Agent=' + useragent
qc ='http://livecdn.fptplay.net/hda4/f-channel.stream/playlist.m3u8'
logotv = 'https://i.imgur.com/Mnuw95h.png'
news = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/qc.ass'
tb = 'Nội dung được tổng hợp từ Internet, VNM không kiểm soát cũng như không chịu trách nhiệm về nội dung trên các kênh truyền hình. Khán giả đồng ý và cân nhắc nội dung khi xem'
CATEGORIES = {
'Truyền hình FPT': 'https://yamcode.com/raw/iptv-fptudp',
'Truyền hình FPT2': 'https://pastebin.com/raw/y8E0J0FZ',
'Truyền hình VNPT': 'https://yamcode.com/raw/iptv-mytvrtp',
'Vthanh': 'http://gg.gg/vthanhtivii',
'PhapSonyTx5': 'http://gg.gg/phaptx5iptv',
'TLNQ': 'https://raw.githubusercontent.com/TLNQChannel/iptvbytlnqchannel/main/tlnqchanneltv.m3u',
'VietNgaTV': 'https://raw.githubusercontent.com/phuhdtv/vietngatv/master/vietngatv.m3u',
'Mytvbox1': 'http://gg.gg/mytvbox1'
}
CATEGORI = {
'Coocaa': 'https://manhkendo.cf/televi.php?list=aHR0cDovL2dnLmdnL2Nvb2NhYQ==',
'Beartv': 'https://manhkendo.cf/televi.php?list=aHR0cDovL2dnLmdnL2JlYXJsaXZldHY='}
CATEace = {
'Acestream Khampha1': 'https://textuploader.com/dl6ui/raw',
'Acestream Khampha2': 'https://pastebin.com/raw/MDyHF0F6',
'Acestream CVACE': 'http://gg.gg/cvace'}
CATEGORIESsport = {
'VN360Sport': 'http://gg.gg/vn360sport',
'IPTV90p': 'http://gg.gg/90phuttv'}
kenhyttt = {
'VTV24': 'https://www.youtube.com/c/vtv24',
'VTCnews': 'https://www.youtube.com/c/vtcnow',
'60 giây': 'https://www.youtube.com/channel/UCRjzfa1E0gA50lvDQipbDMg',
'Thời tiết-Môi trường': 'https://www.youtube.com/user/KenhTruyenHinhVTC14',
'Văn hoá-Du lịch': 'https://www.youtube.com/channel/UCZ7cd8K5jo7fHUksCgMfpeg',
'Kinh tế-Tài chính': 'https://www.youtube.com/user/FBNCVietnam',
'An ninh': 'https://www.youtube.com/c/KenhAnNinh',
'Thông tấn xã': 'https://www.youtube.com/c/VNEWSTRUY%E1%BB%80NH%C3%8CNHTH%C3%94NGT%E1%BA%A4N',
'Quốc hội': 'https://www.youtube.com/channel/UCTJ-FDgxR3NxurDQxNiWWVQ',
'Nhân dân': 'https://www.youtube.com/channel/UCPJfjHrW3-zIeSaZTgmckmg',
'Nông nghiệp-nông thôn': 'https://www.youtube.com/c/K%C3%8ANHVTC16',
'Thế giới đó đây': 'https://www.youtube.com/channel/UCHPzpxcYhxkb0fMJKeSe66g',
'VTC tin mới': 'https://www.youtube.com/user/vtctv',
'Hà Nội tin tức': 'https://www.youtube.com/channel/UC7_mgS3z22z0WhR7COJ8E2w',
'HTV tin tức': 'https://www.youtube.com/c/HTVTinT%E1%BB%A9c',
'THVL tổng hợp': 'https://www.youtube.com/c/THVLTongHop'}
kenhytsp = {
'VFF': 'https://www.youtube.com/channel/UCndcERoL9eG-XNljgUk1Gag',
'VPF': 'https://www.youtube.com/user/Vpfmedia',
'FPT bóng đá': 'https://www.youtube.com/c/FPTFoxy',
'Next Sports': 'https://www.youtube.com/user/todaytvchannel',
'K+ Sports': 'https://www.youtube.com/channel/UC9xeuekJd88ku9LDcmGdUOA',
'On Sports': 'https://www.youtube.com/channel/UCIWo7q6irZUBaoPOrlf5IVw',
'On Sports Plus': 'https://www.youtube.com/channel/UCOEucCL9r4YfNZ9Es6G-g9Q',
'FPT bóng đá Việt': 'https://www.youtube.com/c/FPTB%C3%B3ng%C4%90%C3%A1Vi%E1%BB%87t',
'Quán thể thao': 'https://www.youtube.com/channel/UCEwAazC_ewgN5PPnR9vxFKA',
'Việt Nam Sport': 'https://www.youtube.com/channel/UC4FXEYiVVUdibNnqAnzdscw',
'BLV Quang Huy': 'https://www.youtube.com/c/blvquanghuy',
'BLV Anh Quân': 'https://www.youtube.com/channel/UCQqSJr6WYH0Bq7mrlFhzWDw',
'BLV Tạ Biên Cương': 'https://www.youtube.com/channel/UCbPF5L84DIv7zGg9mCqfGtw',
'Tuyền văn hoá': 'https://www.youtube.com/channel/UCCgCw-IJYpse4qnOCvvcitA',
'Cảm bóng đá': 'https://www.youtube.com/channel/UCtowbSVJlDLjgs-5qsznSTA',
'Nhà báo Minh Hải': 'https://www.youtube.com/user/donkeynhim',
'Anh Quân tin mới': 'https://www.youtube.com/user/viendongquan',
'Anh Quân bóng đá Việt': 'https://www.youtube.com/channel/UCCBwmJaVIB220c5sWdE28XQ'
}

def vieon(url):
	resp = urlquick.get(url, timeout=30, max_age=0, headers=head_macdinh(useragent, url))
	resp.encoding = 'utf-8'
	kq = resp.text
	listplay = re.findall(r'hlsLinkPlay":"(.*?)"', kq)
	return listplay[-1]

def convert_bytes(size):
	for x in ['bytes', 'KB', 'MB', 'GB', 'TB']:
		if size < 1024.0:
			return "%3.1f %s" % (size, x)
		size /= 1024.0
	return size

def ace(kenh, tenkenh):
	if 'acestream' in kenh:
		tach = kenh.split('//')
		p = tach[1]
	elif ':6878' in kenh:
		if '&' in kenh:
			match = re.search(r'id=(.*?)&', kenh)
			p = match.group(1)
		else:
			tach = kenh.split('id=')
			p = tach[1]
	kenhace = ''.join(("{'label': '", tenkenh.strip(),"', 'action': 'play', 'fanart': '', 'icon': '', 'id': '", p.strip(), "'}"))
	mahoa = base64.b64encode(kenhace.encode('utf-8')).decode('utf-8')
	mahoaa = urllib.parse.quote(mahoa)
	eca = 'plugin://script.module.horus/?' + mahoaa
	return eca

def head_macdinh(useragent, url):
	headers = {'user-agent': useragent,
	'referer': url}
	return headers

def stream(url):
	b = 'User-Agent=' + useragent
	if '|' in url:
		a = url + '&' + b
	elif '?' in url:
		a = url + '|' + b
	elif 'm3u8' in url:
		a = url + '?|' + b
	else:
		a = url
	return a

def referer(url):
	x = '&Origin=' + url + '&verifypeer=false&Referer=' + url
	return x

def replace_all(dict, str):
	for key in dict:
		str = str.replace(key, dict[key])
	return str

def get_user_input():
	kb = xbmc.Keyboard('', 'NumberCode được chia sẻ bởi facebook Hội mê Phim')
	kb.doModal() # Onscreen keyboard appears
	if not kb.isConfirmed():
		return
	query = kb.getText() # User input
	return query

def get_kara_input():
	kb = xbmc.Keyboard('', 'Nhập tên bài hát (không dấu)')
	kb.doModal() # Onscreen keyboard appears
	if not kb.isConfirmed():
		return
	query = kb.getText() # User input
	return query

def checkver():
	url = 'https://raw.githubusercontent.com/nguyenducmanh609/kodivn/master/addons.xml'
	resp = urlquick.get(url, timeout=30, max_age=0, headers=head_macdinh(useragent, url))
	check = re.search(r'plugin.video.vnmedia" version="(.*?)"', resp.text)
	ver = check.group(1)
	if __version__ == ver:
		return 
	else:
		return xbmcgui.Dialog().ok(__addonnoti__, 'Đã có phiên bản VNM v' + ver + '\nVui lòng cập nhật tiện ích để tránh phát sinh lỗi')

def get_info_fs(url):
	resp = urlquick.get(url, timeout=20, max_age=60*60, headers=head_macdinh(useragent, url))
	soup = BeautifulSoup(resp.text, 'html.parser')
	if '#404' in soup.title.string:
		return 'Tập tin này bị hỏng - 404'
	else:
		return soup.title.string + ' (' + re.search(r'NHANH \| (.*?)<', resp.text).group(1) + ')'

def userpassfs():
	username = __settings__.getSetting('username')
	password = __settings__.getSetting('password')
	if len(username) == 0 or len(password) == 0:
		__addon__.openSettings()
	else:
		payload = '{"app_key":"L2S7R6ZMagggC5wWkQhX2+aDi467PPuftWUMRFSn","user_email":"'+username+'","password":"'+password+'"}'
		head = {'cache-control': 'no-cache', 'User-Agent': 'Vietmediaf /Kodi1.1.99-092019'}
		try:
			resp = urlquick.post('https://api.fshare.vn/api/user/login', data=payload, headers=head, timeout=20, max_age=6*60*60)
			resp.raise_for_status()
			xbmcgui.Dialog().ok(__addonnoti__, 'Chào mừng [COLOR red]'+username+'[/COLOR]\nĐăng nhập thành công phiên làm việc mới')
			token = resp.json()['token']
			session_id = resp.json()['session_id']
			__settings__.setSetting(id='tokenfshare',value=token)
			__settings__.setSetting(id='sessionfshare',value=session_id)
			return (token,session_id)
		except:
			xbmcgui.Dialog().ok(__addonnoti__, 'Sau 3 lần đăng nhập không thành công, tài khoản sẽ bị khoá 10 phút\nKiểm tra lại tài khoản, mật khẩu, đường truyền Internet...')
			__addon__.openSettings()

@Route.register
def root(plugin, content_type='segment'):
	checkver()
	Truyenhinh = {'label': 'Truyền hình',
	'info':{'plot':tb},
	'art':{'thumb':logotv,
	'fanart':'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'},
	'callback':listiptv_root}
	Thethao = {'label': 'Thể thao',
	'info':{'plot':tb},
	'art':{'thumb':'https://i.imgur.com/x0V60BO.png',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_thethao}
	Tintuc = {'label': 'Tin tức',
	'info':{'plot':tb},
	'art':{'thumb':'https://i.imgur.com/IJJJb8W.png',
	'fanart':'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'},
	'callback':index_tintuc}
	Fshare = {'label': 'Fshare',
	'info':{'plot':tb},
	'art':{'thumb':'https://i.imgur.com/XB3HOOe.png',
	'fanart':'https://fsharetv.com/img/fsharetv.png'},
	'callback':index_fshare}
	Youtube = {'label': 'Youtube',
	'info':{'plot':tb},
	'art':{'thumb':'https://i.imgur.com/0oHqiU3.png',
	'fanart':'https://www.youtube.com/img/desktop/yt_1200.png'},
	'callback':index_youtube}
	yield Listitem.from_dict(**Fshare)
	yield Listitem.from_dict(**Youtube)
	yield Listitem.from_dict(**Truyenhinh)
	yield Listitem.from_dict(**Thethao)
	yield Listitem.from_dict(**Tintuc)

@Route.register
def index_thethao(plugin, content_type='segment'):
	wtinthethao = {'label': r'Tin thể thao',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://thethao360.tv/wp-content/uploads/2020/12/logo-3.png',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_tinthethao}
	wnhomacs = {'label': 'Nhóm ACESTREAM',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg',
	'fanart':'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg'},
	'callback':index_acestream}
	yield Listitem.from_dict(**wtinthethao)
	yield Listitem.from_dict(**wnhomacs)
	for tenlist, urllist in list(CATEGORIESsport.items()):
		item = Listitem()
		item.label = tenlist
		item.art['thumb'] = 'https://i.imgur.com/x0V60BO.png'
		item.art['fanart'] = 'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'
		item.set_callback(list_iptv_sport, url=urllist)
		yield item
	w90phut = {'label': '90PHUT.TV',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://i.imgur.com/jyM3inb.png',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_90p}
	wcakhia = {'label': 'CAKHIA TV',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://static.fastlycdnlive.xyz/cakhia13/user/img/ckstrim.png',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_cakhia}
	wrakhoi = {'label': 'RAKHOI TV',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://static.fastlycdnlive.xyz/rakhoi7/user/img/rakhoi.png',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_rakhoi}
	wxoilac = {'label': 'XOILAC2.COM',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://xoilac2.com/wp-content/themes/bongda/dist/images/xoilac2.com.png',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_xoilac}
	wsaoke = {'label': 'SAOKE.LIVE',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://9767a59e2b.vws.vegacdn.vn/template/logo1.png',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_saoke}
	wbongdahomnay = {'label': 'BONGDAHOMNAY',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://i.imgur.com/TlXaeKj.png',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_bongdahomnay}
	wbinhluantv = {'label': 'BINHLUANTV',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://xoilac.90phuttttt.xyz/imgs/logo.png',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_binhluan}
	wfptsukien = {'label': r'(Thử nghiệm) FPT Play',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://fptbox.com.vn/wp-content/uploads/2019/02/fpt-play-3.jpg',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_fptsukien}
	wvieonsukien = {'label': r'(Thử nghiệm) Vieon',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://static.vieon.vn/vieon-web-v4/assets/img/default-vieon-1200x1200.jpg',
	'fanart':'https://thegioidohoa.com/wp-content/uploads/2017/07/thiet-ke-logo-the-thao.png'},
	'callback':index_vieonsukien}
	yield Listitem.from_dict(**wfptsukien)
	yield Listitem.from_dict(**wvieonsukien)
	yield Listitem.from_dict(**w90phut)
	yield Listitem.from_dict(**wbongdahomnay)
	yield Listitem.from_dict(**wbinhluantv)
	yield Listitem.from_dict(**wcakhia)
	yield Listitem.from_dict(**wrakhoi)
	yield Listitem.from_dict(**wxoilac)
	yield Listitem.from_dict(**wsaoke)

@Route.register
def index_tinthethao(plugin, content_type='segment'):
	for tenlist, urllist in list(kenhytsp.items()):
		item = Listitem()
		item.label = tenlist
		item.art['thumb'] = 'https://thethao360.tv/wp-content/uploads/2020/12/logo-3.png'
		item.art['fanart'] = 'https://thethao360.tv/wp-content/uploads/2020/12/logo-3.png'
		item.set_callback(youtube_kenh, url=urllist)
		yield item

@Route.register
def index_tintuc(plugin,content_type='segment'):
	item1 = Listitem()
	page = 0
	item1.label = 'Tin mới'
	item1.info['plot'] = tb
	item1.art['thumb'] =  'https://cdn.baogiaothong.vn/upload/images/2019-4/profile_avatar_img/2019-11-18/tin-tuc-trong-ngay-hom-nay-1574061980-width1004height565.png'
	item1.art['fanart'] = 'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item1.set_callback(index_mocha, page)
	yield item1
	for tenlist, urllist in list(kenhyttt.items()):
		item = Listitem()
		item.label = tenlist
		item.art['thumb'] = 'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
		item.art['fanart'] = 'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
		item.set_callback(youtube_kenh, url=urllist)
		yield item

@Route.register
def listiptv_root(plugin, **kwargs):
	for tenlist, urllist in list(CATEGORIES.items()):
		item = Listitem()
		item.label = tenlist
		item.art['thumb'] = logotv
		item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
		item.set_callback(list_iptv, url=urllist)
		yield item
	for tenlistmk, urllistmk in list(CATEGORI.items()):
		item1 = Listitem()
		item1.label = tenlistmk
		item1.art['thumb'] = logotv
		item1.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
		item1.set_callback(list_manhkendo, url=urllistmk)
		yield item1

@Route.register
def index_acestream(plugin, content_type='segment'):
	for tenlist, urllist in list(CATEace.items()):
		item = Listitem()
		item.label = tenlist
		item.art['thumb'] = 'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg'
		item.art['fanart'] = 'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg'
		item.set_callback(list_iptv_sport, url=urllist)
		yield item
	wlivetvxs = {'label': 'Livetv.sx',
	'info':{'plot':tb}, 
	'art':{'thumb':'http://cdn.livetv495.me/img/logo_ru.jpg',
	'fanart':'http://cdn.livetv495.me/img/logo_ru.jpg'},
	'callback':index_livetvxs}
	wthunder = {'label': 'Streamthunder.org',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://raw.githubusercontent.com/dw4ss/streamthunder-demo-website/master/images/stream-hd.png',
	'fanart':'https://raw.githubusercontent.com/dw4ss/streamthunder-demo-website/master/images/stream-hd.png'},
	'callback':index_streamthunder}
	w365 = {'label': 'Highlights365.com',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://highlights365.com/static/images/highlights365/logo_header.png',
	'fanart':'https://highlights365.com/static/images/highlights365/logo_header.png'},
	'callback':index_highlights365}
	yield Listitem.from_dict(**wlivetvxs)
	yield Listitem.from_dict(**wthunder)
	yield Listitem.from_dict(**w365)

@Route.register
def index_livetvxs(plugin, content_type='segment'):
	url = 'http://livetv.sx/export/webmasters.php?lang=en'
	resp = urlquick.get(url, timeout=30, max_age=15*60, headers=head_macdinh(useragent, url))
	if 'acestream' in resp.text:
		soup = BeautifulSoup(resp.text, 'html.parser')
		episodes = soup.select('tr td')
		for episode in episodes:
			item = Listitem()
			z = episode.select('td[class="time"]')
			for w in z:
				timex = w.text.strip()
				if len(timex)==4:
					y = str(date.today())+'T0'+str(timex)
				else:
					y = str(date.today())+'T'+str(timex)
				z = (datetime.fromisoformat(y) + timedelta(hours=6)).strftime('%H:%M')
			a = episode.select('td a.title')
			for b in a:
				tentran = b.text
			x = episode.select('div a')
			for y in x:
				item.art['thumb'] = 'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg'
				item.art['fanart'] = 'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg'
				acex = y.get('href')
				item.label = z + ' ' + tentran
				linkplay = ace(acex, item.label)
				item.path = linkplay
				item.set_callback(item.path)
				yield item
	else:
		item3 = Listitem()
		linkmacdinh = stream(qc)
		item3.label = 'Đang cập nhật'
		item3.info['plot'] = tb
		item3.art['thumb'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.art['fanart'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.set_callback(play_vnm, linkmacdinh, item3.label, '')
		yield item3

@Route.register
def index_streamthunder(plugin, content_type='segment'):
	url = 'https://widget.streamthunder.org/list.php?id=21&sport=&sp=&r=&l=&l2='
	resp = urlquick.get(url, timeout=30, max_age=15*60, headers=head_macdinh(useragent, url))
	if 'acestream' in resp.text:
		nd = re.search(r'var chan_arr = (.*?);\n', resp.text).group(1)
		m = json.loads(nd)
		for v in m:
			item = Listitem()
			match = re.search('{"id":"' + v + '(.*?)"date":"(.*?)","match":"(.*?)"', resp.text)
			tentran = match.group(3)
			tg = match.group(2)
			z = (datetime.fromisoformat(tg) + timedelta(hours=6)).strftime('%H:%M')
			for r in m[v]:
				if 'acestream' in r['link']:
					item.art['thumb'] = 'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg'
					item.art['fanart'] = 'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg'
					item.label = z + ' ' + tentran
					linkplay = ace(r['link'], item.label)
					item.path = linkplay
					item.set_callback(item.path)
					yield item
	else:
		item3 = Listitem()
		linkmacdinh = stream(qc)
		item3.label = 'Đang cập nhật'
		item3.info['plot'] = tb
		item3.art['thumb'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.art['fanart'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.set_callback(play_vnm, linkmacdinh, item3.label, '')
		yield item3

@Route.register
def index_highlights365(plugin, content_type='segment'):
	url = 'https://highlights365.com/broadcasts'
	resp = urlquick.get(url, timeout=30, max_age=15*60, headers=head_macdinh(useragent, url))
	soup = BeautifulSoup(resp.text, 'html.parser')
	episodes = soup.select('div[class="broadcast-item"]')
	for episode in episodes:
		item = Listitem()
		linktrans = episode.select('div[class="team-info"] a')
		for linktran in linktrans:
			link = linktran.get('href')
			ten = linktran.text
		times = episode.select('div[class="time"]')
		for time in times:
			timex = time.text
			if len(timex)==4:
				y = str(date.today())+'T0'+str(timex)
			else:
				y = str(date.today())+'T'+str(timex)
			z = (datetime.fromisoformat(y) + timedelta(hours=7)).strftime('%H:%M')
			item.label = z + ' ' + ten
			item.art["thumb"] = 'https://highlights365.com/static/images/highlights365/logo_header.png'
			item.art["fanart"] = 'https://highlights365.com/static/images/highlights365/logo_header.png'
			item.set_callback(laylink_highlights365, 'https://highlights365.com' +link, item.label)
			yield item

@Route.register
def laylink_highlights365(plugin, url, ten):
	resp = urlquick.get(url, timeout=30, max_age=15*60, headers=head_macdinh(useragent, url))
	if 'acestream://' in resp.text:
		soup = BeautifulSoup(resp.text, 'html.parser')
		links = soup.select('div[class="link-list acestream"] a')
		for link in links:
			item = Listitem()
			linktran = link.get('href')
			item.art['thumb'] = 'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg'
			item.art['fanart'] = 'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg'
			item.label = ten
			linkplay = ace(linktran, item.label)
			item.path = linkplay
			item.set_callback(item.path)
			yield item
	else:
		item3 = Listitem()
		linkmacdinh = stream(qc)
		item3.label = 'Đang cập nhật'
		item3.info['plot'] = tb
		item3.art['thumb'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.art['fanart'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.set_callback(play_vnm, linkmacdinh, item3.label, '')
		yield item3

@Route.register
def list_manhkendo(plugin, url, **kwargs):
	resp = urlquick.get(url, timeout=20, max_age=60*60, headers=head_macdinh(useragent, url))
	tach = resp.text.split('\n')
	for k in tach:
		item = Listitem()
		tachhat = k.split('|')
		if tachhat[0]:
			kenh = tachhat[1]
			item.label =tachhat[0].replace('*','')
			item.art['thumb'] = tachhat[3]
			item.art['fanart'] = tachhat[3]
			if 'acestream' in kenh:
				linkplay = ace(kenh, item.label)
				item.path = linkplay
				item.set_callback(item.path)
			elif ':6878' in kenh:
				linkplay = ace(kenh, item.label)
				item.path = linkplay
				item.set_callback(item.path)
			else:
				linkplay = stream(kenh.strip())
				item.set_callback(play_vnm, linkplay, item.label, '')
			item.info['plot'] = tb
			yield item

@Route.register
def list_iptv(plugin, url, **kwargs):
	resp = urlquick.get(url, timeout=20, max_age=2*60*60, headers=head_macdinh(useragent, url))
	resp.encoding = 'utf-8'
	kq = '\n'.join([ll.rstrip() for ll in resp.text.splitlines() if ll.strip()])
	kq = re.sub(r'#h(.*?)\n', '', kq)
	kq = re.sub(r'#EXTV(.*?)\n', '', kq)
	ketqua = kq.split('#EXTI')
	for tach in ketqua:
		item = Listitem()
		listplay = re.findall(r'NF(.*),(.*)\n(.*)', tach)
		for k in listplay:
			if k[2]:
				logo = re.search(r'tvg-logo="(.*?)"', k[0])
				if logo:
					item.art['thumb'] = logo.group(1)
					item.art['fanart'] = logo.group(1)
				else:
					item.art['thumb'] = logotv
					item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
				item.label = k[1].strip()
				kenh = k[2]
				if 'acestream' in kenh:
					linkplay = ace(kenh, item.label)
					item.path = linkplay
					item.set_callback(item.path)
				elif ':6878' in kenh:
					linkplay = ace(kenh, item.label)
					item.path = linkplay
					item.set_callback(item.path)
				else:
					linkplay = stream(kenh.strip())
					item.set_callback(play_vnm, linkplay, item.label, '')
				item.info['plot'] = tb
				yield item

@Route.register
def list_iptv_sport(plugin, url, **kwargs):
	resp = urlquick.get(url, timeout=30, max_age=15*60, headers=head_macdinh(useragent, url))
	resp.encoding = 'utf-8'
	kq = '\n'.join([ll.rstrip() for ll in resp.text.splitlines() if ll.strip()])
	kq = re.sub(r'#h(.*?)\n', '', kq)
	kq = re.sub(r'#EXTV(.*?)\n', '', kq)
	ketqua = kq.split('#EXTI')
	for tach in ketqua:
		item = Listitem()
		listplay = re.findall(r'NF(.*),(.*)\n(.*)', tach)
		for k in listplay:
			if k[2]:
				logo = re.search(r'tvg-logo="(.*?)"', k[0])
				if logo:
					item.art['thumb'] = logo.group(1)
					item.art['fanart'] = logo.group(1)
				else:
					item.art['thumb'] = logotv
					item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
				item.label = k[1].strip()
				kenh = k[2]
				if 'acestream' in kenh:
					linkplay = ace(kenh, item.label)
					item.path = linkplay
					item.set_callback(item.path)
				elif ':6878' in kenh:
					linkplay = ace(kenh, item.label)
					item.path = linkplay
					item.set_callback(item.path)
				else:
					linkplay = stream(kenh.strip())
					item.set_callback(play_vnm, linkplay, item.label, '')
				item.info['plot'] = tb
				yield item

@Route.register
def index_youtube(plugin, content_type='segment'):
	Trendingyt = {'label': 'TOP THỊNH HÀNH',
	'info':{'plot':'Top video nhiều lượt tương tác (xem, thích, bình luận…) trên Youtube'},
	'art':{'thumb':'https://cdn.tgdd.vn//GameApp/1311257//cach-xem-top-thinh-hanh-tren-youtube-cac-nuoc-bang-dien-thoai-thumb-800x450.jpg',
	'fanart':'https://cdn.tgdd.vn//GameApp/1311257//cach-xem-top-thinh-hanh-tren-youtube-cac-nuoc-bang-dien-thoai-thumb-800x450.jpg'},
	'callback':youtube_thinhhanh}
	item3 = Listitem()
	item3.label = 'Tìm karaoke'
	item3.info['plot'] = 'Tiện ích tìm kiếm karaoke'
	item3.path = search_karaoke
	item3.art['thumb'] = 'https://png.pngtree.com/png-vector/20190223/ourlarge/pngtree-karaoke-logo-vector-illustration-png-image_691264.jpg'
	item3.art['fanart'] = 'https://image.freepik.com/free-vector/karaoke-logo_114055-38.jpg'
	item3.set_callback(search_karaoke, item3.path)
	yield Listitem.search(search_youtube)
	yield item3
	yield Listitem.from_dict(**Trendingyt)
	url = 'https://www.youtube.com/?hl=vi'
	resp = urlquick.get(url, timeout=30, max_age=60*60, headers=head_macdinh(useragent, url))
	resp.encoding = 'utf-8'
	kq = resp.text.replace('\\','')
	listplay = re.findall(r'videoRenderer(.*?)accessibility', kq)
	for k in listplay:
		item = Listitem()
		tenvd = re.search(r'text":"(.*?)"}', k).group(1)
		idvd = re.search(r'videoId":"(.*?)"', k).group(1)
		anhvd = re.search(r'url":"(.*?)"', k).group(1)
		item.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=' + idvd
		item.label = tenvd
		item.art["thumb"] = anhvd
		item.art["fanart"] = anhvd
		item.set_callback(item.path)
		yield item

@Route.register
def index_fshare(plugin, content_type='segment'):
	userpassfs()
	Fsharefavorite = {'label': 'Fshare Favorite',
	'info':{'plot':'Yêu thích'},
	'art':{'thumb':'https://banner2.cleanpng.com/20180319/ikq/kisspng-heart-love-brand-logo-favourites-5ab0468bbe3665.1130427115215018357791.jpg',
	'fanart':'https://fsharetv.com/img/fsharetv.png'},
	'callback':fs_favorite}
	Fsharefollow = {'label': 'TOP FSHARE',
	'info':{'plot':'Top 15 thư mục theo dõi nhiều nhất'},
	'art':{'thumb':'https://www.fshare.vn/images/top-follow/title.png',
	'fanart':'https://fsharetv.com/img/fsharetv.png'},
	'callback':fs_topfollow}
	Thuvienhdp = {'label': 'Thư viện HD',
	'info':{'plot':'Thư viện dữ liệu phim Fshare'},
	'art':{'thumb':'https://thuvienhd.com/wp-content/uploads/2020/10/THUVIENHD.NET_.png',
	'fanart':'https://fsharetv.com/img/fsharetv.png'},
	'callback':index_thuvienhd}
	item1 = Listitem()
	item1.label = 'Play NumberCode'
	item1.info['plot'] = 'Mã CODE được tạo từ trang rút gọn http://gg.gg'
	item1.path = searchnumber
	item1.art['thumb'] = 'https://reference.vn/wp-content/uploads/2019/04/lic-su-so-tu-nhien.jpg'
	item1.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
	item1.set_callback(searchnumber, item1.path)
	yield Listitem.search(searchfs)
	yield item1
	yield Listitem.from_dict(**Fsharefavorite)
	yield Listitem.from_dict(**Fsharefollow)
	yield Listitem.from_dict(**Thuvienhdp)

@Route.register
def search_karaoke(plugin,search_query):
	search_query = get_kara_input() # User input via onscreen keyboard
	if not search_query:
		return [] # Return empty list if query is blank
	url = 'https://www.youtube.com/results?search_query=karaoke+' + search_query.replace(' ','+')
	resp = urlquick.get(url, timeout=30, max_age=24*60*60, headers=head_macdinh(useragent, url))
	resp.encoding = 'utf-8'
	kq = resp.text.replace('\\','')
	listplay = re.findall(r'videoRenderer(.*?)accessibility', kq)
	for k in listplay:
		item = Listitem()
		tenvd = re.search(r'text":"(.*?)"}', k).group(1)
		idvd = re.search(r'videoId":"(.*?)"', k).group(1)
		anhvd = re.search(r'url":"(.*?)"', k).group(1)
		item.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=' + idvd
		item.label = tenvd
		item.art["thumb"] = anhvd
		item.art["fanart"] = anhvd
		item.set_callback(item.path)
		yield item

@Route.register
def search_youtube(plugin,search_query):
	url = 'https://www.youtube.com/results?search_query=' + search_query.replace(' ','+')
	resp = urlquick.get(url, timeout=30, max_age=15*60, headers=head_macdinh(useragent, url))
	resp.encoding = 'utf-8'
	kq = resp.text.replace('\\','')
	if 'videoRenderer' in kq:
		listplay = re.findall(r'videoRenderer(.*?)accessibility', kq)
		for k in listplay:
			item = Listitem()
			tenvd = re.search(r'text":"(.*?)"}', k).group(1)
			idvd = re.search(r'videoId":"(.*?)"', k).group(1)
			anhvd = re.search(r'url":"(.*?)"', k).group(1)
			item.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=' + idvd
			item.label = tenvd
			item.art["thumb"] = anhvd
			item.art["fanart"] = anhvd
			item.set_callback(item.path)
			yield item
	elif 'playlistRenderer' in kq:
		listplay1 = re.findall(r'playlistRenderer(.*?)webPageType', kq)
		for k1 in listplay1:
			item1 = Listitem()
			tenvd1 = re.search(r'"simpleText":"(.*?)"}', k1).group(1)
			idvd1 = re.search(r'webCommandMetadata":{"url":"(.*?)"', k1).group(1)
			anhvd1 = re.search(r'url":"(.*?)"', k1).group(1)
			item1.label = tenvd
			item1.art["thumb"] = anhvd1
			item2.art["fanart"] = anhvd1
			item1.set_callback(youtube_tatcavideo, url+idvd1)
			yield item1
	elif 'channelRenderer' in kq:
		listplay2 = re.findall(r'channelRenderer(.*?)webPageType', kq)
		for k2 in listplay2:
			item2 = Listitem()
			tenvd2 = re.search(r'"simpleText":"(.*?)"}', k2).group(1)
			idvd2 = re.search(r'"url":"(.*?)"', k2).group(1)
			anhvd2 = re.search(r'thumbnails":\[{"url":"(.*?)"', k2).group(1)
			item2.label = tenvd2
			item2.art["thumb"] = 'https:' + anhvd2
			item2.art["fanart"] = 'https:' + anhvd2
			item2.set_callback(youtube_kenh, url+idvd2)
			yield item2

@Route.register
def youtube_thinhhanh(plugin, content_type='segment'):
	url = 'https://www.youtube.com/feed/trending'
	resp = urlquick.get(url, timeout=30, max_age=24*60*60, headers=head_macdinh(useragent, url))
	resp.encoding = 'utf-8'
	kq = resp.text.replace('\\','')
	listplay = re.findall(r'videoRenderer(.*?)accessibility', kq)
	for k in listplay:
		item = Listitem()
		tenvd = re.search(r'text":"(.*?)"}', k).group(1)
		idvd = re.search(r'videoId":"(.*?)"', k).group(1)
		anhvd = re.search(r'url":"(.*?)"', k).group(1)
		item.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=' + idvd
		item.label = tenvd
		item.art["thumb"] = anhvd
		item.art["fanart"] = anhvd
		item.set_callback(item.path)
		yield item

@Route.register
def youtube_kenh(plugin, url):
	item2 = Listitem()
	item2.label = 'Danh sách phát'
	item2.art['thumb'] = 'https://www.youtube.com/img/desktop/yt_1200.png'
	item2.art['fanart'] = 'https://www.youtube.com/img/desktop/yt_1200.png'
	item2.set_callback(youtube_dslist, url+'/playlists')
	item1 = Listitem()
	item1.label = 'Tất cả Video'
	item1.art['thumb'] = 'https://www.youtube.com/img/desktop/yt_1200.png'
	item1.art['fanart'] = 'https://www.youtube.com/img/desktop/yt_1200.png'
	item1.set_callback(youtube_tatcavideo, url+'/videos')
	yield item2
	yield item1
	resp = urlquick.get(url, timeout=30, max_age=15*60, headers=head_macdinh(useragent, url))
	resp.encoding = 'utf-8'
	kq = resp.text.replace('\\','')
	listplay = re.findall(r'gridVideoRenderer(.*?)navigationEndpoint', kq)
	for k in listplay:
		item = Listitem()
		tenvd = re.search(r'simpleText":"(.*?)"}', k).group(1)
		idvd = re.search(r'"videoId":"(.*?)"', k).group(1)
		anhvd = re.search(r'url":"(.*?)"', k).group(1)
		item.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=' + idvd
		item.label = tenvd
		item.art["thumb"] = anhvd
		item.art["fanart"] = anhvd
		item.set_callback(item.path)
		yield item

@Route.register
def youtube_dslist(plugin, url):
	resp = urlquick.get(url, timeout=30, max_age=15*60, headers=head_macdinh(useragent, url))
	resp.encoding = 'utf-8'
	kq = resp.text.replace('\\','')
	listplay = re.findall(r'gridPlaylistRenderer(.*?)webPageType', kq)
	for k in listplay:
		item = Listitem()
		tenvd = re.search(r'text":"(.*?)",', k).group(1)
		idvd = re.search(r'webCommandMetadata":{"url":"(.*?)"', k).group(1)
		anhvd = re.search(r'url":"(.*?)"', k).group(1)
		xx = 'https://www.youtube.com' + idvd.replace('u0026','&')
		item.label = tenvd
		item.art["thumb"] = anhvd
		item.art["fanart"] = anhvd
		item.set_callback(youtube_list, xx)
		yield item

@Route.register
def youtube_tatcavideo(plugin, url):
	resp = urlquick.get(url, timeout=30, max_age=15*60, headers=head_macdinh(useragent, url))
	resp.encoding = 'utf-8'
	kq = resp.text.replace('\\','')
	listplay = re.findall(r'gridVideoRenderer(.*?)navigationEndpoint', kq)
	for k in listplay:
		item = Listitem()
		tenvd = re.search(r'{"text":"(.*?)"}', k).group(1)
		idvd = re.search(r'"videoId":"(.*?)"', k).group(1)
		anhvd = re.search(r'url":"(.*?)"', k).group(1)
		item.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=' + idvd
		item.label = tenvd
		item.art["thumb"] = anhvd
		item.art["fanart"] = anhvd
		item.set_callback(item.path)
		yield item

@Route.register
def youtube_list(plugin, url):
	resp = urlquick.get(url, timeout=30, max_age=15*60, headers=head_macdinh(useragent, url))
	resp.encoding = 'utf-8'
	kq = resp.text.replace('\\','')
	listplay = re.findall(r'playlistPanelVideoRenderer(.*?)playlistId', kq)
	for k in listplay:
		item = Listitem()
		tenvd = re.search(r'simpleText":"(.*?)"}', k).group(1)
		idvd = re.search(r'videoId":"(.*?)"', k).group(1)
		anhvd = re.search(r'thumbnails":\[{"url":"(.*?)"', k).group(1)
		item.path = 'plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=' + idvd
		item.label = tenvd
		item.art["thumb"] = anhvd
		item.art["fanart"] = anhvd
		item.set_callback(item.path)
		yield item

@Route.register
def index_mocha(plugin, next_page):
	resp = urlquick.get('http://apivideo.mocha.com.vn:8081/onMediaBackendBiz/mochavideo/listVideoByCate?categoryid=1&limit=50&offset=' + str(next_page) + '0&lastIdStr=&token=', timeout=30, max_age=60*60, headers=head_macdinh(useragent, 'http://m.video.mocha.com.vn/more')).json()
	for k in resp['data']['listVideo']:
		item = Listitem()
		linkplay = stream(k['original_path'])
		item.label = k['name']
		item.info['plot'] = k['description']
		item.art['thumb'] =  k['image_path']
		item.art['fanart'] = k['image_path']
		item.set_callback(play_vnm, linkplay, item.label, '')
		yield item
	yield Listitem.next_page(next_page + 1, callback=index_mocha)

@Route.register
def searchnumber(plugin,search_query):
	search_query = get_user_input() # User input via onscreen keyboard
	if not search_query:
		return [] # Return empty list if query is blank
	z = 'http://gg.gg/' + search_query
	resp = urlquick.get(z, timeout=30, max_age=48*60*60, headers=head_macdinh(useragent, z))
	x = resp.url
	item = Listitem()
	if 'folder' in x:
		if '?' in x:
			match = re.search(r'folder/(.*?)\?', x)
			idfd = match.group(1)
		else:
			tach = x.split('folder/')
			idfd = tach[1]
		item.label = z
		item.info['plot'] = 'Mã CODE ' + search_query + ' được tạo từ trang rút gọn http://gg.gg'
		next_page = 1
		item.art['thumb'] = 'https://static.mservice.io/placebrand/s/momo-upload-api-200424091506-637233165063699729.png'
		item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
		item.set_callback(index_fs, idfd, next_page)
		yield item
	elif 'file' in x:
		xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonnoti__, u'Lấy dữ liệu thành công', 5000, __icon__))
		item.label = get_info_fs(x)
		item.art['thumb'] = 'https://static.mservice.io/placebrand/s/momo-upload-api-200424091506-637233165063699729.png'
		item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
		item.set_callback(play_fs, x, item.label)
		yield item

@Route.register
def index_fs(plugin, idfd, next_page):
	url = 'https://www.fshare.vn/api/v3/files/folder?linkcode=%s&sort=type,name&page=%s' % (idfd, str(next_page))
	kq = urlquick.get(url, timeout=30, max_age=60*60, headers=head_macdinh(useragent, url))
	if 'items' in kq.text and len(kq.json()['items']) > 0:
		for k in kq.json()['items']:
			item = Listitem()
			if k['type'] == 0:
				item.label = k['name']
				item.art['thumb'] = 'https://static.mservice.io/placebrand/s/momo-upload-api-200424091506-637233165063699729.png'
				item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item.set_callback(index_fs, k['linkcode'], 1)
				yield item
			elif k['type'] == 1:
				item.label = k['name'] + ' (' + convert_bytes(k['size']) + ')'
				linkplay = 'https://www.fshare.vn/file/' + k['linkcode']
				item.art['thumb'] = 'https://static.mservice.io/placebrand/s/momo-upload-api-200424091506-637233165063699729.png'
				item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item.set_callback(play_fs, linkplay, item.label)
				yield item
	else:
		xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonnoti__, u'Fshare link folder die', 10000, __icon__))
		xbmc.executebuiltin('Container.Refresh')
	if kq.json().get('_links').get('last'):
		last_page = re.search(r'&page=(\d+)', kq.json().get('_links').get('last')).group(1)
		if int(last_page) > next_page:
			yield Listitem.next_page(idfd, next_page + 1,  callback=index_fs)

@Route.register
def fs_favorite(plugin, content_type='segment'):
	try:
		session_id = __settings__.getSetting('sessionfshare')
		headerfsvn = {'User-Agent': 'Vietmediaf /Kodi1.1.99-092019', 'Cookie' : 'session_id=' + session_id }
		resp = urlquick.get('https://api.fshare.vn/api/fileops/listFavorite', timeout=30, max_age=15*60, headers=headerfsvn)
		for k in resp.json():
			item = Listitem()
			if k['type'] == '0':
				item.label = k['name']
				item.art['thumb'] = 'https://static.mservice.io/placebrand/s/momo-upload-api-200424091506-637233165063699729.png'
				item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item.set_callback(index_fs, k['linkcode'], 1)
				yield item
			elif k['type'] == '1':
				item.label = k['name']
				linkplay = 'https://www.fshare.vn/file/' + k['linkcode']
				item.art['thumb'] = 'https://static.mservice.io/placebrand/s/momo-upload-api-200424091506-637233165063699729.png'
				item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item.set_callback(play_fs, linkplay, item.label)
				yield item
	except:
		xbmcgui.Dialog().ok(__addonnoti__, 'Đăng nhập không thành công\nKiểm tra lại tài khoản, mật khẩu, đường truyền Internet')
		__addon__.openSettings()

@Route.register
def fs_topfollow(plugin, content_type='segment'):
	session_id = __settings__.getSetting('sessionfshare')
	headerfsvn = {'User-Agent': 'Vietmediaf /Kodi1.1.99-092019', 'Cookie' : 'session_id=' + session_id }
	try:
		resp = urlquick.get('https://api.fshare.vn/api/fileops/getTopFollowMovie', timeout=30, max_age=48*60*60, headers=headerfsvn)
		for k in resp.json():
			item = Listitem()
			item.label = k['name']
			item.art['thumb'] = 'https://www.fshare.vn/images/top-follow/title.png'
			item.art['fanart'] = 'https://www.fshare.vn/images/top-follow/title.png'
			item.set_callback(index_fs, k['linkcode'], 1)
			yield item
	except:
		xbmcgui.Dialog().ok(__addonnoti__, 'Đăng nhập không thành công\nKiểm tra lại tài khoản, mật khẩu, đường truyền Internet')
		__addon__.openSettings()

@Route.register
def searchfs(plugin, search_query):
	page = 0
	url = 'https://timfshare.com/search?start=' + str(page)+ '1&q=inurl%3Afshare+' + search_query
	resp = urlquick.get(url, timeout=30, max_age=48*60*60, headers=head_macdinh(useragent, url))
	kq = resp.json()
	for k in kq['items']:
		item = Listitem()
		if 'folder' in k['link']:
			item.label = k['title']
			thumuc = k['link'].split('folder/')
			item.info['plot'] = tb
			item.art['thumb'] = 'https://static.mservice.io/placebrand/s/momo-upload-api-200424091506-637233165063699729.png'
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			item.set_callback(index_fs, thumuc[1], 1)
			yield item
		elif 'file' in k['link']:
			item.label = k['title']
			linkplay = k['link']
			item.info['plot'] = k['snippet']
			item.art['thumb'] = 'https://static.mservice.io/placebrand/s/momo-upload-api-200424091506-637233165063699729.png'
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			item.set_callback(play_fs, linkplay, item.label)
			yield item
	yield Listitem.next_page(search_query, page + 1, callback=searchfspage)

@Route.register
def searchfspage(plugin, search_query, page):
	url = 'https://timfshare.com/search?start=' + str(page)+ '1&q=inurl%3Afshare+' + search_query
	resp = urlquick.get(url, timeout=30, max_age=48*60*60, headers=head_macdinh(useragent, url))
	kq = resp.json()
	for k in kq['items']:
		item = Listitem()
		if 'folder' in k['link']:
			item.label = k['title']
			thumuc = k['link'].split('folder/')
			item.art['thumb'] = 'https://static.mservice.io/placebrand/s/momo-upload-api-200424091506-637233165063699729.png'
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			item.set_callback(index_fs, thumuc[1], 1)
			yield item
		elif 'file' in k['link']:
			item.label = k['title']
			linkplay = k['link']
			item.art['thumb'] = 'https://static.mservice.io/placebrand/s/momo-upload-api-200424091506-637233165063699729.png'
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			item.set_callback(play_fs, linkplay, item.label)
			yield item
	yield Listitem.next_page(search_query, page + 1, callback=searchfspage)

@Route.register
def search_thuvienhd(plugin,search_query):
	url = 'https://thuvienhd.com/?s=' + search_query.replace(' ','+')
	resp = urlquick.get(url, timeout=30, max_age=60*60, headers=head_macdinh(useragent, url))
	soup = BeautifulSoup(resp.text, 'html.parser')
	episodes = soup.select('div.search-page div.result-item')
	for episode in episodes:
		item = Listitem()
		anh = episode.select('img')
		for poster in anh:
			linkanh = poster.get('src')
			ten = poster.get('alt')
		linkphim = episode.select('div.title a')
		for urlphim in linkphim:
			phim = urlphim.get('href')
		ndp = episode.select('div.contenido')
		for inf in ndp:
			noidung = inf.text
		item.label = ten
		next_page = 2
		item.info['plot'] = noidung
		item.art['thumb'] =  linkanh
		item.art['fanart'] = linkanh
		item.set_callback(thuvienhd_linktk, phim)
		yield item
	if 'next page-numbers' in resp.text:
		yield Listitem.next_page(search_query, 2, callback=search_thuvienhdnext)

@Route.register
def search_thuvienhdnext(plugin,search_query, next_page):
	url = 'https://thuvienhd.com/page/' + str(next_page) + '?s=' + search_query.replace(' ','+')
	resp = urlquick.get(url, timeout=30, max_age=60*60, headers=head_macdinh(useragent, url))
	soup = BeautifulSoup(resp.text, 'html.parser')
	episodes = soup.select('div.search-page div.result-item')
	for episode in episodes:
		item = Listitem()
		anh = episode.select('img')
		for poster in anh:
			linkanh = poster.get('src')
			ten = poster.get('alt')
		linkphim = episode.select('div.title a')
		for urlphim in linkphim:
			phim = urlphim.get('href')
		ndp = episode.select('div.contenido')
		for inf in ndp:
			noidung = inf.text
		item.label = ten
		item.info['plot'] = noidung
		item.art['thumb'] =  linkanh
		item.art['fanart'] = linkanh
		item.set_callback(thuvienhd_linktk, phim)
		yield item
	if 'next page-numbers' in resp.text:
		yield Listitem.next_page(search_query, next_page + 1, callback=search_thuvienhdnext)

@Route.register
def thuvienhd_linktk(plugin, url):
	respx = urlquick.get(url, timeout=30, max_age=60*60, headers=head_macdinh(useragent, url))
	soupx = BeautifulSoup(respx.text, 'html.parser')
	episodesx = soupx.select('span[class="box__download"] a')
	for episodex in episodesx:
		linkid = episodex.get('href')
		resp = urlquick.get(linkid, timeout=30, max_age=15*60, headers=head_macdinh(useragent, linkid))
		soup = BeautifulSoup(resp.text, 'html.parser')
		episodes = soup.select('tbody[class="tbody outer"] a')
		for episode in episodes:
			item = Listitem()
			link = episode.get('href')
			ten = episode.get('title')
			for dungluong in episode.select('div[class="face-secondary"]'):
				if 'folder' in link:
					item.label = ten + ' ' + dungluong.text.strip()
					thumuc = link.split('folder/')
					item.info['plot'] = ten + ' ' + dungluong.text
					item.art['thumb'] = 'https://static.mservice.io/placebrand/s/momo-upload-api-200424091506-637233165063699729.png'
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					item.set_callback(index_fs, thumuc[1], 1)
					yield item
				elif 'file' in link:
					item.label = ten + ' ' + dungluong.text.strip()
					linkplay = link
					item.info['plot'] = ten + ' ' + dungluong.text
					item.art['thumb'] = 'https://static.mservice.io/placebrand/s/momo-upload-api-200424091506-637233165063699729.png'
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					item.set_callback(play_fs, linkplay, item.label)
					yield item

@Route.register
def index_thuvienhd(plugin,content_type='segment'):
	yield Listitem.search(search_thuvienhd)
	url = 'https://thuvienhd.com/'
	resp = urlquick.get(url, timeout=30, max_age=60*60, headers=head_macdinh(useragent, url))
	thaythe = {
	'Phần Mềm':'Bluray Nguyên Gốc',
	'genre/software':'genre/bluray-nguyen-goc',
	'MacOS':'ATV',
	'genre/macos':'genre/atv',
	'Game':'Việt Nam',
	'genre/game':'genre/vietnamese'
	}
	goc = replace_all(thaythe, resp.text)
	soup = BeautifulSoup(goc, 'html.parser')
	episodes = soup.select('div.menu-menu-main-container li a')
	for episode in episodes:
		item = Listitem()
		if 'thuvienhd.com' in episode.get('href'):
			phim = episode.get('href') + '/page/'
			item.label = episode.text
			item.info['plot'] = tb
			next_page = 1
			item.art['thumb'] =  'https://thuvienhd.com/wp-content/uploads/2020/10/THUVIENHD.NET_.png'
			item.art['fanart'] = 'https://thuvienhd.com/wp-content/uploads/2020/10/THUVIENHD.NET_.png'
			item.set_callback(thuvienhd_page, phim, next_page + 1)
			yield item

@Route.register
def thuvienhd_page(plugin, url, next_page):
	trangtiep = url + str(next_page)
	resp = urlquick.get(trangtiep, timeout=30, max_age=60*60, headers=head_macdinh(useragent, url))
	soup = BeautifulSoup(resp.text, 'html.parser')
	episodes = soup.select('div.items article')
	for episode in episodes:
		item = Listitem()
		idtv = episode.get('id')
		anh = episode.select('img')
		if 'texto' in resp.text:
			nd = episode.select('div.texto')
			for ndp in nd:
				noidung = ndp.text
		else:
			noidung = tb
		linkphim = episode.select('div.data a')
		for poster in anh:
			linkanh = poster.get('src')
			ten = poster.get('alt')
		for urlphim in linkphim:
			phim = urlphim.get('href')
		item.label = ten
		item.info['plot'] = noidung
		item.art['thumb'] = linkanh
		item.art['fanart'] = linkanh
		item.set_callback(thuvienhd_link, idtv)
		yield item
	yield Listitem.next_page(url, next_page + 1, callback=thuvienhd_page)

@Route.register
def thuvienhd_link(plugin, url):
	tach = url.split('-')
	p = tach[1]
	resp = urlquick.get('https://thuvienhd.com/download?id=' + p, timeout=30, max_age=60*60, headers=head_macdinh(useragent, url))
	soup = BeautifulSoup(resp.text, 'html.parser')
	episodes = soup.select('tbody[class="tbody outer"] a')
	for episode in episodes:
		item = Listitem()
		link = episode.get('href')
		ten = episode.get('title')
		for dungluong in episode.select('div[class="face-secondary"]'):
			if 'folder' in link:
				item.label = ten + ' ' + dungluong.text.strip()
				thumuc = link.split('folder/')
				item.info['plot'] = ten + ' ' + dungluong.text
				item.art['thumb'] = 'https://static.mservice.io/placebrand/s/momo-upload-api-200424091506-637233165063699729.png'
				item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item.set_callback(index_fs, thumuc[1], 1)
				yield item
			elif 'file' in link:
				item.label = ten + ' ' + dungluong.text.strip()
				linkplay = link
				item.info['plot'] = ten + ' ' + dungluong.text
				item.art['thumb'] = 'https://static.mservice.io/placebrand/s/momo-upload-api-200424091506-637233165063699729.png'
				item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item.set_callback(play_fs, linkplay, item.label)
				yield item

@Resolver.register
def play_fs(plugin,url,title):
	try:
		session_id = __settings__.getSetting('sessionfshare')
		token = __settings__.getSetting('tokenfshare')
		payload = {'token': token, 'url': url}
		headerfsvn = {'User-Agent': 'Vietmediaf /Kodi1.1.99-092019', 'Cookie' : 'session_id=' + session_id }
		resp = urlquick.post('https://api.fshare.vn/api/session/download', timeout=30, max_age=0, json=payload, headers=headerfsvn)
		return Listitem().from_dict(**{'label': title,'subtitles' : {news},'callback': resp.json()['location']})
	except:
		xbmcgui.Dialog().ok(__addonnoti__, 'Đăng nhập không thành công hoặc file hỏng\nTruy cập mục Fshare của addon VNM để lấy phiên đăng nhập mới và thử lại')

@Route.register
def index_xoilac(plugin, content_type='segment'):
	url = 'https://90phut.net/wp-admin/admin-ajax.php?action=filter_match&filter=all'
	resp = urlquick.get(url, timeout=30, max_age=15*60, headers=head_macdinh(useragent, url))
	soup = BeautifulSoup(resp.json()['data'], 'html.parser')
	episodes = soup.select('a.link-match')
	for episode in episodes:
		item = Listitem()
		linktrandau = episode.get('href')
		item.label = episode.get('title')
		item.art['thumb'] = 'https://xoilac2.com/wp-content/themes/bongda/dist/images/xoilac2.com.png'
		item.art['fanart'] = 'https://xoilac2.com/wp-content/themes/bongda/dist/images/xoilac2.com.png'
		item.set_callback(list_xoilac, linktrandau, item.label)
		yield item

@Route.register
def list_xoilac(plugin, url, title):
	resp = urlquick.get(url, timeout=30, max_age=0, headers=head_macdinh(useragent, url))
	soup = BeautifulSoup(resp.text, 'html.parser')
	episodes = soup.select('div[class="link-video"] a')
	found = False
	if len(episodes) > 1:
		for episode in episodes:
			item1 = Listitem()
			linktrandau1 = episode.get('href')
			item1.label = episode.text.strip()
			item1.art['thumb'] = 'https://xoilac2.com/wp-content/themes/bongda/dist/images/xoilac2.com.png'
			item1.art['fanart'] = 'https://xoilac2.com/wp-content/themes/bongda/dist/images/xoilac2.com.png'
			item1.set_callback(ifr_xoilac, linktrandau1, item1.label)
			yield item1
	if not found:
		item2 = Listitem()
		item2.label = 'Default - ' + title
		item2.art['thumb'] = 'https://xoilac2.com/wp-content/themes/bongda/dist/images/xoilac2.com.png'
		item2.art['fanart'] = 'https://xoilac2.com/wp-content/themes/bongda/dist/images/xoilac2.com.png'
		item2.set_callback(ifr_xoilac, url, item2.label)
		yield item2

@Route.register
def index_fptsukien(plugin, content_type='segment'):
	url = 'https://fptplay.vn/xem-truyen-hinh'
	resp = urlquick.get(url, timeout=30, max_age=15*60, headers=head_macdinh(useragent, url))
	resp.encoding = 'utf-8'
	kq = resp.text
	source = re.search(r'window.__NUXT__=(.*?);<\/script>', kq).group(1)
	if 'Sự kiện' in source:
		x = json.loads(source)['data'][1]['listChanel']
		for row in x:
			item = Listitem()
			if 'Sự kiện' in row['group_name']:
				link = row['_id']
				thaythe = {'su-kien-1':'https://livecdn.fptplay.net/schedule/sukien01_hls.smil/playlist.m3u8','su-kien-2':'https://livecdn.fptplay.net/schedule/sukien02_hls.smil/playlist.m3u8','su-kien-3':'https://livecdn.fptplay.net/schedule/sukien03_hls.smil/playlist.m3u8','su-kien-4':'https://livecdn.fptplay.net/schedule/sukien04_hls.smil/playlist.m3u8','su-kien-5':'https://livecdn.fptplay.net/schedule/sukien05_hls.smil/playlist.m3u8','su-kien-6':'https://livecdn.fptplay.net/schedule/sukien06_hls.smil/playlist.m3u8','su-kien-7':'https://livecdn.fptplay.net/schedule/sukien07_hls.smil/playlist.m3u8','su-kien-8':'https://livecdn.fptplay.net/schedule/sukien08_hls.smil/playlist.m3u8','su-kien-9':'https://livecdn.fptplay.net/schedule/sukien09_hls.smil/playlist.m3u8','su-kien-10':'https://livecdn.fptplay.net/schedule/sukien10_hls.smil/playlist.m3u8','uefa-1': 'https://livecdn.fptplay.net/hdevent/uefa01_vhls.smil/playlist.m3u8','uefa-2': 'https://livecdn.fptplay.net/hdevent/uefa02_vhls.smil/playlist.m3u8','uefa-3': 'https://livecdn.fptplay.net/hdevent/uefa03_vhls.smil/playlist.m3u8','uefa-4': 'https://livecdn.fptplay.net/hdevent/uefa04_vhls.smil/playlist.m3u8','uefa-5': 'https://livecdn.fptplay.net/hdevent/uefa05_vhls.smil/playlist.m3u8','uefa-6': 'https://livecdn.fptplay.net/hdevent/uefa06_vhls.smil/playlist.m3u8','uefa-7': 'https://livecdn.fptplay.net/hdevent/uefa07_vhls.smil/playlist.m3u8','uefa-8': 'https://livecdn.fptplay.net/hdevent/uefa08_vhls.smil/playlist.m3u8','uefa-9': 'https://livecdn.fptplay.net/hdevent/uefa09_vhls.smil/playlist.m3u8','uefa-10': 'https://livecdn.fptplay.net/hdevent/uefa10_vhls.smil/playlist.m3u8','youth-league-1': 'https://livecdn.fptplay.net/hdevent/youth01_vhls.smil/playlist.m3u8','youth-league-2': 'https://livecdn.fptplay.net/hdevent/youth02_vhls.smil/playlist.m3u8','youth-league-3': 'https://livecdn.fptplay.net/hdevent/youth03_vhls.smil/playlist.m3u8','youth-league-4': 'https://livecdn.fptplay.net/hdevent/youth04_vhls.smil/playlist.m3u8','youth-league-5': 'https://livecdn.fptplay.net/hdevent/youth05_vhls.smil/playlist.m3u8','youth-league-6': 'https://livecdn.fptplay.net/hdevent/youth06_vhls.smil/playlist.m3u8','youth-league-7': 'https://livecdn.fptplay.net/hdevent/youth07_vhls.smil/playlist.m3u8','youth-league-8': 'https://livecdn.fptplay.net/hdevent/youth08_vhls.smil/playlist.m3u8','youth-league-9': 'https://livecdn.fptplay.net/hdevent/youth09_vhls.smil/playlist.m3u8','youth-league-10': 'https://livecdn.fptplay.net/hdevent/youth10_vhls.smil/playlist.m3u8','world-cup-1': 'https://livecdn.fptplay.net/hdevent/worldcup01_hls.smil/playlist.m3u8','world-cup-2': 'https://livecdn.fptplay.net/hdevent/worldcup02_hls.smil/playlist.m3u8','world-cup-3': 'https://livecdn.fptplay.net/hdevent/worldcup03_hls.smil/playlist.m3u8','world-cup-4': 'https://livecdn.fptplay.net/hdevent/worldcup04_hls.smil/playlist.m3u8','world-cup-5': 'https://livecdn.fptplay.net/hdevent/worldcup05_hls.smil/playlist.m3u8','world-cup-6': 'https://livecdn.fptplay.net/hdevent/worldcup06_hls.smil/playlist.m3u8','world-cup-7': 'https://livecdn.fptplay.net/hdevent/worldcup07_hls.smil/playlist.m3u8','world-cup-8': 'https://livecdn.fptplay.net/hdevent/worldcup08_hls.smil/playlist.m3u8','world-cup-9': 'https://livecdn.fptplay.net/hdevent/worldcup09_hls.smil/playlist.m3u8','world-cup-10': 'https://livecdn.fptplay.net/hdevent/worldcup10_hls.smil/playlist.m3u8','f-event': 'https://livecdn.fptplay.net/event/eventExpire_2000.stream/playlist.m3u8','pladio':'https://livecdn.fptplay.net/hda3/pladio_vhls.smil/playlist.m3u8'}
				hls = stream(replace_all(thaythe, link))
				item.info['plot'] = tb
				item.label = row['alias_name']
				item.art['thumb'] = row['thumb']
				item.art['fanart'] = row['thumb']
				item.set_callback(play_vnm, hls, item.label, '')
				yield item
	else:
		item3 = Listitem()
		linkmacdinh = stream(qc)
		item3.label = 'Đang cập nhật'
		item3.info['plot'] = tb
		item3.art['thumb'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.art['fanart'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.set_callback(play_vnm, linkmacdinh, item3.label, '')
		yield item3

@Route.register
def index_vieonsukien(plugin, content_type='segment'):
	url = 'https://api.vieon.vn/backend/cm/v5/ribbon/4bdad485-9048-4c15-970e-e94ce4a595b9?page=0&limit=30&platform=web&ui=012021'
	resp = urlquick.get(url, timeout=30, max_age=15*60, headers=head_macdinh(useragent, url))
	resp.encoding = 'utf-8'
	kq = resp.text
	data = json.loads(kq)['items']
	for k in data:
		item = Listitem()
		item.label = k['title']
		hls = stream(vieon(k['seo']['share_url']))
		item.info['plot'] = tb
		item.art['thumb'] = k['images']['thumbnail_v4']
		item.art['fanart'] = k['images']['thumbnail_v4']
		item.set_callback(play_vnm, hls, item.label, '')
		yield item

@Route.register
def index_bongdahomnay(plugin, content_type='segment'):
	url = 'https://bongdahomnay.tech/'
	resp = urlquick.get(url, timeout=30, max_age=15*60, headers=head_macdinh(useragent, url))
	match = re.findall(r',id:(.*?)}', resp.text)
	for k in match:
		item = Listitem()
		idtran = url + 'truc-tiep/vcl-' + re.search(r'"(.*?)"', k).group(1) + '.html'
		time = re.search(r'fulltime:"(.*?)"', k).group(1)
		match_name = re.search(r'match_name:"(.*?)"', k).group(1).replace(r'\t', '')
		item.info['plot'] = tb
		item.label = time + ' ' + match_name
		item.art['thumb'] = 'https://i.imgur.com/TlXaeKj.png'
		item.art['fanart'] = 'https://i.imgur.com/TlXaeKj.png'
		item.set_callback(list_bongdahomnay, idtran, item.label)
		yield item

@Route.register
def list_bongdahomnay(plugin,url,title):
	resp = urlquick.get(url, timeout=30, max_age=0, headers=head_macdinh(useragent, url))
	if 'm3u8' in resp.text:
		match = re.findall(r'1,url:(.*?)}', resp.text)
		for k in match:
			item = Listitem()
			linktran = stream(re.search(r'"(.*?)"', k).group(1)) + referer(url)
			chatluong = re.search(r'name:"(.*?)"', k).group(1)
			item.info['plot'] = tb
			item.label = chatluong + ' ' + title
			item.art['thumb'] = 'https://i.imgur.com/TlXaeKj.png'
			item.art['fanart'] = 'https://i.imgur.com/TlXaeKj.png'
			item.set_callback(play_vnm, linktran, item.label, '')
			yield item
	else:
		item3 = Listitem()
		linkmacdinh = stream(qc)
		item3.label = 'Đang cập nhật'
		item3.info['plot'] = tb
		item3.art['thumb'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.art['fanart'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.set_callback(play_vnm, linkmacdinh, item3.label, '')
		yield item3

@Route.register
def index_binhluan(plugin, content_type='segment'):
	url = binhluantv + '/api/matches-in-home'
	resp = urlquick.get(url, timeout=30, max_age=10*60, headers=head_macdinh(useragent, url))
	kq = resp.json()
	for k in kq[0]['data']:
		item1 = Listitem()
		ten = '[LIVE]' + k['title']
		linktran = k['_id']
		item1.info['plot'] = tb
		item1.label = ten
		item1.art['thumb'] = 'https://xoilac.90phuttttt.xyz/imgs/logo.png'
		item1.art['fanart'] = 'https://xoilac.90phuttttt.xyz/imgs/logo.png'
		item1.set_callback(list_binhluantv, linktran, item1.label)
		yield item1
	for m in kq[1]['data']:
		item2 = Listitem()
		time = m['timeStartPlayMod']
		ngay = m['dayinweek']
		ten = m['title']
		linktran = binhluantv + '/api/match/' + m['_id']
		item2.info['plot'] = tb
		item2.label = time + ' ' + ngay + ' ' + ten
		item2.art['thumb'] = 'https://xoilac.90phuttttt.xyz/imgs/logo.png'
		item2.art['fanart'] = 'https://xoilac.90phuttttt.xyz/imgs/logo.png'
		item2.set_callback(list_binhluantv, linktran, item2.label)
		yield item2

@Route.register
def list_binhluantv(plugin, url, title):
	resp = urlquick.get(url, timeout=30, max_age=0, headers=head_macdinh(useragent, url))
	kq = resp.json()
	if 'm3u8' in resp.text:
		for k in kq['streamsLink']:
			item = Listitem()
			ten = k['label'] + ' ' + title
			linktran = stream(k['link']) + referer(url)
			item.info['plot'] = tb
			item.label = ten
			item.art['thumb'] = 'https://xoilac.90phuttttt.xyz/imgs/logo.png'
			item.art['fanart'] = 'https://xoilac.90phuttttt.xyz/imgs/logo.png'
			item.set_callback(play_vnm, linktran, item.label, '')
			yield item
	else:
		item3 = Listitem()
		linkmacdinh = stream(qc)
		item3.label = 'Đang cập nhật'
		item3.info['plot'] = tb
		item3.art['thumb'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.art['fanart'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.set_callback(play_vnm, linkmacdinh, item3.label, '')
		yield item3

@Route.register
def index_cakhia(plugin, content_type='segment'):
	url = 'https://cakhiaz.live/node-cache/get-lives-home'
	resp = urlquick.get(url, timeout=30, max_age=5*60, headers=head_macdinh(useragent, url))
	if 'm3u8' in resp.text:
		kq = resp.json()
		for k1 in kq['data']['liveMatchings']:
			for k2 in k1['hlsUrls']:
				item1 = Listitem()
				if 'm3u8' in k2['url']:
					time1 = (datetime.fromisoformat(k1['time'][:-1]) + timedelta(hours=7)).strftime('%H:%M %d-%m')
					linktrandau1 = stream(k2['url']) + referer('https://cakhia10.tv/.html')
					item1.label = k2['name'] + ' ' + time1 + ' ' + k1['teamA']['name'] + '-' + k1['teamB']['name']
					item1.info['plot'] = tb
					item1.art['thumb'] = 'https://static.fastlycdnlive.xyz/cakhia13/user/img/ckstrim.png'
					item1.art['fanart'] = 'https://static.fastlycdnlive.xyz/cakhia13/user/img/ckstrim.png'
					item1.set_callback(play_vnm, linktrandau1, item1.label, '')
					yield item1
		for b1 in kq['data']['livesSapDienRa']:
			for b2 in b1['hlsUrls']:
				item2 = Listitem()
				if 'm3u8' in b2['url']:
					time2 = (datetime.fromisoformat(b1['time'][:-1]) + timedelta(hours=7)).strftime('%H:%M %d-%m')
					linktrandau2 = stream(b2['url']) + referer('https://cakhia10.tv/.html')
					item2.label = b2['name'] + ' ' + time2 + ' ' + b1['teamA']['name'] + '-' + b1['teamB']['name']
					item2.info['plot'] = tb
					item2.art['thumb'] = 'https://static.fastlycdnlive.xyz/cakhia13/user/img/ckstrim.png'
					item2.art['fanart'] = 'https://static.fastlycdnlive.xyz/cakhia13/user/img/ckstrim.png'
					item2.set_callback(play_vnm, linktrandau2, item2.label, '')
					yield item2
	else:
		item3 = Listitem()
		linkmacdinh = stream(qc)
		item3.label = 'Đang cập nhật'
		item3.info['plot'] = tb
		item3.art['thumb'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.art['fanart'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.set_callback(play_vnm, linkmacdinh, item3.label, '')
		yield item3

@Route.register
def index_rakhoi(plugin, content_type='segment'):
	url = 'https://xem.rakhoi.tv/get-tran-dau-sap-dien-ra/6198ac0ccedadf08cbba36df.html'
	resp = urlquick.post(url, timeout=30, max_age=5*60, headers=head_macdinh(useragent, url))
	if 'm3u8' in resp.text:
		kq = resp.json()
		for k1 in kq['data']['lives']:
			for k2 in k1['hlsUrls']:
				item1 = Listitem()
				if 'm3u8' in k2['url']:
					time1 = (datetime.fromisoformat(k1['time'][:-1]) + timedelta(hours=7)).strftime('%H:%M %d-%m')
					linktrandau1 = stream(k2['url']) + referer('https://cakhia10.tv/.html')
					item1.label = k2['name'] + ' ' + time1 + ' ' + k1['teamA']['name'] + '-' + k1['teamB']['name']
					item1.info['plot'] = tb
					item1.art['thumb'] = 'https://static.fastlycdnlive.xyz/rakhoi7/user/img/rakhoi.png'
					item1.art['fanart'] = 'https://static.fastlycdnlive.xyz/rakhoi7/user/img/rakhoi.png'
					item1.set_callback(play_vnm, linktrandau1, item1.label, '')
					yield item1
	else:
		item2 = Listitem()
		linkmacdinh = stream(qc)
		item2.label = 'Đang cập nhật'
		item2.info['plot'] = tb
		item2.art['thumb'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item2.art['fanart'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item2.set_callback(play_vnm, linkmacdinh, item2.label, '')
		yield item2

@Route.register
def index_saoke(plugin, content_type='segment'):
	url = 'https://saoke2.tv/'
	resp = urlquick.get(url, timeout=30, max_age=5*60, headers=head_macdinh(useragent, url))
	if 'm3u8' in resp.text:
		match = re.search(r'lives=(.*?)</script>', resp.text).group(1)
		listplay = re.findall(r'{_id(.*?)primaryId', match)
		for k in listplay:
			ten = re.search(r'Xem trực tiếp bình luận bóng đá hôm nay: (.*?)"', k).group(1)
			tg = re.search(r'time:(.*?),', k).group(1)
			tgjs = json.loads(tg)
			time = datetime.fromtimestamp(tgjs/1000).strftime('%H:%M %d-%m')
			listname = re.findall(r'{name:(.*?)}', k)
			for m in listname:
				item = Listitem()
				if re.search(r'url:"(.*?)"', m).group(1):
					chatluong = re.search(r'"(.*?)"', m).group(1)
					linkplay = stream(re.search(r'url:"(.*?)"', m).group(1)) + referer(url)
					item.label = chatluong + ' ' + time + ' ' + ten
					item.info['plot'] = tb
					item.art['thumb'] = 'https://9767a59e2b.vws.vegacdn.vn/template/logo1.png'
					item.art['fanart'] = 'https://9767a59e2b.vws.vegacdn.vn/template/logo1.png'
					item.set_callback(play_vnm, linkplay, item.label, '')
					yield item
	else:
		item2 = Listitem()
		linkmacdinh = stream(qc)
		item2.label = 'Đang cập nhật'
		item2.info['plot'] = tb
		item2.art['thumb'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item2.art['fanart'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item2.set_callback(play_vnm, linkmacdinh, item2.label, '')
		yield item2

@Route.register
def index_90p(plugin, content_type='segment'):
	resp = urlquick.get(tiengruoi, timeout=30, max_age=15*60, headers=head_macdinh(useragent, tiengruoi))
	web = BeautifulSoup(resp.text, 'html.parser')
	for chinmuoi in web.body.select('a.item'):
		item = Listitem()
		title = chinmuoi.select_one('div.title').text.strip()
		time =  chinmuoi.select_one('div.time').text.strip()
		time = time.replace('Chưa diễn ra', '')
		linktrandau = chinmuoi.get('href')
		item.label = time + ' ' + title
		item.art['thumb'] = 'https://90phuttttt.xyz/images/logo-90.png'
		item.art['fanart'] = 'https://90phuttttt.xyz/images/logo-90.png'
		item.set_callback(list_90p, linktrandau, item.label)
		yield item

@Route.register
def list_90p(plugin,url,title):
	goc = tiengruoi+url
	resp = urlquick.get(goc, timeout=30, max_age=0, headers=head_macdinh(useragent, goc))
	web = BeautifulSoup(resp.text, 'html.parser')
	dulieu = web.body.select('ul.pull-left li.item')
	found = False
	if len(dulieu) > 1:
		for chinmuoi in dulieu:
			item = Listitem()
			if chinmuoi.get('data-url'):
				linkchatluong = stream(chinmuoi.get('data-url')) + referer(tiengruoi)
				item.label = chinmuoi.select_one('a').text.strip() + ' ' + title
				item.info['plot'] = tb
				item.art['thumb'] = 'https://90phuttttt.xyz/images/logo-90.png'
				item.art['fanart'] = 'https://90phuttttt.xyz/images/logo-90.png'
				item.set_callback(play_vnm, linkchatluong, item.label, '')
				yield item
	if not found:
		item = Listitem()
		match = re.search(r'video_url = "(.*?)"', resp.text)
		if 'm3u8' in resp.text:
			linkmacdinh = stream(match.group(1)) + referer(tiengruoi)
		else:
			linkmacdinh = stream(qc)
		item.label = 'Default ' + title
		item.info['plot'] = tb
		item.art['thumb'] = 'https://90phuttttt.xyz/images/logo-90.png'
		item.art['fanart'] = 'https://90phuttttt.xyz/images/logo-90.png'
		item.set_callback(play_vnm, linkmacdinh, item.label, '')
		yield item

@Resolver.register
def play_vnm(plugin,url,title,drmKey):
	if drmKey !='':
		is_helper = inputstreamhelper.Helper('mpd','com.widevine.alpha')
		if is_helper.check_inputstream():
			return Listitem().from_dict(**{'label': plugin._title,'subtitles':{'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/qc.ass'},'callback':url,'properties':{'inputstream':is_helper.inputstream_addon,'inputstream.adaptive.manifest_type':'mpd','inputstream.adaptive.license_type':'com.widevine.alpha','inputstream.adaptive.license_key':drmKey +'||R{SSM}|'}})
	elif 'm3u8' in url :
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':url,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
	else:
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':url})

@Resolver.register
def ifr_xoilac(plugin,url,title):
	resp = urlquick.get(url, timeout=30, max_age=60*60, headers=head_macdinh(useragent, url))
	soup = BeautifulSoup(resp.text, 'html.parser')
	dulieu = soup.body.select('div.embed-responsive-item iframe')
	for xoilac in dulieu:
		ifr = xoilac.get('src')
		layifr = urlquick.get(ifr, timeout=30, max_age=0, headers=head_macdinh(useragent, url))
		match = re.search(r'urlStream = "(.*?)"', layifr.text)
		linkplay = stream(match.group(1)) + referer(ifr)
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay})