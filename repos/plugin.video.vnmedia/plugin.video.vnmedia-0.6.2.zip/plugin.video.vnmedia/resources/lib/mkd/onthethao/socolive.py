from codequick import Route, Listitem, run
from resources.lib.kedon import getlink, stream, referer, playsocolive
import re, json
@Route.register
def index_socolive(plugin, content_type='segment'):
	url = 'https://json.cvndnss.com/all_live_rooms.json'
	resp = getlink(url, url, 5*60)
	nd = re.search(r'\((.*?)}\)', resp.text).group(1) + '}'
	m = json.loads(nd)
	for k in m['data']['hot']:
		item = Listitem()
		item.label = k['anchor']['nickName'] + ' - ' + k['title']
		roomplay = k['roomNum']
		anh = k['cover']
		item.art['thumb'] = anh
		item.art['fanart'] = anh
		item.set_callback(playsocolive, roomplay, item.label)
		yield item