from codequick import Route, Listitem, Resolver
from importlib import import_module
from datetime import datetime
from functools import lru_cache
import re
@lru_cache(maxsize=None)
def respxoilacxyz():
	w = import_module('resources.lib.kedon')
	tr2 = w.tiengruoi()[2]
	resp90 = w.getlink(tr2, tr2, 400)
	if (resp90 is not None):
		ref = re.search(r'  window.base_embed_url(.*?)"(.*?)"', resp90.text).group(2)
	else:
		ref = tr2
	return ref
@Route.register
def index_xoilacxyz(plugin, **kwargs):
	w = import_module('resources.lib.kedon')
	url = 'http://api.vebo.xyz/api/match/live'
	ref = respxoilacxyz()
	resp = w.getlink(url, ref, 400)
	if (resp is not None):
		kq = resp.json()
		for k in kq['data']:
			item = Listitem()
			time = datetime.fromtimestamp(int(k['timestamp'])/1000).strftime('%H:%M %d-%m')
			if k['commentators']:
				item.label = f'{time}: {k["name"]} ({k["commentators"][0]["name"]})'
			else:
				item.label = f'{time}: {k["name"]}'
			item.info['plot'] = w.tb
			item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/xoilac.png'
			item.set_callback(list_xoilacxyz, k['id'], item.label)
			yield item
	else:
		yield w.quangcao()
@Route.register
def list_xoilacxyz(plugin, idk, title, **kwargs):
	w = import_module('resources.lib.kedon')
	ref = respxoilacxyz()
	url = f'http://api.vebo.xyz/api/match/{idk}/meta'
	resp = w.getlink(url, ref, 400)
	if (resp is not None) and ('.m3u8' in resp.text):
		kq = resp.json()
		for k in kq['data']['play_urls']:
			item = Listitem()
			item.label = f'{k["name"]} - {title}'
			item.info['plot'] = w.tb
			item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/xoilac.png'
			item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), f'{w.stream(k["url"])}{w.referer(ref)}', item.label, '')
			yield item
	else:
		yield w.quangcao()