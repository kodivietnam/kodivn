from codequick import Route, Listitem, run
from resources.lib.kedon import logotv, tb
from resources.lib.mkd.ontruyenhinh.listiptv import list_iptv
CATEGORIES = {
'Hoạt hình': 'http://iptv-org.github.io/iptv/categories/animation.m3u',
'Tự động': 'http://iptv-org.github.io/iptv/categories/auto.m3u',
'Kinh doanh': 'http://iptv-org.github.io/iptv/categories/business.m3u',
'Cổ điển': 'http://iptv-org.github.io/iptv/categories/classic.m3u',
'Hài': 'http://iptv-org.github.io/iptv/categories/comedy.m3u',
'Nấu ăn': 'http://iptv-org.github.io/iptv/categories/cooking.m3u',
'Văn hoá': 'http://iptv-org.github.io/iptv/categories/culture.m3u',
'Tài liệu': 'http://iptv-org.github.io/iptv/categories/documentary.m3u',
'Giáo dục': 'http://iptv-org.github.io/iptv/categories/education.m3u',
'Giải trí': 'http://iptv-org.github.io/iptv/categories/entertainment.m3u',
'Gia đình': 'http://iptv-org.github.io/iptv/categories/family.m3u',
'Tổng hợp': 'http://iptv-org.github.io/iptv/categories/general.m3u',
'Thiếu nhi': 'http://iptv-org.github.io/iptv/categories/kids.m3u',
'Pháp luật': 'http://iptv-org.github.io/iptv/categories/legislative.m3u',
'Đời sống': 'http://iptv-org.github.io/iptv/categories/lifestyle.m3u',
'Bản địa': 'http://iptv-org.github.io/iptv/categories/local.m3u',
'Ca nhạc': 'http://iptv-org.github.io/iptv/categories/music.m3u',
'Phim ảnh': 'http://iptv-org.github.io/iptv/categories/movies.m3u',
'Tin tức': 'http://iptv-org.github.io/iptv/categories/news.m3u',
'Thiên nhiên': 'http://iptv-org.github.io/iptv/categories/outdoor.m3u',
'Thư giãn': 'http://iptv-org.github.io/iptv/categories/relax.m3u',
'Tôn giáo': 'http://iptv-org.github.io/iptv/categories/religious.m3u',
'Khoa học': 'http://iptv-org.github.io/iptv/categories/science.m3u',
'Dài kỳ': 'http://iptv-org.github.io/iptv/categories/series.m3u',
'Mua bán': 'http://iptv-org.github.io/iptv/categories/shop.m3u',
'Thể thao': 'http://iptv-org.github.io/iptv/categories/sports.m3u',
'Du lịch': 'http://iptv-org.github.io/iptv/categories/travel.m3u',
'Thời tiết': 'http://iptv-org.github.io/iptv/categories/weather.m3u',
'Khác': 'http://iptv-org.github.io/iptv/categories/other.m3u'
}
@Route.register
def listiptv_qt(plugin, **kwargs):
	for tenlist, urllist in list(CATEGORIES.items()):
		item = Listitem()
		item.label = tenlist
		item.info['plot'] = tb
		item.art['thumb'] = item.art['landscape'] = logotv
		item.art['fanart'] = 'http://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
		item.set_callback(list_iptv, url=urllist)
		yield item