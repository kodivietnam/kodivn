from codequick import Route, Listitem, run
from resources.lib.kedon import getlink, play_bm, quangcao
from bs4 import BeautifulSoup
import re
@Route.register
def index_baomoi(plugin, **kwargs):
	yield nong()
	yield moi()
	yield thegioi()
	yield xahoi()
	yield vanhoa()
	yield kinhte()
	yield giaoduc()
	yield thethao()
	yield bongda()
	yield giaitri()
	yield phapluat()
	yield congnghe()
	yield khoahoc()
	yield doisong()
	yield xeco()
	yield nhadat()
def nong():
	item = Listitem()
	item.label = 'Tin Nóng'
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'http://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'home')
	return item
def moi():
	item = Listitem()
	item.label = 'Tin mới'
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'http://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'new')
	return item
def thegioi():
	item = Listitem()
	item.label = 'Thế giới'
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'http://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'the-gioi')
	return item
def xahoi():
	item = Listitem()
	item.label = 'Xã hội'
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'http://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'xa-hoi')
	return item
def vanhoa():
	item = Listitem()
	item.label = 'Văn hoá'
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'http://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'van-hoa')
	return item
def kinhte():
	item = Listitem()
	item.label = 'Kinh tế'
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'http://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'kinh-te')
	return item
def giaoduc():
	item = Listitem()
	item.label = 'Giáo dục'
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'http://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'giao-duc')
	return item
def thethao():
	item = Listitem()
	item.label = 'Thể thao'
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'http://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'the-thao')
	return item
def bongda():
	item = Listitem()
	item.label = 'Bóng đá'
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'http://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'football')
	return item
def giaitri():
	item = Listitem()
	item.label = 'Giải trí'
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'http://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'giai-tri')
def phapluat():
	item = Listitem()
	item.label = 'Pháp luật'
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'http://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'phap-luat')
	return item
def congnghe():
	item = Listitem()
	item.label = 'Công nghệ'
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'http://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'khoa-hoc-cong-nghe')
	return item
def khoahoc():
	item = Listitem()
	item.label = 'Khoa học'
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'http://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'khoaa-hoc')
	return item
def doisong():
	item = Listitem()
	item.label = 'Đời sống'
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'http://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'doi-song')
	return item
def xeco():
	item = Listitem()
	item.label = 'Xe cộ'
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'http://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'xe-co')
	return item
def nhadat():
	item = Listitem()
	item.label = 'Nhà đất'
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'http://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'nha-dat')
	return item

@Route.register
def list_baomoi(plugin, ten, **kwargs):
	url = 'http://m.baomoi.com'
	r = getlink(url,url, 1000)
	if r is not None:
		idbm = re.search(r'buildId":"(.*?)"', r.text).group(1)
		if ten == 'home':
			url = f'http://m.baomoi.com/_next/data/{idbm}/home.json'
			resp = getlink(url, url, 1000)
			js = resp.json()
			getjs = js['pageProps']['resp']['data']['content']['items']
			for k in getjs:
				item = Listitem()
				item.label = k['title']
				item.info['plot'] = k['description']
				linkbm = f'http://m.baomoi.com{k["url"]}'
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = k['thumb']
				item.set_callback(play_bm, linkbm, item.label)
				yield item
		elif ten == 'new':
			url = f'http://m.baomoi.com/_next/data/{idbm}/new.json'
			resp = getlink(url, url, 1000)
			js = resp.json()
			getjs = js['pageProps']['resp']['data']['content']['items']
			for k in getjs:
				item = Listitem()
				if 'title' in k:
					item.label = k['title']
					item.info['plot'] = k['description']
					linkbm = f'http://m.baomoi.com{k["url"]}'
					item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = k['thumb']
					item.set_callback(play_bm, linkbm, item.label)
					yield item
		elif ten == 'the-gioi':
			url = f'http://m.baomoi.com/_next/data/{idbm}/category/the-gioi.json'
			resp = getlink(url, url, 1000)
			js = resp.json()
			getjs = js['pageProps']['resp']['data']['content']['items']
			for k in getjs:
				item = Listitem()
				if 'title' in k:
					item.label = k['title']
					item.info['plot'] = k['description']
					linkbm = f'http://m.baomoi.com{k["url"]}'
					item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = k['thumb']
					item.set_callback(play_bm, linkbm, item.label)
					yield item
		elif ten == 'xa-hoi':
			url = f'http://m.baomoi.com/_next/data/{idbm}/category/xa-hoi.json'
			resp = getlink(url, url, 1000)
			js = resp.json()
			getjs = js['pageProps']['resp']['data']['content']['items']
			for k in getjs:
				item = Listitem()
				if 'title' in k:
					item.label = k['title']
					item.info['plot'] = k['description']
					linkbm = f'http://m.baomoi.com{k["url"]}'
					item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = k['thumb']
					item.set_callback(play_bm, linkbm, item.label)
					yield item
		elif ten == 'van-hoa':
			url = f'http://m.baomoi.com/_next/data/{idbm}/category/van-hoa.json'
			resp = getlink(url, url, 1000)
			js = resp.json()
			getjs = js['pageProps']['resp']['data']['content']['items']
			for k in getjs:
				item = Listitem()
				if 'title' in k:
					item.label = k['title']
					item.info['plot'] = k['description']
					linkbm = f'http://m.baomoi.com{k["url"]}'
					item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = k['thumb']
					item.set_callback(play_bm, linkbm, item.label)
					yield item
		elif ten == 'kinh-te':
			url = f'http://m.baomoi.com/_next/data/{idbm}/category/kinh-te.json'
			resp = getlink(url, url, 1000)
			js = resp.json()
			getjs = js['pageProps']['resp']['data']['content']['items']
			for k in getjs:
				item = Listitem()
				if 'title' in k:
					item.label = k['title']
					item.info['plot'] = k['description']
					linkbm = f'http://m.baomoi.com{k["url"]}'
					item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = k['thumb']
					item.set_callback(play_bm, linkbm, item.label)
					yield item
		elif ten == 'giao-duc':
			url = f'http://m.baomoi.com/_next/data/{idbm}/category/giao-duc.json'
			resp = getlink(url, url, 1000)
			js = resp.json()
			getjs = js['pageProps']['resp']['data']['content']['items']
			for k in getjs:
				item = Listitem()
				if 'title' in k:
					item.label = k['title']
					item.info['plot'] = k['description']
					linkbm = f'http://m.baomoi.com{k["url"]}'
					item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = k['thumb']
					item.set_callback(play_bm, linkbm, item.label)
					yield item
		elif ten == 'the-thao':
			url = f'http://m.baomoi.com/_next/data/{idbm}/category/the-thao.json'
			resp = getlink(url, url, 1000)
			js = resp.json()
			getjs = js['pageProps']['resp']['data']['content']['items']
			for k in getjs:
				item = Listitem()
				if 'title' in k:
					item.label = k['title']
					item.info['plot'] = k['description']
					linkbm = f'http://m.baomoi.com{k["url"]}'
					item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = k['thumb']
					item.set_callback(play_bm, linkbm, item.label)
					yield item
		elif ten == 'football':
			url = f'http://m.baomoi.com/_next/data/{idbm}/football.json'
			resp = getlink(url, url, 1000)
			js = resp.json()
			getjs = js['pageProps']['resp']['data']['content']['sections'][6]['items']
			for k in getjs:
				item = Listitem()
				item.label = k['title']
				item.info['plot'] = k['description']
				linkbm = f'http://m.baomoi.com{k["url"]}'
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = k['thumb']
				item.set_callback(play_bm, linkbm, item.label)
				yield item
		elif ten == 'giai-tri':
			url = f'http://m.baomoi.com/_next/data/{idbm}/category/giai-tri.json'
			resp = getlink(url, url, 1000)
			js = resp.json()
			getjs = js['pageProps']['resp']['data']['content']['items']
			for k in getjs:
				item = Listitem()
				if 'title' in k:
					item.label = k['title']
					item.info['plot'] = k['description']
					linkbm = f'http://m.baomoi.com{k["url"]}'
					item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = k['thumb']
					item.set_callback(play_bm, linkbm, item.label)
					yield item
		elif ten == 'phap-luat':
			url = f'http://m.baomoi.com/_next/data/{idbm}/category/phap-luat.json'
			resp = getlink(url, url, 1000)
			js = resp.json()
			getjs = js['pageProps']['resp']['data']['content']['items']
			for k in getjs:
				item = Listitem()
				if 'title' in k:
					item.label = k['title']
					item.info['plot'] = k['description']
					linkbm = f'http://m.baomoi.com{k["url"]}'
					item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = k['thumb']
					item.set_callback(play_bm, linkbm, item.label)
					yield item
		elif ten == 'khoa-hoc-cong-nghe':
			url = f'http://m.baomoi.com/_next/data/{idbm}/category/khoa-hoc-cong-nghe.json'
			resp = getlink(url, url, 1000)
			js = resp.json()
			getjs = js['pageProps']['resp']['data']['content']['items']
			for k in getjs:
				item = Listitem()
				if 'title' in k:
					item.label = k['title']
					item.info['plot'] = k['description']
					linkbm = f'http://m.baomoi.com{k["url"]}'
					item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = k['thumb']
					item.set_callback(play_bm, linkbm, item.label)
					yield item
		elif ten == 'khoaa-hoc':
			url = f'http://m.baomoi.com/_next/data/{idbm}/category/khoa-hoc.json'
			resp = getlink(url, url, 1000)
			js = resp.json()
			getjs = js['pageProps']['resp']['data']['content']['items']
			for k in getjs:
				item = Listitem()
				if 'title' in k:
					item.label = k['title']
					item.info['plot'] = k['description']
					linkbm = f'http://m.baomoi.com{k["url"]}'
					item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = k['thumb']
					item.set_callback(play_bm, linkbm, item.label)
					yield item
		elif ten == 'doi-song':
			url = f'http://m.baomoi.com/_next/data/{idbm}/category/doi-song.json'
			resp = getlink(url, url, 1000)
			js = resp.json()
			getjs = js['pageProps']['resp']['data']['content']['items']
			for k in getjs:
				item = Listitem()
				if 'title' in k:
					item.label = k['title']
					item.info['plot'] = k['description']
					linkbm = f'http://m.baomoi.com{k["url"]}'
					item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = k['thumb']
					item.set_callback(play_bm, linkbm, item.label)
					yield item
		elif ten == 'xe-co':
			url = f'http://m.baomoi.com/_next/data/{idbm}/category/xe-co.json'
			resp = getlink(url, url, 1000)
			js = resp.json()
			getjs = js['pageProps']['resp']['data']['content']['items']
			for k in getjs:
				item = Listitem()
				if 'title' in k:
					item.label = k['title']
					item.info['plot'] = k['description']
					linkbm = f'http://m.baomoi.com{k["url"]}'
					item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = k['thumb']
					item.set_callback(play_bm, linkbm, item.label)
					yield item
		elif ten == 'nha-dat':
			url = f'http://m.baomoi.com/_next/data/{idbm}/category/nha-dat.json'
			resp = getlink(url, url, 1000)
			js = resp.json()
			getjs = js['pageProps']['resp']['data']['content']['items']
			for k in getjs:
				item = Listitem()
				if 'title' in k:
					item.label = k['title']
					item.info['plot'] = k['description']
					linkbm = f'http://m.baomoi.com{k["url"]}'
					item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = k['thumb']
					item.set_callback(play_bm, linkbm, item.label)
					yield item
	else:
		yield quangcao()