from codequick import Route, Listitem, run
from resources.lib.kedon import qc, tb, getlink, stream, referer, play_vnm, tiengruoi
from bs4 import BeautifulSoup
from urllib.parse import urlparse
import re
a = urlparse(tiengruoi()[0])
tiengruoi = '%s://%s' % (a.scheme, a.netloc)
@Route.register
def index_90p(plugin, **kwargs):
	resp = getlink(tiengruoi, tiengruoi, 15*60)
	web = BeautifulSoup(resp.content, 'html.parser')
	episodes = web.select('a.item')
	for chinmuoi in episodes:
		item = Listitem()
		title = chinmuoi.select_one('div.title').get_text().strip()
		time = chinmuoi.select_one('div.time').get_text().strip()
		time = time.replace('Chưa diễn ra', '')
		linktrandau = chinmuoi.get('href')
		item.label = '%s %s' % (time, title)
		item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://i.imgur.com/jyM3inb.png'
		item.set_callback(list_90p, linktrandau, item.label)
		yield item

@Route.register
def list_90p(plugin,url,title, **kwargs):
	goc = '%s%s' % (tiengruoi, url)
	resp = getlink(goc, goc, 5*60)
	web = BeautifulSoup(resp.content, 'html.parser')
	dulieu = web.select('ul.pull-left li.item')
	found = False
	if len(dulieu) > 1:
		for chinmuoi in dulieu:
			item = Listitem()
			if chinmuoi.get('data-url'):
				linkchatluong = '%s%s' % (stream(chinmuoi.get('data-url')), referer(tiengruoi))
				item.label = '%s %s' % (chinmuoi.select_one('a').get_text().strip(), title)
				item.info['plot'] = tb
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://i.imgur.com/jyM3inb.png'
				item.set_callback(play_vnm, linkchatluong, item.label, '')
				yield item
	if not found:
		item = Listitem()
		match = re.search(r'video_url = "(.*?)"', resp.text)
		if 'm3u8' in resp.text:
			linkmacdinh = '%s%s' % (stream(match.group(1).strip()), referer(tiengruoi))
		else:
			linkmacdinh = stream(qc)
		item.label = 'Default %s' % title
		item.info['plot'] = tb
		item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://i.imgur.com/jyM3inb.png'
		item.set_callback(play_vnm, linkmacdinh, item.label, '')
		yield item