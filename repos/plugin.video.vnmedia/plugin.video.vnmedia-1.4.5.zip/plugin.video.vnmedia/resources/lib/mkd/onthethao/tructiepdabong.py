from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from resources.lib.kedon import getlink, ifr_xembong, quangcao
import re
@Route.register
def index_ttdb(plugin, **kwargs):
	url = 'https://tructiepdabong1.tv/'
	resp = getlink(url, url, 15*60)
	if resp is not None:
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('div.col-xs-7')
		for episode in episodes:
			item = Listitem()
			linktrandau = '%s%s' % (url, episode.select_one('a.redirectPopup').get('href'))
			title = episode.select_one('div.title').get_text().strip()
			time = episode.select_one('div.time')
			lich = re.search(r'/span>(.*?)<', str(time)).group(1).strip()
			item.label = '%s: %s' % (lich, title)
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = '%sthemes/frontend/default/img/tructiepdabong.png' % url
			item.set_callback(ifr_xembong, linktrandau, item.label)
			yield item
	else:
		yield quangcao()