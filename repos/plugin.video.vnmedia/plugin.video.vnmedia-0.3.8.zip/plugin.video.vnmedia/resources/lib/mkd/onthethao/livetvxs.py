from __future__ import unicode_literals
from codequick import Route, Listitem, run
from datetime import datetime, timedelta, date
from resources.lib.kedon import qc, tb, getlink, stream, ace, play_vnm
from bs4 import BeautifulSoup
@Route.register
def index_livetvxs(plugin, content_type='segment'):
	url = 'http://livetv.sx/export/webmasters.php?lang=en'
	resp = getlink(url, url, 15*60)
	if 'acestream' in resp.text:
		soup = BeautifulSoup(resp.text, 'html.parser')
		episodes = soup.select('tr td')
		for episode in episodes:
			item = Listitem()
			z = episode.select('td[class="time"]')
			for w in z:
				timex = w.text.strip()
				if len(timex)==4:
					y = str(date.today())+'T0'+str(timex)
				else:
					y = str(date.today())+'T'+str(timex)
				z = (datetime.fromisoformat(y) + timedelta(hours=6)).strftime('%H:%M')
			a = episode.select('td a.title')
			for b in a:
				tentran = b.text
			x = episode.select('div a')
			for y in x:
				item.art['thumb'] = 'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg'
				item.art['fanart'] = 'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg'
				acex = y.get('href')
				item.label = z + ' ' + tentran
				linkplay = ace(acex, item.label)
				item.path = linkplay
				item.set_callback(item.path)
				yield item
	else:
		item3 = Listitem()
		linkmacdinh = stream(qc)
		item3.label = 'Đang cập nhật'
		item3.info['plot'] = tb
		item3.art['thumb'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.art['fanart'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.set_callback(play_vnm, linkmacdinh, item3.label, '')
		yield item3