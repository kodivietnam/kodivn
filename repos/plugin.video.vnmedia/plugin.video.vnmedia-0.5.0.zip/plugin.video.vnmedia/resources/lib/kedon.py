from codequick import Resolver, Listitem, run, Script
from bs4 import BeautifulSoup
import inputstreamhelper
import urlquick
import xbmc, xbmcgui, xbmcaddon
import base64
import urllib
import re
import time
import os

__addon__ = xbmcaddon.Addon()
__addonname__ = __addon__.getAddonInfo('name')
__version__ = __addon__.getAddonInfo('version')
__icon__ = __addon__.getAddonInfo('icon')
__settings__ = xbmcaddon.Addon(id='plugin.video.vnmedia')
__addonnoti__ = __addonname__ + ' v' + __version__
useragent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.88 Safari/537.36'
code = 'User-Agent=' + useragent
qc ='https://qtv.vncdn.vn/qtvlive/tv3live.m3u8'
logotv = 'https://i.imgur.com/Mnuw95h.png'
news = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/qc.ass'
tb = 'Nội dung được tìm kiếm từ Internet, VN Media không kiểm soát cũng như không chịu trách nhiệm về nội dung này. Đề nghị khán giả cân nhắc trước khi xem.'

def convert_bytes(size):
	for x in ['bytes', 'KB', 'MB', 'GB', 'TB']:
		if size < 1024.0:
			return "%3.1f %s" % (size, x)
		size /= 1024.0
	return size

def ace(kenh, tenkenh):
	if 'acestream' in kenh:
		tach = kenh.split('//')
		p = tach[1]
	elif ':6878' in kenh:
		if '&' in kenh:
			match = re.search(r'id=(.*?)&', kenh)
			p = match.group(1)
		else:
			tach = kenh.split('id=')
			p = tach[1]
	kenhace = ''.join(("{'label': '", tenkenh.strip(),"', 'action': 'play', 'fanart': '', 'icon': '', 'id': '", p.strip(), "'}"))
	mahoa = base64.b64encode(kenhace.encode('utf-8')).decode('utf-8')
	mahoaa = urllib.parse.quote(mahoa)
	eca = 'plugin://script.module.horus/?' + mahoaa
	return eca

def getlink(url, ref, luu):
	try:
		resp = urlquick.get(url, timeout=20, max_age=luu, headers={'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.88 Safari/537.36','referer': ref})
		resp.encoding = 'utf-8'
		return resp
	except:
		Script.notify(__addonnoti__, 'Lỗi kết nối')
		exit()

def postlink(url, ref, luu):
	try:
		resp = urlquick.post(url, timeout=20, max_age=luu, headers={'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.88 Safari/537.36','referer': ref})
		resp.encoding = 'utf-8'
		return resp
	except:
		Script.notify(__addonnoti__, 'Lỗi kết nối')
		exit()

def postlinktimfs(url, ref, luu):
	try:
		resp = urlquick.post(url, timeout=20, max_age=luu, headers={'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.88 Safari/537.36',
			'referer': ref,
			'authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJuYW1lIjoiZnNoYXJlIiwidXVpZCI6IjcxZjU1NjFkMTUiLCJ0eXBlIjoicGFydG5lciIsImV4cGlyZXMiOjAsImV4cGlyZSI6MH0.WBWRKbFf7nJ7gDn1rOgENh1_doPc07MNsKwiKCJg40U'})
		resp.encoding = 'utf-8'
		return resp
	except:
		Script.notify(__addonnoti__, 'Lỗi kết nối')
		exit()

def mang():
	url = 'https://redirector.googlevideo.com/report_mapping'
	resp = getlink(url, 'https://www.google.com.vn', 0)
	x = resp.text.split('Debug Info')
	return x[0]

def stream(url):
	b = 'User-Agent=' + useragent
	if '|' in url:
		a = url + '&' + b
	elif '?' in url:
		a = url + '|' + b
	elif 'm3u8' in url:
		a = url + '?|' + b
	else:
		a = url
	return a

def referer(url):
	x = '&Origin=' + url + '&verifypeer=false&Referer=' + url
	return x

def replace_all(dict, str):
	for key in dict:
		str = str.replace(key, dict[key])
	return str

def get_user_input():
	kb = xbmc.Keyboard('', 'NumberCode được chia sẻ bởi facebook Hội mê Phim')
	kb.doModal()
	if not kb.isConfirmed():
		return
	query = kb.getText()
	return query

def get_kara_input():
	kb = xbmc.Keyboard('', 'Nhập tên bài hát')
	kb.doModal()
	if not kb.isConfirmed():
		return
	query = kb.getText()
	return query
	
def checkver():
	url = 'https://raw.githubusercontent.com/nguyenducmanh609/kodivn/master/addons.xml'
	resp = getlink(url, url, 0)
	check = re.search(r'plugin.video.vnmedia" version="(.*?)"', resp.text)
	ver = check.group(1)
	if __version__ == ver:
		return xbmcgui.Dialog().ok(__addonnoti__, 'Chào mừng [COLOR red]' + mang() +'[/COLOR]')
	else:
		return xbmcgui.Dialog().ok(__addonnoti__, 'Chào mừng [COLOR red]' + mang() +'[/COLOR]Đã có phiên bản VNM v' + ver + '\nVui lòng cập nhật tiện ích để tránh phát sinh lỗi')
		
def get_info_fs(url):
	resp = getlink(url, url, 60*60)
	soup = BeautifulSoup(resp.text, 'html.parser')
	if '#404' in soup.title.string:
		return 'Tập tin này bị hỏng - 404'
	else:
		return soup.title.string + ' (' + re.search(r'NHANH \| (.*?)<', resp.text).group(1) + ')'

def userpassfs():
	username = __settings__.getSetting('username')
	password = __settings__.getSetting('password')
	if len(username) == 0 or len(password) == 0:
		__addon__.openSettings()
	else:
		payload = '{"app_key":"L2S7R6ZMagggC5wWkQhX2+aDi467PPuftWUMRFSn","user_email":"'+username+'","password":"'+password+'"}'
		head = {'cache-control': 'no-cache', 'User-Agent': 'Vietmediaf /Kodi1.1.99-092019'}
		try:
			resp = urlquick.post('https://api.fshare.vn/api/user/login', data=payload, headers=head, timeout=20, max_age=6*60*60)
			resp.raise_for_status()
		except:
			xbmcgui.Dialog().ok(__addonnoti__, 'Sau 3 lần đăng nhập không thành công, tài khoản sẽ bị khoá 10 phút\nKiểm tra lại tài khoản, mật khẩu, đường truyền Internet...')
			__addon__.openSettings()
			exit()
		token = resp.json()['token']
		session_id = resp.json()['session_id']
		return (token,session_id)

@Resolver.register
def play_vnm(plugin,url,title,drmKey):
	if drmKey !='':
		is_helper = inputstreamhelper.Helper('mpd','com.widevine.alpha')
		if is_helper.check_inputstream():
			return Listitem().from_dict(**{'label': plugin._title,'subtitles':{news},'callback':url,'properties':{'inputstream':is_helper.inputstream_addon,'inputstream.adaptive.manifest_type':'mpd','inputstream.adaptive.license_type':'com.widevine.alpha','inputstream.adaptive.license_key':drmKey +'||R{SSM}|'}})
	elif 'm3u8' in url :
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':url,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
	else:
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':url})

@Resolver.register
def ifr_xoilac(plugin,url,title):
	resp = getlink(url, url, 60*60)
	soup = BeautifulSoup(resp.text, 'html.parser')
	dulieu = soup.body.select('div.embed-responsive-item iframe')
	for xoilac in dulieu:
		ifr = xoilac.get('src')
		layifr = getlink(ifr, url, 0)
		match = re.search(r'urlStream = "(.*?)"', layifr.text)
		linkplay = stream(match.group(1)) + referer(ifr)
		if 'm3u8' in linkplay:
			return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
		else:
			return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay})

@Resolver.register
def ifr_xembong(plugin,url,title):
	resp = getlink(url, url, 0)
	if 'm3u8' in resp.text:
		match = re.search(r'linkStream = \'(.*?)\'', resp.text)
		linkplay = stream(match.group(1)) + referer(url)
	else:
		linkplay = stream(qc)
	return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})

@Resolver.register
def play_fs(plugin,url,title):
	try:
		session_id = userpassfs()[1]
		token = userpassfs()[0]
		payload = {'token': token, 'url': url}
		headerfsvn = {'User-Agent': 'Vietmediaf /Kodi1.1.99-092019', 'Cookie' : 'session_id=' + session_id }
		resp = urlquick.post('https://api.fshare.vn/api/session/download', timeout=30, max_age=0, json=payload, headers=headerfsvn)
		return Listitem().from_dict(**{'label': title,'subtitles' : {news},'callback': resp.json()['location']})
	except:
		xbmcgui.Dialog().ok(__addonnoti__, 'Tập tin này bị hỏng')

@Resolver.register
def play_vieon(plugin,url,title):
	resp = getlink(url, url, 0)
	kq = resp.text
	listplay = re.findall(r'hlsLinkPlay":"(.*?)"', kq)
	if 'm3u8' in listplay[-1]:
		linkplay = stream(listplay[-1]) + referer(url)
	else:
		linkplay = stream(qc)
	if 'm3u8' in linkplay :
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
	else:
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay})

@Resolver.register
def play_vtvrep(plugin,idx, title):
	url = 'https://vtvgo.vn/ajax-get-epg-detail?epg_id=' + str(idx)
	resp = getlink(url, url, 0)
	if 'm3u8' in resp.text:
		linkplay = stream(resp.json()['data'])
	else:
		linkplay = stream(qc)
	if 'm3u8' in linkplay :
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
	else:
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay})