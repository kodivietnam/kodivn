from codequick import Route, Listitem, run
from datetime import datetime, timedelta
from resources.lib.kedon import qc, postlink, tb, stream, referer, play_vnm
@Route.register
def index_rakhoi(plugin, content_type='segment'):
	url = 'https://xem.rakhoi.tv/get-tran-dau-sap-dien-ra/6198ac0ccedadf08cbba36df.html'
	resp = postlink(url, url, 5*60)
	if 'm3u8' in resp.text:
		kq = resp.json()
		for k1 in kq['data']['lives']:
			for k2 in k1['hlsUrls']:
				item1 = Listitem()
				if 'm3u8' in k2['url']:
					time1 = (datetime.fromisoformat(k1['time'][:-1]) + timedelta(hours=7)).strftime('%H:%M %d-%m')
					linktrandau1 = stream(k2['url']) + referer('https://rakhoi5.tv/.html')
					item1.label = k2['name'] + ' ' + time1 + ' ' + k1['teamA']['name'] + '-' + k1['teamB']['name']
					item1.info['plot'] = tb
					item1.art['thumb'] = 'https://rakhoi-tv.com/wp-content/uploads/2021/12/rakhoiTVremake.png'
					item1.art['fanart'] = 'https://rakhoi-tv.com/wp-content/uploads/2021/12/rakhoiTVremake.png'
					item1.set_callback(play_vnm, linktrandau1, item1.label, '')
					yield item1
	else:
		item2 = Listitem()
		linkmacdinh = stream(qc)
		item2.label = 'Đang cập nhật'
		item2.info['plot'] = tb
		item2.art['thumb'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item2.art['fanart'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item2.set_callback(play_vnm, linkmacdinh, item2.label, '')
		yield item2