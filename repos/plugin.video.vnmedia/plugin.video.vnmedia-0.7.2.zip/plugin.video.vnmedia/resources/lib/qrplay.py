from codequick import Route, Listitem, run, Script
import urlquick, xbmcgui, xbmcaddon, xbmcvfs, xbmc, time, os, pyqrcode
from resources.lib.kedon import getlink, get_user_input, get_info_fs, play_fs, postlinktimfs, convert_bytes, quangcao
from resources.lib.mkd.onfshare.ifshare import index_fs

ADDON = xbmcaddon.Addon()
CWD = ADDON.getAddonInfo('path')
PROFILE = ADDON.getAddonInfo('profile')
REMOTE_URL = 'http://fshare.fun/remote/'
SERVICE_URL = 'http://fshare.fun/api/v1/get'
PIN = ''
COMMAND = {}


@Route.register
def qrplay(plugin, content_type='segment'):
    global PIN, COMMAND
    PIN = create_pin()
    if (PIN == ''):
        Script.notify(ADDON.getAddonInfo('name'), 'Lỗi kết nối')
    else:
        url = '%s%s' % (REMOTE_URL, PIN)
        imagefile = os.path.join(xbmcvfs.translatePath(PROFILE), '%s.png' % PIN)
        qrIMG = pyqrcode.create(url)
        qrIMG.png(imagefile, scale=10)
        message = 'Hãy scan QR bằng điện thoại [CR]Hoặc [CR]Vào url: [B]%s[/B][CR]để nhập Fshare link hoặc từ khóa tìm kiếm' % url
        qr = QRCode("pin-dialog.xml", CWD, "default",
                    image=imagefile, text=message)
        qr.doModal()
        del qr
        xbmcvfs.delete(imagefile)
        if 'message' in COMMAND.keys() and COMMAND['message'] != '':
            fshareUrlStr = COMMAND['recommend']
            if (COMMAND['message'].find('http') != -1):
                fshareUrlStr = '%s,%s' % (
                    fshareUrlStr, COMMAND['message'].replace(" ", ","))
            fshareUrls = fshareUrlStr.split(',')
            for fshareUrl in fshareUrls:
                if fshareUrl != '':
                    item = Listitem()
                    x = fshareUrl
                    item.label = get_info_fs(x)
                    item.info['plot'] = x
                    item.art['thumb'] = 'http://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=0&size=400x400&ecc=L' % item.info['plot']
                    item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
                    item.set_callback(play_fs, x, item.label)
                    yield item

            if (COMMAND['message'].find('http') == -1):
                url = 'https://api.timfshare.com/v1/string-query-search?query=%s' % COMMAND['message']
                resp = postlinktimfs(url, 'https://timfshare.com/', 48*60*60)
                kq = resp.json()
                for k in kq['data']:
                    item = Listitem()
                    if 'file' in k['url']:
                        item.label = k['name'] + \
                            ' (' + convert_bytes(k['size']) + ')'
                        item.info['plot'] = k['url']
                        linkplay = k['url']
                        item.art['thumb'] = 'http://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=0&size=400x400&ecc=L' % item.info['plot']
                        item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
                        item.set_callback(play_fs, linkplay, item.label)
                        yield item
        else:
            yield quangcao()
        COMMAND = {}
def create_pin():
    try:
        params = {'command': 'get_pin', 'customer': '-get_pin'}
        res = urlquick.post(SERVICE_URL, data=params, timeout=20, max_age=0).json()
        return res
    except:
        return ''
class QRCode(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.image = kwargs["image"]
        self.text = kwargs["text"]

    def onInit(self):
        self.imagecontrol = 1001
        self.textbox = 1002
        self.okbutton = 1003
        self.showdialog()
        self.getCommand()

    def showdialog(self):
        self.getControl(self.imagecontrol).setImage(self.image)
        self.getControl(self.textbox).setText(self.text)
        self.setFocus(self.getControl(self.okbutton))
        self.windowId = xbmcgui.getCurrentWindowDialogId()

    def onClick(self, controlId):
        if (controlId == self.okbutton):
            xbmcgui.Window(10000).setProperty('waiting_command', 'false')
            self.close()

    def getCommand(self):
        global COMMAND
        max_waiting_time = time.time() + 120
        while self.windowId == xbmcgui.getCurrentWindowDialogId() and max_waiting_time > time.time():
            remaining = round(max_waiting_time-time.time())
            xbmc.sleep(1000)
            self.getControl(self.textbox).setText(
                self.text + '[CR][CR]Thời gian chờ còn lại: %d giây' % remaining)
            params = {
                'command': 'get_command',
                'pin': PIN
            }
            try:
                res = urlquick.post(SERVICE_URL, data=params, timeout=20, max_age=0).json()
                if res['status'] == '1':
                    COMMAND = res
                    self.close()
                    break
            except:
                pass
        self.close()