from codequick import Route, Listitem, Resolver
from importlib import import_module
from urllib.parse import urlparse
from bs4 import BeautifulSoup
@Route.register
def index_91phut(plugin, **kwargs):
	w = import_module('resources.lib.kedon')
	v = urlparse(w.fu('http://hqth.me/91phut'))
	url = f'{v.scheme}://{v.netloc}/vb-ajax.php?action=filter_match&filter=all&league='
	resp = w.getlink(url, url, 1000)
	if (resp is not None):
		soup = BeautifulSoup(resp.json()['data']['html'], 'html.parser')
		for episode in soup.select('div.position-relative.match'):
			item = Listitem()
			try:
				item.label = f"{episode.select_one('a.link-match').get('title')} - BLV: {episode.select_one('span.text-ellipsis').get_text(strip=True)}"
			except:
				item.label = episode.select_one('a.link-match').get('title')
			item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/mitom.png'
			item.set_callback(list_91phut, episode.select_one('a.link-match').get('href'), item.label)
			yield item
	else:
		yield w.quangcao()
@Route.register
def list_91phut(plugin, url, title, **kwargs):
	w = import_module('resources.lib.kedon')
	resp = w.getlink(url, url, 400)
	if (resp is not None):
		soup = BeautifulSoup(resp.content, 'html.parser')
		for episode in soup.select('div.link-video a'):
			item = Listitem()
			item.label = f'{episode.get_text(strip=True)} - {title}'
			item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/mitom.png'
			item.set_callback(Resolver.ref('/resources/lib/kedon:ifr_bongda'), episode.get('href'), item.label)
			yield item
	else:
		yield w.quangcao()