from codequick import Route, Listitem, Resolver
from importlib import import_module
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import re
def respphut90():
	tr1 = 'http://thapcam.tv/tc/js/main.js'
	resp90 = import_module('resources.lib.kedon').getlink(tr1, tr1, 1000)
	if (resp90 is not None):
		html_content = re.sub(r"(\n\s*//.*)", "", resp90.content.decode())
		ref = re.search(r'base_embed_url\s*=\s*("|\')([^"\s]+)("|\')', html_content)[1]
	else:
		ref = tr1
	return ref
def get_tv1():
	return import_module('resources.lib.kedon').getlinkvnm('https://api.thapcam.xyz/api/match/featured', 'http://thapcam.tv/')
def get_tv2():
	return import_module('resources.lib.kedon').getlinkvnm('https://api.thapcam.xyz/api/match/live', 'http://thapcam.tv/')
@Route.register
def index_thapcam(plugin, **kwargs):
	w = import_module('resources.lib.kedon')
	ref = respphut90()
	with ThreadPoolExecutor(2) as ex:
		f1 = ex.submit(get_tv1)
		f2 = ex.submit(get_tv2)
		resp1 = f1.result()
		resp2 = f2.result()
	if (resp1 is not None) or (resp2 is not None):
		for k1 in resp1.json()['data']:
			item1 = Listitem()
			time = datetime.fromtimestamp(int(k1['timestamp'])/1000).strftime('%H:%M %d-%m')
			if k1['commentators']:
				item1.label = f'[B]{time}: {k1["name"]} ({k1["commentators"][0]["name"]})[/B]'
			else:
				item1.label = f'[B]{time}: {k1["name"]}[/B]'
			item1.info['plot'] = w.tb
			item1.art['thumb'] = item1.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/thapcamtv.png'
			item1.set_callback(list_thapcam, k1['id'], item1.label)
			yield item1
		for k2 in resp2.json()['data']:
			if k2['match_status'] == 'live' or k2['match_status'] == 'pending':
				item2 = Listitem()
				time = datetime.fromtimestamp(int(k2['timestamp'])/1000).strftime('%H:%M %d-%m')
				if k2['commentators']:
					item2.label = f'{time}: {k2["name"]} ({k2["commentators"][0]["name"]})'
				else:
					item2.label = f'{time}: {k2["name"]}'
				item2.info['plot'] = w.tb
				item2.art['thumb'] = item2.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/thapcamtv.png'
				item2.set_callback(list_thapcam, k2['id'], item2.label)
				yield item2
	else:
		yield w.quangcao()
@Route.register
def list_thapcam(plugin, idk, title, **kwargs):
	w = import_module('resources.lib.kedon')
	ref = respphut90()
	url = f'http://api.thapcam.xyz/api/match/{idk}/meta'
	resp = w.getlink(url, ref, 400)
	if (resp is not None) and ('.m3u8' in resp.text):
		kq = resp.json()
		for k in kq['data']['play_urls']:
			item = Listitem()
			item.label = f'{k["name"]} - {title}'
			linktrandau = f'{w.stream(k["url"])}{w.referer(ref)}'
			item.info['plot'] = w.tb
			item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/vebo.png'
			item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), linktrandau, item.label, '')
			yield item
	else:
		yield w.quangcao()