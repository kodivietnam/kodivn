from codequick import Route, Listitem, Resolver
from importlib import import_module
@Route.register
def index_gglive(plugin, **kwargs):
	w = import_module('resources.lib.kedon')
	ref = 'https://gglive.vn/'
	url = 'https://gglive.vn/api/livestream/list?page=1&page_size=1000'
	resp = w.getlinkvnm(url, ref)
	if (resp is not None):
		for m in resp.json()['data']:
			item = Listitem()
			item.label = f'{m["title"]} ({m["user"]["full_name"]})'
			item.info['plot'] = w.tb
			item.art['thumb'] = item.art['fanart'] = m['thumb']
			item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), f'{w.stream(m["hls"])}{w.referer(ref)}', item.label, '')
			yield item
	else:
		yield w.quangcao()