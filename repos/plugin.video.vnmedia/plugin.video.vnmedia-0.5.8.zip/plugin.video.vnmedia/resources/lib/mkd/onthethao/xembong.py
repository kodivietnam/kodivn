from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from resources.lib.kedon import getlink, ifr_xembong
@Route.register
def index_xembong(plugin, content_type='segment'):
	url = 'https://xembong.co'
	resp = getlink(url, url, 15*60)
	soup = BeautifulSoup(resp.text, 'html.parser')
	episodes = soup.select('div[class="grid-matches__item"] a[class="redirectPopup"]')
	for episode in episodes:
		item = Listitem()
		linktrandau = url + episode.get('href')
		time = episode.select_one('div[class="grid-match__hour"]').text.strip()
		day = episode.select_one('div[class="grid-match__day"]').text.strip()
		title = episode.select_one('a').get('title')
		item.label = time + '-' + day + ': ' + title
		item.art['thumb'] = 'https://xembong.co/themes/frontend/default/img/logo.png'
		item.art['fanart'] = 'https://xembong.co/themes/frontend/default/img/logo.png'
		item.set_callback(ifr_xembong, linktrandau, item.label)
		yield item