from codequick import Route, Listitem, run
from datetime import datetime, timedelta
from resources.lib.kedon import qc, tb, getlink, stream, referer, play_vnm
@Route.register
def index_cakhia(plugin, content_type='segment'):
	url = 'https://cakhia16.tv/node-cache/get-lives-home'
	resp = getlink(url, url, 5*60)
	if 'm3u8' in resp.text:
		kq = resp.json()
		for k1 in kq['data']['liveMatchings']:
			for k2 in k1['hlsUrls']:
				item1 = Listitem()
				if 'm3u8' in k2['url']:
					time1 = (datetime.fromisoformat(k1['time'][:-1]) + timedelta(hours=7)).strftime('%H:%M %d-%m')
					linktrandau1 = stream(k2['url']) + referer('https://cakhia16.tv/.html')
					item1.label = k2['name'] + ' ' + time1 + ' ' + k1['teamA']['name'] + '-' + k1['teamB']['name']
					item1.info['plot'] = tb
					item1.art['thumb'] = 'https://cakhiastatic.fastlycdnlive.xyz/cakhia/cakhia33/user/img/ckstrim.png'
					item1.art['fanart'] = 'https://cakhiastatic.fastlycdnlive.xyz/cakhia/cakhia33/user/img/ckstrim.png'
					item1.set_callback(play_vnm, linktrandau1, item1.label, '')
					yield item1
		for b1 in kq['data']['livesSapDienRa']:
			for b2 in b1['hlsUrls']:
				item2 = Listitem()
				if 'm3u8' in b2['url']:
					time2 = (datetime.fromisoformat(b1['time'][:-1]) + timedelta(hours=7)).strftime('%H:%M %d-%m')
					linktrandau2 = stream(b2['url']) + referer('https://cakhia16.tv/.html')
					item2.label = b2['name'] + ' ' + time2 + ' ' + b1['teamA']['name'] + '-' + b1['teamB']['name']
					item2.info['plot'] = tb
					item2.art['thumb'] = 'https://cakhiastatic.fastlycdnlive.xyz/cakhia/cakhia33/user/img/ckstrim.png'
					item2.art['fanart'] = 'https://cakhiastatic.fastlycdnlive.xyz/cakhia/cakhia33/user/img/ckstrim.png'
					item2.set_callback(play_vnm, linktrandau2, item2.label, '')
					yield item2
	else:
		item3 = Listitem()
		linkmacdinh = stream(qc)
		item3.label = 'Đang cập nhật'
		item3.info['plot'] = tb
		item3.art['thumb'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.art['fanart'] = 'http://mku.edu.vn/dist/2021/11/anh-dang-cap-nhat.jpg'
		item3.set_callback(play_vnm, linkmacdinh, item3.label, '')
		yield item3