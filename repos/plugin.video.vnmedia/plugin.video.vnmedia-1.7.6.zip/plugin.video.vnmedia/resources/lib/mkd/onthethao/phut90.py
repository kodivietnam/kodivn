from codequick import Route, Listitem, run
from resources.lib.kedon import getlink, stream, tiengruoi, referer, play_vnm, quangcao, tb, re
import datetime
resp90 = getlink(tiengruoi()[0], tiengruoi()[0], 0)
if resp90 is not None:
	ref = re.search(r'  window.base_embed_url(.*?)"(.*?)"', resp90.text).group(2)
else:
	ref = tiengruoi()[0]
@Route.register
def index_90p(plugin, **kwargs):
	url = 'http://api.vebo.xyz/api/match/featured/mt'
	resp = getlink(url, ref, 1000)
	if resp is not None:
		kq = resp.json()
		for k in kq['data']:
			item = Listitem()
			time = datetime.datetime.fromtimestamp(int(k['timestamp'])/1000).strftime('%H:%M %d-%m')
			idk = k['id']
			if k['commentators']:
				item.label = f'{time}: {k["name"]} ({k["commentators"][0]["name"]})'
			else:
				item.label = f'{time}: {k["name"]}'
			item.info['plot'] = tb
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://i.imgur.com/jyM3inb.png'
			item.set_callback(list_90p, idk, item.label)
			yield item
	else:
		yield quangcao()
@Route.register
def list_90p(plugin, idk, title, **kwargs):
	url = f'http://api.vebo.xyz/api/match/{idk}/meta'
	resp = getlink(url, ref, 400)
	if resp is not None:
		if '.m3u8' in resp.text:
			kq = resp.json()
			for k in kq['data']['play_urls']:
				item = Listitem()
				item.label = f'{k["name"]} - {title}'
				linktrandau = f'{stream(k["url"])}{referer(ref)}'
				item.info['plot'] = tb
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://i.imgur.com/jyM3inb.png'
				item.set_callback(play_vnm, linktrandau, item.label, '')
				yield item
		else:
			yield quangcao()
	else:
		yield quangcao()