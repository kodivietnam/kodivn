from requests import Session
from xbmc import executebuiltin
from xbmcaddon import Addon
from shutil import rmtree
from os.path import exists
from xbmcvfs import translatePath
def autorun_addon():
    executebuiltin('UpdateAddonRepos()')
    packages_path = translatePath('special://home/addons/packages')
    if Addon().getSetting('auto_run') == 'true':
        executebuiltin('RunAddon(plugin.video.vnmedia)')
    if Addon().getSetting('auto_noti') == 'true':
        r = Session().get('http://speedtest.vn/get-ip-info', timeout=20, headers={'user-agent': 'okhttp/4.10.0'})
        a = ' '.join([c for c in reversed(r.json().values())]) if (r is not None) else 'VNNIC error'
        executebuiltin(f'Notification("KODI VIỆT NAM", {a}, 10000, {Addon().getAddonInfo("icon")})')
    if exists(packages_path):
        try:
            rmtree(packages_path)
        except:
            pass
autorun_addon()