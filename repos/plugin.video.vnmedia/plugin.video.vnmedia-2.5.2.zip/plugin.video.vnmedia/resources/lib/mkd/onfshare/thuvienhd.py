from codequick import Route, Listitem, Script, Resolver
from importlib import import_module
from bs4 import BeautifulSoup
from xbmcgui import DialogProgress
from urllib.parse import quote_plus
from xbmcaddon import Addon
from requests import Session
from concurrent.futures import ThreadPoolExecutor, as_completed
import re
@Route.register
def search_thuvienhd(plugin,search_query, **kwargs):
	w = import_module('resources.lib.kedon')
	dp = DialogProgress()
	dp.create(w.__addonnoti__, 'Đang lấy dữ liệu...')
	dp.update(5)
	sr = quote_plus(search_query)
	url = f'http://thuvienhd.com/?s={sr.replace(" ","+")}'
	urlrf = 'https://thuvienhd.com'
	resp = w.getlink(url, urlrf, 10000)
	if (resp is not None):
		match = re.search(r'"nonce":"(.*?)"', resp.text)[1]
		urltv = f'http://thuvienhd.com/wp-json/dooplay/search/?nonce={match}&keyword={sr}'
		r = w.getlink(urltv, urlrf, 10000)
		if 'No results' in r.text:
			yield w.quangcao()
		else:
			for k in r.json().values():
				item = Listitem()
				item.label = k['title']
				item.info['plot'] = w.tb
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = w.yttk(item.label)
				item.art['thumb'] = item.art['fanart'] = k['img']
				item.set_callback(thuvienhd_linktk, k['url'])
				yield item
	else:
		yield w.quangcao()
	dp.update(100)
	dp.close()
@Route.register
def index_thuvienhd(plugin, **kwargs):
	w = import_module('resources.lib.kedon')
	yield Listitem.search(search_thuvienhd)
	url = 'http://thuvienhd.com/'
	resp = w.getlink(url, url, 10000)
	if (resp is not None):
		soup = BeautifulSoup(resp.content, 'html.parser')
		for episode in soup.select('ul.genres.falsescroll li a'):
			if 'thuvienhd.com' in episode.get('href'):
				item = Listitem()
				item.label = episode.get_text(strip=True)
				item.info['plot'] = w.tb
				item.art['thumb'] = item.art['fanart'] = f'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/thuvienhd.png'
				item.set_callback(thuvienhd_page, f'{episode.get("href")}/page/', 1)
				yield item
	else:
		yield w.quangcao()
@Route.register
def thuvienhd_linktk(plugin, url, **kwargs):
	w = import_module('resources.lib.kedon')
	respx = w.getlink(url, url, 10000)
	if (respx is not None):
		t = BeautifulSoup(respx.content, 'html.parser').select_one('span.box__download a').get('href')
		resp = w.getlink(t, url, 10000)
		if (resp is not None):
			urls = re.findall(r'https?://(?:www\.)?fshare\.vn/(?:file|folder)/[^\s\'"]+', resp.text)
			length = len(urls)
			dialog = DialogProgress()
			dialog.create(w.__addonnoti__, 'Đang lấy dữ liệu...')
			dialog.update(5, f'Đang giải mã {length} dữ liệu...')
			if length>0:
				with ThreadPoolExecutor(length) as ex:
					future_to_url = {ex.submit(w.get_info_fs, url): url for url in urls}
					for future in as_completed(future_to_url):
						link = future_to_url[future]
						data = future.result()
						if 'folder' in link:
							item = Listitem()
							item.label = data[0]
							item.info['plot'] = w.tb
							item.info['mediatype'] = 'episode'
							item.info['rating'] = 10.0
							item.info['trailer'] = w.yttk(item.label)
							item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={link}&qzone=1&margin=1&size=400x400&ecc=L'
							item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
							item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
							item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), link.split('folder/')[1], 1)
							yield item
						elif 'file' in link:
							item = Listitem()
							item.label = data[0]
							item.info['plot'] = w.tb
							item.info['size'] = data[1]
							item.info['mediatype'] = 'episode'
							item.info['rating'] = 10.0
							item.info['trailer'] = w.yttk(item.label)
							item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={link}&qzone=1&margin=1&size=400x400&ecc=L'
							item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
							if Addon().getSetting('taifshare') == 'true':
								item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', link)
							item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
							item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), link, item.label)
							yield item
						dialog.update(50)
			else:
				yield w.quangcao()
			dialog.update(100)
			dialog.close()
		else:
			yield w.quangcao()
	else:
		yield w.quangcao()
@Route.register
def thuvienhd_page(plugin, url, next_page, **kwargs):
	w = import_module('resources.lib.kedon')
	trangtiep = f'{url}{next_page}'
	resp = w.getlink(trangtiep, trangtiep, 5000)
	if (resp is not None):
		soup = BeautifulSoup(resp.content, 'html.parser')
		for episode in soup.select('div.items article'):
			item = Listitem()
			item.label = episode.select_one('img').get('alt')
			item.info['plot'] = f"{episode.select_one('div.texto').get_text(strip=True)}\n{w.tb}" if 'texto' in resp.text else w.tb
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = w.yttk(item.label)
			item.art['thumb'] = item.art['fanart'] = episode.select_one('img').get('src')
			item.set_callback(thuvienhd_link, episode.get('id').split('-')[1])
			yield item
		for checkpage in soup.select('div.pagination a'):
			if str(next_page + 1) in checkpage.get_text(strip=True):
				item1 = Listitem()
				item1.label = f'Trang {next_page + 1}'
				item1.art['thumb'] = item1.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
				item1.set_callback(thuvienhd_page, url, next_page + 1)
				yield item1
	else:
		yield w.quangcao()
@Route.register
def thuvienhd_link(plugin, idk, **kwargs):
	w = import_module('resources.lib.kedon')
	t = f'http://thuvienhd.com/download?id={idk}'
	resp = w.getlink(t, t, 10000)
	if (resp is not None):
		urls = re.findall(r'https?://(?:www\.)?fshare\.vn/(?:file|folder)/[^\s\'"]+', resp.text)
		length = len(urls)
		dialog = DialogProgress()
		dialog.create(w.__addonnoti__, 'Đang lấy dữ liệu...')
		dialog.update(5, f'Đang giải mã {length} dữ liệu...')
		if length>0:
			with ThreadPoolExecutor(length) as ex:
				future_to_url = {ex.submit(w.get_info_fs, url): url for url in urls}
				for future in as_completed(future_to_url):
					link = future_to_url[future]
					data = future.result()
					if 'folder' in link:
						item = Listitem()
						item.label = data[0]
						item.info['plot'] = w.tb
						item.info['mediatype'] = 'episode'
						item.info['rating'] = 10.0
						item.info['trailer'] = w.yttk(item.label)
						item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={link}&qzone=1&margin=1&size=400x400&ecc=L'
						item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
						item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
						item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), link.split('folder/')[1], 1)
						yield item
					elif 'file' in link:
						item = Listitem()
						item.label = data[0]
						item.info['plot'] = w.tb
						item.info['size'] = data[1]
						item.info['mediatype'] = 'episode'
						item.info['rating'] = 10.0
						item.info['trailer'] = w.yttk(item.label)
						item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={link}&qzone=1&margin=1&size=400x400&ecc=L'
						item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
						if Addon().getSetting('taifshare') == 'true':
							item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', link)
						item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
						item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), link, item.label)
						yield item
					dialog.update(50)
		else:
			yield w.quangcao()
		dialog.update(100)
		dialog.close()
	else:
		yield w.quangcao()