from codequick import Route, Listitem, run
@Route.register
def root(plugin, content_type='video'):
    item = Listitem()
    item.label = 'CLOSED'
    item.info['mediatype'] = 'tvshow'
    item.art['thumb'] = item.art['poster'] = 'https://www.shutterstock.com/image-vector/sorry-we-closed-sign-on-600nw-1403010206.jpg'
    item.set_callback('plugin://plugin.video.vietmediaf')
    yield item
if __name__ == '__main__':
    run()