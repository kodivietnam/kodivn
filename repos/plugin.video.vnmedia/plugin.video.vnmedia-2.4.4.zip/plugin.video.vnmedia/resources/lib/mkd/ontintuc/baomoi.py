from codequick import Route, Listitem, Resolver
from importlib import import_module
from functools import lru_cache
import re
@Route.register
def index_baomoi(plugin, **kwargs):
	yield nong()
	yield moi()
	yield thegioi()
	yield xahoi()
	yield vanhoa()
	yield kinhte()
	yield giaoduc()
	yield thethao()
	yield bongda()
	yield giaitri()
	yield phapluat()
	yield congnghe()
	yield khoahoc()
	yield doisong()
	yield xeco()
	yield nhadat()
@lru_cache(maxsize=None)
def nong():
	item = Listitem()
	item.label = 'Tin Nóng'
	item.art['thumb'] = item.art['fanart'] = 'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'home')
	return item
@lru_cache(maxsize=None)
def moi():
	item = Listitem()
	item.label = 'Tin mới'
	item.art['thumb'] = item.art['fanart'] = 'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'new')
	return item
@lru_cache(maxsize=None)
def thegioi():
	item = Listitem()
	item.label = 'Thế giới'
	item.art['thumb'] = item.art['fanart'] = 'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'the-gioi')
	return item
@lru_cache(maxsize=None)
def xahoi():
	item = Listitem()
	item.label = 'Xã hội'
	item.art['thumb'] = item.art['fanart'] = 'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'xa-hoi')
	return item
@lru_cache(maxsize=None)
def vanhoa():
	item = Listitem()
	item.label = 'Văn hoá'
	item.art['thumb'] = item.art['fanart'] = 'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'van-hoa')
	return item
@lru_cache(maxsize=None)
def kinhte():
	item = Listitem()
	item.label = 'Kinh tế'
	item.art['thumb'] = item.art['fanart'] = 'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'kinh-te')
	return item
@lru_cache(maxsize=None)
def giaoduc():
	item = Listitem()
	item.label = 'Giáo dục'
	item.art['thumb'] = item.art['fanart'] = 'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'giao-duc')
	return item
@lru_cache(maxsize=None)
def thethao():
	item = Listitem()
	item.label = 'Thể thao'
	item.art['thumb'] = item.art['fanart'] = 'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'the-thao')
	return item
@lru_cache(maxsize=None)
def bongda():
	item = Listitem()
	item.label = 'Bóng đá'
	item.art['thumb'] = item.art['fanart'] = 'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'football')
	return item
@lru_cache(maxsize=None)
def giaitri():
	item = Listitem()
	item.label = 'Giải trí'
	item.art['thumb'] = item.art['fanart'] = 'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'giai-tri')
	return item
@lru_cache(maxsize=None)
def phapluat():
	item = Listitem()
	item.label = 'Pháp luật'
	item.art['thumb'] = item.art['fanart'] = 'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'phap-luat')
	return item
@lru_cache(maxsize=None)
def congnghe():
	item = Listitem()
	item.label = 'Công nghệ'
	item.art['thumb'] = item.art['fanart'] = 'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'khoa-hoc-cong-nghe')
	return item
@lru_cache(maxsize=None)
def khoahoc():
	item = Listitem()
	item.label = 'Khoa học'
	item.art['thumb'] = item.art['fanart'] = 'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'khoaa-hoc')
	return item
@lru_cache(maxsize=None)
def doisong():
	item = Listitem()
	item.label = 'Đời sống'
	item.art['thumb'] = item.art['fanart'] = 'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'doi-song')
	return item
@lru_cache(maxsize=None)
def xeco():
	item = Listitem()
	item.label = 'Xe cộ'
	item.art['thumb'] = item.art['fanart'] = 'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'xe-co')
	return item
@lru_cache(maxsize=None)
def nhadat():
	item = Listitem()
	item.label = 'Nhà đất'
	item.art['thumb'] = item.art['fanart'] = 'https://cdn.pixabay.com/photo/2016/09/04/17/46/news-1644696_960_720.png'
	item.set_callback(list_baomoi, 'nha-dat')
	return item
@Route.register
def list_baomoi(plugin, ten, **kwargs):
	w = import_module('resources.lib.kedon')
	r = w.getlinkvnm('https://m.baomoi.com','https://m.baomoi.com')
	if r is not None and 'buildId":"' in r.text:
		idbm = re.search(r'buildId":"(.*?)"', r.text)[1]
		if (ten == 'home') or (ten == 'new'):
			url = f'https://m.baomoi.com/_next/data/{idbm}/{ten}.json'
		else:
			url = f'https://m.baomoi.com/_next/data/{idbm}/category/{ten}.json'
		kq = w.getlinkvnm(url, 'https://m.baomoi.com').json()
		getjs = kq['pageProps']['resp']['data']['content']['items']
		for k in getjs:
			if 'title' in k:
				item = Listitem()
				item.label = k['title']
				item.info['plot'] = k['description']
				linkbm = f'https://m.baomoi.com{k["url"]}'
				item.art['thumb'] = item.art['fanart'] = k['thumb']
				item.set_callback(Resolver.ref('/resources/lib/kedon:play_bm'), linkbm, item.label)
				yield item
	else:
		yield w.quangcao()