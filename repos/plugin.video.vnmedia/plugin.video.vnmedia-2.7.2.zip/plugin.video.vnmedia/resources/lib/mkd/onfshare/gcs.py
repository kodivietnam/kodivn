from codequick import Route, Listitem, Script, Resolver
from resources.lib.kedon import getlink, fu, yttk, tb, getrow, quangcao, __addonnoti__
from xbmcaddon import Addon
from json import loads
from functools import lru_cache
from urllib.parse import unquote
import re
@Route.register
def index_gcs(plugin, **kwargs):
    if u:= Addon().getSetting('TextURL'):
        respx = getlink(u, u, 6000)
        if (respx is not None):
            x = fu(u)
            if 'docs.google.com' in x:
                if 'gid' in x:
                    timid = re.findall(r'/d/(.*?)/.*?gid=(\d+)', x)
                    sid = timid[0][0]
                    gid = timid[0][1]
                else:
                    sid = re.findall(r'/d/(.*?)/', x)[0]
                    gid = '0'
                url = f'https://docs.google.com/spreadsheets/d/{sid}/gviz/tq?gid={gid}&headers=1'
                resp = getlink(url, url, 6000)
                if (resp is not None):
                    try:
                        noi = re.search(r'\{.*\}', resp.text)[0]
                        m = loads(noi)
                        cols = m['table']['cols']
                        rows = m['table']['rows']
                        if 'http' in cols[1]['label']:
                            item = Listitem()
                            kenh = cols[1]['label']
                            item.label = cols[0]['label']
                            item.info['mediatype'] = 'movie'
                            item.info['rating'] = 10.0
                            item.info['trailer'] = yttk(item.label)
                            item.art['thumb'] = cols[2]['label'] if len(cols) > 2 else 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare.png'
                            item.info['plot'] = f"{cols[3]['label']}\n{tb}" if len(cols) > 3 else tb
                            item.art['fanart'] = cols[4]['label'] if len(cols) > 4 else (cols[2]['label'] if len(cols) > 2 else 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare.png')
                            set_item_callbacks(item, kenh, item.label)
                            yield item
                        for cow in cols:
                            p = cow['label']
                            if '|http' in p:
                                yield create_listitem_from_link(p, '[COLOR red]VN Media[/COLOR]')
                        for row in rows:
                            k = getrow(row['c'][0])
                            if '|http' in k:
                                yield create_listitem_from_link(k, '[COLOR red]VN Media[/COLOR]')
                            elif 'http' in getrow(row['c'][1]):
                                item = Listitem()
                                item.label = k
                                item.info['mediatype'] = 'movie'
                                item.info['rating'] = 10.0
                                item.info['trailer'] = yttk(item.label)
                                kenh = getrow(row['c'][1])
                                item.art['thumb'] = getrow(row['c'][2]) if len(row['c']) > 2 else 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare.png'
                                item.info['plot'] = f"{getrow(row['c'][3])}\n{tb}" if len(row['c']) > 3 else tb
                                item.art['fanart'] = getrow(row['c'][4]) if len(row['c']) > 4 else (getrow(row['c'][2]) if len(row['c']) > 2 else 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare.png')
                                set_item_callbacks(item, kenh, item.label)
                                yield item
                            else:
                                yield []
                    except:
                        yield []
                else:
                    yield []
            else:
                tach = (ll.rstrip() for ll in respx.iter_lines(decode_unicode=True) if ll.strip())
                for k in tach:
                    yield listitemvmf(k, '[COLOR red]VN Media[/COLOR]')
        else:
            yield quangcao()
    else:
        Script.notify(__addonnoti__, 'Vui lòng nhập Link trong cài đặt của VN Media')
        yield quangcao()
@Route.register
def listgg_gcs(plugin, urltext, title):
    if 'gid' in urltext:
        timid = re.findall(r'/d/(.+?)/.+?gid=(\d+)', urltext)
        sid = timid[0][0]
        gid = timid[0][1]
    else:
        sid = re.findall(r'/d/(.*?)/', urltext)[0]
        gid = '0'
    url = f'https://docs.google.com/spreadsheets/d/{sid}/gviz/tq?gid={gid}&headers=1'
    resp = getlink(url, url, 6000)
    if (resp is not None):
        try:
            noi = re.search(r'\{.*\}', resp.text)[0]
            m = loads(noi)
            cols = m['table']['cols']
            rows = m['table']['rows']
            if 'http' in cols[1]['label']:
                item = Listitem()
                kenh = cols[1]['label']
                item.label = cols[0]['label']
                item.info['mediatype'] = 'movie'
                item.info['rating'] = 10.0
                item.info['trailer'] = yttk(item.label)
                item.art['thumb'] = cols[2]['label'] if len(cols) > 2 else 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare.png'
                item.info['plot'] = f"{cols[3]['label']}\n{tb}" if len(cols) > 3 else f'{title}\n{tb}'
                item.art['fanart'] = cols[4]['label'] if len(cols) > 4 else (cols[2]['label'] if len(cols) > 2 else 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare.png')
                set_item_callbacks(item, kenh, item.label)
                yield item
            for cow in cols:
                p = cow['label']
                if '|http' in p:
                    yield create_listitem_from_link(p, title)
            for row in rows:
                k = getrow(row['c'][0])
                if '|http' in k:
                    yield create_listitem_from_link(k, title)
                elif 'http' in getrow(row['c'][1]):
                    item = Listitem()
                    item.label = k
                    item.info['mediatype'] = 'movie'
                    item.info['rating'] = 10.0
                    item.info['trailer'] = yttk(item.label)
                    kenh = getrow(row['c'][1])
                    item.art['thumb'] = getrow(row['c'][2]) if len(row['c']) > 2 else 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare.png'
                    item.info['plot'] = f"{getrow(row['c'][3])}\n{tb}" if len(row['c']) > 3 else f'{title}\n{tb}'
                    item.art['fanart'] = getrow(row['c'][4]) if len(row['c']) > 4 else (getrow(row['c'][2]) if len(row['c']) > 2 else 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare.png')
                    set_item_callbacks(item, kenh, item.label)
                    yield item
                else:
                    yield []
        except:
            yield quangcao()
    else:
        yield quangcao()
@Route.register
def listvmf_gcs(plugin, url, title):
    resp = getlink(url, url, 600)
    if (resp is not None) and (resp.content):
        tach = (ll.rstrip() for ll in resp.iter_lines(decode_unicode=True) if ll.strip())
        for k in tach:
            yield listitemvmf(k, '[COLOR red]VN Media[/COLOR]')
    else:
        yield quangcao()
@lru_cache(maxsize=None)
def set_item_callbacks(item, kenh, title):
    script = Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo')
    taifshare = Addon().getSetting('taifshare')
    if 'fshare.vn/folder' in kenh:
        item.context.script(script, 'Thêm vào Fshare Favorite', kenh)
        item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), kenh, 0)
    elif 'fshare.vn/file' in kenh:
        item.context.script(script, 'Thêm vào Fshare Favorite', kenh)
        if taifshare == 'true':
            item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', kenh)
        item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), kenh, item.label)
    elif 'docs.google.com' in kenh:
        item.set_callback(listgg_gcs, kenh, title)
    elif 'VMF' in kenh:
        item.set_callback(listvmf_gcs, kenh.replace('VMF-', ''), title)
    else:
        item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), unquote(kenh), item.label, '')
@lru_cache(maxsize=None)
def create_listitem_from_link(link, title):
    tachhat = link.split('|')
    if tachhat[1] and len(tachhat) > 1:
        item = Listitem()
        kenh = tachhat[1]
        item.label = tachhat[0].translate(str.maketrans({'*': '', '@': ''}))
        item.info['mediatype'] = 'movie'
        item.info['rating'] = 10.0
        item.info['trailer'] = yttk(item.label)
        item.art['thumb'] = tachhat[3] if len(tachhat) > 3 else 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare.png'
        item.info['plot'] = f'{tachhat[4]}\n{tb}' if len(tachhat) > 4 else f'{title}\n{tb}'
        item.art['fanart'] = tachhat[5] if len(tachhat) > 5 else (tachhat[3] if len(tachhat) > 3 else 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare.png')
        set_item_callbacks(item, kenh, item.label)
        return item
@lru_cache(maxsize=None)
def listitemvmf(link, title):
    tachhat = link.split('|')
    if len(tachhat) > 1:
        item = Listitem()
        kenh = tachhat[1]
        item.label = tachhat[0].translate(str.maketrans({'*': '', '@': ''}))
        item.info['mediatype'] = 'episode'
        item.info['rating'] = 10.0
        item.info['trailer'] = yttk(item.label)
        item.art['thumb'] = tachhat[3] if len(tachhat) > 3 else 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare.png'
        item.info['plot'] = f'{tachhat[4]}\n{tb}' if len(tachhat) > 4 else f'{title}\n{tb}'
        item.art['fanart'] = tachhat[5] if len(tachhat) > 5 else (tachhat[3] if len(tachhat) > 3 else 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare.png')
        set_item_callbacks(item, kenh, item.label)
        return item