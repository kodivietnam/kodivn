from codequick import Route, Listitem, run
from resources.lib.kedon import tb, postlinktimfs, play_fs, __addonnoti__, getlink, __addon__, getlinkphongblack, yttk
from resources.lib.mkd.onfshare.ifshare import index_fs, tfavo
from resources.lib.download import downloadfs
import xbmcgui, urllib, re
@Route.register
def searchfs(plugin, search_query, **kwargs):
	dp = xbmcgui.DialogProgress()
	dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
	dp.update(0)
	search_query = urllib.parse.quote_plus(search_query)
	urlvmf = f'http://phongblack.me/search.php?author=phongblack&search={search_query}'
	respvmf = getlinkphongblack(urlvmf, 'http://www.google.com', 3600)
	if respvmf is not None:
		x = respvmf.json()['items']
		for m in x:
			item1 = Listitem()
			ten = re.sub('[\[\]\{\}]','|', m['label'])
			if 'info' in m:
				mota = m['info']['plot']
			path = m['path']
			if '/file/' in path:
				item1.label = ten
				link = path.split('&url=')
				linkplay = link[1]
				item1.info['mediatype'] = 'episode'
				item1.info['rating'] = 10.0
				item1.info['trailer'] = yttk(item1.label)
				item1.art['thumb'] = item1.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
				item1.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item1.info['plot'] = mota
				if __addon__.getSetting("taifshare") == "true":
					item1.context.script(downloadfs, 'Tải về', linkplay)
				item1.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
				item1.set_callback(play_fs, linkplay, item1.label)
				yield item1
			elif '/folder/' in path:
				item1.label = ten
				link = path.split('&url=')
				linkplay = link[1]
				thumuc = linkplay.split('folder/')
				item1.info['mediatype'] = 'episode'
				item1.info['rating'] = 10.0
				item1.info['trailer'] = yttk(item1.label)
				item1.art['thumb'] = item1.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
				item1.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item1.info['plot'] = mota
				item1.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
				item1.set_callback(index_fs, thumuc[1], 1)
				yield item1
	else:
		yield []
	url = f'https://api.timfshare.com/v1/string-query-search?query={search_query}'
	resp = postlinktimfs(url, 'https://timfshare.com/', 3600)
	if resp is not None:
		kq = resp.json()
		if kq['data']:
			for k in kq['data']:
				item = Listitem()
				linkplay = k['url']
				if 'folder' in linkplay:
					item.label = k['name']
					thumuc = linkplay.split('folder/')
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(item.label)
					item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
					item.set_callback(index_fs, thumuc[1], 1)
					yield item
				elif 'file' in linkplay:
					item.label = k['name']
					item.info['size'] = k['size']
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(item.label)
					item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					if __addon__.getSetting("taifshare") == "true":
						item.context.script(downloadfs, 'Tải về', linkplay)
					item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
					item.set_callback(play_fs, linkplay, item.label)
					yield item
	else:
		yield []
	urltvhd = f'https://thuvienhd.com/?feed=fsharejson&search={search_query}'
	resptvhd = getlink(urltvhd, 'https://thuvienhd.com/', 3600)
	if resptvhd is not None:
		kqtvhd = resptvhd.json()
		for t in kqtvhd:
			for d in t['links']:
				item = Listitem()
				linkplay = d['link']
				if 'folder' in linkplay:
					item.label = d['title']
					thumuc = linkplay.split('folder/')
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(item.label)
					item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
					item.set_callback(index_fs, thumuc[1], 1)
					yield item
				elif 'file' in linkplay:
					item.label = d['title']
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(item.label)
					item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={linkplay}&qzone=1&margin=1&size=400x400&ecc=L'
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					if __addon__.getSetting("taifshare") == "true":
						item.context.script(downloadfs, 'Tải về', linkplay)
					item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
					item.set_callback(play_fs, linkplay, item.label)
					yield item
	else:
		yield []
	dp.update(100)
	dp.close()
@Route.register
def index_pdx(plugin, **kwargs):
	urltvhd = 'https://thuvienhd.com/?feed=fsharejson&search='
	resptvhd = getlink(urltvhd, 'https://thuvienhd.com/', 3600)
	if resptvhd is not None:
		kqtvhd = resptvhd.json()
		for t in kqtvhd:
			for d in t['links']:
				item = Listitem()
				linkplay = d['link']
				if 'folder' in linkplay:
					item.label = d['title']
					thumuc = linkplay.split('folder/')
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(item.label)
					item.info['plot'] = t['title']
					item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = t['image']
					item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
					item.set_callback(index_fs, thumuc[1], 1)
					yield item
				elif 'file' in linkplay:
					item.label = d['title']
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(item.label)
					item.info['plot'] = t['title']
					item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = t['image']
					if __addon__.getSetting("taifshare") == "true":
						item.context.script(downloadfs, 'Tải về', linkplay)
					item.context.script(tfavo, 'Thêm vào Fshare Favorite', linkplay)
					item.set_callback(play_fs, linkplay, item.label)
					yield item
	else:
		yield []