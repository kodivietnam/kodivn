from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from resources.lib.kedon import getlink, ifr_xembong
@Route.register
def index_bongdat(plugin, **kwargs):
	url = 'https://bongdat.website'
	resp = getlink(url, url, 15*60)
	soup = BeautifulSoup(resp.content, 'html.parser')
	episodes = soup.select('ul.box_timeList_table_ul li')
	for episode in episodes:
		item = Listitem()
		item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://bongdat.life/themes/frontend/default/img/logo.png'
		linktrandau = '%s%s' % (url, episode.select_one('a').get('href'))
		item.label = episode.text.replace('\n', ' ').replace('    ', ' ').strip()
		item.set_callback(ifr_xembong, linktrandau, item.label)
		yield item