from codequick import Route, Listitem, run
from datetime import datetime, timedelta, date
from resources.lib.kedon import quangcao, getlink, stream, ace
from bs4 import BeautifulSoup
@Route.register
def index_highlights365(plugin, **kwargs):
	url = 'https://highlights365.com/broadcasts'
	resp = getlink(url, url, 15*60)
	soup = BeautifulSoup(resp.content, 'html.parser')
	episodes = soup.select('div.broadcast-item')
	for episode in episodes:
		linktrans = episode.select('div.team-info a')
		for linktran in linktrans:
			link = linktran.get('href')
			ten = linktran.text
		times = episode.select('div.time')
		for time in times:
			item = Listitem()
			timex = time.text
			if len(timex)==4:
				y = '%sT0%s' % (date.today(), timex)
			else:
				y = '%sT%s' % (date.today(), timex)
			z = (datetime.fromisoformat(y) + timedelta(hours=7)).strftime('%H:%M')
			item.label = '%s %s' % (z, ten)
			anh = episode.select_one('div.c-flag img').get('data-src')
			item.art['thumb'] = item.art['landscape'] = 'https:%s' % anh
			item.art['fanart'] = 'https://highlights365.com/static/images/highlights365/logo_header.png'
			item.set_callback(laylink_highlights365, 'https://highlights365.com%s' % link, item.label)
			yield item

@Route.register
def laylink_highlights365(plugin, url, ten, **kwargs):
	resp = getlink(url, url, 15*60)
	if 'acestream://' in resp.text:
		soup = BeautifulSoup(resp.content, 'html.parser')
		links = soup.select('div.link-list.acestream a')
		for index, number in enumerate(links):
			item = Listitem()
			linktran = number.get('href')
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg'
			item.label = 'Link %s-%s' % (index+1, ten)
			linkplay = ace(linktran, item.label)
			item.path = linkplay
			item.set_callback(item.path)
			yield item
	else:
		yield quangcao()