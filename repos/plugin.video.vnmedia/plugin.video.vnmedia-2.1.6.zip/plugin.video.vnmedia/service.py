import xbmc, xbmcaddon, urllib3, json
from resources.lib.kedon import getlinkvnm
def autorun_addon():
    xbmc.executebuiltin('UpdateAddonRepos()')
    if xbmcaddon.Addon().getSetting('auto_run') == 'true':
        xbmc.executebuiltin('RunAddon(plugin.video.vnmedia)')
    if xbmcaddon.Addon().getSetting('auto_noti') == 'true':
        url = 'https://speedtest.vn/get-ip-info'
        r = getlinkvnm(url, url)
        d = json.loads(r.data.decode('utf-8'))
        a = ''
        for k,v in d.items():
            a += f'{v} '
        xbmc.executebuiltin(f'Notification("KODI VIỆT NAM", {a}, 10000, {xbmcaddon.Addon().getAddonInfo("icon")})')
    return
autorun_addon()