from codequick import Route, Listitem, run, Resolver
from resources.lib.kedon import tb, getlink, quangcao, qc, stream
from resources.lib.mkd.onfshare.ifshare import logincsn
from resources.lib.mkd.ontintuc.mocha import index_mocha
from bs4 import BeautifulSoup
import re
CATEcsnmusic = {
'BXH Nhạc Việt Nam': 'http://chiasenhac.vn/nhac-hot/vietnam.html',
'BXH Nhạc US-UK': 'http://chiasenhac.vn/nhac-hot/us-uk.html',
'BXH Nhạc Beat - Không lời': 'http://chiasenhac.vn/nhac-hot/beat-playback.html',
'BXH Nhạc Hoa': 'http://chiasenhac.vn/nhac-hot/chinese.html',
'BXH Nhạc Hàn': 'http://chiasenhac.vn/nhac-hot/korea.html',
'BXH Nhạc Nhật': 'http://chiasenhac.vn/nhac-hot/japan.html',
'BXH Nhạc Pháp': 'http://chiasenhac.vn/nhac-hot/france.html',
'BXH Nhạc Nước khác': 'http://chiasenhac.vn/nhac-hot/other.html'}
CATEcsnvideo = {
'BXH Video Việt Nam': 'http://chiasenhac.vn/nhac-hot/video/v-video.html',
'BXH Video US-UK': 'http://chiasenhac.vn/nhac-hot/video/us-video.html',
'BXH Video Hoa': 'http://chiasenhac.vn/nhac-hot/video/c-video.html',
'BXH Video Hàn': 'http://chiasenhac.vn/nhac-hot/video/k-video.html',
'BXH Video Nhật': 'http://chiasenhac.vn/nhac-hot/video/j-video.html',
'BXH Video Pháp': 'http://chiasenhac.vn/nhac-hot/video/f-video.html',
'BXH Video Nước khác': 'http://chiasenhac.vn/nhac-hot/video/o-video.html'}
@Route.register
def index_amnhac(plugin, **kwargs):
	BVNmusic = {'label': 'Bảng xếp hạng bài hát',
	'info': {'plot': 'Bảng xếp hạng bài hát'},
	'art': {'thumb': 'https://chiasenhac.vn/images/logo-header.png',
	'fanart': 'https://chiasenhac.vn/images/logo-header.png'},
	'callback': index_bxhmusic}
	BVNvideo = {'label': 'Bảng xếp hạng video',
	'info': {'plot': 'Bảng xếp hạng video'},
	'art': {'thumb': 'https://chiasenhac.vn/images/logo-header.png',
	'fanart': 'https://chiasenhac.vn/images/logo-header.png'},
	'callback': index_bxhvideo}
	yield Listitem.from_dict(**BVNmusic)
	yield Listitem.from_dict(**BVNvideo)
	yield videomusic()
@Route.register
def index_bxhmusic(plugin, **kwargs):
	for tenlist, urllist in list(CATEcsnmusic.items()):
		item = Listitem()
		item.label = tenlist
		item.info['plot'] = tb
		item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://chiasenhac.vn/images/logo-header.png'
		item.set_callback(list_bxhmusic, url=urllist)
		yield item
@Route.register
def index_bxhvideo(plugin, **kwargs):
	for tenlist, urllist in list(CATEcsnvideo.items()):
		item = Listitem()
		item.label = tenlist
		item.info['plot'] = tb
		item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://chiasenhac.vn/images/logo-header.png'
		item.set_callback(list_bxhvideo, url=urllist)
		yield item
@Route.register
def list_bxhmusic(plugin, url, **kwargs):
	r = getlink(url, url, 1000)
	try:
		if 'card-footer' in r.text:
			sre = re.compile("\((.*)\)")
			soup = BeautifulSoup(r.content, 'html.parser')
			episodes = soup.select('div.element.mb-2.card-footer')
			for episode in episodes:
				item = Listitem()
				linktrandau = episode.select_one('a').get('href')
				anh = episode.select_one('div.image').get('style')
				linkanh = sre.search(anh).group(1)
				tenbai = episode.select_one('div.content h6').get_text()
				casi = episode.select_one('p.name_singer').get_text()
				chatluong = episode.select_one('p.loss').get_text()
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = linkanh
				item.label = f'{tenbai} ({casi}) - {chatluong}'
				item.set_callback(playcsn, linktrandau, item.label)
				yield item
		else:
			yield quangcao()
	except:
		yield quangcao()
@Route.register
def list_bxhvideo(plugin, url, **kwargs):
	r = getlink(url, url, 1000)
	try:
		if 'card-footer' in r.text:
			sre = re.compile("\((.*)\)")
			soup = BeautifulSoup(r.content, 'html.parser')
			episodes = soup.select('div.element.py-3.border-bottom.card-footer')
			for episode in episodes:
				item = Listitem()
				linktrandau = episode.select_one('a').get('href')
				anh = episode.select_one('div.image').get('style')
				linkanh = sre.search(anh).group(1)
				tenbai = episode.select_one('div.content h6').get_text()
				casi = episode.select_one('p.name_singer').get_text()
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = linkanh
				item.label = f'{tenbai} ({casi})'
				item.set_callback(playcsn, linktrandau, item.label)
				yield item
		else:
			yield quangcao()
	except:
		yield quangcao()
@Resolver.register
def playcsn(plugin, url, title, **kwargs):
	news = 'http://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/qc.ass'
	if 'http' in url:
		a = url
	else:
		a = f'https://chiasenhac.vn{url}'
	r = logincsn().get(a)
	try:
		linkplay = re.findall(r'download_item" href="(.*?)"', r.text)[-2]
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay})
	except:
		linkplay = stream(qc)
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay,'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream':'inputstream.adaptive'}})
def videomusic():
	item = Listitem()
	page = 0
	idk = 4
	item.label = 'Video Nhạc hay'
	item.info['plot'] = tb
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://png.pngtree.com/element_our/png_detail/20181022/music-and-live-music-logo-with-neon-light-effect-vector-png_199406.jpg'
	item.set_callback(index_mocha, idk, page)
	return item