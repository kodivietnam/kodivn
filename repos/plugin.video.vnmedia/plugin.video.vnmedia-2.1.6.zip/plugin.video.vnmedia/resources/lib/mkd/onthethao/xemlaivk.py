from codequick import Route, Listitem, run
from resources.lib.kedon import quangcao, useragent, play_vk, tb
import urlquick, html
@Route.register
def index_xemlaivk(plugin, **kwargs):
	kenhxem = {
	'Nổi bật': '536336236',
	'Tiengruoi': '-214691467',
	'90Phut': '-214584571',
	'Vebo': '743378311',
	'Binhluan': '606949250'}
	for tenkenh, idkenh in list(kenhxem.items()):
		item = Listitem()
		item.label = tenkenh
		item.info['plot'] = tb
		item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://upload.wikimedia.org/wikipedia/commons/e/e1/Replay-Logo-HD.png'
		item.set_callback(list_xemlaivk, idkenh, item.label)
		yield item
@Route.register
def list_xemlaivk(plugin, idpl, title, **kwargs):
	headers = {'origin': 'https://vk.com', 'referer': 'https://vk.com/', 'user-agent': useragent, 'x-requested-with': 'XMLHttpRequest'}
	data = {'al': '1', 'need_albums': '0', 'offset': '0', 'oid': idpl, 'rowlen': '3', 'section': 'all', 'snippet_video': '0'}
	url = 'https://vk.com/al_video.php?act=load_videos_silent'
	r = urlquick.post(url, data=data, headers=headers, max_age=1000)
	try:
		a = r.json()['payload'][1][0]['all']['list']
		for k in a:
			item = Listitem()
			idvd1 = k[0]
			idvd2 = k[1]
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = k[2]
			item.label = html.unescape(k[3])
			item.set_callback(play_vk, idvd1, idvd2, item.label)
			yield item
	except:
		yield quangcao()