from codequick import Route, Listitem, run
from resources.lib.kedon import getlink, tiengruoi, quangcao, tb, stream, referer, play_vnm
import re, datetime
def respphut90():
	tr1 = tiengruoi()[1]
	resp90 = getlink(tr1, tr1, 0)
	try:
		ref = re.search(r'  window.base_embed_url(.*?)"(.*?)"', resp90.text).group(2)
	except:
		ref = tr1
	return ref
@Route.register
def index_vebo(plugin, **kwargs):
	url = 'http://api.vebo.xyz/api/match/featured'
	ref = respphut90()
	resp = getlink(url, ref, 1000)
	try:
		kq = resp.json()
		for k in kq['data']:
			item = Listitem()
			time = datetime.datetime.fromtimestamp(int(k['timestamp'])/1000).strftime('%H:%M %d-%m')
			idk = k['id']
			if k['commentators']:
				item.label = f'{time}: {k["name"]} ({k["commentators"][0]["name"]})'
			else:
				item.label = f'{time}: {k["name"]}'
			item.info['plot'] = tb
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://90m.link/images/logo-01.png'
			item.set_callback(list_vebo, idk, item.label)
			yield item
	except:
		yield quangcao()
@Route.register
def list_vebo(plugin, idk, title, **kwargs):
	ref = respphut90()
	url = f'http://api.vebo.xyz/api/match/{idk}/meta'
	resp = getlink(url, ref, 400)
	try:
		kq = resp.json()
		for k in kq['data']['play_urls']:
			item = Listitem()
			item.label = f'{k["name"]} - {title}'
			linktrandau = f'{stream(k["url"])}{referer(ref)}'
			item.info['plot'] = tb
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://90m.link/images/logo-01.png'
			item.set_callback(play_vnm, linktrandau, item.label, '')
			yield item
	except:
		yield quangcao()