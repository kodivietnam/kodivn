from codequick import Route, Listitem, run
from resources.lib.kedon import getlink, quangcao, ifr_bongda
from bs4 import BeautifulSoup
@Route.register
def index_91phut(plugin, **kwargs):
	url = 'http://hqth.me/91phut'
	resp = getlink(url, url, 1000)
	try:
		soup = BeautifulSoup(resp.json()['data']['html'], 'html.parser')
		episodes = soup.select('a.redirectPopup')
		for episode in episodes:
			item = Listitem()
			linktrandau = episode.get('href')
			item.label = episode.get('title')
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://thesaigontimes.vn/Uploads/Articles/277259/707bc_untitled_1.jpg'
			item.set_callback(list_91phut, linktrandau, item.label)
			yield item
	except:
		yield quangcao()
@Route.register
def list_91phut(plugin, url, title, **kwargs):
	resp = getlink(url, url, 400)
	try:
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('div.link-video a')
		for episode in episodes:
			item = Listitem()
			linktrandau = episode.get('href')
			item.label = f'{episode.get_text().strip()} - {title}'
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://thesaigontimes.vn/Uploads/Articles/277259/707bc_untitled_1.jpg'
			item.set_callback(ifr_bongda, linktrandau, item.label)
			yield item
	except:
		yield quangcao()