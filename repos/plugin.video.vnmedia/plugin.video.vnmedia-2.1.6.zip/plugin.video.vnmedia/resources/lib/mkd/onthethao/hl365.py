from codequick import Route, Listitem, run
from resources.lib.kedon import quangcao, getlink, ace
from datetime import datetime, timedelta, date
from bs4 import BeautifulSoup
@Route.register
def index_highlights365(plugin, **kwargs):
	url = 'http://highlights365.com/broadcasts'
	resp = getlink(url, url, 1000)
	try:
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('div.broadcast-item')
		for episode in episodes:
			linktrans = episode.select('div.team-info a')
			for linktran in linktrans:
				link = linktran.get('href')
				ten = linktran.get_text()
			times = episode.select('div.time')
			for time in times:
				item = Listitem()
				timex = time.get_text()
				if len(timex)==4:
					y = f'{date.today()}T0{timex}'
				else:
					y = f'{date.today()}T{timex}'
				z = (datetime.fromisoformat(y) + timedelta(hours=7)).strftime('%H:%M')
				item.label = f'{z} {ten}'
				anh = episode.select_one('div.c-flag img').get('data-src')
				item.art['thumb'] = item.art['landscape'] = f'https:{anh}'
				item.art['fanart'] = 'https://highlights365.com/static/images/highlights365/logo_header.png'
				item.set_callback(laylink_highlights365, f'https://highlights365.com{link}', item.label)
				yield item
	except:
		yield quangcao()

@Route.register
def laylink_highlights365(plugin, url, ten, **kwargs):
	resp = getlink(url, url, 1000)
	try:
		soup = BeautifulSoup(resp.content, 'html.parser')
		links = soup.select('div.link-list.acestream a')
		for index, number in enumerate(links):
			item = Listitem()
			linktran = number.get('href')
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg'
			item.label = f'Link {index+1}-{ten}'
			linkplay = ace(linktran, item.label)
			item.path = linkplay
			item.set_callback(item.path)
			yield item
	except:
		yield quangcao()