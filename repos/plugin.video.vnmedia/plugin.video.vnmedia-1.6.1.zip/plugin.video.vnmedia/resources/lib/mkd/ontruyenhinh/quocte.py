from codequick import Route, Listitem, run
from resources.lib.kedon import logotv, tb
from resources.lib.mkd.ontruyenhinh.listiptv import list_iptv
CATEGORIES = {
'Hoạt hình': 'https://iptv-org.github.io/iptv/categories/animation.m3u',
'Tự động': 'https://iptv-org.github.io/iptv/categories/auto.m3u',
'Kinh doanh': 'https://iptv-org.github.io/iptv/categories/business.m3u',
'Cổ điển': 'https://iptv-org.github.io/iptv/categories/classic.m3u',
'Hài': 'https://iptv-org.github.io/iptv/categories/comedy.m3u',
'Nấu ăn': 'https://iptv-org.github.io/iptv/categories/cooking.m3u',
'Văn hoá': 'https://iptv-org.github.io/iptv/categories/culture.m3u',
'Tài liệu': 'https://iptv-org.github.io/iptv/categories/documentary.m3u',
'Giáo dục': 'https://iptv-org.github.io/iptv/categories/education.m3u',
'Giải trí': 'https://iptv-org.github.io/iptv/categories/entertainment.m3u',
'Gia đình': 'https://iptv-org.github.io/iptv/categories/family.m3u',
'Tổng hợp': 'https://iptv-org.github.io/iptv/categories/general.m3u',
'Thiếu nhi': 'https://iptv-org.github.io/iptv/categories/kids.m3u',
'Pháp luật': 'https://iptv-org.github.io/iptv/categories/legislative.m3u',
'Đời sống': 'https://iptv-org.github.io/iptv/categories/lifestyle.m3u',
'Bản địa': 'https://iptv-org.github.io/iptv/categories/local.m3u',
'Ca nhạc': 'https://iptv-org.github.io/iptv/categories/music.m3u',
'Phim ảnh': 'https://iptv-org.github.io/iptv/categories/movies.m3u',
'Tin tức': 'https://iptv-org.github.io/iptv/categories/news.m3u',
'Thiên nhiên': 'https://iptv-org.github.io/iptv/categories/outdoor.m3u',
'Thư giãn': 'https://iptv-org.github.io/iptv/categories/relax.m3u',
'Tôn giáo': 'https://iptv-org.github.io/iptv/categories/religious.m3u',
'Khoa học': 'https://iptv-org.github.io/iptv/categories/science.m3u',
'Dài kỳ': 'https://iptv-org.github.io/iptv/categories/series.m3u',
'Mua bán': 'https://iptv-org.github.io/iptv/categories/shop.m3u',
'Thể thao': 'https://iptv-org.github.io/iptv/categories/sports.m3u',
'Du lịch': 'https://iptv-org.github.io/iptv/categories/travel.m3u',
'Thời tiết': 'https://iptv-org.github.io/iptv/categories/weather.m3u',
'Khác': 'https://iptv-org.github.io/iptv/categories/other.m3u'
}
@Route.register
def listiptv_qt(plugin, **kwargs):
	for tenlist, urllist in list(CATEGORIES.items()):
		item = Listitem()
		item.label = tenlist
		item.info['plot'] = tb
		item.art['thumb'] = item.art['landscape'] = logotv
		item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
		item.set_callback(list_iptv, url=urllist)
		yield item