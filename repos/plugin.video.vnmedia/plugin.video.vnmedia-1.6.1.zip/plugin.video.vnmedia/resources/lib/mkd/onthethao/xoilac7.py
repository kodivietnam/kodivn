from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from resources.lib.kedon import getlink, ifr_bongda, quangcao
mx = 'https://xoilac5.net/'
@Route.register
def index_xoilac7(plugin, **kwargs):
	url = f'{mx}vb-ajax.php?action=filter_match&filter=all&league='
	resp = getlink(url, mx, 1000)
	if resp is not None:
		soup = BeautifulSoup(resp.json()['data']['html'], 'html.parser')
		episodes = soup.select('div.grid-match')
		for episode in episodes:
			item = Listitem()
			linktrandau = episode.select_one('a.redirectPopup').get('href')
			ten = episode.select_one('a.redirectPopup').get('title')
			blv = episode.select_one('div.grid-match__commentator').get_text().strip()
			if blv:
				item.label = f'{ten} - {blv}'
			else:
				item.label = ten
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = f'{mx}wp-content/themes/bongda/dist/images/xoilac7.net.png'
			item.set_callback(list_xoilac7, linktrandau, item.label)
			yield item
	else:
		yield quangcao()
@Route.register
def list_xoilac7(plugin, url, title, **kwargs):
	resp = getlink(url, url, 400)
	if resp is not None:
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('div#tv_links a.text-center')
		for episode in episodes:
			item = Listitem()
			linktrandau = episode.get('href')
			item.label = f'{episode.get_text().strip()} - {title}'
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = f'{mx}wp-content/themes/bongda/dist/images/xoilac7.net.png'
			item.set_callback(ifr_bongda, linktrandau, item.label)
			yield item
	else:
		yield quangcao()