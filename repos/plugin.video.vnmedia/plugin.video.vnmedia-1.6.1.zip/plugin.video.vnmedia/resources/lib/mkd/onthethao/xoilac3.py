from codequick import Route, Listitem, run
from resources.lib.kedon import quangcao, getlink, stream, referer, play_vnm, xembd
from bs4 import BeautifulSoup
from urllib.parse import urlparse
l = xembd()[2]
m = urlparse(l)
linkweb = f'{m.scheme}://{m.netloc}'
@Route.register
def index_xoilac3(plugin, **kwargs):
	url = 'https://s2.zencdn.xyz/static/json/common/live.json'
	resp = getlink(url, url, 400)
	if resp is not None:
		if 'link' in resp.text:
			kq = resp.json()
			for k in kq:
				item = Listitem()
				linktrandau = f'{linkweb}{k["link"]}'
				if k['cmt']:
					item.label = f'{k["time"]}: {k["title"]} - BLV {k["cmt"]}'
				else:
					item.label = f'{k["time"]}: {k["title"]}'
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = f'{linkweb}{k["cover"]}'
				item.set_callback(list_xoilac3, linktrandau, item.label)
				yield item
		else:
			yield quangcao()
	else:
		yield quangcao()
@Route.register
def list_xoilac3(plugin,url,title, **kwargs):
	resp = getlink(url, url, 1000)
	if resp is not None:
		if '.m3u8' in resp.text:
			web = BeautifulSoup(resp.content, 'html.parser')
			for k in web.body.select('video-js.video-js source'):
				item = Listitem()
				linktrandau = f'{stream(k.get("src"))}{referer(linkweb)}'
				item.label = f'{k.get("label")} - {title}'
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = f'{linkweb}/wp-content/uploads/2022/06/logo-xoilac-tv-1.jpg'
				item.set_callback(play_vnm, linktrandau, item.label, '')
				yield item
		else:
			yield quangcao()
	else:
		yield quangcao()