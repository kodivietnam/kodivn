from codequick import Route, Listitem, run, Script
from bs4 import BeautifulSoup
from resources.lib.kedon import quangcao, getlink, play_fs, __addonnoti__, get_info_fs
from resources.lib.mkd.onfshare.ifshare import index_fs, loginfhdvn, likehdvn, tfavo
from resources.lib.download import downloadfs
import xbmcgui, urllib, re, threading
threads = []
dulieu = {}
def get_html(link):
    dulieu[link] = get_info_fs(link)
nhomhdvn = {
'4K': 'https://hdvietnam.org/forums/4k.337/',
'WEB-DL, HDTV 4K': 'https://hdvietnam.org/forums/web-dl-hdtv-4k.344/',
'Bluray Remux 4K': 'https://hdvietnam.org/forums/bluray-remux-4k.345/',
'Bluray Nguyên Gốc 4K': 'https://hdvietnam.org/forums/bluray-nguyen-goc-4k.346/',
'Fshare.vn': 'https://hdvietnam.org/forums/fshare-vn.33/',
'Fshare-WEB-DL, HDTV': 'https://hdvietnam.org/forums/web-dl-hdtv.271/',
'Fshare-Bluray Remux': 'https://hdvietnam.org/forums/bluray-remux.324/',
'Fshare-mHD, SD': 'https://hdvietnam.org/forums/mhd-sd.77/',
'Fshare-Bluray nguyên gốc': 'https://hdvietnam.org/forums/bluray-nguyen-goc.78/',
'Thư viện link Phim': 'https://hdvietnam.org/forums/thu-vien-link-phim.150/',
'Phim có audio Việt': 'https://hdvietnam.org/forums/phim-co-audio-viet.265/',
'Phim bộ - Series': 'https://hdvietnam.org/forums/phim-bo-series.57/',
'Phim bộ - mHD, SD': 'https://hdvietnam.org/forums/mhd-sd.104/',
'Phim hoạt hình': 'https://hdvietnam.org/forums/phim-hoat-hinh.123/',
'Phim hoạt hình - mHD, SD': 'https://hdvietnam.org/forums/mhd-sd.124/',
'Phim tài liệu - Documentaries': 'https://hdvietnam.org/forums/phim-tai-lieu-documentaries.116/',
'Phim 3D': 'https://hdvietnam.org/forums/3d.110/',
'Phim cho iOS/Android': 'https://hdvietnam.org/forums/phim-cho-ios-android.157/'
}
@Route.register
def search_hdvn(plugin,search_query, **kwargs):
    dp = xbmcgui.DialogProgress()
    dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
    dp.update(0)
    search_query = urllib.parse.quote_plus(search_query)
    url = 'https://hdvietnam.org/search/2022/?page=1&q=%s&t=post&o=date&c[node]=337+344+345+346+33+271+324+77+78' % search_query.replace(' ','+')
    r = getlink(url, url, 2*24*60*60)
    idsearch = re.search(r'search/([0-9]+)', r.url).group(1)
    if 'titleText' in r.text:
        soup = BeautifulSoup(r.content, 'html.parser')
        episodes = soup.select('div.titleText a')
        for episode in episodes:
            item = Listitem()
            item.label = episode.get_text()
            linkphim = episode.get('href')
            item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://hdvietnam.org/images/hd-vietnam-logo.png'
            item.set_callback(hdvn_link, linkphim)
            yield item
        yield Listitem.next_page(search_query, 2, idsearch, callback=search_hdvnnext)
    else:
        Script.notify(__addonnoti__, 'Không tìm thấy kết quả')
        yield quangcao()
    dp.update(100)
    dp.close()

@Route.register
def search_hdvnnext(plugin,search_query, next_page, idsearch, **kwargs):
    search_query = urllib.parse.quote_plus(search_query)
    url = 'https://hdvietnam.org/search/%s/?page=%s&q=%s&t=post&o=date&c[node]=337+344+345+346+33+271+324+77+78' % (idsearch, next_page, search_query.replace(' ','+'))
    r = getlink(url, url, 2*24*60*60)
    if 'titleText' in r.text:
        soup = BeautifulSoup(r.content, 'html.parser')
        episodes = soup.select('div.titleText a')
        for episode in episodes:
            item = Listitem()
            item.label = episode.get_text()
            linkphim = episode.get('href')
            item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://hdvietnam.org/images/hd-vietnam-logo.png'
            item.set_callback(hdvn_link, linkphim)
            yield item
        item1 = Listitem()
        item1.label = 'Trang %s' % (next_page + 1)
        item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
        item1.set_callback(search_hdvnnext, search_query, next_page + 1, idsearch)
        yield item1
    else:
        Script.notify(__addonnoti__, 'Không tìm thấy kết quả')
        yield quangcao()
@Route.register
def index_hdvn(plugin, **kwargs):
    yield Listitem.search(search_hdvn)
    for tenlist, urllist in list(nhomhdvn.items()):
        item = Listitem()
        item.label = tenlist
        item.art['thumb'] = item.art['landscape'] = 'https://hdvietnam.org/images/hd-vietnam-logo.png'
        item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
        item.set_callback(hdvn_page, url=urllist, next_page=1)
        yield item

@Route.register
def hdvn_page(plugin, url, next_page, **kwargs):
    trangtiep = '%spage-%s' % (url, next_page)
    r = getlink(trangtiep, trangtiep, 15*60)
    soup = BeautifulSoup(r.content, 'html.parser')
    episodes = soup.select('a.PreviewTooltip')
    for episode in episodes:
        item = Listitem()
        linkphim = episode.get('href')
        p = episode.get_text()
        item.label = re.sub('[\[\]\{\}]','|', p)
        item.art['thumb'] = item.art['landscape'] = 'https://hdvietnam.org/images/hd-vietnam-logo.png'
        item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
        item.set_callback(hdvn_link, linkphim)
        yield item
    item1 = Listitem()
    item1.label = 'Trang %s' % (next_page + 1)
    item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
    item1.set_callback(hdvn_page, url, next_page + 1)
    yield item1

@Route.register
def hdvn_link(plugin, url, **kwargs):
    likehdvn(url)
    r = loginfhdvn().get('https://hdvietnam.org/%s' % url)
    if 'fshare.vn' in r.text:
        soup = BeautifulSoup(r.content, 'html.parser')
        episodes = soup.select('a.externalLink')
        urls = []
        for episode in episodes:
            if 'fshare.vn' in episode.get('href'):
                linkphim = episode.get('href')
                urls.append(linkphim)
        length = len(episodes)
        done = len(urls)
        progress = int(done * 100 / length)
        dialog = xbmcgui.DialogProgress()
        dialog.create('%s đang giải mã...' % __addonnoti__, 'Đang giải mã %d dữ liệu...' % length)
        dialog.update(progress, 'Đang giải mã %d/%d dữ liệu...' % (done, length))
        for link in urls:
            thread = threading.Thread(target=get_html, args=(link, ))
            thread.start()
            threads.append(thread)
        for t in threads:
            t.join()
        for k in urls:
            x = dulieu[k]
            ten = x[0]
            dungluong = x[1]
            diachi = x[2]
            item = Listitem()
            if 'folder' in diachi:
                item.label = ten
                thumuc = diachi.split('folder/')
                item.art['thumb'] = item.art['landscape'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=1&size=400x400&ecc=L' % link
                item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
                item.context.script(tfavo, 'Thêm vào Fshare Favorite', diachi)
                item.set_callback(index_fs, thumuc[1], 1)
                yield item
            elif 'file' in diachi:
                item.label = ten
                item.info['size'] = dungluong
                item.art['thumb'] = item.art['landscape'] = 'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=%s&qzone=1&margin=1&size=400x400&ecc=L' % link
                item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
                item.context.script(downloadfs, 'Tải về', diachi)
                item.context.script(tfavo, 'Thêm vào Fshare Favorite', diachi)
                item.set_callback(play_fs, diachi, item.label)
                yield item
            dialog.update(100)
            dialog.close()
    else:
        yield quangcao()