from codequick import Route, Listitem, run
from resources.lib.kedon import getlink, stream, play_vnm, quangcao, referer, tb
@Route.register
def index_mocha(plugin, idk, next_page, **kwargs):
	resp = getlink(f'http://apivideo.mocha.com.vn:8081/onMediaBackendBiz/mochavideo/listVideoByCate?categoryid={idk}&limit=50&offset={next_page}0&lastIdStr=&token=', 'http://video.mocha.com.vn/', 1000)
	if resp is not None:
		kq = resp.json()
		for k in kq['data']['listVideo']:
			item = Listitem()
			item.label = k['name']
			if 'playlist' in k['original_path']:
				linkget = k['original_path']
			elif k['list_resolution']:
				linkget = k["list_resolution"][-1]['video_path']
			linkplay = f'{stream(linkget)}{referer("http://video.mocha.com.vn/")}'
			item.info['plot'] = f'{k["description"]}\n{tb}'
			item.art['thumb'] = item.art['landscape'] = k['image_path']
			item.art['fanart'] = k['image_path']
			item.set_callback(play_vnm, linkplay, item.label, '')
			yield item
		item1 = Listitem()
		item1.label = 'Trang tiếp'
		item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
		item1.set_callback(index_mocha, idk, next_page + 5)
		yield item1
	else:
		yield quangcao()