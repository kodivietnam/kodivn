from codequick import Route, Listitem, run
from resources.lib.kedon import getlink, ifr_bongda, quangcao, tb
from datetime import datetime
from bs4 import BeautifulSoup
import re, os
@Route.register
def index_cauthuonline(plugin, **kwargs):
	linkweb = 'https://cauthutv.online'
	now = datetime.now()
	timestamp = datetime.timestamp(now)
	url = f'{linkweb}/ajax/schedule-data?filter=live&{timestamp}'
	r = getlink(url,url, 1000)
	if r is not None:
		if 'item-match' in r.text:
			sre = re.compile(r'[\n\r]+')
			soup = BeautifulSoup(r.content, 'html.parser')
			episodes = soup.select('a.item-match')
			for episode in episodes:
				item = Listitem()
				linktran = episode.get('href')
				thoigian = episode.select_one('div.time-match').get_text().strip()
				tenx = episode.select_one('div.body-web').get_text().rstrip(os.linesep)
				ten = sre.sub('', tenx).replace('vs', ' vs ')
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = f'{linkweb}/wp-content/uploads/2022/07/cauthu_tv_logo.png'
				item.label = f'{thoigian}: {ten}'
				item.info['plot'] = tb
				item.set_callback(ifr_bongda, linktran, item.label)
				yield item
		else:
			yield quangcao()
	else:
		yield quangcao()