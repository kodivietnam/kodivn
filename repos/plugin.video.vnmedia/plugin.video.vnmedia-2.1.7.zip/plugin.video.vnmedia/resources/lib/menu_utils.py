from codequick import Script
import xbmcvfs, os, json, importlib
def get_menus_settings():
    MENUS_SETTINGS_FP = os.path.join(Script.get_info('profile'), "menus_settings.json")
    if not xbmcvfs.exists(MENUS_SETTINGS_FP):
        return {}
    with open(MENUS_SETTINGS_FP) as f:
        return json.load(f)
def get_item_order(item_id, menu_id, item_infos):
    menus_settings = get_menus_settings()
    item_order = menus_settings.get(menu_id, {}).get(item_id, {}).get('order', None)
    if item_order is None:
        item_order = item_infos['order']
    return item_order
def get_sorted_menu(plugin, menu_id):
    current_menu = importlib.import_module('resources.lib.skeletons.' + menu_id).menu
    menu = []
    for item_id, item_infos in list(current_menu.items()):
        add_item = True
        if item_infos['enabled'] is False:
            add_item = False
        if add_item:
            item_order = get_item_order(item_id, menu_id, item_infos)
            item = (item_order, item_id, item_infos)
            menu.append(item)
    return sorted(menu, key=lambda x: x[0])