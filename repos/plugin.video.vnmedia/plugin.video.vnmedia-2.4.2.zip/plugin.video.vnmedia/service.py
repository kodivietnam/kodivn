from urlquick import get
from xbmc import executebuiltin
from xbmcaddon import Addon
def autorun_addon():
    executebuiltin('UpdateAddonRepos()')
    if Addon().getSetting('auto_run') == 'true':
        executebuiltin('RunAddon(plugin.video.vnmedia)')
    if Addon().getSetting('auto_noti') == 'true':
        r = get('https://speedtest.vn/get-ip-info', timeout=15, headers={'user-agent': 'okhttp/4.10.0'})
        a = ' '.join([c for c in reversed(r.json().values())]) if (r is not None) else 'VNNIC error'
        executebuiltin(f'Notification("KODI VIỆT NAM", {a}, 10000, {Addon().getAddonInfo("icon")})')
    return
autorun_addon()