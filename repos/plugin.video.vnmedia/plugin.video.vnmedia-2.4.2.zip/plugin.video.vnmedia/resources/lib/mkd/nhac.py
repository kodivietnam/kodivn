from codequick import Route, Listitem, Resolver
from importlib import import_module
from bs4 import BeautifulSoup
from functools import lru_cache
from urlquick import get
import re
@Route.register
def index_amnhac(plugin, **kwargs):
	yield Listitem.from_dict(**{'label': 'Bài hát',
	'art': {'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/amnhac.png',
	'fanart': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/1792312.jpg'},
	'callback': index_baihat})
	yield Listitem.from_dict(**{'label': 'Playlist',
	'art': {'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/amnhac.png',
	'fanart': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/1792312.jpg'},
	'callback': index_playlist})
	yield Listitem.from_dict(**{'label': 'Tuyển tập',
	'art': {'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/amnhac.png',
	'fanart': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/1792312.jpg'},
	'callback': index_tuyentap})
	yield Listitem.from_dict(**{'label': 'Video',
	'art': {'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/amnhac.png',
	'fanart': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/1792312.jpg'},
	'callback': index_video})
	yield Listitem.from_dict(**{'label': 'Bảng xếp hạng',
	'art': {'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/amnhac.png',
	'fanart': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/1792312.jpg'},
	'callback': index_bxhvn})
	yield Listitem.from_dict(**{'label': 'Chủ đề',
	'art': {'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/amnhac.png',
	'fanart': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/1792312.jpg'},
	'callback': index_chude})
	yield Listitem.from_dict(**{'label': 'TOP 100',
	'art': {'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/amnhac.png',
	'fanart': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/1792312.jpg'},
	'callback': index_top})
	yield Listitem.from_dict(**{'label': 'Nghe gì',
	'art': {'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/amnhac.png',
	'fanart': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/1792312.jpg'},
	'callback': nghegi})
	yield videomusic()
@Route.register
def index_baihat(plugin, **kwargs):
	h = import_module('resources.lib.kedon')
	r = h.checkfs('https://www.nhaccuatui.com/bai-hat/bai-hat-moi.html')
	if r is not None:
		soup = BeautifulSoup(r.content, 'html.parser')
		for k in ((l.text, l.get('href')) for l in soup.select('div.box_cata_control ul li a') if l.get('href') is not None):
			item = Listitem()
			item.label = k[0]
			item.art['thumb'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/amnhac.png'
			item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/1792312.jpg'
			item.set_callback(listbai_nct, k[1])
			yield item
	else:
		yield h.quangcao()
@Route.register
def nghegi(plugin, **kwargs):
	headers={'x-nct-token': 'eyJhbGciOiJIUzI1NiJ9.eyJsb2dpbk1ldGhvZCI6IjUiLCJleHAiOjE2ODMyMDYyNzEsImV4cGlyZWREYXRlIjoiMCIsIm5iZiI6MTY4MDYxNDI3MSwiZGV2aWNlaW5mbyI6IntcIkRldmljZUlEXCI6XCIzQjBGNDUyNUJDOEQ0NUI0QUQxNjZDNzdBMDQ1NjlFNlwiLFwiT3NOYW1lXCI6XCJBTkRST0lEXCIsXCJPc1ZlcnNpb25cIjpcIjIyXCIsXCJBcHBOYW1lXCI6XCJOQ1RNb2JpbGVcIixcIkFwcFZlcnNpb25cIjpcIjguMS4yXCIsXCJVc2VyTmFtZVwiOlwiXCIsXCJQcm92aWRlclwiOlwiTkNUQ29ycFwiLFwiRGV2aWNlTmFtZVwiOlwiQVNVU19aMDFRRFwiLFwiUXVhbGl0eVBsYXlcIjpcIlwiLFwiUXVhbGl0eURvd25sb2FkXCI6XCJcIixcIlF1YWxpdHlDbG91ZFwiOlwiXCIsXCJOZXR3b3JrXCI6XCJXSUZJXCIsXCJRdWFsaXR5TVZQbGF5XCI6XCJcIixcIlF1YWxpdHlNVkRvd25sb2FkXCI6XCJcIixcIkFkSURcIjpcIlwiLFwiRGV2aWNlVHlwZVwiOlwiU01BUlRfUEhPTkVcIixcImlzVk5cIjp0cnVlfSIsImlhdCI6MTY4MDYxNDI3MSwiZGV2aWNlSWQiOiIzQjBGNDUyNUJDOEQ0NUI0QUQxNjZDNzdBMDQ1NjlFNiJ9.4GAMSL6i72oG52XlpLo0VckBEe37bKjqR5jIuSqSqoo',
	'user-agent':'okhttp/4.10.0-RC1',
	'x-nct-deviceid': '3B0F4525BC8D45B4AD166C77A04569E6',
	'x-nct-version':'8.1.2',
	'x-nct-language':'vi',
	'x-nct-uuid':'a48d89a4d33e9a3c',
	'x-nct-checksum':'ab6eb574836879df6bcb204ea3e3e655121521cfbf21a8959edbd9136d13bd30',
	'x-nct-userid':'33007211',
	'x-nct-os':'android',
	'accept-encoding':'gzip'}
	r = get('https://graph.nhaccuatui.com/api/v1/song/feed', headers=headers)
	if r is not None:
		for k in r.json()['data']['list']:
			item = Listitem()
			item.label = k['name']
			item.art['thumb'] = k['image']
			item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/1792312.jpg'
			item.path = k['streamURL'][-1]['stream']
			item.set_path(item.path)
			yield item
	else:
		yield h.quangcao()
@Route.register
def index_bxhmusic(plugin, **kwargs):
	M = {'Trending Tiktok': 'https://www.nhaccuatui.com/playlist/top-trending-tiktok-2023-va.lv0G8HlIW0Vq.html',
	'Remix Việt': 'https://www.nhaccuatui.com/playlist/remix-viet-va.GtHX3d4uPnrI.html',
	'Lofi': 'https://www.nhaccuatui.com/playlist/lofi-viet-va.rueiRaOJV9ER.html',
	'BXH Nhạc Hoa': 'http://chiasenhac.vn/nhac-hot/chinese.html',
	'BXH Nhạc Hàn': 'http://chiasenhac.vn/nhac-hot/korea.html',
	'BXH Nhạc Nhật': 'http://chiasenhac.vn/nhac-hot/japan.html',
	'BXH Nhạc Pháp': 'http://chiasenhac.vn/nhac-hot/france.html',
	'BXH Nhạc Nước khác': 'http://chiasenhac.vn/nhac-hot/other.html'}
	for k in M:
		item = Listitem()
		item.label = k
		item.art['thumb'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/amnhac.png'
		item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/1792312.jpg'
		item.set_callback(playlist_nct, M[k])
		yield item
@Route.register
def index_playlist(plugin, **kwargs):
	h = import_module('resources.lib.kedon')
	r = h.checkfs('https://www.nhaccuatui.com/playlist/playlist-moi.html')
	if r is not None:
		soup = BeautifulSoup(r.content, 'html.parser')
		for k in ((l.text, l.get('href')) for l in soup.select('div.box_cata_control ul li a') if l.get('href') is not None):
			item = Listitem()
			item.label = k[0]
			item.art['thumb'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/amnhac.png'
			item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/1792312.jpg'
			item.set_callback(albumplaylist_nct, k[1])
			yield item
	else:
		yield h.quangcao()
@Route.register
def index_tuyentap(plugin, **kwargs):
	h = import_module('resources.lib.kedon')
	r = h.checkfs('https://www.nhaccuatui.com/playlist/tags')
	if r is not None:
		soup = BeautifulSoup(r.content, 'html.parser')
		for k in ((k.select_one('h3').get_text(strip=True), l.get_text(strip=True),l.get('href')) for k in soup.select('div.box_menu_tag') for l in k.select('a')):
			item = Listitem()
			item.label = f'{k[0]}: {k[1]}'
			item.art['thumb'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/amnhac.png'
			item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/1792312.jpg'
			item.set_callback(tuyentapplaylist_nct, k[2])
			yield item
	else:
		yield h.quangcao()
@Route.register
def index_video(plugin, **kwargs):
	h = import_module('resources.lib.kedon')
	r = h.checkfs('https://www.nhaccuatui.com/video.html')
	if r is not None:
		soup = BeautifulSoup(r.content, 'html.parser')
		for k in ((l.text, l.get('href')) for l in soup.select('div.box_cata_control ul li a') if l.get('href') is not None):
			item = Listitem()
			item.label = k[0]
			item.art['thumb'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/amnhac.png'
			item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/1792312.jpg'
			item.set_callback(videoplaylist_nct, k[1])
			yield item
	else:
		yield h.quangcao()
@Route.register
def index_bxhvn(plugin, **kwargs):
	h = import_module('resources.lib.kedon')
	r = h.checkfs('https://www.nhaccuatui.com/bai-hat/top-20.nhac-viet.html')
	if r is not None:
		soup = BeautifulSoup(r.content, 'html.parser')
		for k in soup.select('ul.search_control_select a'):
			item = Listitem()
			item.label = k.get_text(strip=True)
			item.art['thumb'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/amnhac.png'
			item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/1792312.jpg'
			item.set_callback(bxhplaylist_nct, k.get('href'))
			yield item
	else:
		yield h.quangcao()
@Route.register
def index_chude(plugin, **kwargs):
	h = import_module('resources.lib.kedon')
	r = h.checkfs('https://www.nhaccuatui.com/chu-de.html')
	if r is not None:
		soup = BeautifulSoup(r.content, 'html.parser')
		for k in soup.select('div.fram_select a.name_song'):
			item = Listitem()
			item.label = k.get_text(strip=True)
			item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/1792312.jpg'
			item.set_callback(playlist_nct, k.get('href'))
			yield item
	else:
		yield h.quangcao()
@Route.register
def index_top(plugin, **kwargs):
	M = {'Việt Nam': 'https://www.nhaccuatui.com/top100/top-100-nhac-tre.m3liaiy6vVsF.html',
	'Âu Mỹ': 'https://www.nhaccuatui.com/top100/top-100-pop.zE23R7bc8e9X.html',
	'Châu Á': 'https://www.nhaccuatui.com/top100/top-100-nhac-han.iciV0mD8L9Ed.html',
	'Không lời': 'https://www.nhaccuatui.com/top100/top-100-khong-loi.kr9KYNtkzmnA.html'}
	for k in M:
		item = Listitem()
		item.label = k
		item.art['thumb'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/amnhac.png'
		item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/1792312.jpg'
		item.set_callback(index_top100, M[k])
		yield item
@Route.register
def index_top100(plugin, url, **kwargs):
	h = import_module('resources.lib.kedon')
	r = h.checkfs(url)
	if r is not None:
		soup = BeautifulSoup(r.content, 'html.parser')
		for k in soup.select('ul.detail_menu_browsing_dashboard a'):
			item = Listitem()
			item.label = k.get_text(strip=True)
			item.art['thumb'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/amnhac.png'
			item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/1792312.jpg'
			item.set_callback(playlist_nct, k.get('href'))
			yield item
	else:
		yield h.quangcao()
@Route.register
def playlist_nct(plugin, url, **kwargs):
	h = import_module('resources.lib.kedon')
	if idk:= re.search(r"(?<=\.)([\w-]+)(?=\.\w+$)", url):
		headers={'x-nct-token': 'eyJhbGciOiJIUzI1NiJ9.eyJsb2dpbk1ldGhvZCI6IjUiLCJleHAiOjE2ODMyMDYyNzEsImV4cGlyZWREYXRlIjoiMCIsIm5iZiI6MTY4MDYxNDI3MSwiZGV2aWNlaW5mbyI6IntcIkRldmljZUlEXCI6XCIzQjBGNDUyNUJDOEQ0NUI0QUQxNjZDNzdBMDQ1NjlFNlwiLFwiT3NOYW1lXCI6XCJBTkRST0lEXCIsXCJPc1ZlcnNpb25cIjpcIjIyXCIsXCJBcHBOYW1lXCI6XCJOQ1RNb2JpbGVcIixcIkFwcFZlcnNpb25cIjpcIjguMS4yXCIsXCJVc2VyTmFtZVwiOlwiXCIsXCJQcm92aWRlclwiOlwiTkNUQ29ycFwiLFwiRGV2aWNlTmFtZVwiOlwiQVNVU19aMDFRRFwiLFwiUXVhbGl0eVBsYXlcIjpcIlwiLFwiUXVhbGl0eURvd25sb2FkXCI6XCJcIixcIlF1YWxpdHlDbG91ZFwiOlwiXCIsXCJOZXR3b3JrXCI6XCJXSUZJXCIsXCJRdWFsaXR5TVZQbGF5XCI6XCJcIixcIlF1YWxpdHlNVkRvd25sb2FkXCI6XCJcIixcIkFkSURcIjpcIlwiLFwiRGV2aWNlVHlwZVwiOlwiU01BUlRfUEhPTkVcIixcImlzVk5cIjp0cnVlfSIsImlhdCI6MTY4MDYxNDI3MSwiZGV2aWNlSWQiOiIzQjBGNDUyNUJDOEQ0NUI0QUQxNjZDNzdBMDQ1NjlFNiJ9.4GAMSL6i72oG52XlpLo0VckBEe37bKjqR5jIuSqSqoo',
		'user-agent':'okhttp/4.10.0-RC1',
		'x-nct-deviceid': '3B0F4525BC8D45B4AD166C77A04569E6',
		'x-nct-version':'8.1.2',
		'x-nct-language':'vi',
		'x-nct-uuid':'a48d89a4d33e9a3c',
		'x-nct-checksum':'ab6eb574836879df6bcb204ea3e3e655121521cfbf21a8959edbd9136d13bd30',
		'x-nct-userid':'33007211',
		'x-nct-os':'android',
		'accept-encoding':'gzip'}
		r = get(f'https://graph.nhaccuatui.com/api/v1/playlist/detail/{idk[1]}', headers=headers)
		for k in r.json()['data']['listSong']:
			item = Listitem()
			item.label = k['name']
			item.art['thumb'] = k['image']
			item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/1792312.jpg'
			item.path = k['streamURL'][-1]['stream']
			item.set_path(item.path)
			yield item
	else:
		yield h.quangcao()
@Route.register
def albumplaylist_nct(plugin, url, **kwargs):
	h = import_module('resources.lib.kedon')
	r = h.checkfs(url)
	if r is not None:
		soup = BeautifulSoup(r.content, 'html.parser')
		if g:=soup.select('div.fram_select ul li'):
			for k in g:
				item = Listitem()
				a = k.select_one('div.info_album a')
				item.label = a.get_text(strip=True)
				item.art['thumb'] = item.art['fanart'] = k.select_one('img').get('data-src')
				item.set_callback(playlist_nct, a.get('href'))
				yield item
			if page:=soup.select('div.box_pageview'):
				for k in page:
					item = Listitem()
					a = k.select_one('a[rel="next"]')
					item.label = f'Trang {a.get_text(strip=True)}'
					item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
					item.set_callback(albumplaylist_nct, a.get('href'))
					yield item
		else:
			yield h.quangcao()
	else:
		yield h.quangcao()
@Route.register
def tuyentapplaylist_nct(plugin, url, **kwargs):
	h = import_module('resources.lib.kedon')
	r = h.checkfs(url)
	if r is not None:
		soup = BeautifulSoup(r.content, 'html.parser')
		if g:=soup.select('div.list_album.tag ul li'):
			for k in g:
				item = Listitem()
				a = k.select_one('div.info_album a')
				item.label = a.get_text(strip=True)
				item.art['thumb'] = item.art['fanart'] = k.select_one('img').get('data-src')
				item.set_callback(playlist_nct, a.get('href'))
				yield item
			if page:=soup.select('div.box_pageview'):
				for k in page:
					item = Listitem()
					a = k.select_one('a[rel="next"]')
					item.label = f'Trang {a.get_text(strip=True)}'
					item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
					item.set_callback(tuyentapplaylist_nct, a.get('href'))
					yield item
		else:
			yield h.quangcao()
	else:
		yield h.quangcao()
@Route.register
def videoplaylist_nct(plugin, url, **kwargs):
	h = import_module('resources.lib.kedon')
	r = h.checkfs(url)
	if r is not None:
		soup = BeautifulSoup(r.content, 'html.parser')
		if g:= soup.select('div.list_video ul li'):
			for k in g:
				a = k.select_one('a.name_song')
				item = Listitem()
				item.label = a.get_text(strip=True)
				item.art['thumb'] = item.art['fanart'] = k.select_one('img').get('data-src')
				item.set_callback(playvdnct, a.get('href'), item.label)
				yield item
			if page:=soup.select('div.box_pageview'):
				for k in page:
					item = Listitem()
					a = k.select_one('a[rel="next"]')
					item.label = f'Trang {a.get_text(strip=True)}'
					item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
					item.set_callback(videoplaylist_nct, a.get('href'))
					yield item
		else:
			yield h.quangcao()
	else:
		yield h.quangcao()
@Route.register
def bxhplaylist_nct(plugin, url, **kwargs):
	h = import_module('resources.lib.kedon')
	if idk:= re.search(r"(?<=\.)([\w-]+)(?=\.\w+$)", url):
		headers={'x-nct-token': 'eyJhbGciOiJIUzI1NiJ9.eyJsb2dpbk1ldGhvZCI6IjUiLCJleHAiOjE2ODMyMDYyNzEsImV4cGlyZWREYXRlIjoiMCIsIm5iZiI6MTY4MDYxNDI3MSwiZGV2aWNlaW5mbyI6IntcIkRldmljZUlEXCI6XCIzQjBGNDUyNUJDOEQ0NUI0QUQxNjZDNzdBMDQ1NjlFNlwiLFwiT3NOYW1lXCI6XCJBTkRST0lEXCIsXCJPc1ZlcnNpb25cIjpcIjIyXCIsXCJBcHBOYW1lXCI6XCJOQ1RNb2JpbGVcIixcIkFwcFZlcnNpb25cIjpcIjguMS4yXCIsXCJVc2VyTmFtZVwiOlwiXCIsXCJQcm92aWRlclwiOlwiTkNUQ29ycFwiLFwiRGV2aWNlTmFtZVwiOlwiQVNVU19aMDFRRFwiLFwiUXVhbGl0eVBsYXlcIjpcIlwiLFwiUXVhbGl0eURvd25sb2FkXCI6XCJcIixcIlF1YWxpdHlDbG91ZFwiOlwiXCIsXCJOZXR3b3JrXCI6XCJXSUZJXCIsXCJRdWFsaXR5TVZQbGF5XCI6XCJcIixcIlF1YWxpdHlNVkRvd25sb2FkXCI6XCJcIixcIkFkSURcIjpcIlwiLFwiRGV2aWNlVHlwZVwiOlwiU01BUlRfUEhPTkVcIixcImlzVk5cIjp0cnVlfSIsImlhdCI6MTY4MDYxNDI3MSwiZGV2aWNlSWQiOiIzQjBGNDUyNUJDOEQ0NUI0QUQxNjZDNzdBMDQ1NjlFNiJ9.4GAMSL6i72oG52XlpLo0VckBEe37bKjqR5jIuSqSqoo',
		'user-agent':'okhttp/4.10.0-RC1',
		'x-nct-deviceid': '3B0F4525BC8D45B4AD166C77A04569E6',
		'x-nct-version':'8.1.2',
		'x-nct-language':'vi',
		'x-nct-uuid':'a48d89a4d33e9a3c',
		'x-nct-checksum':'ab6eb574836879df6bcb204ea3e3e655121521cfbf21a8959edbd9136d13bd30',
		'x-nct-userid':'33007211',
		'x-nct-os':'android',
		'accept-encoding':'gzip'}
		r = get(f'https://graph.nhaccuatui.com/api/v1/playlist/charts/{idk[1]}', headers=headers)
		for k in r.json()['data']['items']:
			item = Listitem()
			item.label = k['name']
			item.art['thumb'] = k['image']
			item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/1792312.jpg'
			item.set_callback(playnct, k['linkShare'], item.label)
			yield item
	else:
		yield h.quangcao()
@Route.register
def listbai_nct(plugin, url, **kwargs):
	h = import_module('resources.lib.kedon')
	r = h.checkfs(url)
	if r is not None:
		soup = BeautifulSoup(r.content, 'html.parser')
		if g:=soup.select('div.info_song a.avatar_song'):
			for k in g:
				item = Listitem()
				item.label = k.get('title')
				item.art['thumb'] = k.select_one('img').get('src')
				item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/1792312.jpg'
				item.set_callback(playnct, k.get('href'), item.label)
				yield item
			if page:=soup.select('div.box_pageview'):
				for k in page:
					item = Listitem()
					a = k.select_one('a[rel="next"]')
					item.label = f'Trang {a.get_text(strip=True)}'
					item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
					item.set_callback(listbai_nct, a.get('href'))
					yield item
		else:
			yield h.quangcao()
	else:
		yield h.quangcao()
@Resolver.register
def playnct(plugin, url, title, **kwargs):
	w = import_module('resources.lib.kedon')
	news = 'http://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/qc.ass'
	#idk = re.search(r'\.(\w+)\.html', url)
	if idk:= re.search(r'\.(\w+)\.html', url):
		headers={'x-nct-token': 'eyJhbGciOiJIUzI1NiJ9.eyJsb2dpbk1ldGhvZCI6IjUiLCJleHAiOjE2ODMyMDYyNzEsImV4cGlyZWREYXRlIjoiMCIsIm5iZiI6MTY4MDYxNDI3MSwiZGV2aWNlaW5mbyI6IntcIkRldmljZUlEXCI6XCIzQjBGNDUyNUJDOEQ0NUI0QUQxNjZDNzdBMDQ1NjlFNlwiLFwiT3NOYW1lXCI6XCJBTkRST0lEXCIsXCJPc1ZlcnNpb25cIjpcIjIyXCIsXCJBcHBOYW1lXCI6XCJOQ1RNb2JpbGVcIixcIkFwcFZlcnNpb25cIjpcIjguMS4yXCIsXCJVc2VyTmFtZVwiOlwiXCIsXCJQcm92aWRlclwiOlwiTkNUQ29ycFwiLFwiRGV2aWNlTmFtZVwiOlwiQVNVU19aMDFRRFwiLFwiUXVhbGl0eVBsYXlcIjpcIlwiLFwiUXVhbGl0eURvd25sb2FkXCI6XCJcIixcIlF1YWxpdHlDbG91ZFwiOlwiXCIsXCJOZXR3b3JrXCI6XCJXSUZJXCIsXCJRdWFsaXR5TVZQbGF5XCI6XCJcIixcIlF1YWxpdHlNVkRvd25sb2FkXCI6XCJcIixcIkFkSURcIjpcIlwiLFwiRGV2aWNlVHlwZVwiOlwiU01BUlRfUEhPTkVcIixcImlzVk5cIjp0cnVlfSIsImlhdCI6MTY4MDYxNDI3MSwiZGV2aWNlSWQiOiIzQjBGNDUyNUJDOEQ0NUI0QUQxNjZDNzdBMDQ1NjlFNiJ9.4GAMSL6i72oG52XlpLo0VckBEe37bKjqR5jIuSqSqoo',
		'user-agent':'okhttp/4.10.0-RC1',
		'x-nct-deviceid': '3B0F4525BC8D45B4AD166C77A04569E6',
		'x-nct-version':'8.1.2',
		'x-nct-language':'vi',
		'x-nct-uuid':'a48d89a4d33e9a3c',
		'x-nct-checksum':'ab6eb574836879df6bcb204ea3e3e655121521cfbf21a8959edbd9136d13bd30',
		'x-nct-userid':'33007211',
		'x-nct-os':'android',
		'accept-encoding':'gzip'}
		r = get(f'https://graph.nhaccuatui.com/v7/songs/detail/{idk[1]}?iscloud=false&isDailyMix=false', headers=headers)
		linkplay = r.json()['data']['streamURL'][-1]['stream']
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay})
	else:
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':w.qc()})
@Resolver.register
def playvdnct(plugin, url, title, **kwargs):
	w = import_module('resources.lib.kedon')
	news = 'http://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/qc.ass'
	item = Listitem()
	idk = re.search(r'\.(\w+)\.html', url)
	if idk:= re.search(r"(?<=\.)([\w-]+)(?=\.\w+$)", url):
		headers={'x-nct-token': 'eyJhbGciOiJIUzI1NiJ9.eyJsb2dpbk1ldGhvZCI6IjUiLCJleHAiOjE2ODMyMDYyNzEsImV4cGlyZWREYXRlIjoiMCIsIm5iZiI6MTY4MDYxNDI3MSwiZGV2aWNlaW5mbyI6IntcIkRldmljZUlEXCI6XCIzQjBGNDUyNUJDOEQ0NUI0QUQxNjZDNzdBMDQ1NjlFNlwiLFwiT3NOYW1lXCI6XCJBTkRST0lEXCIsXCJPc1ZlcnNpb25cIjpcIjIyXCIsXCJBcHBOYW1lXCI6XCJOQ1RNb2JpbGVcIixcIkFwcFZlcnNpb25cIjpcIjguMS4yXCIsXCJVc2VyTmFtZVwiOlwiXCIsXCJQcm92aWRlclwiOlwiTkNUQ29ycFwiLFwiRGV2aWNlTmFtZVwiOlwiQVNVU19aMDFRRFwiLFwiUXVhbGl0eVBsYXlcIjpcIlwiLFwiUXVhbGl0eURvd25sb2FkXCI6XCJcIixcIlF1YWxpdHlDbG91ZFwiOlwiXCIsXCJOZXR3b3JrXCI6XCJXSUZJXCIsXCJRdWFsaXR5TVZQbGF5XCI6XCJcIixcIlF1YWxpdHlNVkRvd25sb2FkXCI6XCJcIixcIkFkSURcIjpcIlwiLFwiRGV2aWNlVHlwZVwiOlwiU01BUlRfUEhPTkVcIixcImlzVk5cIjp0cnVlfSIsImlhdCI6MTY4MDYxNDI3MSwiZGV2aWNlSWQiOiIzQjBGNDUyNUJDOEQ0NUI0QUQxNjZDNzdBMDQ1NjlFNiJ9.4GAMSL6i72oG52XlpLo0VckBEe37bKjqR5jIuSqSqoo',
		'user-agent':'okhttp/4.10.0-RC1',
		'x-nct-deviceid': '3B0F4525BC8D45B4AD166C77A04569E6',
		'x-nct-version':'8.1.2',
		'x-nct-language':'vi',
		'x-nct-uuid':'a48d89a4d33e9a3c',
		'x-nct-checksum':'ab6eb574836879df6bcb204ea3e3e655121521cfbf21a8959edbd9136d13bd30',
		'x-nct-userid':'33007211',
		'x-nct-os':'android',
		'accept-encoding':'gzip'}
		r = get(f'https://graph.nhaccuatui.com/v7/videos/detail/{idk[1]}?isFirst=false', headers=headers)
		linkplay= r.json()['data']['streamURL'][-1]['stream']
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':linkplay})
	else:
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':w.qc()})
@lru_cache(maxsize=None)
def videomusic():
	item = Listitem()
	item.label = 'Video nhạc tổng hợp'
	item.art['thumb'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/amnhac.png'
	item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/1792312.jpg'
	item.set_callback(Route.ref('/resources/lib/mkd/ontintuc/mocha:index_mocha'), 4, 0)
	return item