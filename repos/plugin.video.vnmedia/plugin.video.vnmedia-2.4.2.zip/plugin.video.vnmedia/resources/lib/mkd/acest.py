from codequick import Route, Listitem
from importlib import import_module
from functools import lru_cache
@Route.register
def index_acestream(plugin, **kwargs):
	tb = import_module('resources.lib.kedon').tb
	yield acekp()
	yield Listitem.from_dict(**{'label': 'Livetv.sx',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/acestream.png',
	'fanart':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/acestream.png'},
	'callback':Route.ref('/resources/lib/mkd/onthethao/livetvxs:index_livetvxs')})
	yield Listitem.from_dict(**{'label': 'Streamthunder.org',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/acestream.png',
	'fanart':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/acestream.png'},
	'callback':Route.ref('/resources/lib/mkd/onthethao/streamthunder:index_streamthunder')})
	yield Listitem.from_dict(**{'label': 'Highlights365.com',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://highlights365.com/static/images/highlights365/logo_header.png',
	'fanart':'https://highlights365.com/static/images/highlights365/logo_header.png'},
	'callback':Route.ref('/resources/lib/mkd/onthethao/hl365:index_highlights365')})
@lru_cache(maxsize=None)
def acekp():
	item = Listitem()
	item.label = 'Acestream Khampha'
	item.info['plot'] = import_module('resources.lib.kedon').tb
	item.path = Route.ref('/resources/lib/qrplay:qrplay')
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/acestream.png'
	item.set_callback(Route.ref('/resources/lib/mkd/ontruyenhinh/listiptv:list_iptv'), 'http://note.hqth.me/raw/ace-45692')
	return item