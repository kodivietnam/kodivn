from codequick import Route, Listitem, Resolver
from importlib import import_module
from datetime import datetime
from bs4 import BeautifulSoup
import re, os
@Route.register
def index_cauthuonline(plugin, **kwargs):
	w = import_module('resources.lib.kedon')
	linkweb = 'https://cauthutv.online'
	now = datetime.now()
	timestamp = datetime.timestamp(now)
	url = f'{linkweb}/ajax/schedule-data?filter=live&{timestamp}'
	r = w.getlink(url,url, 1000)
	if (r is not None) and ('item-match' in r.text):
		sre = re.compile(r'[\n\r]+')
		soup = BeautifulSoup(r.content, 'html.parser')
		for episode in soup.select('a.item-match'):
			item = Listitem()
			ten = sre.sub('', episode.select_one('div.body-web').get_text(strip=True)).replace('vs', ' vs ')
			item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/cauthu.png'
			item.label = f"{episode.select_one('div.time-match').get_text(strip=True)}: {ten}"
			item.info['plot'] = w.tb
			item.set_callback(Resolver.ref('/resources/lib/kedon:ifr_bongda'), episode.get('href'), item.label)
			yield item
	else:
		yield w.quangcao()