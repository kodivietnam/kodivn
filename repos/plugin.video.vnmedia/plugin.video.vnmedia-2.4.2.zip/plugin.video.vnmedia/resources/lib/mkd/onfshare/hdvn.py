from codequick import Route, Listitem, Resolver, Script
from bs4 import BeautifulSoup
from importlib import import_module
from concurrent.futures import ThreadPoolExecutor, as_completed
from xbmcgui import DialogProgress
from xbmcaddon import Addon
from urllib.parse import quote_plus
import re
@Route.register
def search_hdvn(plugin,search_query, **kwargs):
    w = import_module('resources.lib.kedon')
    hd = import_module('resources.lib.mkd.onfshare.ifshare').hdvn
    dp = DialogProgress()
    dp.create(w.__addonnoti__, 'Đang lấy dữ liệu...')
    dp.update(5)
    search_query = quote_plus(search_query)
    url = f'{hd}/search/2022/?page=1&q={search_query.replace(" ","+")}&t=post&o=date&c[node]=337+344+345+346+33+271+324+77+78'
    r = w.getlink(url, url, 7200)
    if (r is not None):
        idsearch = re.search(r'search/([0-9]+)', w.fu(url))[1]
        if 'titleText' in r.text:
            soup = BeautifulSoup(r.content, 'html.parser')
            for episode in soup.select('div.titleText a'):
                item = Listitem()
                item.label = episode.get_text(strip=True)
                item.info['plot'] = w.tb
                item.info['mediatype'] = 'episode'
                item.info['rating'] = 10.0
                item.info['trailer'] = w.yttk(item.label)
                linkphim = episode.get('href')
                item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/hdvn.png'
                item.set_callback(hdvn_link, linkphim)
                yield item
            yield Listitem.next_page(search_query, 2, idsearch, callback=search_hdvnnext)
        else:
            Script.notify(w.__addonnoti__, 'Không tìm thấy kết quả')
            yield w.quangcao()
    else:
        yield w.quangcao()
    dp.update(100)
    dp.close()
@Route.register
def search_hdvnnext(plugin,search_query, next_page, idsearch, **kwargs):
    w = import_module('resources.lib.kedon')
    hd = import_module('resources.lib.mkd.onfshare.ifshare').hdvn
    search_query = quote_plus(search_query)
    url = f'{hd}/search/{idsearch}/?page={next_page}&q={search_query.replace(" ","+")}&t=post&o=date&c[node]=337+344+345+346+33+271+324+77+78'
    r = w.getlink(url, url, 7200)
    if (r is not None) and ('titleText' in r.text):
        soup = BeautifulSoup(r.content, 'html.parser')
        for episode in soup.select('div.titleText a'):
            item = Listitem()
            item.label = episode.get_text(strip=True)
            item.info['plot'] = w.tb
            item.info['mediatype'] = 'episode'
            item.info['rating'] = 10.0
            item.info['trailer'] = w.yttk(item.label)
            linkphim = episode.get('href')
            item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/hdvn.png'
            item.set_callback(hdvn_link, linkphim)
            yield item
        item1 = Listitem()
        item1.label = f'Trang {next_page + 1}'
        item1.art['thumb'] = item1.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
        item1.set_callback(search_hdvnnext, search_query, next_page + 1, idsearch)
        yield item1
    else:
        Script.notify(w.__addonnoti__, 'Không tìm thấy kết quả')
        yield w.quangcao()
@Route.register
def index_hdvn(plugin, **kwargs):
    hd = import_module('resources.lib.mkd.onfshare.ifshare').hdvn
    H = {
    '4K': f'{hd}/forums/4k.337/',
    'WEB-DL, HDTV 4K': f'{hd}/forums/web-dl-hdtv-4k.344/',
    'Bluray Remux 4K': f'{hd}/forums/bluray-remux-4k.345/',
    'Bluray Nguyên Gốc 4K': f'{hd}/forums/bluray-nguyen-goc-4k.346/',
    'Fshare.vn': f'{hd}/forums/fshare-vn.33/',
    'Fshare-WEB-DL, HDTV': f'{hd}/forums/web-dl-hdtv.271/',
    'Fshare-Bluray Remux': f'{hd}/forums/bluray-remux.324/',
    'Fshare-mHD, SD': f'{hd}/forums/mhd-sd.77/',
    'Fshare-Bluray nguyên gốc': f'{hd}/forums/bluray-nguyen-goc.78/',
    'Thư viện link Phim': f'{hd}/forums/thu-vien-link-phim.150/',
    'Phim có audio Việt': f'{hd}/forums/phim-co-audio-viet.265/',
    'Phim bộ - Series': f'{hd}/forums/phim-bo-series.57/',
    'Phim bộ - mHD, SD': f'{hd}/forums/mhd-sd.104/',
    'Phim hoạt hình': f'{hd}/forums/phim-hoat-hinh.123/',
    'Phim hoạt hình - mHD, SD': f'{hd}/forums/mhd-sd.124/',
    'Phim tài liệu - Documentaries': f'{hd}/forums/phim-tai-lieu-documentaries.116/',
    'Phim 3D': f'{hd}/forums/3d.110/',
    'Phim cho iOS/Android': f'{hd}/forums/phim-cho-ios-android.157/',
    'Music request': f'{hd}/forums/music-request.28/',
    'HD Video Clip': f'{hd}/forums/hd-video-clip.50/',
    'Video nhạc US-EU': f'{hd}/forums/us-eu.189/',
    'Video nhạc Việt Nam': f'{hd}/forums/viet-nam.191/',
    'Video nhạc Asia': f'{hd}/forums/asia.190/',
    'Soundtrack': f'{hd}/forums/soundtrack.73/',
    'Lossless Albums': f'{hd}/forums/lossless-albums.26/',
    'Lossless Việt Nam': f'{hd}/forums/nhac-viet-nam.183/',
    'Lossless Quốc tế': f'{hd}/forums/nhac-quoc-te.184/',
    'Lossless không lời': f'{hd}/forums/nhac-khong-loi.185/',
    'Lossy albums': f'{hd}/forums/lossy-albums.27/',
    'mHD, SD Video Clips': f'{hd}/forums/mhd-sd-video-clips.25/'
    }
    yield Listitem.search(search_hdvn)
    for k in H:
        item = Listitem()
        item.label = k
        item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/hdvn.png'
        item.info['plot'] = import_module('resources.lib.kedon').tb
        item.set_callback(hdvn_page, H[k], 1)
        yield item
@Route.register
def hdvn_page(plugin, url, next_page, **kwargs):
    w = import_module('resources.lib.kedon')
    hd = import_module('resources.lib.mkd.onfshare.ifshare').hdvn
    trangtiep = f'{url}page-{next_page}'
    r = w.getlink(trangtiep, trangtiep, 14400)
    if (r is not None):
        soup = BeautifulSoup(r.content, 'html.parser')
        for episode in soup.select('a.PreviewTooltip'):
            item = Listitem()
            linkphim = episode.get('href')
            p = episode.get_text(strip=True)
            item.label = p
            item.info['plot'] = w.tb
            item.info['mediatype'] = 'episode'
            item.info['rating'] = 10.0
            item.info['trailer'] = w.yttk(item.label)
            item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/hdvn.png'
            item.set_callback(hdvn_link, linkphim)
            yield item
        item1 = Listitem()
        item1.label = f'Trang {next_page + 1}'
        item1.art['thumb'] = item1.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
        item1.set_callback(hdvn_page, url, next_page + 1)
        yield item1
    else:
        yield w.quangcao()
@Route.register
def hdvn_link(plugin, url, **kwargs):
    w = import_module('resources.lib.kedon')
    hd = import_module('resources.lib.mkd.onfshare.ifshare').hdvn
    import_module('resources.lib.mkd.onfshare.ifshare').likehdvn(url)
    r = import_module('resources.lib.mkd.onfshare.ifshare').loginfhdvn().get(f'{hd}/{url}')
    if 'fshare.vn' in r.text:
        soup = BeautifulSoup(r.content, 'html.parser')
        urls = list(dict.fromkeys([episode.get('href') for episode in soup.select('a.externalLink') if 'fshare.vn' in episode.get('href')]))
        length = len(urls)
        dialog = DialogProgress()
        dialog.create(w.__addonnoti__, 'Đang lấy dữ liệu...')
        dialog.update(5, f'Đang giải mã {length} dữ liệu...')
        if length>0:
            with ThreadPoolExecutor(length) as ex:
                future_to_url = {ex.submit(w.get_info_fs, url): url for url in urls}
                for future in as_completed(future_to_url):
                    link = future_to_url[future]
                    data = future.result()
                    if 'folder' in link:
                        item = Listitem()
                        item.label = data[0]
                        item.info['plot'] = w.tb
                        item.info['mediatype'] = 'episode'
                        item.info['rating'] = 10.0
                        item.info['trailer'] = w.yttk(item.label)
                        item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={link}&qzone=1&margin=1&size=400x400&ecc=L'
                        item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
                        item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
                        item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), link.split('folder/')[1], 1)
                        yield item
                    elif 'file' in link:
                        item = Listitem()
                        item.label = data[0]
                        item.info['plot'] = w.tb
                        item.info['size'] = data[1]
                        item.info['mediatype'] = 'episode'
                        item.info['rating'] = 10.0
                        item.info['trailer'] = w.yttk(item.label)
                        item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={link}&qzone=1&margin=1&size=400x400&ecc=L'
                        item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
                        if Addon().getSetting('taifshare') == 'true':
                            item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', link)
                        item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
                        item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), link, item.label)
                        yield item
                    dialog.update(50)
        else:
            yield []
        dialog.update(100)
        dialog.close()
    else:
        yield w.quangcao()