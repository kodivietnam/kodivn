from codequick import Resolver, Route, Listitem
from importlib import import_module
@Route.register
def index_thieunhi(plugin, **kwargs):
	h = import_module('resources.lib.kedon')
	resp = h.getlink(f'http://apivideo.mocha.com.vn:8081/onMediaBackendBiz/mochavideo/listVideoByCate?categoryid=1023&limit=50&offset=00&lastIdStr=&token=', 'http://video.mocha.com.vn/', 1000)
	if (resp is not None):
		kq = resp.json()
		for k in kq['data']['listVideo']:
			item = Listitem()
			item.label = k['name']
			if 'playlist' in k["original_path"]:
				linkget = k["original_path"]
			else:
				linkget = k["list_resolution"][-1]['video_path']
			item.info['plot'] = f'{k["description"]}\n{h.tb}'
			item.art['thumb'] = item.art['landscape'] = k['image_path']
			item.art['fanart'] = k['image_path']
			item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), f'{h.stream(linkget)}{h.referer("http://video.mocha.com.vn/")}', item.label, '')
			yield item
		item1 = Listitem()
		item1.label = 'Trang tiếp'
		item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
		item1.set_callback(index_nextthieunhi, 5)
		yield item1
	else:
		yield h.quangcao()
@Route.register
def index_nextthieunhi(plugin, next_page, **kwargs):
	h = import_module('resources.lib.kedon')
	resp = h.getlink(f'http://apivideo.mocha.com.vn:8081/onMediaBackendBiz/mochavideo/listVideoByCate?categoryid=1023&limit=50&offset={next_page}0&lastIdStr=&token=', 'http://video.mocha.com.vn/', 1000)
	if (resp is not None):
		kq = resp.json()
		for k in kq['data']['listVideo']:
			item = Listitem()
			item.label = k['name']
			if 'playlist' in k["original_path"]:
				linkget = k["original_path"]
			else:
				linkget = k["list_resolution"][-1]['video_path']
			item.info['plot'] = f'{k["description"]}\n{h.tb}'
			item.art['thumb'] = item.art['landscape'] = k['image_path']
			item.art['fanart'] = k['image_path']
			item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), f'{h.stream(linkget)}{h.referer("http://video.mocha.com.vn/")}', item.label, '')
			yield item
		item1 = Listitem()
		item1.label = 'Trang tiếp'
		item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
		item1.set_callback(index_nextthieunhi, next_page + 5)
		yield item1
	else:
		yield h.quangcao()