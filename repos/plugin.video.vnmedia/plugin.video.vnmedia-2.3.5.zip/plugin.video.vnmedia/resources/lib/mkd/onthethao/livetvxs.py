from codequick import Route, Listitem
from importlib import import_module
from datetime import datetime, timedelta, date
from bs4 import BeautifulSoup
@Route.register
def index_livetvxs(plugin, **kwargs):
	q = import_module('resources.lib.kedon')
	url = 'http://livetv.sx/export/webmasters.php?lang=en'
	resp = q.getlink(url, url, 1000)
	if (resp is not None) and ('acestream' in resp.text):
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('tr td')
		for episode in episodes:
			z = episode.select('td.time')
			for w in z:
				timex = w.get_text(strip=True)
				if len(timex)==4:
					y = f'{date.today()}T0{timex}'
				else:
					y = f'{date.today()}T{timex}'
				z = (datetime.fromisoformat(y) + timedelta(hours=6)).strftime('%H:%M')
			a = episode.select('td a.title')
			for b in a:
				tentran = b.get_text(strip=True)
			anh = episode.select('td img')
			for im in anh:
				img = f'https:{im.get("src")}'
			x = episode.select('div a')
			for index, number in enumerate(x):
				item = Listitem()
				item.art['thumb'] = item.art['landscape'] = img
				item.art['fanart'] = 'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg'
				item.label = f'Link {index+1}-{z} {tentran}'
				item.path = q.ace(number.get('href'), item.label)
				item.set_callback(item.path)
				yield item
	else:
		yield q.quangcao()