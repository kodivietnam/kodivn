from codequick import Route, Listitem, Script, Resolver
from importlib import import_module
from bs4 import BeautifulSoup
from xbmcgui import DialogProgress
from xbmcaddon import Addon
from urllib.parse import quote_plus
import re
@Route.register
def search_thuviencine(plugin,search_query, **kwargs):
	w = import_module('resources.lib.kedon')
	dp = DialogProgress()
	dp.create(w.__addonnoti__, 'Đang lấy dữ liệu...')
	dp.update(5)
	url = 'https://thuviencine.com'
	resp = w.getlink(url, url, 7200)
	if (resp is not None):
		match = re.search(r'"nonce":"(.*?)"', resp.text).group(1)
		urltv = f'https://thuviencine.com/wp-json/moviewp/search/?nonce={match}&keyword={quote_plus(search_query)}'
		r = w.getlink(urltv, url, 7200)
		if 'No results' in r.text:
			yield w.quangcao()
		else:
			for k in r.json().values():
				item = Listitem()
				item.label = k['title']
				item.info['plot'] = w.tb
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = w.yttk(item.label)
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = k['img']
				item.set_callback(thuviencine_link, k['url'])
				yield item
	else:
		yield w.quangcao()
	dp.update(100)
	dp.close()
@Route.register
def index_thuviencine(plugin, **kwargs):
	w = import_module('resources.lib.kedon')
	yield Listitem.search(search_thuviencine)
	url = 'http://thuviencine.com'
	resp = w.getlink(url, url, 7200)
	if (resp is not None):
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('div.sidebar.sb-left a')
		for episode in episodes:
			item = Listitem()
			phim = episode.get('href')
			item.label = episode.get_text(strip=True)
			item.info['plot'] = w.tb
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://thuviencine.com/wp-content/uploads/2021/09/logo-red.png'
			item.set_callback(thuviencine_page, phim, 1)
			yield item
		nhomtheloais = soup.select('nav.filters a')
		for nhomtheloai in nhomtheloais:
			item1 = Listitem()
			nhom = nhomtheloai.get('href')
			tennhom = nhomtheloai.get_text(strip=True)
			if tennhom:
				item1.label = tennhom
				item1.info['plot'] = w.tb
				item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://thuviencine.com/wp-content/uploads/2021/09/logo-red.png'
				item1.set_callback(thuviencine_page, nhom, 1)
				yield item1
	else:
		yield w.quangcao()
@Route.register
def thuviencine_page(plugin, url, next_page, **kwargs):
	w = import_module('resources.lib.kedon')
	trangtiep = f'{url}page/{next_page}'
	resp = w.getlink(trangtiep, trangtiep, 7200)
	if (resp is not None):
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('div.item-container a')
		for episode in episodes:
			item = Listitem()
			anh = episode.select('img')
			ndp = episode.select('p.movie-description')
			for inf in ndp:
				noidung = inf.get_text(strip=True)
			linkphim = episode.get('href')
			for poster in anh:
				linkanh = poster.get('data-src')
			ten = episode.get('title')
			if ten:
				item.label = ten
				item.info['plot'] = f'{noidung}\n{w.tb}'
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = w.yttk(item.label)
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = linkanh
				item.set_callback(thuviencine_link, linkphim)
				yield item
		if 'resppages' in resp.text:
			item1 = Listitem()
			item1.label = f'Trang {next_page + 1}'
			item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://www.pngitem.com/pimgs/m/241-2417141_go-next-page-icon-hd-png-download.png'
			item1.set_callback(thuviencine_page, url, next_page + 1)
			yield item1
	else:
		yield w.quangcao()
@Route.register
def thuviencine_link(plugin, url, **kwargs):
	w = import_module('resources.lib.kedon')
	resp = w.getlink(url, url, 7200)
	if (resp is not None):
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('li#download-button a')
		for episode in episodes:
			linktai = episode.get('href')
			respx = w.getlink(linktai, linktai, 7200)
			web = BeautifulSoup(respx.content, 'html.parser')
			nhomlinktai = web.select('div.movie-actions a')
			for nhomlinktaix in nhomlinktai:
				item = Listitem()
				link = nhomlinktaix.get('href')
				tenx = nhomlinktaix.select('span')
				dl = nhomlinktaix.select('i')
				for ten in tenx:
					tenphim = ten.get_text(strip=True)
				for dlx in dl:
					dungluongphim = dlx.get_text(strip=True)
					tach = dungluongphim.split('|')
					dlp = tach[1]
				if 'folder' in link:
					item.label = f'{tenphim}{dlp}'
					item.info['plot'] = w.tb
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = w.yttk(item.label)
					item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={link}&qzone=1&margin=1&size=400x400&ecc=L'
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
					item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), link.split('folder/')[1], 1)
					yield item
				elif 'file' in link:
					item.label = f'{tenphim}{dlp}'
					item.info['plot'] = w.tb
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = w.yttk(item.label)
					item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={link}&qzone=1&margin=1&size=400x400&ecc=L'
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					if Addon().getSetting('taifshare') == 'true':
						item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', link)
					item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), link, item.label)
					item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
					yield item
	else:
		yield w.quangcao()