from codequick import Script, Route, Listitem, Resolver
from importlib import import_module
from concurrent.futures import ThreadPoolExecutor, as_completed
from xbmcgui import DialogProgress
from urllib.parse import quote_plus
from xbmcaddon import Addon
from json import loads
import re
def get_tkfs1(search_query):
	return import_module('resources.lib.kedon').getlinkphongblack(f'http://phongblack.me/search.php?author=phongblack&search={search_query}', 'http://www.google.com', 21600)
def get_tkfs2(search_query):
	return import_module('resources.lib.kedon').postlinktimfs(f'https://api.timfshare.com/v1/string-query-search?query={search_query}', 'https://timfshare.com/', 21600)
def get_tkfs3(search_query):
	return import_module('resources.lib.kedon').getlink(f'https://thuvienhd.com/?feed=fsharejson&search={search_query}', 'https://thuvienhd.com/', 21600)
def get_tkfs4():
	return import_module('resources.lib.kedon').getlink(f'https://thuvienhd.com/?feed=fsharejson&search=', 'https://thuvienhd.com/', 21600)
@Route.register
def searchfs(plugin, search_query, **kwargs):
	w = import_module('resources.lib.kedon')
	dp = DialogProgress()
	dp.create(w.__addonnoti__, 'Đang lấy dữ liệu...')
	search_query = quote_plus(search_query)
	with ThreadPoolExecutor(4) as ex:
		f1 = ex.submit(get_tkfs1, search_query)
		f2 = ex.submit(get_tkfs2, search_query)
		f3 = ex.submit(get_tkfs3, search_query)
		f4 = ex.submit(get_tkfs4)
	dp.update(50)
	try:
		if f3.result().content != f4.result().content:
			kqtvhd = f3.result().json()
			for dem, t in enumerate(kqtvhd):
				item = Listitem()
				item.label = t['title']
				item.info['plot'] = f'{t["title"]}\n{w.tb}'
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = w.yttk(item.label)
				item.art['thumb'] = item.art['landscape'] = t['image']
				item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item.set_callback(timnhanhfs, dem, search_query)
				yield item
	except:
		if f3.result().content != f4.result().content:
			text = f3.result().text
			data = re.sub('<(.*?)\n','',text)
			jsm = loads(data)
			for dem, t in enumerate(jsm):
				item = Listitem()
				item.label = t['title']
				item.info['plot'] = f'{t["title"]}\n{w.tb}'
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = w.yttk(item.label)
				item.art['thumb'] = item.art['landscape'] = t['image']
				item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item.set_callback(timnhanhfs, dem, search_query)
				yield item
	try:
		x = f1.result().json()['items']
		for m in x:
			item = Listitem()
			if 'info' in m:
				mota = f"{m['info']['plot']}\n{w.tb}"
			else:
				mote = w.tb
			path = m['path']
			if '/file/' in path:
				item.label = m['label']
				link = path.split('&url=')[1]
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = w.yttk(item.label)
				item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={path.split("&url=")[1]}&qzone=1&margin=1&size=400x400&ecc=L'
				item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item.info['plot'] = mota
				if Addon().getSetting('taifshare') == 'true':
					item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', link)
				item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
				item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), link, item.label)
				yield item
			elif '/folder/' in path:
				item.label = m['label']
				link = path.split("&url=")[1]
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = w.yttk(item.label)
				item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={path.split("&url=")[1]}&qzone=1&margin=1&size=400x400&ecc=L'
				item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
				item.info['plot'] = mota
				item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
				item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), link.split("folder/")[1], 1)
				yield item
	except:
		try:
			kq = f2.result().json()
			if 'data' in kq:
				for k in kq['data']:
					item = Listitem()
					if 'folder' in k['url']:
						item.label = k['name']
						item.info['plot'] = w.tb
						item.info['mediatype'] = 'episode'
						item.info['rating'] = 10.0
						item.info['trailer'] = w.yttk(item.label)
						item.art['thumb'] = item.art['landscape'] = f"https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={k['url']}&qzone=1&margin=1&size=400x400&ecc=L"
						item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
						item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', k['url'])
						item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), k['url'].split('folder/')[1], 1)
						yield item
					elif 'file' in k['url']:
						item.label = k['name']
						item.info['plot'] = w.tb
						item.info['size'] = k['size']
						item.info['mediatype'] = 'episode'
						item.info['rating'] = 10.0
						item.info['trailer'] = w.yttk(item.label)
						item.art['thumb'] = item.art['landscape'] = f"https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={k['url']}&qzone=1&margin=1&size=400x400&ecc=L"
						item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
						if Addon().getSetting('taifshare') == 'true':
							item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', k['url'])
						item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', k['url'])
						item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), k['url'], item.label)
						yield item
		except:
			pass
	dp.update(100)
	dp.close()
@Route.register
def index_pdx(plugin, **kwargs):
	w = import_module('resources.lib.kedon')
	resptvhd = get_tkfs3('')
	try:
		kqtvhd = resptvhd.json()
		for dem, t in enumerate(kqtvhd):
			item = Listitem()
			item.label = t['title']
			item.info['plot'] = f'{t["title"]}\n{w.tb}'
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = w.yttk(item.label)
			item.art['thumb'] = item.art['landscape'] = t['image']
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			item.set_callback(timnhanhfs, dem, '')
			yield item
	except:
		text = resptvhd.text
		data = re.sub('<(.*?)\n','',text)
		jsm = loads(data)
		for dem, t in enumerate(jsm):
			item = Listitem()
			item.label = t['title']
			item.info['plot'] = f'{t["title"]}\n{w.tb}'
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = w.yttk(item.label)
			item.art['thumb'] = item.art['landscape'] = t['image']
			item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
			item.set_callback(timnhanhfs, dem, '')
			yield item
@Route.register
def timnhanhfs(plugin, dem, tukhoa):
	w = import_module('resources.lib.kedon')
	try:
		kqtvhd = get_tkfs3(tukhoa).json()
	except:
		kqtvhd = loads(re.sub('<(.*?)\n', '', get_tkfs3(tukhoa).text))
	if kqtvhd[dem]['links']:
		urls = [k['link'] for k in kqtvhd[dem]['links']]
		length = len(urls)
		dialog = DialogProgress()
		dialog.create(w.__addonnoti__, 'Đang lấy dữ liệu...')
		dialog.update(5, f'Đang giải mã {length} dữ liệu...')
		with ThreadPoolExecutor(length) as ex:
			future_to_url = {ex.submit(w.get_info_fs, url): url for url in urls}
			for future in as_completed(future_to_url):
				link = future_to_url[future]
				data = future.result()
				item = Listitem()
				if 'folder' in link:
					item.label = data[0]
					item.info['plot'] = w.tb
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = w.yttk(item.label)
					item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={link}&qzone=1&margin=1&size=400x400&ecc=L'
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
					item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), link.split('folder/')[1], 1)
					yield item
				elif 'file' in link:
					item.label = data[0]
					item.info['plot'] = w.tb
					item.info['size'] = data[1]
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = w.yttk(item.label)
					item.art['thumb'] = item.art['landscape'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={link}&qzone=1&margin=1&size=400x400&ecc=L'
					item.art['fanart'] = 'https://fsharetv.com/img/fsharetv.png'
					if Addon().getSetting('taifshare') == 'true':
						item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', link)
					item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
					item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), link, item.label)
					yield item
				dialog.update(50)
		dialog.update(100)
		dialog.close()
	else:
		yield []