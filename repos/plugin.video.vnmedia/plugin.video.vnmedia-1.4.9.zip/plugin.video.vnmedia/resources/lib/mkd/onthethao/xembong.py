from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from resources.lib.kedon import getlink, ifr_xembong, quangcao
@Route.register
def index_xembong(plugin, **kwargs):
	url = 'https://xembong1.tv/'
	resp = getlink(url, url, 15*60)
	if resp is not None:
		soup = BeautifulSoup(resp.content, 'html.parser')
		episodes = soup.select('div.grid-matches__item > a.redirectPopup')
		for episode in episodes:
			item = Listitem()
			linktrandau = '%s%s' % (url, episode.get('href'))
			time = episode.select_one('div.grid-match__hour').get_text().strip()
			day = episode.select_one('div.grid-match__day').get_text().strip()
			title = episode.select_one('a').get('title')
			item.label = '%s-%s: %s' % (time, day, title)
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = '%sthemes/frontend/default/img/logo.png' % url
			item.set_callback(ifr_xembong, linktrandau, item.label)
			yield item
	else:
		yield quangcao()