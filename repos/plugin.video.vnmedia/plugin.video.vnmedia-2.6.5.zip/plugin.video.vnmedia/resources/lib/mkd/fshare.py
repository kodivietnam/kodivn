from codequick import Route, Listitem
from functools import lru_cache
@Route.register
def index_fshare(plugin, **kwargs):
	yield Listitem.search(Route.ref('/resources/lib/mkd/onfshare/timfshare:searchfs'))
	yield Listitem.from_dict(**{'label': 'LỊCH SỬ XEM',
	'info': {'plot': 'Nội dung được xem gần nhất'},
	'art': {'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/lichsu.png',
	'fanart': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/lichsu.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/ifshare:index_daxem')})
	yield makeQrPlayItem()
	yield Listitem.from_dict(**{'label': 'NHẬP CODEPLAY',
	'info': {'plot': 'Nhập MÃ CODE để phát phim'},
	'art': {'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/playcode.png',
	'fanart': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/playcode.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/codenumber:index_number')})
	yield Listitem.from_dict(**{'label': 'Fshare Favourite',
	'info':{'plot':'Yêu thích'},
	'art':{'thumb':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/yeuthich.png',
	'fanart':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/yeuthich.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/ifshare:fs_favorite')})
	yield moicapnhat()
	yield trending()
	yield phim4k()
	yield bluray()
	yield thuyetminh()
	yield longtieng()
	yield phimle()
	yield phimbo()
	yield anime()
	yield Listitem.from_dict(**{'label': 'TOP 250 IMDb',
	'info':{'plot':'Top 250 phim IMDb'},
	'art':{'thumb':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/top250.png',
	'fanart':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/top250.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/ifshare:top250')})
	yield toppopular()
	yield topchieurap()
	yield Listitem.from_dict(**{'label': 'TOP Âu Mỹ',
	'info':{'plot':'Top phim Anh ngữ'},
	'art':{'thumb':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/imdbaumy.png',
	'fanart':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/imdbaumy.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/ifshare:topaumy')})
	yield toptoday()
	yield topweek()
	yield toprated()
	yield toprevenue()
	yield Listitem.from_dict(**{'label': 'Xem gì hôm nay',
	'info': {'plot': 'Phim đề xuất'},
	'art': {'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/dexuat.png',
	'fanart': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/dexuat.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/timfshare:index_pdx')})
	yield Listitem.from_dict(**{'label': 'TÔI TỔNG HỢP',
	'info': {'plot': 'Nội dung cá nhân được tạo từ googlesheet'},
	'art': {'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/gocchiase.png',
	'fanart': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/gocchiase.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/gcs:index_gcs')})
	yield Listitem.from_dict(**{'label': 'HdVietNam',
	'info':{'plot':'Thư viện dữ liệu phim Fshare'},
	'art':{'thumb':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/thuvienhd.png',
	'fanart':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/thuvienhd.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/hdvn:index_hdvn')})
	yield Listitem.from_dict(**{'label': 'Thư viện HD',
	'info':{'plot':'Thư viện dữ liệu phim Fshare'},
	'art':{'thumb':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/tvhd.png',
	'fanart':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/tvhd.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/thuvienhd:index_thuvienhd')})
	yield Listitem.from_dict(**{'label': 'Thư viện Cine',
	'info':{'plot':'Thư viện dữ liệu phim Fshare'},
	'art':{'thumb':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/thuviencine.png',
	'fanart':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/thuviencine.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/thuviencine:index_thuviencine')})
	yield Listitem.from_dict(**{'label': 'TOP FSHARE',
	'info':{'plot':'Top 15 thư mục theo dõi nhiều nhất'},
	'art':{'thumb':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/topfshare.png',
	'fanart':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/topfshare.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/ifshare:fs_topfollow')})
@lru_cache(maxsize=None)
def makeQrPlayItem():
	item = Listitem()
	item.label = 'Mobile Play - [B][COLOR yellow]http://bit.ly/okvnm[/COLOR][/B]'
	item.info['plot'] = '[B][COLOR yellow]http://bit.ly/okvnm[/COLOR][/B][CR]Dùng điện thoại để nhập link Fshare hoặc nhập từ khóa tìm kiếm thuận tiện'
	item.path = Route.ref('/resources/lib/qrplay:qrplay')
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/qrcodeplay.png'
	item.set_callback(item.path)
	return item
@lru_cache(maxsize=None)
def moicapnhat():
	item = Listitem()
	item.label = '[COLOR yellow][B]MỚI NHẤT[/B][/COLOR]'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/moicapnhat.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_page'), 'https://thuvienhd.com/recent/page/', 1)
	return item
@lru_cache(maxsize=None)
def phim4k():
	item = Listitem()
	item.label = '4K - H265'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/4k.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_page'), 'https://thuvienhd.com/genre/4k/page/', 1)
	return item
@lru_cache(maxsize=None)
def bluray():
	item = Listitem()
	item.label = 'Bluray nguyên gốc'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/bluray.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_page'), 'https://thuvienhd.com/genre/bluray-nguyen-goc/page/', 1)
	return item
@lru_cache(maxsize=None)
def thuyetminh():
	item = Listitem()
	item.label = 'Thuyết minh'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/thuyetminh.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_page'), 'https://thuvienhd.com/genre/thuyet-minh-tieng-viet/page/', 1)
	return item
@lru_cache(maxsize=None)
def longtieng():
	item = Listitem()
	item.label = 'Lồng tiếng'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/longtieng.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_page'), 'https://thuvienhd.com/genre/long-tieng-tieng-viet/page/', 1)
	return item
@lru_cache(maxsize=None)
def anime():
	item = Listitem()
	item.label = 'Anime'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/anime.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_page'), 'https://thuvienhd.com/genre/animation/page/', 1)
	return item
@lru_cache(maxsize=None)
def phimle():
	item = Listitem()
	item.label = 'Phim lẻ'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/phimle.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_page'), 'https://thuvienhd.com/genre/phim-le/page/', 1)
	return item
@lru_cache(maxsize=None)
def phimbo():
	item = Listitem()
	item.label = 'Phim bộ'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/phimbo.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_page'), 'https://thuvienhd.com/genre/series/page/', 1)
	return item
@lru_cache(maxsize=None)
def trending():
	item = Listitem()
	item.label = '[COLOR yellow][B]TRENDING[/B][/COLOR]'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/hot.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuviencine:thuviencine_page'), 'https://thuviencine.com/top/', 1)
	return item
@lru_cache(maxsize=None)
def toptoday():
	item = Listitem()
	item.label = 'TOP VNM hôm nay'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/most_played.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:trendview'), 'day', 1)
	return item
@lru_cache(maxsize=None)
def topweek():
	item = Listitem()
	item.label = 'TOP VNM tuần này'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/most_played.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:trendview'), 'week', 1)
	return item
@lru_cache(maxsize=None)
def toprated():
	item = Listitem()
	item.label = 'VNM xếp hạng'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/top_rated.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:trendview'), 'top_rated', 1)
	return item
@lru_cache(maxsize=None)
def toprevenue():
	item = Listitem()
	item.label = 'TOP doanh thu'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/trending.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:trendview'), 'revenue', 1)
	return item
@lru_cache(maxsize=None)
def topchieurap():
	item = Listitem()
	item.label = 'TOP phòng vé'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/imdbchieurap.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:trendview'), 'now_playing', 1)
	return item
@lru_cache(maxsize=None)
def toppopular():
	item = Listitem()
	item.label = 'TOP Thịnh hành IMDb'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/imdbthinhhanh.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:trendview'), 'popular', 1)
	return item