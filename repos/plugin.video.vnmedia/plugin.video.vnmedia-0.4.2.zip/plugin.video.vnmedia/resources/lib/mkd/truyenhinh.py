from codequick import Route, Listitem, run
from resources.lib.kedon import logotv, tb
from resources.lib.mkd.ontruyenhinh.replayvtv import index_vtv
from resources.lib.mkd.ontruyenhinh.listiptv import list_iptv, list_manhkendo
from resources.lib.mkd.ontruyenhinh.quocte import listiptv_qt
CATEGORIES = {
'Truyền hình FPT': 'https://yamcode.com/raw/iptv-fptudp',
'Truyền hình FPT2': 'https://pastebin.com/raw/y8E0J0FZ',
'Truyền hình VNPT': 'https://yamcode.com/raw/iptv-mytvrtp',
'Truyền hình Viettel': 'https://raw.githubusercontent.com/TLNQChannel/iptvbytlnqchannel/main/viettel-tv.m3u',
'BotVN': 'https://raw.githubusercontent.com/iptv-org/iptv/master/channels/vn.m3u',
'BotVN2': 'https://iptv-org.github.io/iptv/languages/vie.m3u',
'BotFPTplay': 'https://raw.githubusercontent.com/iptv-org/iptv/master/channels/vn_fptplay.m3u',
'Vthanh': 'http://gg.gg/vthanhtivii',
'PhapSonyTx5': 'http://gg.gg/phaptx5iptv',
'Nguyễn Kiệt': 'http://gg.gg/kiptv2022',
'VietNgaTV': 'https://raw.githubusercontent.com/phuhdtv/vietngatv/master/vietngatv.m3u',
'Mytvbox1': 'http://gg.gg/mytvbox1'
}
CATEGORI = {
'Coocaa': 'http://thunghiem.x10.mx/televi.php?list=aHR0cDovL2dnLmdnL2Nvb2NhYQ==',
'Beartv': 'http://manhkendo.000webhostapp.com/televi.php?list=aHR0cDovL2dnLmdnL2JlYXJsaXZldHY='}
@Route.register
def listiptv_root(plugin, **kwargs):
	Xemlai = {'label': 'Xem lại truyền hình',
	'info':{'plot':tb},
	'art':{'thumb':'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg',
	'fanart':'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'},
	'callback':index_vtv}
	Quocte = {'label': 'Quốc tế',
	'info':{'plot':tb},
	'art':{'thumb':'https://banner2.cleanpng.com/20180512/que/kisspng-universal-channel-television-channel-logo-nbcunive-5af77e4bc377b8.2654559015261691638006.jpg',
	'fanart':'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'},
	'callback':listiptv_qt}
	yield Listitem.from_dict(**Xemlai)
	yield Listitem.from_dict(**Quocte)
	for tenlist, urllist in list(CATEGORIES.items()):
		item = Listitem()
		item.label = tenlist
		item.info['plot'] = tb
		item.art['thumb'] = logotv
		item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
		item.set_callback(list_iptv, url=urllist)
		yield item
	for tenlistmk, urllistmk in list(CATEGORI.items()):
		item1 = Listitem()
		item1.label = tenlistmk
		item1.info['plot'] = tb
		item1.art['thumb'] = logotv
		item1.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
		item1.set_callback(list_manhkendo, url=urllistmk)
		yield item1