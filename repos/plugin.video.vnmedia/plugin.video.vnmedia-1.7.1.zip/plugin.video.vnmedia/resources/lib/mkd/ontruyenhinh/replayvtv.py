from codequick import Route, Listitem, run
from resources.lib.mkd.ontruyenhinh.replaythvl import get_thvl, get_vtv
import datetime
kenhid = {
'VTV2': '3',
'VTV3': '4',
'VTV5': '110',
'VTV Cần Thơ': '98'}
kenhidx = {
'THVL1': 'thvl1',
'THVL2': 'thvl2',
'THVL3': 'thvl3',
'THVL4': 'thvl4'}
today = datetime.date.today()
homqua = today - datetime.timedelta(days = 1)
homkia = today - datetime.timedelta(days = 2)
@Route.register
def index_vtv(plugin, **kwargs):
	item = Listitem()
	item.label = 'Hôm nay'
	tg = str(today)
	item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
	item.set_callback(list_vtv, tg, item.label, today)
	item1 = Listitem()
	item1.label = 'Hôm qua'
	tg1 = str(homqua)
	item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
	item1.set_callback(list_vtv, tg1, item1.label, homqua)
	item2 = Listitem()
	item2.label = 'Hôm kia'
	tg2 = str(homkia)
	item2.art['thumb'] = item2.art['landscape'] = item2.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
	item2.set_callback(list_vtv, tg2, item2.label, homkia)
	yield item
	yield item1
	yield item2
@Route.register
def list_vtv(plugin, tg, ngay, hom, **kwargs):
	for tenlist, idlist in list(kenhid.items()):
		item = Listitem()
		item.label = tenlist
		item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
		item.set_callback(get_vtv, idlist, hom)
		yield item
	for tenlist1, idlist1 in list(kenhidx.items()):
		item1 = Listitem()
		item1.label = tenlist1
		item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
		item1.set_callback(get_thvl, idlist1, hom)
		yield item1