from codequick import Route, Listitem, run
from resources.lib.kedon import tb
from resources.lib.mkd.ontruyenhinh.replayvtv import index_vtv
from resources.lib.mkd.ontruyenhinh.listiptv import list_iptv
from resources.lib.mkd.ontruyenhinh.quocte import listiptv_qt
from resources.lib.mkd.ontruyenhinh.vtvgo import index_vtvgo
CATEGORIES = {
'Truyền hình FPT1': 'https://bit.ly/iptvfptlist',
'Truyền hình FPT2': 'https://raw.githubusercontent.com/thanh51/repository.thanh51/master/ONETV.m3u',
'Truyền hình FPT3': 'https://pastebin.com/raw/y8E0J0FZ',
'Truyền hình VNPT': 'https://bit.ly/iptvmytvlist',
'Truyền hình Viettel': 'https://bit.ly/iptvvietteltvlist',
'BotVN': 'https://iptv-org.github.io/iptv/languages/vie.m3u',
'VietSimpleTV': 'http://vietcago.tk/tv.m3u',
'VthanhTV': 'https://playlist.vthanhtivi.pw',
'CV Media': 'http://cvacetv.ga',
'TuBienTV': 'https://sport.tbtv.us',
'NguyenHoaiTV': 'http://hoaivnpt.duckdns.org/live-football/live-football.php',
'PhapSonyTx5': 'https://raw.githubusercontent.com/rupanh123-phap/rupanh123-phap/main/Phaptx5.mp4',
'Phu3X': 'https://user.aiiptv.click/?PHU3X',
'Nguyễn Kiệt': 'https://tinyurl.com/kip1708',
'VietNgaTV': 'https://raw.githubusercontent.com/phuhdtv/vietngatv/master/vietngatv.m3u',
'Beartv': 'https://bit.ly/beartvplay',
'Phim miễn phí': 'https://iptvvn.xyz/phimiptv'
}
@Route.register
def listiptv_root(plugin, **kwargs):
	Xemlai = {'label': 'Xem lại truyền hình',
	'info':{'plot':tb},
	'art':{'thumb':'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg',
	'fanart':'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'},
	'callback':index_vtv}
	Quocte = {'label': 'Quốc tế',
	'info':{'plot':tb},
	'art':{'thumb':'https://banner2.cleanpng.com/20180512/que/kisspng-universal-channel-television-channel-logo-nbcunive-5af77e4bc377b8.2654559015261691638006.jpg',
	'fanart':'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'},
	'callback':listiptv_qt}
	wvtvgo = {'label': r'VTVGO',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://cdn.tgdd.vn/2020/07/content/2-cach-xem-vtv-go-tren-may-tinh-don-gian-nhat-thumb-800x450.jpg',
	'fanart':'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'},
	'callback':index_vtvgo}
	yield Listitem.from_dict(**Xemlai)
	yield Listitem.from_dict(**Quocte)
	yield Listitem.from_dict(**wvtvgo)
	for tenlist, urllist in list(CATEGORIES.items()):
		item = Listitem()
		item.label = tenlist
		item.info['plot'] = tb
		item.art['thumb'] = item.art['landscape'] = 'https://i.imgur.com/Mnuw95h.png'
		item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
		item.set_callback(list_iptv, url=urllist)
		yield item