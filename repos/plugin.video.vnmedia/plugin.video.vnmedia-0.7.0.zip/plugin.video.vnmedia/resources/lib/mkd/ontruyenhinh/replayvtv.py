from codequick import Route, Listitem, run
from resources.lib.kedon import getlink, play_vtvrep
from resources.lib.mkd.ontruyenhinh.replaythvl import get_thvl
from bs4 import BeautifulSoup
import datetime
kenhid = {
'VTV1': '1',
'VTV2': '2',
'VTV3': '3',
'VTV4': '4',
'VTV5': '5',
'VTV5 Tây Nam Bộ': '7',
'VTV5 Tây Nguyên': '163',
'VTV6': '6',
'VTV7': '27',
'VTV8': '36',
'VTV9': '39',
'VTC1': '99',
'QPVN': '103',
'Vnews': '97',
'Tiền Giang': '123',
'Khánh Hoà': '125',
'Bình Dương 1': '179'}

kenhidx = {
'THVL1': 'thvl1',
'THVL2': 'thvl2',
'THVL3': 'thvl3',
'THVL4': 'thvl4'}

today = datetime.date.today()
homqua = today - datetime.timedelta(days = 1)
homkia = today - datetime.timedelta(days = 2)
@Route.register
def index_vtv(plugin, content_type='segment'):
	item = Listitem()
	item.label = 'Hôm nay'
	tg = str(today).replace('-','')
	item.art['thumb'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
	item.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
	item.set_callback(list_vtv, tg, item.label, today)
	item1 = Listitem()
	item1.label = 'Hôm qua'
	tg1 = str(homqua).replace('-','')
	item1.art['thumb'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
	item1.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
	item1.set_callback(list_vtv, tg1, item1.label, homqua)
	item2 = Listitem()
	item2.label = 'Hôm kia'
	tg2 = str(homkia).replace('-','')
	item2.art['thumb'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
	item2.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
	item2.set_callback(list_vtv, tg2, item2.label, homkia)
	yield item
	yield item1
	yield item2

@Route.register
def list_vtv(plugin, tg, ngay, hom):
	for tenlist, idlist in list(kenhid.items()):
		item = Listitem()
		item.label = tenlist
		item.art['thumb'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
		item.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
		item.set_callback(get_vtv, tg, idlist, ngay)
		yield item
	for tenlist1, idlist1 in list(kenhidx.items()):
		item1 = Listitem()
		item1.label = tenlist1
		item1.art['thumb'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
		item1.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
		item1.set_callback(get_thvl, idlist1, hom)
		yield item1

@Route.register
def get_vtv(plugin, tg, idk, ngay):
	url = 'https://vtvgo.vn/ajax-get-list-epg?selected_date_epg=' + str(tg) + '&channel_id=' + str(idk)
	resp = getlink(url, url, 15*60)
	web = BeautifulSoup(resp.text, 'html.parser')
	for k in web.select('li.select_program'):
		item = Listitem()
		idlink = k.get('data-id')
		for tgs in k.select('div.col-md-3'):
			tg = tgs.text.strip()
		for ct1s in k.select('h3'):
			ct1 = ct1s.text.strip()
		for ct2s in k.select('h4'):
			ct2 = ct2s.text
		item.label = tg + ' ' + ngay + ': ' + ct1 + ' ' + ct2
		item.art['thumb'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
		item.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
		item.set_callback(play_vtvrep, idlink, item.label)
		yield item