from codequick import Route, Listitem, run
from datetime import datetime, timedelta
from resources.lib.kedon import quangcao, getlink, stream, ace
import re, json
@Route.register
def index_streamthunder(plugin, content_type='segment'):
	url = 'https://widget.streamthunder.org/list.php?id=21&sport=&sp=&r=&l=&l2='
	resp = getlink(url, url, 15*60)
	if 'acestream' in resp.text:
		nd = re.search(r'var chan_arr = (.*?);\n', resp.text).group(1)
		m = json.loads(nd)
		for v in m:
			item = Listitem()
			match = re.search('{"id":"' + v + '(.*?)"date":"(.*?)","match":"(.*?)"', resp.text)
			tentran = match.group(3)
			tg = match.group(2)
			z = (datetime.fromisoformat(tg) + timedelta(hours=6)).strftime('%H:%M')
			for r in m[v]:
				if 'acestream' in r['link']:
					item.art['thumb'] = 'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg'
					item.art['fanart'] = 'https://imgt.taimienphi.vn/cf/Images/vi/2018/3/20/cach-xem-bong-da-tren-acestream.jpg'
					item.label = z + ' ' + tentran
					linkplay = ace(r['link'], item.label)
					item.path = linkplay
					item.set_callback(item.path)
					yield item
	else:
		yield quangcao()