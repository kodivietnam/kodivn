from requests import Session
from xbmc import executebuiltin
from xbmcaddon import Addon
from shutil import rmtree
from os.path import exists
from xbmcvfs import translatePath
from bs4 import BeautifulSoup
from concurrent.futures import ThreadPoolExecutor
def tt():
    r = Session().get('https://speedtest.vn/get-ip-info', timeout=20, headers={'user-agent': 'okhttp/4.10.0'})
    return ' '.join([c for c in reversed(r.json().values())]) if (r is not None) else 'VNNIC error'
def inf():
    r = Session().get('https://vn.search.yahoo.com/?ei=UTF-8', timeout=20, headers={'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36'})
    return BeautifulSoup(r.content, 'html.parser').select_one('div.dd.SycWeather').text if (r is not None) else 'KODI VIỆT NAM'
def autorun_addon():
    executebuiltin('UpdateAddonRepos()')
    packages_path = translatePath('special://home/addons/packages')
    if Addon().getSetting('auto_run') == 'true':
        executebuiltin('RunAddon(plugin.video.vnmedia)')
    if Addon().getSetting('auto_noti') == 'true':
        with ThreadPoolExecutor(2) as ex:
            f1 = ex.submit(tt)
            f2 = ex.submit(inf)
            a = f1.result()
            b = f2.result()
        executebuiltin(f'Notification("{b}", "{a}", 10000, {Addon().getAddonInfo("icon")})')
    if exists(packages_path):
        try:
            rmtree(packages_path)
        except:
            pass
autorun_addon()