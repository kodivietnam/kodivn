from codequick import Script
from xbmcvfs import exists
from os.path import join
from json import load
from importlib import import_module
def get_menus_settings():
    MENUS_SETTINGS_FP = join(Script.get_info('profile'), "menus_settings.json")
    if not exists(MENUS_SETTINGS_FP):
        return {}
    with open(MENUS_SETTINGS_FP) as f:
        return load(f)
def get_item_order(item_id, menu_id, item_infos):
    menus_settings = get_menus_settings()
    item_order = menus_settings.get(menu_id, {}).get(item_id, {}).get('order', None)
    if item_order is None:
        item_order = item_infos['order']
    return item_order
def get_sorted_menu(plugin, menu_id):
    V = import_module('resources.lib.skeletons.' + menu_id).menu
    menu = []
    for k in V:
        add_item = True
        if V[k]['enabled'] is False:
            add_item = False
        if add_item:
            item_order = get_item_order(k, menu_id, V[k])
            item = (item_order, k, V[k])
            menu.append(item)
    return sorted(menu, key=lambda x: x[0])