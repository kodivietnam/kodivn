from codequick import Route, Resolver, Listitem
from resources.lib.menu_utils import get_sorted_menu
from resources.lib.addon_utils import get_item_label, get_item_media_path
from xbmc import executebuiltin
from xbmcgui import getCurrentWindowId
@Route.register
def root(plugin):
    executebuiltin('UpdateAddonRepos()')
    return generic_menu(plugin, 'root')
@Route.register
def generic_menu(plugin, item_id=None, **kwargs):
    if item_id is None:
        executebuiltin(f'Action(Back,{getCurrentWindowId()})')
        yield False
    else:
        menu_id = item_id
        plugin.redirect_single_item = True
        menu = get_sorted_menu(plugin, menu_id)
        if not menu:
            yield False
        for index, (item_order, item_id, item_infos) in enumerate(menu):
            item = Listitem()
            item.label = get_item_label(item_id, item_infos)
            if 'thumb' in item_infos:
                item.art['thumb'] = get_item_media_path(item_infos['thumb'])
            if 'fanart' in item_infos:
                item.art['fanart'] = get_item_media_path(item_infos['fanart'])
            item.params['item_id'] = item_id
            if 'route' in item_infos:
                item.set_callback((Route.ref(item_infos['route'])))
            elif 'resolver' in item_infos:
                item.set_callback((Resolver.ref(item_infos['resolver'])))
            else:
                continue
            yield item