from resources.lib.kedon import getlinkvnm
from functools import lru_cache
from xbmc import executebuiltin
from xbmcaddon import Addon
from json import loads
@lru_cache(maxsize=None)
def autorun_addon():
    executebuiltin('UpdateAddonRepos()')
    if Addon().getSetting('auto_run') == 'true':
        executebuiltin('RunAddon(plugin.video.vnmedia)')
    if Addon().getSetting('auto_noti') == 'true':
        url = 'https://speedtest.vn/get-ip-info'
        r = getlinkvnm(url, url).data.decode('utf-8')
        if r:
            d = loads(r)
            a = ' '.join([c for c in reversed(d.values())])
        else:
            a = 'VNNIC error'
        executebuiltin(f'Notification("KODI VIỆT NAM", {a}, 10000, {Addon().getAddonInfo("icon")})')
    return
autorun_addon()