from codequick import Route, Listitem, run
from resources.lib.kedon import quangcao, getlink, stream, referer, play_vnm, tiengruoi
from urllib.parse import urlparse
import datetime
today = datetime.date.today()
a = urlparse(tiengruoi()[1])
vebo = '%s://%s' % (a.scheme, a.netloc)
@Route.register
def index_vebo(plugin, **kwargs):
	url1 = 'https://api.vebo.dev/match/live-v2/live'
	resp1 = getlink(url1, url1, 15*60)
	for k in resp1.json()['data']['matches']:
		item = Listitem()
		linktran = k['_id']
		gio = k['show_time']
		ngay = k['show_date']
		doikhach = k['away']['name']
		doinha = k['home']['name']
		item.label = '%s %s: %s - %s' % (gio, ngay, doinha, doikhach)
		item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = '%s/static/img/logo.png' % vebo
		item.set_callback(list_vebo, linktran, item.label)
		yield item
	tg = str(today).replace('-','')
	url2 = '%s/ajax/match/fixture/%s/1' % (vebo, tg)
	resp2 = getlink(url2, url2, 15*60)
	for k in resp2.json()['data'][0]:
		for m in k['matches']:
			item2 = Listitem()
			linktran = m['_id']
			tentran = m['name']
			gio = m['show_time']
			ngay = m['show_date']
			item2.label = '%s %s: %s' % (gio, ngay, tentran)
			item2.art['thumb'] = item2.art['landscape'] = item2.art['fanart'] = '%s/static/img/logo.png' % vebo
			item2.set_callback(list_vebo, linktran, item2.label)
			yield item2
@Route.register
def list_vebo(plugin, idtran, title, **kwargs):
	url = '%s/ajax/match/detail/%s/detail' % (vebo, idtran)
	resp = getlink(url, url, 5*60)
	if 'm3u8' in resp.text:
		for k in resp.json()['play_urls']:
			item = Listitem()
			linktran = '%s%s' % (stream(k['url'].replace('\t','')), referer('%s/' % vebo))
			item.label = '%s %s' % (k['name'], title)
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = '%s/static/img/logo.png' % vebo
			item.set_callback(play_vnm, linktran, item.label, '')
			yield item
	else:
		yield quangcao()