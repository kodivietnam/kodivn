from codequick import Route, Listitem, run
from datetime import datetime, timedelta
from bs4 import BeautifulSoup
from urllib.parse import urlparse
from resources.lib.kedon import quangcao, getlink, postlink, stream, referer, play_vnm, tb, rakhoi
l = rakhoi()[0]
m = urlparse(l)
url = '%s://%s/' % (m.scheme, m.netloc)
@Route.register
def index_rakhoi(plugin, **kwargs):
	urlx = 'https://xem.rakhoi.tv/get-tran-dau-sap-dien-ra/6198ac0ccedadf08cbba36df.html'
	resp = postlink(urlx, urlx, 6*60)
	if 'm3u8' in resp.text:
		kq = resp.json()
		for k1 in kq['data']['lives']:
			for k2 in k1['hlsUrls']:
				item1 = Listitem()
				if 'm3u8' in k2['url']:
					time1 = (datetime.fromisoformat(k1['time'][:-1]) + timedelta(hours=7)).strftime('%H:%M %d-%m')
					linktrandau1 = '%s%s' % (stream(k2['url']), referer(url))
					item1.label = '%s-%s: %s-%s' % (k2['name'], time1, k1['teamA']['name'], k1['teamB']['name'])
					item1.info['plot'] = tb
					item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://rakhoi-tv.com/wp-content/uploads/2021/12/rakhoiTVremake.png'
					item1.set_callback(play_vnm, linktrandau1, item1.label, '')
					yield item1		
	else:
		yield quangcao()