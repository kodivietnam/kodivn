from codequick import Route, Listitem, run, Script
@Route.register
def index_vtvgo(plugin, **kwargs):
	from resources.lib.kedon import tb, getlink, play_vnm, stream, referer, quangcao
	url = 'https://api.vtvgiaitri.vn/api/v3/channel'
	r = getlink(url, 'https://vtvgiaitri.vn', 900)
	if r is not None:
		m = r.json()['data']
		for k in m:
			item = Listitem()
			linkkenh = k['url']
			linktrandau = f'{stream(linkkenh)}{referer("https://vtvgiaitri.vn")}'
			anh = k['mobile_logo']
			item.label = k['name']
			item.info['plot'] = tb
			item.art['thumb'] = item.art['landscape'] = anh
			item.art['fanart'] = 'https://is3-ssl.mzstatic.com/image/thumb/Purple126/v4/b2/97/48/b2974814-bc6e-3d59-8ea3-86ace210b426/AppIcon-0-0-1x_U007emarketing-0-0-0-7-0-0-sRGB-0-0-0-GLES2_U002c0-512MB-85-220-0-0.png/1200x600wa.png'
			item.set_callback(play_vnm, linktrandau, item.label, '')
			yield item
	else:
		yield quangcao()