from codequick import Route, Listitem, run
from bs4 import BeautifulSoup
from resources.lib.kedon import getlink, ifr_bongda, cauthu, quangcao
from urllib.parse import urlparse
from datetime import datetime
import re, os
#l = cauthu()[0]
#m = urlparse(l)
#linkweb = '%s://%s' % (m.scheme, m.netloc)
linkweb = 'https://cauthu.tv'
now = datetime.now()
timestamp = datetime.timestamp(now)
@Route.register
def index_cauthu(plugin, **kwargs):
	url = '%s/ajax/schedule-data?filter=live&%s' % (linkweb, timestamp)
	r = getlink(url,url, 15*60)
	if 'match-link' in r.text:
		soup = BeautifulSoup(r.content, 'html.parser')
		episodes = soup.select('div.grid-matches__item')
		for episode in episodes:
			item = Listitem()
			linktran = episode.select_one('a.match-link').get('href')
			thoigian = episode.select_one('span.t_time.time').get_text()
			doinha = episode.select_one('div.team.team-home').get_text().strip()
			doikhach = episode.select_one('div.team.team-away').get_text().strip()
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = '%s/wp-content/uploads/2022/06/cauthu_tv_logo.png' % linkweb
			item.label = '%s: %s vs %s' % (thoigian, doinha, doikhach)
			item.set_callback(ifr_bongda, linktran, item.label)
			yield item
	else:
		yield quangcao()