from codequick import Route, Listitem, run
from datetime import datetime, timedelta
from bs4 import BeautifulSoup
from urllib.parse import urlparse
from resources.lib.kedon import quangcao, getlink, stream, referer, play_vnm, tb, rakhoi
l = rakhoi()[0]
m = urlparse(l)
url = '%s://%s/' % (m.scheme, m.netloc)
@Route.register
def index_rakhoi(plugin, **kwargs):
	ux = '%snode-cache/get-lives-home' % url
	resp = getlink(ux, ux, 6*60)
	if '.m3u8' in resp.text:
		kq = resp.json()
		for m in kq['data'].values():
			for k in m:
				time = (datetime.fromisoformat(k['time'][:-1]) + timedelta(hours=7)).strftime('%H:%M %d-%m')
				doi1 = k['teamA']['name']
				doi2 = k['teamB']['name']
				blv1 = k['commentator']
				blv2 = k['commentatorCaHeo']
				for d in k['hlsUrls']:
					if 'm3u8' in d['url']:
						item1 = Listitem()
						tentrandau1 = '%s-%s: %s-%s' % (d['name'], time, doi1, doi2)
						linktrandau1 = '%s%s' % (stream(d['url']), referer(url))
						if blv1:
							item1.label = '%s - BLV: %s' % (tentrandau1, blv1)
						else:
							item1.label = tentrandau1
						item1.art['thumb'] = item1.art['landscape'] = item1.art['fanart'] = 'https://i.imgur.com/8tEAlqc.png'
						item1.set_callback(play_vnm, linktrandau1, item1.label, '')
						yield item1
				if 'hlsUrlsCaHeo' in k:
					for e in k['hlsUrlsCaHeo']:
						if 'm3u8' in e['url']:
							item2 = Listitem()
							tentrandau2 = '%s-%s: %s-%s' % (e['name'], time, doi1, doi2)
							linktrandau2 = '%s%s' % (stream(e['url']), referer(url))
							if blv2:
								item2.label = '%s - BLV: %s' % (tentrandau2, blv2)
							else:
								item2.label = tentrandau2
							item2.art['thumb'] = item2.art['landscape'] = item2.art['fanart'] = 'https://i.imgur.com/KdSuVMn.png'
							item2.set_callback(play_vnm, linktrandau2, item2.label, '')
							yield item2
	else:
		yield quangcao()