from codequick import Route, Listitem, run
from resources.lib.kedon import logotv, tb
from resources.lib.mkd.ontruyenhinh.replayvtv import index_vtv
from resources.lib.mkd.ontruyenhinh.listiptv import list_iptv, list_manhkendo
from resources.lib.mkd.ontruyenhinh.quocte import listiptv_qt
from resources.lib.mkd.ontruyenhinh.vtvgo import index_vtvgo
CATEGORIES = {
'Truyền hình FPT1': 'https://bit.ly/iptvfptlist',
'Truyền hình FPT2': 'https://raw.githubusercontent.com/thanh51/repository.thanh51/master/ONETV.m3u',
'Truyền hình FPT3': 'https://pastebin.com/raw/y8E0J0FZ',
'Truyền hình VNPT': 'https://bit.ly/iptvmytvlist',
'Truyền hình Viettel': 'https://bit.ly/iptvvietteltvlist',
'BotVN': 'https://iptv-org.github.io/iptv/languages/vie.m3u',
'Vthanh': 'https://s.id/tivi',
'PhapSonyTx5': 'https://raw.githubusercontent.com/rupanh123-phap/rupanh123-phap/main/Phaptx5.mp4',
'Nguyễn Kiệt': 'https://tinyurl.com/kip1708',
'VietNgaTV': 'https://raw.githubusercontent.com/phuhdtv/vietngatv/master/vietngatv.m3u',
'Coocaa1': 'https://s.id/iptv',
'Beartv1': 'https://s.id/bearlivetv',
'TuBienTV': 'https://s.id/tbientv'
}
CATEGORI = {
'Coocaa': 'https://mi3s.top/televi.php?list=aHR0cHM6Ly9zLmlkL2lwdHY=',
'Beartv': 'https://mi3s.top/televi.php?list=aHR0cHM6Ly9zLmlkL2JlYXJsaXZldHY='}
@Route.register
def listiptv_root(plugin, **kwargs):
	Xemlai = {'label': 'Xem lại truyền hình',
	'info':{'plot':tb},
	'art':{'thumb':'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg',
	'fanart':'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'},
	'callback':index_vtv}
	Quocte = {'label': 'Quốc tế',
	'info':{'plot':tb},
	'art':{'thumb':'https://banner2.cleanpng.com/20180512/que/kisspng-universal-channel-television-channel-logo-nbcunive-5af77e4bc377b8.2654559015261691638006.jpg',
	'fanart':'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'},
	'callback':listiptv_qt}
	wvtvgo = {'label': r'VTVGO',
	'info':{'plot':tb}, 
	'art':{'thumb':'https://is3-ssl.mzstatic.com/image/thumb/Purple126/v4/b2/97/48/b2974814-bc6e-3d59-8ea3-86ace210b426/AppIcon-0-0-1x_U007emarketing-0-0-0-7-0-0-sRGB-0-0-0-GLES2_U002c0-512MB-85-220-0-0.png/1200x600wa.png',
	'fanart':'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'},
	'callback':index_vtvgo}
	yield Listitem.from_dict(**Xemlai)
	yield Listitem.from_dict(**Quocte)
	yield Listitem.from_dict(**wvtvgo)
	for tenlist, urllist in list(CATEGORIES.items()):
		item = Listitem()
		item.label = tenlist
		item.info['plot'] = tb
		item.art['thumb'] = item.art['landscape'] = logotv
		item.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
		item.set_callback(list_iptv, url=urllist)
		yield item
	for tenlistmk, urllistmk in list(CATEGORI.items()):
		item1 = Listitem()
		item1.label = tenlistmk
		item1.info['plot'] = tb
		item1.art['thumb'] = item1.art['landscape'] = logotv
		item1.art['fanart'] = 'https://images-na.ssl-images-amazon.com/images/I/41cpao5TRpL.png'
		item1.set_callback(list_manhkendo, url=urllistmk)
		yield item1