# -*- coding: utf-8 -*-
import utils.xbmc_helper as helper
from animehay.parser.category import Parser as Category
from animehay.parser.channel import Parser as Channel
from animehay.parser.movie import Parser as Movie
from utils.mozie_request import Request
from six.moves.urllib.parse import quote_plus
import json
try:
    from cloudscraper2 import CloudScraper
except:
    import cloudscraper as CloudScraper


class Animehay:
    domain = "https://animehay.club"
    domain2 = 'https://animehay.pro'

    def __init__(self):
        self.username = helper.getSetting('animehay.username')
        self.password = helper.getSetting('animehay.password')
        self.request = Request(session=True)
        self.request = CloudScraper.create_scraper(browser={
            'browser': 'firefox',
            'platform': 'windows',
            'mobile': True
        }, allow_brotli=False)
        self.login()

    def login(self, redirect=None):
        params = {
            'email': self.username,
            'password': self.password,
            'action_login': "submit"
        }
        response = self.request.post('%s/dang-nhap?ref=/' % self.domain, params)
        return response

    def getCategory(self):
        response = self.request.get(self.domain)
        return Category().get(response.content), Channel().get(response.content, 1)

    def getChannel(self, channel, page=1):
        channel = channel.replace(self.domain, "")
        if page > 1:
            if channel == '/':
                url = '%s%s/trang-%d.html' % (self.domain, '/phim-moi-cap-nhap', page)
            else:
                url = '%s%s/trang-%d.html' % (self.domain, channel.replace(".html", ""), page)
        else:
            url = '%s%s' % (self.domain, channel)
        response = self.request.get(url)
        return Channel().get(response.content, page)

    def getMovie(self, mid):
        url = Movie().get_movie_link(self.request.get(mid).content)
        response = self.request.get(url)
        return Movie().get(response.content)

    def getLink(self, movie):
        response = self.request.get(movie['link'])
        return Movie().get_link(response.content, movie['link'])

    def search(self, text):
        params = {"action":"live_search","keyword":text}
        response = self.request.post('%s/api' % self.domain, json=params)
        r = json.loads(response.text)
        return Channel().search(r['result'])
