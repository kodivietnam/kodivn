# -*- coding: utf-8 -*-
import json
import re

import utils.xbmc_helper as helper
from bs4 import BeautifulSoup
from kodi_six.utils import py2_encode
from utils.mozie_request import Request

try:
    from urlparse import urlparse, parse_qs
except ImportError:
    from urllib.parse import urlparse, parse_qs


def from_char_code(*args):
    return ''.join(map(chr, args))


class Parser:
    def get_movie_link(self, response):
        soup = BeautifulSoup(response, "html.parser")
        return soup.select_one('div.info-movie div.flex.ah-frame-bg div.flex.flex-1 a.button-default').get('href')

    def get(self, response, skipEps=False):
        movie = {
            'group': {},
            'episode': [],
            'links': [],
        }
        soup = BeautifulSoup(response, "html.parser")
        # get all server list
        servers = soup.select("div.list-item-episode.scroll-bar")
        for server in servers:
            server_name = 'ANIMEHAY'
            if server_name not in movie['group']: movie['group'][server_name] = []
            for ep in server.select('a'):
                movie['group'][server_name].append({
                    'link': py2_encode(ep.get('href')),
                    'title': '%s' % py2_encode(ep.get('title'))
                })
        return movie

    def get_link(self, response, originUrl):
        movie = {
            'group': {},
            'episode': [],
            'links': [],
        }
        soup = BeautifulSoup(response, "html.parser")
        links = Parser.extract_link(soup)
        for link in links:
            movie['links'].append({
                'link': link[0],
                'title': 'Link %s' % link[1],
                'type': link[1],
                'originUrl': originUrl,
                'resolve': False
            })
        return movie
    
    @staticmethod
    def extract_link(response, args=None):
        links = []
        T = (helper.findstring(str(response), "$info_play_video = ", "var $list_sv")).replace('\\', '').replace('JSON.parse("','').replace('")','')
        m = re.search(r"source:\s?(\[.*?\])", T)
        m2 = re.search(r"source_fbo:\s?(\[.*?\])", T)
        if m is not None:
            sources = m.group(1)
            valid_json = re.sub(r'(?<={|,)\s?([a-zA-Z][a-zA-Z0-9]*)(?=:)', r'"\1"', sources)
            valid_json = valid_json.replace(',]', ']')
            sources = json.loads(valid_json)
            if len(sources) > 0:
                for s in sources:
                    source = (s['file'], s['label'])
                    links.append(source)
        if m2 is not None:
            sources = m2.group(1)
            valid_json = re.sub(r'(?<={|,)\s?([a-zA-Z][a-zA-Z0-9]*)(?=:)', r'"\1"', sources)
            valid_json = valid_json.replace(',]', ']')
            sources = json.loads(valid_json)
            if len(sources) > 0:
                for s in sources:
                    print(s)
                    source = (s['file'], 'FBO')
                    links.append(source)
        return links
