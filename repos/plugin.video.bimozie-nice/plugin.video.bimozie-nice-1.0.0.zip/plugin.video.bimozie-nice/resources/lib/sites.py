# -*- coding: utf-8 -*-

SITES = [
  {
    "name": "THỂ THAO - SPORT",
    "logo": "https://ec.europa.eu/eurostat/documents/6921402/9104237/Shutterstock_Lisa_Kolbasa.png/f988f8b6-4138-4a91-9761-885bacab0ce2?t=1533725002000",
    "version": 1,
    "searchable": False,
    "sites": [
      {
        "name": "90p.live",
        "logo": "https://i.imgur.com/jyM3inb.png",
        "className": "Phut90",
        "plugin": "phut90.plugin",
        "version": 1,
        "searchable": False
      },
      {
        "name": "thuckhuya.live",
        "logo": "https://thuckhuya.live/wp-content/themes/itfs/assets/images/thuckhuya-logo.png",
        "className": "Thuckhuya",
        "plugin": "thuckhuya.plugin",
        "version": 1,
        "searchable": False
      }
    ]
  },
  {
    "name": "TV ONLINE",
    "logo": "https://tvonline.bg/wp-content/themes/Design3/images/logo.jpg",
    "version": 1,
    "searchable": False,
    "sites": [
      {
        "name": "Xemtivimienphi.com",
        "logo": "https://tvonline.bg/wp-content/themes/Design3/images/logo.jpg",
        "className": "TVOnline",
        "plugin": "tvonline.plugin",
        "version": 1,
        "searchable": False
      },
      {
        "name": "TVmienphi.tv",
        "logo": "https://tvonline.bg/wp-content/themes/Design3/images/logo.jpg",
        "className": "TVMienphi",
        "plugin": "tvmienphi.plugin",
        "version": 1,
        "searchable": False
      }
    ]
  },
  {
    "name": "PHIM - MOVIES",
    "logo": "https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/summer-movies-1587392939.jpg",
    "version": 1,
    "searchable": True,
    "sites": [
      {
        "name": "fmovies.to",
        "logo": "https://i.ibb.co/JzZDxGM/image.png",
        "className": "fmovies",
        "plugin": "fmovies.plugin",
        "version": 31
      },
      {
        "name": "hayghex.net",
        "logo": "https://hayghes.com/favicon.png",
        "className": "Hayghes",
        "plugin": "hayghes.plugin",
        "version": 1
      },
      {
        "name": "fptplay.vn",
        "logo": "https://fptplay.vn/images/logo.png",
        "className": "Fptplay",
        "plugin": "fptplay.plugin",
        "version": 1
      },
      {
        "name": "vkool.tv",
        "logo": "https://i.ibb.co/TcWtgB5/rsz-image.png",
        "className": "Vkool",
        "plugin": "vkool.plugin",
        "version": 1
      },
      {
        "name": "fim1080.com",
        "logo": "https://fim1080.com/assets/img/phim1080.png",
        "className": "Fimfast",
        "plugin": "fimfast.plugin",
        "version": 1
      },
      {
        "name": "biluu.org",
        "logo": "https://biluu.org/Theme/images/logo-bilutv-bold.png",
        "className": "Bilutv",
        "plugin": "bilutv.plugin",
        "version": 1
      },
      {
        "name": "phimdinhcao.com",
        "logo": "https://www.phimdinhcao.com/templates/themes/phim/images/phimmedia-s.png",
        "className": "Phimmedia",
        "plugin": "phimmedia.plugin",
        "version": 1
      },
      {
        "name": "bphimmoi.net",
        "logo": "https://bphimmoi.net/wp-content/uploads/2021/08/logo.png",
        "className": "Phimmoi",
        "plugin": "phimmoi.plugin",
        "version": 1
      },
      {
        "name": "biphim.co",
        "logo": "https://i.ibb.co/tBKrQtK/image.png",
        "className": "Hphim",
        "plugin": "hphim.plugin",
        "version": 1
      },
      {
        "name": "tvhai.org",
        "logo": "https://i.ibb.co/WyMTx2c/image.png",
        "className": "Tvhay",
        "plugin": "tvhay.plugin",
        "version": 1
      },
      {
        "name": "vphimmoi.tv",
        "logo": "https://i2.wp.com/vuviphimx.com/wp-content/uploads/2021/08/vuviphimx.png",
        "className": "Vuviphim",
        "plugin": "vuviphim.plugin",
        "version": 1
      },
      {
        "name": "phimgi.org",
        "logo": "https://xemphimgi.net/wp-content/uploads/phim-gi-logo-01-625x136.png",
        "className": "Phimgi",
        "plugin": "phimgi.plugin",
        "version": 31
      },
	  {
        "name": "xemphimgii.net",
        "logo": "https://xemphimgi.net/wp-content/uploads/phim-gi-logo-01-625x136.png",
        "className": "Phimgi",
        "plugin": "phimgi.plugin",
        "version": 31
      },
      {
        "name": "dongphim.net",
        "logo": "http://media.dongphim.net/media/image/id/5c921766acc399d72c8b456b_200x",
        "className": "Dongphim",
        "plugin": "dongphim.plugin",
        "version": 1
      },
      {
        "name": "phim7z.tv",
        "logo": "https://phim7z.tv/wp-content/themes/khophim/assets/images/logo-dark.png",
        "className": "Phim7z",
        "plugin": "phim7z.plugin",
        "version": 31
      },
      {
        "name": "motphjm.net",
        "logo": "https://motphjm.net/motphim.png",
        "className": "Motphim",
        "plugin": "motphim.plugin",
        "version": 1
      }
    ]
  },
  {
    "name": "HOẠT HÌNH - ANIME",
    "logo": "https://upload.wikimedia.org/wikipedia/commons/d/de/Anime_Tv_Channel.jpg",
    "version": 1,
    "searchable": True,
    "sites": [
      {
        "name": "animehay.tv",
        "logo": "https://animehay.club/themes/img/logo.png",
        "className": "Animehay",
        "plugin": "animehay.plugin",
        "version": 1
      },
      {
        "name": "anime47.com",
        "logo": "https://i.ibb.co/swSHyV0/image.png",
        "className": "anime47",
        "plugin": "anime47.plugin",
        "version": 31
      },
      {
        "name": "hhhkungfu.tv",
        "logo": "https://1.bp.blogspot.com/-H3dUNhId3b8/XnYlJNnNc1I/AAAAAAAAAyk/D7y03lFi2gcb-Rde0Kh5O12NVpRBSsNLgCLcBGAsYHQ/s1600/Logo.png",
        "className": "hhkungfu",
        "plugin": "hhkungfu.plugin",
        "version": 1
      }
    ]
  },
  {
    "name": "FSHARE",
    "logo": "https://add.pics/images/2020/09/26/fshare-logo-170720206b70eaba4ed2526d.png",
    "version": 1,
    "searchable": True,
    "sites": [
      {
        "name": "My Fshare favorite",
        "logo": "https://add.pics/images/2020/09/26/fshare-logo-170720206b70eaba4ed2526d.png",
        "className": "FShare",
        "plugin": "fshare.plugin",
        "version": 1,
        "searchable": False
      },
      {
        "name": "hdvietnam.com (beta)",
        "logo": "http://www.hdvietnam.com/images/hd-vietnam-logo.png",
        "className": "Hdvietnam",
        "plugin": "hdvietnam.plugin",
        "version": 1
      },
      {
        "name": "fcine.net",
        "logo": "https://fcine.net/uploads/monthly_2019_07/FCINE-LOGO.png.6e9c546f90ccb1b61c0502769b3fe1e8.png",
        "className": "Fcine",
        "plugin": "fcine.plugin",
        "version": 1
      }
    ]
  }
]
